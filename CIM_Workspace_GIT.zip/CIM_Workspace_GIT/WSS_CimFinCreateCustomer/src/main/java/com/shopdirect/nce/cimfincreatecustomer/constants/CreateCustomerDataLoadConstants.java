package com.shopdirect.nce.cimfincreatecustomer.constants;

public interface CreateCustomerDataLoadConstants {
	
	
	String SERVICE_NAME = "cim";

	// do not remove or rename the AUDITLOG_ entries
	// used in the WSW audit log handler code
	// configuration file type
	String LOAD_FINANCIERDATA_CONFIGURATION_FILE_KEY="financierFileLoadConfig";
	String AUDITLOG_CONFIGURATION_TYPE = "propertiesConfigClassName";
	// key matching entry in master configuration for configuration file
	// filename
	String AUDITLOG_CONFIGURATION_FILE_KEY = "serviceConfiguration";
	//File Name of external Client
	String EXTERNAL_CONFIGURATION_FILE_KEY = "externalClientConfig";
	//File Name of  database configuration
	String DATABASE_CONFIGURATION_FILE_KEY = "cimDbConfig";
	//File Name of data conmfig
	String DATA_CONFIGURATION_FILE_KEY = "dataConfig";

	String AUDITLOG_REQUEST = "auditLogRequest";
	String AUDITLOG_REQUEST_MASK = "auditLogRequestMask";
	String AUDITLOG_REQUEST_MASK_FIELDS = "auditLogRequestMaskFields";

	String AUDITLOG_RESPONSE = "auditLogResponse";
	String AUDITLOG_RESPONSE_MASK = "auditLogResponseMask";
	String AUDITLOG_RESPONSE_MASK_FIELDS = "auditLogResponseMaskFields";

	// All DB Schema Key Name
	String DB_SCHEMA_CIM_STG_KEY= "DB_SCHEMA_CIM_STG";
	String DB_SCHEMA_MAIN_CIM_KEY = "DB_SCHEMA_CIM";
	 
	// Empty String
	
	String EMPTY_STRING = "";
	
	int DEFAULT_INT_VAL = 0;
	
	/// Config Error Code 
	String SERVICE_EXCEPTION="1000";
	String FILE_CONFIG_ERROR_CODE="1001";
	
	
	String GENERIC_WEBSERVICE_TRANSFPORMATION_ERROR_CODE="2000";
	String GENERIC_BUSINESS_ERROR_CODE="3000";
	String FINANCIER_BUSINESS_ERROR_CODE="3010";
	
	
	//DB ERROR CODE 
	String CONNECTTION_DB_ERROR_CODE = "5000";
	String GENERIC_DB_ERROR_CODE = "5001";

	//DB Configuration
	String CIM_DB_CONFIG = "cimDbConfig";
	
	//INT1171 Update Customer Account
	String CREATECUSTOMER_ENDPOINT_URL = "CREATECUSTOMER_ENDPOINT_URL";
	String CREATECUSTOMER_EXTERNAL_SERVICE_NAME="CREATECUSTOMER_EXTERNAL_SERVICE_NAME";
	String CREATECUSTOMER_SERVICE_WSDL_PATH="CREATECUSTOMER_SERVICE_WSDL_PATH";
	String CREATECUSTOMER_SERVICE_NAMESPACE_URI="CREATECUSTOMER_SERVICE_NAMESPACE_URI";
	
	String BUSINESS_FAILURE = "1";
	String FAILURE_STATUS_CODE = "2";
	String FAILURE_MESSAGE = "Failed";
	
	// CREDIT DATA LOAD
	String CIM_OUTBOUND_DATA_MAPPING = "CimOutboundDataMapping";
	String CIM_OUTBOUND_MAP = "CustomerDetailsMap";

	String RUN_STATUS_NOT_STARTED = "NOT STARTED";
	String RUN_STATUS_FAILED = "FAILED";
	String RUN_STATUS_SUCCESS = "SUCCESS";
	
	int HEADER_RECORD = 1;
	String FINANCIER_DATA_LOAD_PROCESS_NAME = "CreditDataLoad";
	
	
}
