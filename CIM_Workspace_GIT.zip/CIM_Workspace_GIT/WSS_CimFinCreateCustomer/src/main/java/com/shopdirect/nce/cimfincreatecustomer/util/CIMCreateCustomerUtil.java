package com.shopdirect.nce.cimfincreatecustomer.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Map;
import java.util.TimeZone;
import java.util.UUID;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;


/**
 * This is main Utility class for the PPC service 
 * @author ibm
 *
 */
public class CIMCreateCustomerUtil {
	
	private static SDLoggerImpl logger = new SDLoggerImpl();
	
	/**
	 * Default private constructor
	 */
	private CIMCreateCustomerUtil(){
		
	}
	
	/**
	 * Convert String to Integer.
	 * @param temp
	 * @return
	 * @throws Exception
	 */
	public static int convertToInteger(String temp) {
		return Integer.parseInt(temp);
	}
	/**
	 * Validate Object null or blank
	 * @param temp (String
	 * @return boolean
	 */
	public static boolean  isNullOrEmpty(String temp) {
		return temp == null || StatementProcessorBatchConstants.EMPTY_STRING.equals(temp.trim());
	}
	/**
	 * Validate null object
	 * @param temp
	 * @return boolean
	 */
	public static boolean  isNullOrEmpty(Object temp) {
		return temp == null;
	}
	/**
	 * Validate null of Integer
	 * @param temp
	 * @return
	 */
	public static boolean isNullOrEmpty(int temp) {
		return temp == StatementProcessorBatchConstants.DEFAULT_INT_VAL;
	}
	/**
	 * Genarate UUID
	 * @return String
	 */
	public static String generateUUIDString(){
		return  UUID.randomUUID().toString();
	}
	

	
	
	/**
	 * @return the logger
	 */
	public static SDLoggerImpl getLogger() {
		return logger;
	}


	/**
	 * Create Default Correlation ID
	 * @param correlationID
	 * @return String
	 */
	public static String getCorrelationID(String correlationID){
		if(isNullOrEmpty(correlationID)){
			return generateUUIDString();
		}
		return correlationID;
	}

	/**
	 * Pull the Stack trace of JVM Throwable.
	 * @param originException 
	 * @return String
	 */
	public static String getprintStackTraceString(Throwable originException){
		String errorString = null;
		if(originException != null){
			StringWriter errors = new StringWriter();
			originException.printStackTrace(new PrintWriter(errors));
			errorString = errors.toString(); 
			getLogger().error(errorString);
			if(errorString.length() > 1000){
				errorString = errorString.substring(0, 1000);
			}
		}
		return errorString;
	}

	/**
	 * This method print the Exception details  in Error log
	 * @param exception
	 */
	public static void printExceptionInformation(Exception exception){
		if(exception != null){
			StringWriter errors = new StringWriter();
			exception.printStackTrace(new PrintWriter(errors));
			getLogger().error("The error message :: " + errors.toString());
		}else{
			getLogger().error("Receive Empty Exception object");
		}
	}
	
	/**
	 * 
	 * @return Schema
	 * @throws Exception
	 */
	public static String getSchema() throws StatementProcessorBatchException {
		CommonConfigHelper configHelper = CommonConfigHelper.getInstance();
		return configHelper.loadPropertyConfig(StatementProcessorBatchConstants.SP_DB_CONFIG)
				.getConfigData("DB_SCHEMA_SP");
	}
	/**
	 * Build a Proper Error Detail for generation.
	 * @param stEx
	 * @return string
	 */
	public static String getExceptionDetails(StatementProcessorBatchException stEx) {
		try {
			StringBuilder sb = new StringBuilder();
			sb.append("[ErrorCode : ").append(stEx.getErrorCode()).append("]")
			.append("[Error Description :").append(stEx.getErrorDesc()).append("]")
			.append("[Method Location : ").append(stEx.getMethodDetail()).append("]")
			.append("[Stack Trace : ").append(CIMCreateCustomerUtil.getprintStackTraceString(stEx.getCause())).append("]");
			return sb.toString();
		} catch (Exception e) {
			getLogger().error("[StatementProcessorBatchUtil-getExceptionDetails]-- runtime exception generated: " + e);
		}

		return null;
	}

	/*
	 * utility method to convert java.util.Date to XMLGregorianCalendar
	 */
	public static XMLGregorianCalendar getDate(java.util.Date inputDate) throws DatatypeConfigurationException {
		if (inputDate == null) {
			return null;
		}
		GregorianCalendar cal = new GregorianCalendar();
		cal.setTime(inputDate);
		return DatatypeFactory.newInstance().newXMLGregorianCalendar(cal);
	}

	public static java.sql.Date getSqlDate(java.util.Date inputDate) {
		return new java.sql.Date(inputDate.getTime());
	}	
	
	/**
	 * This method parses the string into Double by catching any exceptions safely and returns the result accordingly.
	 * @param str
	 * @return
	 */
	public static double parseDoubleSafely(String str) {
	    double result = 0;
	    try {
	        result = Double.parseDouble(str);
	    } catch (NumberFormatException nfe) {
	    	logger.error("[StatementProcessorBatchUtil -- parseDoubleSafely] -- NumberFormatException: " + nfe.getMessage());
	    }
	    return result;
	}
	
	/**
	 * This method parses the String date field safely and returns the result accordingly.
	 * @param str
	 * @return Date
	 */
	public static Date parseDateSafely(String str) {
		Date result = null;
		SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
	    
	    	if(str != null && !str.isEmpty()){
	    		try {
					return formatter.parse(str);
				} catch (ParseException pe) {
					logger.error("[StatementProcessorBatchUtil -- parseDateSafely] -- ParseException: " + pe.getMessage());
				}
	    	}
	        
	     
	    return result;
	}
	
	
	public static String getFinancierFilePath(){
		String filePath = null;
		  Map<String, String> env = System.getenv();
	        for (String envName : env.keySet()) {
		 if("FINANCIER_FILES_PATH".equals(envName)){
	           filePath= env.get(envName);
		   }
	        }
	        
	       return filePath;
	}

	/**
	 * 
	 * @param fileName
	 * @param status
	 * @param batchRunDate
	 * @return
	 */
	public static String generateFileName(String fileName,String status, String batchRunDate){
		String underScore = "_";
		StringBuilder sb = new StringBuilder();
		sb.append(batchRunDate);
		if(fileName != null){
			sb.append(underScore);
			sb.append(fileName);
		}
		if( status != null) {
			sb.append(underScore);
			sb.append(status);
		}
		return sb.toString();
	}
	
	/**
	 * @param file
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	public static void processFile(File file) throws IOException {
		FileReader  reader = new FileReader(file);
		BufferedReader buf = new BufferedReader(reader);
		
		boolean endOfFile = false ;
		StringBuilder sb = new StringBuilder();
		
		while(!endOfFile){
			String str = buf.readLine();
			if(str != null  && str.trim().length() > 1 ){
				
					sb.append(str);	
					endOfFile  = false;
					
			}else{
				endOfFile  = true;
			}
			
			if(!endOfFile){
				sb.append("\n");
			}
			
		}
		buf.close();
		FileWriter writer = new FileWriter(file);
		BufferedWriter bufWritter = new BufferedWriter(writer);
		String updateString = sb.toString();
		updateString = updateString.substring(0, updateString.length()-1);
		bufWritter.write(updateString);
		bufWritter.close();
	}

	
	
	public static String generatePrimaryKey(){
		return  UUID.randomUUID().toString();
	}
	
	public static Date getCurrentDate() throws ParseException{
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		String formatDate = simpleDateFormat.format(new Date(System.currentTimeMillis()));
    	return simpleDateFormat.parse(formatDate);
	}
	
	public static XMLGregorianCalendar getUTCDate() throws DatatypeConfigurationException {
		TimeZone timeZone= TimeZone.getTimeZone("CET");
		
		GregorianCalendar gc = new GregorianCalendar();
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		df.setTimeZone(timeZone);
		return DatatypeFactory.newInstance().newXMLGregorianCalendar(gc);
	}
	
	public static java.sql.Date getDbSQLDate() {
		java.util.Date today = new java.util.Date();
		return new java.sql.Date(today.getTime());
	}
	
	public static XMLGregorianCalendar getOnlyDate(java.util.Date inputDate) throws DatatypeConfigurationException {
		GregorianCalendar cal = new GregorianCalendar();
		cal.setTime(inputDate);
		XMLGregorianCalendar xmlDate = DatatypeFactory.newInstance().newXMLGregorianCalendar(cal);
		xmlDate.setTime(DatatypeConstants.FIELD_UNDEFINED, DatatypeConstants.FIELD_UNDEFINED,
				DatatypeConstants.FIELD_UNDEFINED, DatatypeConstants.FIELD_UNDEFINED);
		xmlDate.setTimezone(DatatypeConstants.FIELD_UNDEFINED);
		return xmlDate;
	}
	
	public static java.sql.Date convertSqlDate(Object date) {
		java.sql.Date sqlDate = null;
		if (date == null) {
			return null;
		}
		try {
			String strDate = date.toString();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
			java.util.Date utilDate = sdf.parse(strDate);
			sqlDate = new java.sql.Date(utilDate.getTime());
		} catch (ParseException px) {
			px.printStackTrace();
		}
		return sqlDate;
	}
	
	public static java.sql.Date convertJavaDateToSqlDate(Date date) {
		java.sql.Date sqlDate = null;
		if (date == null) {
			return null;
		}
		sqlDate = new java.sql.Date(date.getTime());
		return sqlDate;
	}
}
