/**
 * 
 */
package com.shopdirect.nce.cimfincreatecustomer.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Arrays;

import com.shopdirect.nce.cimfincreatecustomer.constants.CreateCustomerDataLoadConstants;
import com.shopdirect.nce.cimfincreatecustomer.constants.Query;
import com.shopdirect.nce.cimfincreatecustomer.exception.CimCreateCustomerException;
import com.shopdirect.nce.cimfincreatecustomer.util.CommonConfigHelper;
import com.shopdirect.nce.cimfincreatecustomer.util.CIMCreateCustomerUtil;
import com.shopdirect.nce.cimfincreatecustomer.util.UCPConnection;

/**
 * @author MeghnaBhattacharya
 *
 */
public class CustomerDetailFileLoadDaoImpl extends CIMBaseDao  {
	
	boolean isLoadSuccess = false;
	Connection connection = null;
	int retCode = 0;
	String retMsg = null;
	CallableStatement callStmt = null;
	private static SDLoggerImpl logger = new SDLoggerImpl();
	Object[] procReturnVal = new Object[2];
	String errMsg = null;

	/**
	 * 
	 */
	public CustomerDetailFileLoadDaoImpl() throws CimCreateCustomerException  {
		super();
	}

	public Object[] loadCustonerDetailsData() {
		logger.debug("[CustomerDetailFileLoadDaoImpl -- loadCustonerDetailsData]  -- START");
		
		String isLoadSuccessMessege = null;
		CommonConfigHelper commonConfigHelper = CommonConfigHelper.getInstance();
		ExternalFileDataConfiguration Dbconfig = commonConfigHelper.loadPropertyConfig("cimDbConfig");
		
		String PACK_ACC_DISASSOCIATE_EXTERNAL = commonConfigHelper.readConfigData(Dbconfig, "PACK_ACC_DISASSOCIATE_EXTERNAL");
		String PRC_LOAD_CUSTOMER_STG_EXT = commonConfigHelper.readConfigData(Dbconfig, "PRC_LOAD_CUSTOMER_STG_EXT");
		
		setSpMainSchema(getSchema(CreateCustomerDataLoadConstants.DB_SCHEMA_CIM_STG_KEY));

		try {
			connection = UCPConnection.getConnection();
			String callQueryStr = Query.getLoadCustomerDataQuery(PACK_ACC_DISASSOCIATE_EXTERNAL, PRC_LOAD_CUSTOMER_STG_EXT);
			callStmt = connection.prepareCall(callQueryStr);
			callStmt.executeUpdate();

			retCode = callStmt.getInt(3);
			retMsg = callStmt.getString(4);
			ARRAY outArray = (ARRAY) callStmt.getArray(2);
			Object[] outList = (Object[]) outArray.getArray();
			
			if (retCode == 0) {
				isLoadSuccess = true;
			} else {

				logger.debug("Load Customer Data Exception errMsg=========" + errMsg);
				isLoadSuccess = false;
				throw new CimCreateCustomerException(CreateCustomerDataLoadConstants.GENERIC_BUSINESS_ERROR_CODE,
						"[CustomerDetailFileLoadDaoImpl - loadCustonerDetailsData] CimCreateCustomerException Block",
						"Database Failed Insertion execution exception " + errMsg, null, null,
						new CimCreateCustomerException());
			}
			
			isLoadSuccessMessege = retMsg;
			procReturnVal[0]= retCode;
			procReturnVal[1]= retMsg;
			
			logger.debug("isLoadSuccess=======" + isLoadSuccess);
			logger.debug("[CustomerDetailFileLoadDaoImpl -- loadCustonerDetailsData]  -- END");

		} catch (SQLException sqlException) {
			isLoadSuccess = false;
			isLoadSuccessMessege = sqlException.getMessage();
			logger.error("Load Customer Data SQLException Exception =======" + isLoadSuccessMessege);
			throw new CimCreateCustomerException(CreateCustomerDataLoadConstants.GENERIC_DB_ERROR_CODE,
					"[CustomerDetailFileLoadDaoImpl - loadCustonerDetailsData] SQLException Block",
					"Database execution exception [SQLCode: " + sqlException.getSQLState() + "] , SQL Detail "
							+ sqlException.getMessage(),
					null, null, sqlException);

		} catch (Exception exception) {
			isLoadSuccess = false;
			isLoadSuccessMessege = exception.getMessage();
			logger.error("Load Customer Data Exception =======" + isLoadSuccessMessege);
			throw new CimCreateCustomerException(CreateCustomerDataLoadConstants.CONNECTTION_DB_ERROR_CODE,
					"[CustomerDetailFileLoadDaoImpl - loadCustonerDetailsData] Exception Block",
					"Database execution exception " + exception.getMessage(), null, null, exception);
		} finally {

			try {

				/**
				 * UPDATE the CONTROL TABLE PROVIDING IF INSERT IN AGREEMENT
				 * TABLE IS SUCCESS OR FAILURE
				 */

				if (callStmt != null) {
					callStmt.close();
				}

				if (connection != null) {
					connection.close();
				}

			} catch (Exception e) {
				logger.error("[CustomerDetailFileLoadDaoImpl - loadCustonerDetailsData]  -- Exception Block, Database execution exception "+e.getMessage());					
			}
		}

		return procReturnVal;
	}

}
