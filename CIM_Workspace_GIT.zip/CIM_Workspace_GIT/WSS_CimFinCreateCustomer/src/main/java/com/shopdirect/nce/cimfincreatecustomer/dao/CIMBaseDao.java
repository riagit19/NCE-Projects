/**
 * 
 */
package com.shopdirect.nce.cimfincreatecustomer.dao;

import java.sql.Connection;
import java.sql.SQLException;

import com.shopdirect.nce.cimfincreatecustomer.constants.CreateCustomerDataLoadConstants;
import com.shopdirect.nce.cimfincreatecustomer.exception.CimCreateCustomerException;
import com.shopdirect.nce.common.extcnfg.ExternalFileDataConfiguration;
import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.util.CommonConfigHelper;
import com.shopdirect.nce.sp.util.UCPConnection;

/**
 * @author amitkumar4
 *
 */
public class CIMBaseDao {

	private static SDLoggerImpl logger = new SDLoggerImpl();
	
	private CommonConfigHelper commonConfigHelper = null;
	private ExternalFileDataConfiguration extFileDataBaseCfg = null;
	private String stgSchema;
	private String spMainSchema;
	/**
	 * 
	 */
	public CIMBaseDao() throws CimCreateCustomerException {
		setCommonConfigHelper(CommonConfigHelper.getInstance());
	}
	/**
	 * 
	 * @throws StatementProcessorBatchException
	 */
	protected String getSchema(String schemaName) throws CimCreateCustomerException {
		ExternalFileDataConfiguration extconfig = getCommonConfigHelper().loadPropertyConfig(CreateCustomerDataLoadConstants.DATABASE_CONFIGURATION_FILE_KEY);
		return getCommonConfigHelper().readConfigData(extconfig, schemaName);
		
	}
	/**
	 * @return the commonConfigHelper
	 */
	public CommonConfigHelper getCommonConfigHelper() {
		return commonConfigHelper;
	}
	/**
	 * @param commonConfigHelper the commonConfigHelper to set
	 */
	public void setCommonConfigHelper(CommonConfigHelper commonConfigHelper) {
		this.commonConfigHelper = commonConfigHelper;
	}
	
	

	/**
	 * @return the stgSchema
	 */
	public String getStgSchema() {
		return stgSchema;
	}
	/**
	 * @param stgSchema the stgSchema to set
	 */
	public void setStgSchema(String stgSchema) {
		this.stgSchema = stgSchema;
	}
	/**
	 * @return the spMainSchema
	 */
	public String getSpMainSchema() {
		return spMainSchema;
	}
	/**
	 * @param spMainSchema the spMainSchema to set
	 */
	public void setSpMainSchema(String spMainSchema) {
		this.spMainSchema = spMainSchema;
	}
	/**
	 * @return the logger
	 */
	public SDLoggerImpl getLogger() {
		return logger;
	}
	
	/**
	 * @return the Connection object
	 */	
	public static Connection getCon() throws StatementProcessorBatchException, SQLException {
		return UCPConnection.getConnection();
	}
	
	

}
