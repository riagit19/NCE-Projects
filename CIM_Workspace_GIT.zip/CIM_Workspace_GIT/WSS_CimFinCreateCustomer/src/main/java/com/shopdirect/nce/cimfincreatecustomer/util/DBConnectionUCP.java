package com.shopdirect.nce.sp.util;

import java.sql.Connection;
import java.sql.SQLException;

import com.shopdirect.nce.common.extcnfg.ExternalFileDataConfiguration;
import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;

import oracle.ucp.UniversalConnectionPoolAdapter;
import oracle.ucp.UniversalConnectionPoolException;
import oracle.ucp.admin.UniversalConnectionPoolManager;
import oracle.ucp.admin.UniversalConnectionPoolManagerImpl;
import oracle.ucp.jdbc.PoolDataSource;
import oracle.ucp.jdbc.PoolDataSourceFactory;

public class DBConnectionUCP {

	static final SDLoggerImpl LOGGER = new SDLoggerImpl();
	private static final String DEFAULT_POOLNAME = "UCP-pool";
	private static DBConnectionUCP dbConnectionUCP = null;
	private static PoolDataSource pds;

	private static String connectionFactory = "oracle.jdbc.pool.OracleDataSource";
	private static String url = "DB_URL";
	private static String user = "DB_USER";
	private static String passKey = "DB_PASSWORD";
	private static Integer minPoolSize = 2;
	private static Integer maxPoolSize = 10;
	private static Integer initialPoolSize = 5;
	private static UniversalConnectionPoolManager mgr = null;

	private DBConnectionUCP() {

	}

	public static DBConnectionUCP getInstance() throws StatementProcessorBatchException {
		if (dbConnectionUCP == null) {
			LOGGER.debug("[DBConnectionUCP -- getInstance] -- Start");
			dbConnectionUCP = new DBConnectionUCP();
			pds = getPoolDataSource();
			LOGGER.debug("[DBConnectionUCP -- getInstance] -- End");
		}
		return dbConnectionUCP;
	}

	private static PoolDataSource getPoolDataSource() throws StatementProcessorBatchException {
		try {
			LOGGER.debug("[DBConnectionUCP -- getPoolDataSource] -- Start");
			mgr = UniversalConnectionPoolManagerImpl.getUniversalConnectionPoolManager();
			if (mgr != null && pds == null) {
					getDatabaseResoucePool();
					cretaeConnectionPool();
					startConnectionPool();
			}
		} catch (UniversalConnectionPoolException ucpException) {
			LOGGER.error("[DBConnectionUCP -- getPoolDataSource] -- Exception: " + ucpException);
		}
		LOGGER.debug("[DBConnectionUCP -- getPoolDataSource] -- End");
		return pds;
	}

	private static PoolDataSource getDatabaseResoucePool() throws StatementProcessorBatchException {
		try {
			LOGGER.debug("[DBConnectionUCP -- getDatabaseResoucePool] -- Start");
			pds = PoolDataSourceFactory.getPoolDataSource();

			CommonConfigHelper commonConfigHelper = CommonConfigHelper.getInstance();
			ExternalFileDataConfiguration dbconfig = commonConfigHelper.loadPropertyConfig("spDbConfig");

			pds.setConnectionFactoryClassName(connectionFactory);
			pds.setURL(commonConfigHelper.readConfigData(dbconfig, url));
			pds.setUser(commonConfigHelper.readConfigData(dbconfig, user));
			pds.setPassword(commonConfigHelper.readConfigData(dbconfig, passKey));
			pds.setConnectionPoolName(DEFAULT_POOLNAME);
			pds.setMinPoolSize(minPoolSize);
			pds.setMaxPoolSize(maxPoolSize);
			pds.setInitialPoolSize(initialPoolSize);
			pds.setInactiveConnectionTimeout(60);

			LOGGER.debug("[DBConnectionUCP -- getDatabaseResoucePool] -- Pool Data Source Borrowed Connection Count: " + pds.getBorrowedConnectionsCount());
		} catch (SQLException sqlException) {
			LOGGER.debug("[DBConnectionUCP -- getDatabaseResoucePool] -- SQL Exception: " + sqlException);
		} catch (NullPointerException npe) {
			LOGGER.debug("[DBConnectionUCP -- getDatabaseResoucePool] --  Null Pointer Exception: " + npe);
		}
		LOGGER.debug("[DBConnectionUCP -- getDatabaseResoucePool] -- End");
		return pds;
	}

	private static void cretaeConnectionPool() throws UniversalConnectionPoolException {
		LOGGER.debug("[DBConnectionUCP -- cretaeConnectionPool] -- Start");
		mgr.createConnectionPool((UniversalConnectionPoolAdapter) pds);
		LOGGER.debug("[DBConnectionUCP -- cretaeConnectionPool] -- End");
	}

	private static void startConnectionPool() throws UniversalConnectionPoolException {
		LOGGER.debug("[DBConnectionUCP -- startConnectionPool] -- Start");
		mgr.startConnectionPool(DEFAULT_POOLNAME);
		LOGGER.debug("[DBConnectionUCP -- startConnectionPool] -- End");
	}
	
	public Connection getConnection() throws SQLException {
		return pds.getConnection();
	}

	public void destroyConnectionPool() throws SQLException {
		try {
			Connection con = pds.getConnection();
			con.close();
			mgr.destroyConnectionPool(DEFAULT_POOLNAME);
			verifyConnectionDestroy();
		} catch (UniversalConnectionPoolException poolException) {
			LOGGER.debug("[DBConnectionUCP -- destroyConnectionPool] -- UniversalConnectionPoolException: " + poolException);
		}
	}

	private void verifyConnectionDestroy() {
		try {
			pds.getConnection();
		} catch (Exception e) {
			LOGGER.debug("[DBConnectionUCP -- destroyConnectionPool] -- Exception: " + e);
		}
	}
}
