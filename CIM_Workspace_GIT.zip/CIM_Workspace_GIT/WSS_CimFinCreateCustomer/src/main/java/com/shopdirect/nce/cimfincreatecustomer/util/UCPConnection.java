package com.shopdirect.nce.cimfincreatecustomer.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import com.shopdirect.nce.cimfincreatecustomer.constants.CreateCustomerDataLoadConstants;
import com.shopdirect.nce.cimfincreatecustomer.exception.CimCreateCustomerException;
import com.shopdirect.nce.common.extcnfg.ExternalFileDataConfiguration;
import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;

import oracle.ucp.jdbc.PoolDataSource;

/**
 * 
 * @author SudiptaRoy
 * 
 *         Get the Universal Connection Pool configured in WebLogic
 */
public class UCPConnection {

	private static final SDLoggerImpl LOGGER = new SDLoggerImpl();

	private UCPConnection() {
		// Private Constructor
	}

	public static Connection getConnection() throws CimCreateCustomerException {
		LOGGER.debug("[UCPConnection -- getConnection] -- Start");
		Connection connection = null;
		Context ctx;
		CommonConfigHelper commonConfigHelper = CommonConfigHelper.getInstance();
		ExternalFileDataConfiguration dbconfig = commonConfigHelper.loadPropertyConfig("spDbConfig");
		final String dataSource = commonConfigHelper.readConfigData(dbconfig, "UCP_DS");
		try {
			ctx = new InitialContext();
			PoolDataSource pds = (PoolDataSource) ctx.lookup(dataSource);
			connection = pds.getConnection();
		} catch (NamingException | SQLException ex) {
			LOGGER.error("[UCPConnection -- getConnection] -- Exception while fetching UCP: " + ex);
			throw new CimCreateCustomerException(CreateCustomerDataLoadConstants.CONNECTTION_DB_ERROR_CODE, ex.getMessage(), ex);
		}
		LOGGER.debug("[UCPConnection -- getConnection] -- End");
		return connection;
	}
}
