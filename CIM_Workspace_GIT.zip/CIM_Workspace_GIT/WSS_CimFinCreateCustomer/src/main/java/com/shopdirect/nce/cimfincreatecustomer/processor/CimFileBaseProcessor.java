package com.shopdirect.nce.cimfincreatecustomer.processor;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.shopdirect.nce.cimfincreatecustomer.constants.CimCreateCustomerConstants;
import com.shopdirect.nce.cimfincreatecustomer.constants.CreateCustomerDataLoadConstants;
import com.shopdirect.nce.cimfincreatecustomer.exception.CimCreateCustomerException;
import com.shopdirect.nce.common.extcnfg.ExternalFileDataConfiguration;
import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.dao.SPErrorLogDaoImpl;
import com.shopdirect.nce.sp.model.SpErrorLog;

public class CimFileBaseProcessor implements DataFileProcessor{
	
	private static final String EMPTY_QUOTES = "\"\"";
	private static final String COLUMN_NAME = "ColumnName";
	private static final String DATE_TYPE = "java.util.Date";
	private static final String STRING_TYPE = "java.lang.String";
	private static final String DOUBLE_TYPE = "java.lang.Double";
	private static final String INTEGER_TYPE = "java.lang.Integer";
	private static final String LONG_TYPE = "java.lang.Long";
	private static final String TIMESTAMP_TYPE = "java.sql.Timestamp";
	private static final String SEQUENCE = "Sequence";
	private static final String DATA_TYPE = "DataType";
	Map<String, Double> statMap = new HashMap<>();
	Integer logTraceId = 0;
	boolean isValid = false;	
	private static SDLoggerImpl logger = new SDLoggerImpl();
	private CommonConfigHelper commonConfigHelper = null;
	String financierFilePath = null;
	private ExternalFileDataConfiguration extFileDataCfg = null;
	int batchInsertcount;
	private ExternalFileDataConfiguration dataconfig;
	private String batchRunDate;
	
	/**
	 * @throws CimCreateCustomerException
	 */
	public CimFileBaseProcessor() throws CimCreateCustomerException {
		setCommonConfigHelper(CommonConfigHelper.getInstance());
		initExternalConfig();
	}	
	
	/**
	 * @return the dataconfig
	 */
	public ExternalFileDataConfiguration getDataconfig() {
		return dataconfig;
	}

	/**
	 * @param dataconfig the dataconfig to set
	 */
	public void setDataconfig(ExternalFileDataConfiguration dataconfig) {
		this.dataconfig = dataconfig;
	}
	
	public ExternalFileDataConfiguration getExtFileDataCfg() {
		return extFileDataCfg;
	}

	public void setExtFileDataCfg(ExternalFileDataConfiguration extFileDataCfg) {
		this.extFileDataCfg = extFileDataCfg;
	}

	protected void initExternalConfig() throws CimCreateCustomerException {
		logger.debug("[FinFileBaseProcessor -- initExternalConfig]  -- START");

		this.extFileDataCfg = getCommonConfigHelper()
				.loadPropertyConfig(CreateCustomerDataLoadConstants.LOAD_FINANCIERDATA_CONFIGURATION_FILE_KEY);
		this.setFinancierFilePath(
				commonConfigHelper.readConfigData(getExtFileDataCfg(), CimCreateCustomerConstants.FINANCIER_FILES_PATH));
		
		this.dataconfig = getCommonConfigHelper().loadPropertyConfig("dataConfig");

		logger.debug("[FinFileBaseProcessor -- initExternalConfig]  -- END");
	}

	public String getFinancierFilePath() {
		getLogger().debug("FinFileBaseProcessor getFinancierFilePath START" + financierFilePath);
		return financierFilePath;
	}

	public void setFinancierFilePath(String financierFilePath) {
		this.financierFilePath = financierFilePath;
	}

	public static SDLoggerImpl getLogger() {
		return logger;
	}

	public static void setLogger(SDLoggerImpl logger) {
		CimFileBaseProcessor.logger = logger;
	}

	public CommonConfigHelper getCommonConfigHelper() {
		return commonConfigHelper;
	}

	public void setCommonConfigHelper(CommonConfigHelper commonConfigHelper) {
		this.commonConfigHelper = commonConfigHelper;
	}

	
	/**
	 * @return
	 * @throws CimCreateCustomerException
	 */
	@SuppressWarnings("unchecked")
	protected List<Map<String, Object>> getColumns(String mappingFile, String rootNode)
			throws CimCreateCustomerException {
		ExternalFileDataConfiguration extConf = getCommonConfigHelper().loadXmlConfig(mappingFile);
		@SuppressWarnings("unchecked")
		Map<String, Object> objectMap = extConf.getXmlDataStructure(rootNode);
		return (List<Map<String, Object>>) objectMap.get(COLUMN_NAME);
	}

	/**
	 * @param contents
	 * @param columns
	 * @param instance
	 * @throws NoSuchMethodException
	 * @throws IllegalAccessException
	 * @throws InvocationTargetException
	 * @throws ParseException
	 */
	protected void constructObjects(String[] contents, List<Map<String, Object>> columns, Object instance)
			throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, ParseException, Exception {
		for (Map<String, Object> column : columns) {

			String setterMethodName = getSetterMethodName(column);

			int index = Integer.parseInt(column.get(SEQUENCE).toString());
			String content = contents[index];
			if (isValidContent(content)) {
				content = content.trim();
				try {
					if (STRING_TYPE.equals(column.get(DATA_TYPE).toString())) {
						String value = content.replaceAll("^\"|\"$", "");
						Method method = instance.getClass().getMethod(setterMethodName, String.class);
						method.invoke(instance, value);
					} else if (DOUBLE_TYPE.equals(column.get(DATA_TYPE).toString())) {
						Double value = Double.parseDouble(content);
						Method method = instance.getClass().getMethod(setterMethodName, Double.class);
						method.invoke(instance, value);
					} else if (DATE_TYPE.equals(column.get(DATA_TYPE).toString())) {
						setDate(instance, setterMethodName, content);
					} else if (INTEGER_TYPE.equals(column.get(DATA_TYPE).toString())) {
						Integer value = Integer.parseInt(content);
						Method method = instance.getClass().getMethod(setterMethodName, Integer.class);
						method.invoke(instance, value);
					}else if (LONG_TYPE.equals(column.get(DATA_TYPE).toString())) {
						Long value = Long.parseLong(content);
						Method method = instance.getClass().getMethod(setterMethodName, Long.class);
						method.invoke(instance, value);			
					}else if (TIMESTAMP_TYPE.equals(column.get(DATA_TYPE).toString())) {
						Date date = CIMCreateCustomerUtil.parseDateSafely(content);
						Timestamp value = new Timestamp(date.getTime());
						Method method = instance.getClass().getMethod(setterMethodName, Timestamp.class);
						method.invoke(instance, value);
					}else if ("primitive-double".equals(column.get(DATA_TYPE).toString())) {
						double value = Double.parseDouble(content);
						Method method = instance.getClass().getMethod(setterMethodName, double.class);
						method.invoke(instance, value);
					}
				} catch (Exception e) {
					String msg = "Setter: " + setterMethodName + " Value:" + content;
					getLogger().error("[FinFileBaseProcessor -- constructObjects] -- Exception: " + msg); 
					throw new Exception(e.getMessage() + "- ID is -" + contents[0]);
				}
			}
		}
	}

	/**
	 * @param instance
	 * @param setterMethodName
	 * @param content
	 * @throws NoSuchMethodException
	 * @throws IllegalAccessException
	 * @throws InvocationTargetException
	 */
	protected void setDate(Object instance, String setterMethodName, String content)
			throws NoSuchMethodException, IllegalAccessException, InvocationTargetException {
		Date value = CIMCreateCustomerUtil.parseDateSafely(content);
		if ("setCreatedDateTime".equalsIgnoreCase(setterMethodName)) {
			value = new Date();
		}
		Method method = instance.getClass().getMethod(setterMethodName, Date.class);
		method.invoke(instance, value);
	}

	/**
	 * @param content
	 * @return
	 */
	protected boolean isValidContent(String content) {
		return content != null && !content.isEmpty() && !content.equals(EMPTY_QUOTES);
	}

	/**
	 * @param column
	 * @return
	 */
	protected String getSetterMethodName(Map<String, Object> column) {
		String attribute = column.get("ClassAttributeName").toString();
		String setterMethodName = attribute.substring(0, 1).toUpperCase();
		setterMethodName = setterMethodName + attribute.substring(1, attribute.length());
		setterMethodName = "set" + setterMethodName;
		return setterMethodName;
	}

	protected boolean validateDate(String dateToValidate) {
		String dateFromat = "yyyyMMdd";
		boolean result;
		SimpleDateFormat sdf = new SimpleDateFormat(dateFromat);
		sdf.setLenient(false);
		if (dateToValidate == null) {
			return false;
		}
		try {
			/**
			 * If date is not Valid
			 * then it will throw 
			 * ParseException
			 */
			sdf.parse(dateToValidate);
			result = true;
		} catch (ParseException e) {
			logger.error("ParseException = " + e);
			return false;
		} catch (Exception e) {
			logger.error("Generic Exception = " + e);
			return false;
		}

		return result;

	}

	/**
	 * @param file
	 * @return
	 */
	protected boolean isNewFile(File file) {
		return file != null && file.isFile() && file.getName() != null && file.getName().contains(CimCreateCustomerConstants.NEW_STATUS);
	}

	/**
	 * This method gives the total count of records for a given file.
	 * 
	 * @param fileName
	 * @return totalRecordsCount
	 */
	protected int getRecordsCount(String fileName) throws IOException {

		LineNumberReader lnr;

		lnr = new LineNumberReader(new FileReader(new File(fileName)));
		lnr.skip(Long.MAX_VALUE);
		int totalRecordsCount = lnr.getLineNumber() + 1; // index starts with 0.
		lnr.close(); // Finally, the LineNumberReader object should be closed to
						// prevent resource leak

		return totalRecordsCount;
	}


	protected void insertErrorLog(String errorCode, String errorDesc, String executionStat, String programName,
			String stepNumber, String statusMsg, String stepStatus) throws Exception {
		SpErrorLog spErrLog = new SpErrorLog();
		spErrLog.setErrCode(errorCode);
		spErrLog.setErrDesc(errorDesc);
		spErrLog.setExeStat(executionStat);
		spErrLog.setProgramName(programName);
		spErrLog.setStartDate(new Timestamp(System.currentTimeMillis()));
		spErrLog.setStepNumber(stepNumber);
		spErrLog.setStatusMsg(statusMsg);
		spErrLog.setStepDesc(CimCreateCustomerConstants.STEP_DESCRIPTION);
		spErrLog.setStepStatus(stepStatus);
		spErrLog.setEndDate(new Timestamp(System.currentTimeMillis()));

		SPErrorLogDaoImpl spErrorLogDao = new SPErrorLogDaoImpl();
		spErrorLogDao.insertErrorLogData(spErrLog);

	}

	
	
	protected String setBatchRunDate(String batchRunDt) {
		if(batchRunDt != null && !batchRunDt.isEmpty() && batchRunDt.length() == 10) {
			batchRunDate = batchRunDt.replaceAll("-", "");
		}
		return batchRunDate;
	}	
}
