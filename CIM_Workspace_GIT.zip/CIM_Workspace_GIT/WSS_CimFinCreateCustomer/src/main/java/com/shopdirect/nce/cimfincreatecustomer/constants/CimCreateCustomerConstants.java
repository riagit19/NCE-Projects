package com.shopdirect.nce.cimfincreatecustomer.constants;




/**
 * This class contains all the static constant values used in the application.
 * @author ibm
 *
 */
public class CimCreateCustomerConstants {
	
	public static final String FINANCIER_FILES_PATH  = "cim.outbound.files.path";
	
	public static final String PROCESSED_STATUS = "SUCCESS";
	public static final String NEW_STATUS = "New";
	public static final String FAILED_STATUS = "Failed";
	public static final String CIM_CUSTOMER_DETAILS_INPUT = "CIM_CUSTOMER_DETAILS_INPUT";

	//error code for financier file load
	public static final String MISMATCH_ON_RECORD_COUNT= "mismatch.on.record.count";
	public static final String MISMATCH_RECORD_COUNT_STATUS_MESSAGE="mismatch.recordcount.status.message";
	public static final String STEP_DESCRIPTION = "Load Financial Statement Data into SP Staging";
	public static final String PROGRAMNAME = "Financier Data Load";
	public static final String STEPNUMBER = "1";
	public static final String STEPSTATUS="ERROR";
	public static final String FILENOTFOUNDERRORCODE = "2";
	public static final String FILENOTFOUNDERRORDESC = "No such file found with this batch run date.";
	public static final String MISMATCH_ON_COLUMN_COUNT="Number of column is mismatch, please reverify your file.";
	
	private CimCreateCustomerConstants() {
		//Private Constructor of Constant Class
	}
}
