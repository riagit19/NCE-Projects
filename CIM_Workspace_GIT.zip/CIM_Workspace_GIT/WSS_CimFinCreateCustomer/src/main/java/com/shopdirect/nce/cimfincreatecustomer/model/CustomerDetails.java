package com.shopdirect.nce.cimfincreatecustomer.model;

public class CustomerDetails {

}
