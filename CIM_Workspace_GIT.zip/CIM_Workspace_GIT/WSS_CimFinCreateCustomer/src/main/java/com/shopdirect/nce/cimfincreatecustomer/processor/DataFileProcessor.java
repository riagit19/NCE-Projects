package com.shopdirect.nce.cimfincreatecustomer.processor;
import java.io.File;
import java.lang.reflect.InvocationTargetException;
import java.text.ParseException;
import java.util.List;
import java.util.Map;

import com.shopdirect.nce.cimfincreatecustomer.exception.CimCreateCustomerException;



/**
 * @author AyantikaBiswas
 *
 */
public interface DataFileProcessor {
	
	public static boolean processFile(File folder, long batchID, int user) throws CimCreateCustomerException{
		return false;}	
	
	public static boolean isValidFile(File file) {
		return false;
	}
	
	/**
	 * @return
	 * @throws CimCreateCustomerExceptions
	 */
	static List<Map<String, Object>> getColumns(String mappingFile, String rootNode){
		return null;
	}

	public static void constructObjects(String[] contents, List<Map<String, Object>> columns, Object instance)
			throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, ParseException {}



	/**
	 * @param content
	 * @return
	 */
	public static boolean isValidContent(String content) {
		return false;}


	public static boolean isValidFileName() {
		return false;}

	public static boolean validateDate(String dateToValidate) {
		return false;}
	

}
