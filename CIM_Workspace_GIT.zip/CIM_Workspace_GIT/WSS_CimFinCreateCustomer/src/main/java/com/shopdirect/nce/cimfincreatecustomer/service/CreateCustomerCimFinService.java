package com.shopdirect.nce.cimfincreatecustomer.service;

import com.shopdirect.nce.cimfincreatecustomer.business.CustomerDetailFileLoadProcessorImpl;
import com.shopdirect.nce.cimfincreatecustomer.exception.CimCreateCustomerException;

public class CreateCustomerCimFinService {

	public CreateCustomerCimFinService() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		
		try {
			CustomerDetailFileLoadProcessorImpl businessImpl = new CustomerDetailFileLoadProcessorImpl();
			
			boolean loadDetails = businessImpl.loadCustomerDetails();
			
			System.out.println("----- Load Customer Details in Staging table ------" + loadDetails);
			
		} catch (CimCreateCustomerException e) {
			System.out.println("----- Load Customer Details ***** Exception Messege **** ------" + e.getMessage());
			System.out.println("----- Load Customer Details ***** Exception **** ------" + e);
			e.printStackTrace();
		}

	}

}
