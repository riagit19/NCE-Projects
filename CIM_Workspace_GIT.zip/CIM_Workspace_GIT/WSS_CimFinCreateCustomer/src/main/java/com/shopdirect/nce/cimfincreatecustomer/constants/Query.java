package com.shopdirect.nce.cimfincreatecustomer.constants;

import java.sql.Timestamp;

import com.shopdirect.nce.sp.model.CustomerAccountInfo;
import com.shopdirect.nce.sp.util.StatementProcessorBatchUtil;

/**
 * @author VijayaprakashPrathip
 *
 */
/**
 * @author VijayaprakashPrathip
 *
 */
public class Query {
	
	private Query() {
		// Private Constructor
	}

	
	public static String getLoadCustomerDataQuery(String packageName, String procName){

		StringBuilder loadCustomerData = new StringBuilder();
		
		loadCustomerData.append("{call ");
		loadCustomerData.append(packageName).append(".");
		loadCustomerData.append(procName);
		loadCustomerData.append("()}");
		
		return loadCustomerData.toString();
		}

	
	/**
	 * the getCustrAccountDetailsJMSMsgQuery
	 * @param CustID
	 * @return
	 */
	public static StringBuilder getCustrAccountDetailsJMSMsgQuery(String spMainSchema){
		
		StringBuilder strCustAccountInfo = new StringBuilder();
		strCustAccountInfo.append( " SELECT  CIM_ACCOUNT_INFO_ID ,PUBLIC_ACCOUNT_NUMBER,CREDIT_ACCOUNT_NUMBER, ");
		strCustAccountInfo.append( " RETAIL_ACCOUNT_NUMBER, LINKED_ACCOUNT_IND, STATEMENT_DATE, ");
		strCustAccountInfo.append( " PAYMENT_DUE_DATE, PENDING_PDD, STMT_OFFSET_DAYS_FRM_PDD, ");
		strCustAccountInfo.append( " BRAND_CODE, BRAND_TYPE, SPECIAL_ATTENTION_CODE, ");
		strCustAccountInfo.append( " LATE_ARREARS_IND, CREDIT_RISK_FACTOR, TITLE ,");
		strCustAccountInfo.append( " SURNAME, INITIALS, FORENAME, GENDER, ") ;
		strCustAccountInfo.append( " EMAIL, NATIONAL_DIALLING_CODE, ");
		strCustAccountInfo.append( " MOBILE_PHONE_NUMBER, ADDRESS_LINE_1, ADDRESS_LINE_2, ");
		strCustAccountInfo.append( " ADDRESS_LINE_3, ADDRESS_LINE_4, POSTCODE, ");
		strCustAccountInfo.append( " DELIVERY_POINT_SUFFIX, COUNTRY_NAME, ACCOUNT_STATUS, ");
		strCustAccountInfo.append( " PREVIOUS_ACCOUNT_STATUS, CREDIT_STATUS, DIVERT_NEXT_STAT_TO_OFFICE_IND,  ");
		strCustAccountInfo.append( " ONLINE_STATEMENT_IND, DO_NOT_PRINT_STATEMENT_IND, STATUS, ");
		strCustAccountInfo.append( " TIMESTAMP_CREATED, TIMESTAMP_MODIFIED, DATE_OF_BIRTH, ");
		strCustAccountInfo.append( " DATE_ACCOUNT_STATUS_CHANGE, CREDIT_START_DATE ");
		strCustAccountInfo.append( " FROM ").append(spMainSchema).append(".").append("CIM_ACCOUNT_INFO WHERE STATUS IN ('AR_Started', 'NEW') ");
		strCustAccountInfo.append( " AND TO_CHAR(STATEMENT_DATE,'YYYY-MM-DD') = ?") ;
		strCustAccountInfo.append( " AND CUSTOMER_ID = ?");
		
		return strCustAccountInfo ;
	}
	
	/**
	 * the getPseudoChageQuery()
	 * @return
	 */
	public static StringBuilder getPseudoChagesCalQuery(){
		
		StringBuilder custAcctDetailsPseudoChageDetails = new StringBuilder();
		
		custAcctDetailsPseudoChageDetails.append("SELECT CMI.CREDIT_ACCOUNT_NUMBER, CMI.PUBLIC_ACCOUNT_NUMBER, CMI.RETAIL_ACCOUNT_NUMBER,");
		custAcctDetailsPseudoChageDetails.append("A.BRAND, A.MINIMUM_PAYMENT, A.MINIMUM_PAYMENT_PERCENTAGE, A.AVAILABLE_TO_SPEND,");
		custAcctDetailsPseudoChageDetails.append("CMI.PAYMENT_DUE_DATE, CMI.STMT_OFFSET_DAYS_FRM_PDD, N.ARREARS_AMOUNT,");
		custAcctDetailsPseudoChageDetails.append("DI.CASH_PRICE, DI.ITEM_TYPE, DI.DRAWDOWN_CODE,");
		custAcctDetailsPseudoChageDetails.append("DT.OUTSTANDING_BALANCE, DT.START_DATE, DT.BNPL_END_DATE, DT.DAILY_INTEREST_RATE ");
		custAcctDetailsPseudoChageDetails.append(" ");
		custAcctDetailsPseudoChageDetails.append("FROM SPDEV.CIM_ACCOUNT_INFO CMI, ");
		custAcctDetailsPseudoChageDetails.append("SPDEV.AGREEMENT A, SPDEV.DRAWDOWN_TERM DT, SPDEV.DRAWDOWN_ITEM DI, SPDEV.NOSIA N ");
		custAcctDetailsPseudoChageDetails.append("WHERE CMI.CREDIT_ACCOUNT_NUMBER  = TRUNC(A.AGREEMENT_CODE)   AND ");
		custAcctDetailsPseudoChageDetails.append(" CMI.CREDIT_ACCOUNT_NUMBER  =  TRUNC(CMI.CREDIT_ACCOUNT_NUMBER) AND ");
		custAcctDetailsPseudoChageDetails.append(" CMI.CREDIT_ACCOUNT_NUMBER  = TRUNC(DT.AGREEMENT_CODE)   AND ");
		custAcctDetailsPseudoChageDetails.append(" TRUNC(DT.DRAWDOWN_CODE)    = TRUNC(DI.DRAWDOWN_CODE) AND ");
		custAcctDetailsPseudoChageDetails.append(" CMI.CREDIT_ACCOUNT_NUMBER = ?");
	
		return custAcctDetailsPseudoChageDetails ;
	}
	/**
	 * 
	 * @param schema 
	 * @return successfulARQuery
	 * @throws Exception
	 */
	public static StringBuilder getSuccessfulARQuery(String schema) {
		return new StringBuilder("UPDATE " + schema + ".CIM_ACCOUNT_INFO CIM SET STATUS = ? WHERE " +
				"CIM.PUBLIC_ACCOUNT_NUMBER = ? AND CIM.CIM_ACCOUNT_INFO_ID=? ");
	}
	/**
	 * the getPseudoChageQuery()
	 * @return
	 * @throws Exception 
	 */
	public static StringBuilder getAccountReassessementConfirmation(String spMainSchema) {
		StringBuilder custARConfirmation = new StringBuilder();
		custARConfirmation.append("SELECT DISTINCT A.AGREEMENT_ID AS A_AGREEMENT_CODE, DT.OS_BAL AS DT_OUTSTANDING_BALANCE, DT.START_DTE AS DT_START_DATE, DT.BNPL_EDATE AS DT_BNPL_END_DATE, DI.ITEM_CODE AS DI_ITEM_TYPE, ");
		custARConfirmation.append("'0' AS DT_DEFERRED_DATE, DT.INT_RATE AS DT_DAILY_INTEREST_RATE, ");
		custARConfirmation.append("CIM.PAYMENT_DUE_DATE AS CIM_PAYMENT_DUE_DATE, CIM.STMT_OFFSET_DAYS_FRM_PDD AS CIM_STMT_OFFSET_DAYS_FRM_PDD, DT.DRAWDOWN_ID AS DT_DRAWDOWN_CODE,");
		custARConfirmation.append("DT.PROD_CODE AS DT_PRODUCT_CATEGORY, ");
		custARConfirmation.append("DT.PLN_TERM_PER AS DT_DRAWDOWN_TERM, 'Month' As DT_DRAWDOWN_TERM_UNIT ");
		custARConfirmation.append("FROM CIM_ACCOUNT_INFO CIM, DRAWDOWN DT, DRAWDOWN_ITEM DI, AGREEMENT A ");
		custARConfirmation.append("WHERE TRIM(CIM.CREDIT_ACCOUNT_NUMBER) = TRIM(A.AGREEMENT_ID) ");
		custARConfirmation.append("AND TRIM(CIM.CREDIT_ACCOUNT_NUMBER) = TRIM(DT.AGREEMENT_ID) ");
		custARConfirmation.append("AND TRIM(DT.DRAWDOWN_ID) = TRIM(DI.DRAWDOWN_ID) ");
		custARConfirmation.append("AND TRIM(CIM.PUBLIC_ACCOUNT_NUMBER)=? and TO_CHAR(CIM.STATEMENT_DATE,'YYYY-MM-DD')=?");
		return custARConfirmation ;
	}

	//TO_CHAR(CIM.STATEMENT_DATE,'YYYY-MM-DD') =
	/**
	 * Fetch the latest Closing balance of the Account.
	 * @param schema
	 * @return String
	 */
	public static String custAccountBalanceQuery(String schema){
		StringBuilder custAccountBalance = new StringBuilder("SELECT CLOSING_BALANCE FROM");
		custAccountBalance.append(" (SELECT ROWNUM,CLOSING_BALANCE").append(" FROM ").append(schema).append(".").append("AGREEMENT ");
		custAccountBalance.append(" WHERE AGREEMENT_ID = ?  ORDER BY STATEMENT_DATE DESC)");
		custAccountBalance.append(" WHERE ROWNUM=1");
		return custAccountBalance.toString();
	}

	public static String lastTransDateQuery(String schema) {
		StringBuilder lastTransDate = new StringBuilder("SELECT DATE_OF_TRXN FROM");
		lastTransDate.append(" (SELECT ROWNUM , L.DATE_OF_TRANSACTION DATE_OF_TRXN ");
		lastTransDate.append("	FROM ").append(schema).append(".").append("PERIODIC_STATEMENT S").append(",").append(schema).append(".").append("PERIODIC_STATEMENT_LINE L ");
		lastTransDate.append(" WHERE S.PERIODIC_STATEMENT_ID = L.PERIODIC_STATEMENT_ID ");
		lastTransDate.append(" AND S.CONTRACT_NUMBER = ? ");
		lastTransDate.append(" AND DATE_OF_TRANSACTION <= TO_DATE(? , 'YYYY-MM-DD')");
		lastTransDate.append(" ORDER BY DATE_OF_TRANSACTION DESC)  WHERE ROWNUM =1 ");
		return lastTransDate.toString();
	}


	public static StringBuilder getCreditStatus() {
		StringBuilder creditStatus = new StringBuilder(" SELECT CREDIT_STATUS FROM CIM_ACCOUNT_INFO ");
		creditStatus.append( " WHERE CREDIT_ACCOUNT_NUMBER = ? ");
		return creditStatus;
	}
	
	public static StringBuilder updateAccountStatus() {
		StringBuilder updateStatus = new StringBuilder(" UPDATE CIM_ACCOUNT_INFO SET ACCOUNT_STATUS = ?"); 
		updateStatus.append(" WHERE CREDIT_ACCOUNT_NUMBER = ? AND CIM_ACCOUNT_INFO_ID = ? ");
		return updateStatus;
	}	
	
     public static String getChangeRates(){
    	 StringBuilder changeRates = new StringBuilder("");
    	 changeRates.append("SELECT DISTINCT CAI.STATEMENT_DATE,CAI.BRAND_CODE, CAI.CIM_ACCOUNT_INFO_ID, CAI.CREDIT_ACCOUNT_NUMBER, AR.IMPLEMENT_AFTER,");
    	 changeRates.append("RM.RISK_NAV_SCORE, AR.AIR_ACTION, AR.AIR ");
    	 changeRates.append("FROM CIM_ACCOUNT_INFO CAI, ");
    	 changeRates.append("RISK_NAVIGATOR_PARAMS RM , ");
    	 changeRates.append("ACCOUNT_REASSESSMENT AR ");
    	 changeRates.append("WHERE CAI.PUBLIC_ACCOUNT_NUMBER=RM.PUBLIC_ACCOUNT_NUMBER(+) ");
    	 changeRates.append("AND CAI.PUBLIC_ACCOUNT_NUMBER=AR.PUBLIC_ACCOUNT_NUMBER(+) ");
    	 changeRates.append("AND cim_account_info_id is not null AND ");
    	 changeRates.append("TO_CHAR(CAI.STATEMENT_DATE,'YYYY-MM-DD') = ? AND CAI.PUBLIC_ACCOUNT_NUMBER = ?");
		return changeRates.toString();
	}
	
     public static String updateAccountStatusQuery(String schema){
    	 StringBuilder updateStatusBuilder = new StringBuilder(" UPDATE ").append(schema).append(".").append("CIM_ACCOUNT_INFO SET ACCOUNT_STATUS =?" ); 
    	 updateStatusBuilder.append(" WHERE CIM_ACCOUNT_INFO_ID=?");
 		return updateStatusBuilder.toString();
     }

     public static String updateForecastedInterest(String schema,String estimatedInterest,String agreementCode) {
 		StringBuilder custARConfirmation = new StringBuilder();
 		custARConfirmation.append("UPDATE AGREEMENT SET FORECASTED_INTEREST="+"'"+estimatedInterest+"'");
 		custARConfirmation.append(" WHERE AGREEMENT_ID="+"'"+agreementCode+"'");
 		return custARConfirmation.toString() ;
 	}
     
     /*
      * This method returns list of contract_number ready for reprint
      */
     public static StringBuilder getAccountList(String schema) {
  		StringBuilder reprintAccount = new StringBuilder();
  		
  		reprintAccount.append("SELECT distinct contract_number  AS ACCOUNT_NUMBER ");
  		reprintAccount.append("FROM periodic_statement ");
  		reprintAccount.append("WHERE STATEMENT_STATUS = 'REPRINT_NEW' ");
  		reprintAccount.append(" and reprint_code         = 1 ");
  		reprintAccount.append(" UNION ");
  		reprintAccount.append(" select distinct etrad_agent_number AS ACCOUNT_NUMBER "); 
  		reprintAccount.append("FROM periodic_statement ");
  		reprintAccount.append("WHERE STATEMENT_STATUS = 'REPRINT_NEW' ");
  		reprintAccount.append(" and reprint_code         = 1  ");
  		reprintAccount.append(" UNION ");
  		reprintAccount.append(" SELECT distinct contract_number  AS ACCOUNT_NUMBER  ");
  		reprintAccount.append("FROM annual_statement_loan ");
  		reprintAccount.append("WHERE statement_odt_lfcys_code = 10");
  		return reprintAccount;
     }
     /**
 	 * 
 	 * @param schema 
 	 * @return successfulARQuery
 	 * @throws Exception
 	 */
 	public static StringBuilder startARQuery(String schema) {
 		return new StringBuilder("UPDATE " + schema + ".CIM_ACCOUNT_INFO CIM SET STATUS = ? WHERE " +
 				"CIM.CUSTOMER_ID = ? AND TO_CHAR(CIM.STATEMENT_DATE,'YYYY-MM-DD')=?");
 	}
	
	public static StringBuilder insertAccountList(String schema,CustomerAccountInfo custInfo,Timestamp timestamp) {
   		StringBuilder reprintAccount = new StringBuilder();
   		reprintAccount.append("Insert into CIM_ACCOUNT_INFO (CIM_ACCOUNT_INFO_ID,PUBLIC_ACCOUNT_NUMBER,CREDIT_ACCOUNT_NUMBER,RETAIL_ACCOUNT_NUMBER,LINKED_ACCOUNT_IND,STATEMENT_DATE,");
   		reprintAccount.append( "PAYMENT_DUE_DATE,PENDING_PDD,BRAND_CODE,BRAND_TYPE,SPECIAL_ATTENTION_CODE,LATE_ARREARS_IND,CREDIT_RISK_FACTOR,TITLE,SURNAME,INITIALS,FORENAME,GENDER,EMAIL,");
   		reprintAccount.append("NATIONAL_DIALLING_CODE,MOBILE_PHONE_NUMBER,ADDRESS_LINE_1,ADDRESS_LINE_2,ADDRESS_LINE_3,ADDRESS_LINE_4,POSTCODE,DELIVERY_POINT_SUFFIX,COUNTRY_NAME,");
   		reprintAccount.append("ACCOUNT_STATUS,CREDIT_STATUS,DIVERT_NEXT_STAT_TO_OFFICE_IND,ONLINE_STATEMENT_IND,DO_NOT_PRINT_STATEMENT_IND,STATUS,TIMESTAMP_CREATED,TIMESTAMP_MODIFIED,");
   		reprintAccount.append("DATE_OF_BIRTH,DATE_ACCOUNT_STATUS_CHANGE) values (");
   		reprintAccount.append("CAI_ID_SEQ.NEXTVAL"+",'"+custInfo.getPublicAccountId()+"'"+",'"+custInfo.getCreditAccountId()+"','"+custInfo.getRetailAccountId()+"',0,to_date('"+CIMCreateCustomerUtil.getDbSQLDate()+"','YYYY-MM-DD'),to_date('02-JAN-17','DD-MON-RR')");
   		reprintAccount.append(",null,'"+custInfo.getBrandCode()+"','"+custInfo.getCreditStatus()+"',null,1,null,null,null,null,null,null,null,null,null,'"+custInfo.getAddressLine1()+"','"+custInfo.getAddressLine2()+"',null,null,'"+custInfo.getPostCode()+"',null,null,0,'"+custInfo.getCreditStatus()+"',");
   		
   		
   		reprintAccount.append( "null,null,null,'REPRINT_NEW',to_timestamp('"+timestamp+"','YYYY-MM-DD HH24:MI:SSXFF'),to_timestamp('"+timestamp+"','YYYY-MM-DD HH24:MI:SSXFF'),null,null)");
   		return reprintAccount;
      }
	
	/**
	 * @param schema
	 * @return
	 */
	public static String insertErrorLog(String schema) {
		StringBuilder errorLog = new StringBuilder("INSERT INTO ").append(schema).append(".").append("SP_ERROR_LOG VALUES(sp_error_log_seq.nextval,?,?,?,?,?,?,?,?,?,?)");
		return errorLog.toString();
	}

	/**
	 * @param spMainSchemaDate
	 * @return
	 */
	public static String assessAccountInfo(String spMainSchema){
    	 StringBuilder assessAccountInfo = new StringBuilder("");
    	 assessAccountInfo.append(" SELECT C.PUBLIC_ACCOUNT_NUMBER PAN, C.CREDIT_RISK_FACTOR RISK,");
    	 assessAccountInfo.append(" A.SCHEDULED_PAYMENT_AMT SPA, A.ARREARS_AMOUNT CRA,");
    	 assessAccountInfo.append(" C.STATUS TS,A.SCHEDULED_PAYMENT_PAST_DUE SPPD,");
    	 assessAccountInfo.append(" A.AVAILABLE_TO_SPEND OTB,C.ACCOUNT_STATUS STATUS");
    	 assessAccountInfo.append(" FROM  AGREEMENT A,");
    	 assessAccountInfo.append(spMainSchema).append(".").append("CIM_ACCOUNT_INFO C ");
    	 assessAccountInfo.append(" WHERE TRIM(A.AGREEMENT_ID) = C.CREDIT_ACCOUNT_NUMBER");
    	 assessAccountInfo.append(" AND C.PUBLIC_ACCOUNT_NUMBER = ? AND TO_CHAR(C.STATEMENT_DATE,'YYYY-MM-DD') = TO_CHAR(?,'YYYY-MM-DD')  ");    	 		
 		return assessAccountInfo.toString();
	}
	
	/**
	 * the getInsertControlDataQuery()
	 * @return
	 * @throws Exception 
	 */
	public static String getInsertControlDataQuery(String spMainSchema) {
		StringBuilder insertControlInfo = new StringBuilder();
		insertControlInfo.append("INSERT INTO ").append(spMainSchema).append(".").append("SP_CRDT_FIL_LOAD_CONTROL(BATCH_ID, FILE_NAME, ");
		insertControlInfo.append("FILE_RUN_STATUS, ERROR_MESSAGE, CREATED_DATE, CREATED_BY, ");
		insertControlInfo.append("FILE_IDENTIFIER, PROCESS_NAME) VALUES(?, ?, ?, ?, ?, ?, ?, ?)");
		return insertControlInfo.toString() ;
	}
	
	/**
	 * the getUpdateControlDataQuery()
	 * @return
	 * @throws Exception 
	 */
	public static String getUpdateControlDataQuery(String spMainSchema) {
		StringBuilder updateControlInfo = new StringBuilder();
		updateControlInfo.append("UPDATE ").append(spMainSchema).append(".").append("SP_CRDT_FIL_LOAD_CONTROL ");
		updateControlInfo.append("SET FILE_RUN_STATUS = ?, ERROR_MESSAGE = ?, LAST_UPDATED_DATE = ? ");
		updateControlInfo.append("WHERE BATCH_ID = ? AND FILE_IDENTIFIER = ?");
		return updateControlInfo.toString() ;
	}

	public static String getDeleteDataQuery(String spMainSchema, String packageName, String procName) {
		StringBuilder deleteDataInfo = new StringBuilder();
		deleteDataInfo.append("{call ");
		deleteDataInfo.append(packageName).append(".");
		deleteDataInfo.append(procName);
		deleteDataInfo.append("(?,?,?)}");
		return deleteDataInfo.toString();
	}
	
	public static String getInsertFinDataQuery(String packageName, String procName) {
		StringBuilder insertFinData = new StringBuilder();
		insertFinData.append("{call ");
		insertFinData.append(packageName).append(".");
		insertFinData.append(procName);
		insertFinData.append("(?,?,?,?)}");
		return insertFinData.toString();
	}

	public static String getAccountOpenedDate() {
		StringBuilder accntOpened = new StringBuilder(" SELECT CREDIT_START_DATE FROM CIM_ACCOUNT_INFO ");
		accntOpened.append( " WHERE CIM_ACCOUNT_INFO_ID = ? ");
		return accntOpened.toString();
	}

	public static String getLastOrderDate(String schema) {
		StringBuilder lastOrdered = new StringBuilder("SELECT DATE_OF_TRXN FROM");
		lastOrdered.append(" (SELECT ROWNUM , L.DATE_OF_TRANSACTION DATE_OF_TRXN ");
		lastOrdered.append("	FROM ").append(schema).append(".").append("PERIODIC_STATEMENT S").append(",").append(schema).append(".").append("PERIODIC_STATEMENT_LINE L ");
		lastOrdered.append(" WHERE S.PERIODIC_STATEMENT_ID = L.PERIODIC_STATEMENT_ID ");
		lastOrdered.append(" AND S.CONTRACT_NUMBER = ? ");
		lastOrdered.append(" AND DATE_OF_TRANSACTION >= TO_DATE(? , 'YYYY-MM-DD') ");
		lastOrdered.append(" AND STATEMENT_MOVE_ITEM_TYPE_CODE = 'X' ");
		lastOrdered.append(" AND STATEMENT_PRINT_GROUP_CODE = 2 ");
		lastOrdered.append(" ORDER BY DATE_OF_TRANSACTION DESC)  WHERE ROWNUM =1 ");
		
		return lastOrdered.toString();
	}

	public static String updateEstimatedInterest(String schema, String estimatedInterest, String drawdownId) {
		StringBuilder estIntQuery = new StringBuilder("UPDATE " + schema + ".DRAWDOWN SET ESTIMATED_INTEREST=");
		estIntQuery.append("'" + estimatedInterest + "'" + " WHERE DRAWDOWN_ID=" + "'" + drawdownId + "'");
		return estIntQuery.toString();
	}

	public static String getInsertBnplAccruedIntQuery(String schema, int bnplSid, String estimatedInt, String drawdownId, int historySid) {
		StringBuilder insertBnplIntQuery = new StringBuilder("INSERT INTO " + schema + ".BNPL_ACCR_INT_DD_HISTORY (BNPL_ACCR_INT_SID, BNPL_ACCUR_INT_DD_SID, DRAWDOWN_ID, ESTIMATED_INT, DEF_INT) VALUES ('");
		insertBnplIntQuery.append(bnplSid + "', '" + historySid + "', '" + drawdownId + "', " + estimatedInt + ", " + estimatedInt + ")");
		return insertBnplIntQuery.toString();
	}
	
	public static String getInsertBnplDefIntByMonthQuery(String schema, int bnplPeriod, String amount, int monthSid, int historySid) {
		StringBuilder insertBnplIntQuery = new StringBuilder("INSERT INTO " + schema + ".bnpl_def_int_by_month_history (BNPL_ACCUR_INT_DD_SID, BNPL_DEF_INT_BY_MONTH_SID, AMOUNT, BNPL_PERIOD) VALUES ('");
		insertBnplIntQuery.append(historySid + "', '" + monthSid + "', '" + amount + "', " + bnplPeriod + ")");
		return insertBnplIntQuery.toString();
	}
	
	public static String getInsertBnplAccIntQuery(String schema, int bnplSid, String retailNum, String publicAcc, String stmtDate) {
		StringBuilder insertBnplIntQuery = new StringBuilder("INSERT INTO " + schema + ".bnpl_acc_int_acct_history (BNPL_ACCR_INT_SID, RETAIL_ACCOUNT_NUMBER, PUBLIC_ACCOUNT_NUMBER, STATEMENT_DATE) VALUES ('");
		insertBnplIntQuery.append(bnplSid + "', '" + retailNum + "', '" + publicAcc + "', '" + stmtDate + "')");
		return insertBnplIntQuery.toString();
	}
	
	public static String getUpdateAccReassessmentQuery(String schema) {
		StringBuilder updateQuery = new StringBuilder("UPDATE " + schema + ".ACCOUNT_REASSESSMENT ");
		updateQuery.append("SET CREDIT_LIMIT_ACTION = ? , CREDIT_LIMIT_AMOUNT = ?, CL_STATUS = ?");
		updateQuery.append(" WHERE PUBLIC_ACCOUNT_NUMBER = ?");
		return updateQuery.toString();
	}
	
	public static String getInsertAccReassessmentQuery(String schema, String pubAccNo, String creditLimitAction, String creditLimitAmt, String clStatus) {
		StringBuilder insertQuery = new StringBuilder("INSERT INTO " + schema + ".ACCOUNT_REASSESSMENT ");
		insertQuery.append("(PUBLIC_ACCOUNT_NUMBER, CREDIT_LIMIT_ACTION, CREDIT_LIMIT_AMOUNT, CL_STATUS) VALUES ");
		insertQuery.append("('" + pubAccNo + "', '" + creditLimitAction + "', '" + creditLimitAmt + "', '" + clStatus + "')");
		return insertQuery.toString();
	}
	
	public static String getTriadDataQuery(String packageName, String procName) {
		StringBuilder triadData = new StringBuilder();
		triadData.append("{call ");
		triadData.append(packageName).append(".");
		triadData.append(procName);
		triadData.append("(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}");
		return triadData.toString();
	}
	
	public static String getAccountArrearsStatusQuery(String packageName, String procName) {
		StringBuilder triadData = new StringBuilder();
		triadData.append("{call ");
		triadData.append(packageName).append(".");
		triadData.append(procName);
		triadData.append("(?, ?, ?, ?, ?, ?)}");
		return triadData.toString();
	}
	
	public static String getInsertAcCreditLimitInfoQuery(String schema,String pubAccNo, String creditLimitAction, String proposedCreditLimitAmt, 
			String statementDate,  String actualCreditLimitAmt, String arrearsStatus,
			String creditLimitReasonCode, String creditRiskFactor,
			String authStrategyID, String custBehaviourScore, String daysProposedLimitExpires, 
			String limitCapValue, String shadowCreditMonetoryLimit,
			String actualCreditMonetroyLimit, String tradingCode) {
		StringBuilder insertQuery = new StringBuilder("INSERT INTO " + schema + ".ACCOUNT_CREDIT_LIMIT_INFO ");
		insertQuery.append("( PUBLIC_ACCOUNT_NUMBER, STATEMENT_DATE, ACTION, ACTUAL_CREDIT_LIMIT_AMT, PROPOSE_CREDIT_LIMIT_AMT, CREDIT_LIMIT_ACTION, ");
		insertQuery.append("AREEARS_STATUS, CREDIT_LIMIT_RSN_CD, CREDIT_RSK_FACTOR, AUTH_STATEGY_ID, CUST_BEHAVIOUR_SCORE, ");
		insertQuery.append("SHADOW_CREDIT_MONETARY_LIMIT, ACTUAL_CREDIT_MONETARY_LIMIT, DAYS_PROPOSED_LIMIT_EXPIRES, CAP_LIMIT_VALUE, TRADING_STATUS_CODE) VALUES ");
		insertQuery.append("('" + pubAccNo + "', '" + statementDate + "', '" + creditLimitAction + "', '" + actualCreditLimitAmt + "', '" + proposedCreditLimitAmt + "', '" + creditLimitAction + "', '");
		insertQuery.append(arrearsStatus + "', '" + creditLimitReasonCode + "', '" + creditRiskFactor + "', '" + authStrategyID + "', '" + custBehaviourScore + "', '");
		insertQuery.append(shadowCreditMonetoryLimit + "', '" + actualCreditMonetroyLimit + "', '" + daysProposedLimitExpires + "', '" + limitCapValue + "', '" + tradingCode + "')");
		return insertQuery.toString();
	}
	
	public static String getUpdateCimAccountInfoStatus(String schema) {
		StringBuilder updateQuery = new StringBuilder("UPDATE " + schema + ".CIM_ACCOUNT_INFO ");
		updateQuery.append("SET STATUS = ? ");
		updateQuery.append(" WHERE PUBLIC_ACCOUNT_NUMBER = ? AND to_CHAR(STATEMENT_DATE, 'dd-Mon-yy') = ?");
		return updateQuery.toString();
	}
	
	public static String getUpdateAcCreditLimitInfoQuery(String schema) {
		StringBuilder updateQuery = new StringBuilder("UPDATE " + schema + ".ACCOUNT_CREDIT_LIMIT_INFO ");
		updateQuery.append(" SET ACTION = ?, PROPOSE_CREDIT_LIMIT_AMT = ?, CREDIT_LIMIT_RSN_CD= ?,  CREDIT_RSK_FACTOR = ?, ");
		updateQuery.append(" AUTH_STATEGY_ID = ?, CUST_BEHAVIOUR_SCORE = ?, DAYS_PROPOSED_LIMIT_EXPIRES = ?, CAP_LIMIT_VALUE = ?, ");
		updateQuery.append(" SHADOW_CREDIT_MONETARY_LIMIT = ?, ACTUAL_CREDIT_MONETARY_LIMIT = ?  ");
		updateQuery.append(" WHERE PUBLIC_ACCOUNT_NUMBER = ? AND STATEMENT_DATE = ?");
		return updateQuery.toString();
	}
}
