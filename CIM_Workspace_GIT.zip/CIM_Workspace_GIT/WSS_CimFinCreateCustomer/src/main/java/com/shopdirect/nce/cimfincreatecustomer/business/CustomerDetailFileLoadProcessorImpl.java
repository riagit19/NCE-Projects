package com.shopdirect.nce.cimfincreatecustomer.business;

import java.io.File;

import com.shopdirect.nce.cimfincreatecustomer.constants.CreateCustomerDataLoadConstants;
import com.shopdirect.nce.cimfincreatecustomer.dao.CustomerDetailFileLoadDaoImpl;
import com.shopdirect.nce.cimfincreatecustomer.exception.CimCreateCustomerException;
import com.shopdirect.nce.cimfincreatecustomer.processor.CimFileBaseProcessor;
import com.shopdirect.nce.cimfincreatecustomer.processor.DataFileProcessor;

public class CustomerDetailFileLoadProcessorImpl extends CimFileBaseProcessor implements DataFileProcessor {
	
	private CustomerDetailFileLoadDaoImpl customerDetailFileLoadDaoImpl;

	public CustomerDetailFileLoadProcessorImpl() throws CimCreateCustomerException {
		super();
	}
	
	
	public boolean loadCustomerDetails()
			throws CimCreateCustomerException {
		
		getLogger().debug("[CustomerDetailFileLoadProcessorImpl -- loadCustomerDetails]  -- START");
		
		boolean loadedCustomerDetails = false;
		
		Object[] procReturnVal = new Object[2];
		int retCode = 0;
		String retMsg = null;

		try {
					
					procReturnVal = getCustomerDetailFileLoadDaoImpl().loadCustonerDetailsData();
					retCode = (int) procReturnVal[0];
					retMsg = (String) procReturnVal[1];
					
					if (retCode == 0) {
						loadedCustomerDetails = true;
					} else {
						loadedCustomerDetails = false;
					}
					
		} catch (Exception exception) {
			loadedCustomerDetails = false;

			getLogger().error("[CustomerDetailFileLoadProcessorImpl -- loadCustomerDetails] -- Customer Detail Data Load Error occured ");
			getLogger().error("[CustomerDetailFileLoadProcessorImpl -- loadCustomerDetails] -- Customer Detail Data Load Exception: " + exception);
			
			throw new CimCreateCustomerException(CreateCustomerDataLoadConstants.GENERIC_BUSINESS_ERROR_CODE,
					"[CustomerDetailFileLoadProcessorImpl-loadCustomerDetails] CimCreateCustomerException Block",
					"Customer Detail Data Load Exception ", null, null,
					new CimCreateCustomerException());
		}
		
		getLogger().debug("[CustomerDetailFileLoadProcessorImpl -- loadCustomerDetails]  -- END");
		return loadedCustomerDetails;
	}


	/**
	 * @return the customerDetailFileLoadDaoImpl
	 * @throws CimCreateCustomerException 
	 */
	public CustomerDetailFileLoadDaoImpl getCustomerDetailFileLoadDaoImpl() throws CimCreateCustomerException {
		if(customerDetailFileLoadDaoImpl == null) {
			customerDetailFileLoadDaoImpl = new CustomerDetailFileLoadDaoImpl();
		}
		return customerDetailFileLoadDaoImpl;
	}


	/**
	 * @param customerDetailFileLoadDaoImpl the customerDetailFileLoadDaoImpl to set
	 */
	public void setCustomerDetailFileLoadDaoImpl(CustomerDetailFileLoadDaoImpl customerDetailFileLoadDaoImpl) {
		this.customerDetailFileLoadDaoImpl = customerDetailFileLoadDaoImpl;
	}
	
	
	

}
