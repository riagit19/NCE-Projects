package com.shopdirect.nce.cimfincreatecustomer.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;

public class CalendarFormatUtil {

	private static SDLoggerImpl logger = new SDLoggerImpl();
	
	private CalendarFormatUtil() {
		
	}
	
	public static Calendar convertCalendar(String inputDate) throws StatementProcessorBatchException{
		logger.debug("[CalendarFormatUtil -- convertCalendar] -- Start"); 
		Calendar chargeDate = Calendar.getInstance();
			try{	
				SimpleDateFormat dateFormatter=new SimpleDateFormat("yyyy-MM-dd");
				Date date = dateFormatter.parse(inputDate);
				chargeDate.setTime(date);
			}catch(Exception e){
				logger.debug("[CalendarFormatUtil -- convertCalendar] -- Exception: " + e.getMessage());
				throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_BUSINESS_ERROR_CODE,
						"[CalendarFormatUtil-convertCalendar] Exception Block",
						"Business exception generated at time to process the data collection "+ e.getMessage(),
						null, null,e);
			}
			logger.debug("[CalendarFormatUtil -- convertCalendar] -- End"); 
			return chargeDate;
	}

}
