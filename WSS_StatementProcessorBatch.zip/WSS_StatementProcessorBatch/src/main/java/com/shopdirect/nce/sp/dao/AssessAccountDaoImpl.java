package com.shopdirect.nce.sp.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.Query;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.AssessAccountInfoModel;

public class AssessAccountDaoImpl extends AccountReassessmentBaseDao{

private static final String SQL_DETAIL = "] , SQL Detail ";
private static final String DATABASE_EXCEPTION_SQL_CODE = "Database execution exception [SQLCode: ";
private static final String DATABASE_EXECUTION_EXCEPTION = "Database execution exception ";

private Connection con;

public AssessAccountDaoImpl() throws StatementProcessorBatchException {
	super();
	setStgSchema(getSchema(StatementProcessorBatchConstants.DB_SCHEMA_STG_KEY));
	setSpMainSchema(getSchema(StatementProcessorBatchConstants.DB_SCHEMA_MAIN_SP_KEY));		
}


public AssessAccountInfoModel getAssessAccountInfo(AssessAccountInfoModel assessAccountInfoModel, Date statementDate) throws StatementProcessorBatchException {
	SDLoggerImpl logger = new SDLoggerImpl();
	logger.debug("[AssessAccountDaoImpl -- getAssessAccountInfo] -- Start");
	ResultSet assessAccntResultset = null;
	
    try {
    	
    	logger.debug("Start of getAssessAccountInfo :");
    	String queryStr = Query.assessAccountInfo(getStgSchema());
    	logger.info("queryStr==========================="+queryStr);
    	con = getCon();
		try (PreparedStatement stmt = con.prepareStatement(queryStr)) {
			stmt.setString(1, assessAccountInfoModel.getPublicAccountNumber());
			stmt.setDate(2, getDate(statementDate));
			assessAccntResultset = stmt.executeQuery();
		    createAssessAccountModel(assessAccountInfoModel, assessAccntResultset);
		}
    }catch (SQLException sqlException) {
    	logger.error("[AssessAccountDaoImpl -- getAssessAccountInfo] -- SQLException: " + sqlException);
		throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_DB_ERROR_CODE,
				"[AssessAccountDaoImpl - getAssessAccountInfo] SQLException Block",
				DATABASE_EXCEPTION_SQL_CODE+ sqlException.getSQLState() + SQL_DETAIL+sqlException.getMessage(),
				null, null,sqlException);
	      
	       
	 
    }catch(Exception exception){
    	logger.error("[AssessAccountDaoImpl -- getAssessAccountInfo] -- Exception: " + exception);
		throw new StatementProcessorBatchException(StatementProcessorBatchConstants.CONNECTTION_DB_ERROR_CODE,
				"[AssessAccountDaoImpl - getAssessAccountInfo] Exception Block",
				DATABASE_EXECUTION_EXCEPTION+ exception.getMessage(),
				null, null,exception);
 }finally {
	   
	   try {
		   if(assessAccntResultset != null){
			   assessAccntResultset.close();
		   }
			if (con != null) {
				con.close();
			}
		} catch (Exception e) {
			getLogger().error("[AssessAccountDaoImpl - getAssessAccountInfo] finally Block: failed to close DB objects. " + e);
		}
    }
	logger.debug("[AssessAccountDaoImpl -- getAssessAccountInfo] -- END");
    return assessAccountInfoModel;
	
}


private void createAssessAccountModel(AssessAccountInfoModel assessAccountInfoModel, ResultSet assessAccntResultset)
		throws SQLException {
	if(assessAccntResultset != null){
	    while(assessAccntResultset.next()){			    	
	    	
	    	assessAccountInfoModel.setCreditRiskFactor(assessAccntResultset.getBigDecimal("RISK"));			    	
	    	assessAccountInfoModel.setPastDueAmount(assessAccntResultset.getBigDecimal("SPA"));
	    	assessAccountInfoModel.setCurrentArrearsPosition(assessAccntResultset.getBigDecimal("CRA"));
	    	assessAccountInfoModel.setTradingStatus(assessAccntResultset.getString("TS"));
	    	assessAccountInfoModel.setScheduledPaymentPastDue(assessAccntResultset.getBigDecimal("SPPD"));
	    	assessAccountInfoModel.setOpenToBuy(assessAccntResultset.getBigDecimal("OTB"));
	    	assessAccountInfoModel.setCurrentAccountStatus(assessAccntResultset.getString("STATUS"));
	    	
	    }
	}
}

/*
 * This is utility method for getting current Date
 */
private static java.sql.Date getDate(java.util.Date inputDate) {
	return new java.sql.Date(inputDate.getTime());
}
}
