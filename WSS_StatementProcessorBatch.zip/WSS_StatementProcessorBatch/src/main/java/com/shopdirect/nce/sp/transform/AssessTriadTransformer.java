package com.shopdirect.nce.sp.transform;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.rule.model.Account;
import com.shopdirect.nce.sp.model.AccountResponseType;
import com.shopdirect.nce.sp.model.AccountingSnapshot;
import com.shopdirect.nce.sp.model.AccountingSnapshotTriad;
import com.shopdirect.nce.sp.model.AgreementTriad;
import com.shopdirect.nce.sp.model.AuthType;
import com.shopdirect.nce.sp.model.BatchDetails;
import com.shopdirect.nce.sp.model.BatchGroup;
import com.shopdirect.nce.sp.model.BatchLinked;
import com.shopdirect.nce.sp.model.BatchLinkedGroup;
import com.shopdirect.nce.sp.model.BatchLinkedMonth;
import com.shopdirect.nce.sp.model.BatchMonth;
import com.shopdirect.nce.sp.model.CreditLimitType;
import com.shopdirect.nce.sp.model.CurrentAccoutingSnapshotTriad;
import com.shopdirect.nce.sp.model.CustomerAccountInfo;
import com.shopdirect.nce.sp.model.CustomerContractTriad;
import com.shopdirect.nce.sp.model.ReassessTriadRespType;
import com.shopdirect.nce.sp.model.RetailContractTriad;
import com.shopdirect.nce.sp.model.TriadDataType;
import com.shopdirect.nce.sp.model.TriadResponseType;
import com.shopdirect.osb.reassesstriadar.ReassessTRIADARRequestType;
import com.shopdirect.osb.reassesstriadar.ReassessTRIADARResponseType;
import com.shopdirect.osb.reassesstriadar.ReassessTRIADARType;
import com.shopdirect.osb.reassesstriadar.UpdateRiskResultRequestType;

/**
 * 
 * @author SudiptaRoy
 *
 */
public class AssessTriadTransformer {

	private static final SDLoggerImpl LOGGER = new SDLoggerImpl();
	
	public ReassessTRIADARRequestType transformRequest(BatchDetails batchDetails, List<BatchLinked> batchLinkedList,
						List<AccountingSnapshot> accountingSnapshotList, List<BatchGroup> batchGroupList, 
						List<BatchLinkedGroup> batchLinkedGroupList, List<BatchMonth> batchMonthList, 
						List<BatchLinkedMonth> batchLinkedMonthList, CustomerAccountInfo accountInfo,
						CustomerContractTriad customerContractTriad, RetailContractTriad retailContractTriad,
						AgreementTriad agreementTriad, CurrentAccoutingSnapshotTriad currentAccSnapshotTriad,
						AccountingSnapshotTriad accountingSnapshotTriad, 
						Account accountRule, String callType, String reasonCode,
						String tradingCode) throws Exception {
		
		LOGGER.debug("[AssessTriadTransformer -- transformRequest] -- Start");
		ReassessTRIADARRequestType reassessTRIADARRequestType = new ReassessTRIADARRequestType();
		
		ReassessTRIADARType reassessTRIADARType = new ReassessTRIADARType();
		reassessTRIADARRequestType.setReassessTRIADAR(reassessTRIADARType);
		
		CRDRDataTransformer crdrDataTransformer = new CRDRDataTransformer();
		crdrDataTransformer.transformCRDRDataType(reassessTRIADARType, accountInfo, batchDetails, callType);
		
		Sams200RequestTransformer sams200RequestTransformer = new Sams200RequestTransformer();
		sams200RequestTransformer.transformSams200CRequestType(reassessTRIADARType, batchDetails, batchGroupList, batchMonthList, batchLinkedList,
				batchLinkedGroupList, batchLinkedMonthList, accountInfo, customerContractTriad, agreementTriad, retailContractTriad, accountRule,
				callType);
		
		IssueAccountSnapshotDataTransformer issueAccountSnapshotDataTransformer = new IssueAccountSnapshotDataTransformer();
		issueAccountSnapshotDataTransformer.issueAccountSnapshotDataRequest(reassessTRIADARType, accountInfo, agreementTriad, customerContractTriad,
					accountingSnapshotTriad, tradingCode);
		

		UpdateRiskResultRequestType updateRiskResultRequestType = new UpdateRiskResultRequestType();
		reassessTRIADARType.setUpdateRiskResultRequest(updateRiskResultRequestType);

		updateRiskResultRequestType.setStatementNumber(agreementTriad.getFnStatNo() != null ? agreementTriad.getFnStatNo().toBigInteger() : null);
		updateRiskResultRequestType.setCRFUppdateReasonCode(reasonCode);
		
		CheckBNPLEligibilityRequestTransformer checkBNPLEligibilityRequestTransformer = new CheckBNPLEligibilityRequestTransformer();
		checkBNPLEligibilityRequestTransformer.checkBNPLEligibilityRequest(reassessTRIADARType, accountInfo, batchDetails, customerContractTriad, 
				retailContractTriad, agreementTriad, accountingSnapshotList, batchLinkedList, currentAccSnapshotTriad, accountRule, callType);
		
		LOGGER.debug("[AssessTriadTransformer -- transformRequest] -- End");
		return reassessTRIADARRequestType;
	}
	
	public com.shopdirect.nce.sp.model.ReassessTRIADARResponseType transformRespone(ReassessTRIADARResponseType response) {
		LOGGER.debug("[AssessTriadTransformer -- transformRespone] -- Start");
		com.shopdirect.nce.sp.model.ReassessTRIADARResponseType modelResponse = new com.shopdirect.nce.sp.model.ReassessTRIADARResponseType();
		
		ReassessTriadRespType modelReassessTriadResp = new ReassessTriadRespType();
		modelResponse.setReassessTriadRespType(modelReassessTriadResp);
		
		TriadResponseType modelTriadResponse = new TriadResponseType();
		modelReassessTriadResp.setTriadResponseType(modelTriadResponse);
		
		AccountResponseType modelAccountResponse = new AccountResponseType();
		modelTriadResponse.setAccountResponseType(modelAccountResponse);
		
		TriadDataType modelTriadData = new TriadDataType();
		modelAccountResponse.setTriadDataType(modelTriadData);
		
		AuthType modelAuth = new AuthType();
		CreditLimitType modelCreditLimit = new CreditLimitType();
		modelTriadData.setAuthType(modelAuth);
		modelTriadData.setCreditLimitType(modelCreditLimit);
		
		transformAuth(modelAuth, response);
		transformCreditLimit(modelCreditLimit, response);
		
		LOGGER.debug("[AssessTriadTransformer -- transformRespone] -- End");
		return modelResponse;
	}

	private void transformCreditLimit(CreditLimitType modelCreditLimit, ReassessTRIADARResponseType response) {
		LOGGER.debug("[AssessTriadTransformer -- transformCreditLimit] -- Start");
		com.shopdirect.osb.reassesstriadar.ReassessTriadRespType reassessTriadRespType = response.getReassessTriadResp();
		if (reassessTriadRespType != null) {
			com.shopdirect.osb.reassesstriadar.TriadResponseType triadResponseType = reassessTriadRespType.getTriadResponse();
			if (triadResponseType != null) {
				com.shopdirect.osb.reassesstriadar.AccountResponseType accountResponseType = triadResponseType.getAccountResponse();
				if (accountResponseType != null) {
					com.shopdirect.osb.reassesstriadar.TriadDataType triadDataType = accountResponseType.getTriadData();
					if (triadDataType != null) {
						com.shopdirect.osb.reassesstriadar.CreditLimitType creditLimitType = triadDataType.getCreditLimit();
						if (creditLimitType != null) {
							modelCreditLimit.setaCDAlignedBehaviourScore(creditLimitType.getACDAlignedBehaviourScore());
							modelCreditLimit.setaCDRawBehaviourScore(creditLimitType.getACDRawBehaviourScore());
							modelCreditLimit.setaCDScorecardId(creditLimitType.getACDScorecardId());
							modelCreditLimit.setActualCreditLimit(creditLimitType.getActualCreditLimit());
							modelCreditLimit.setAffordabilityUpdateRequiredCode(creditLimitType.getAffordabilityUpdateRequiredCode());
							modelCreditLimit.setAnnotationsTriadDecisionKeyBatch(creditLimitType.getAnnotationsTriadDecisionKeyBatch());
							modelCreditLimit.setAuthDigitsLowerLimit(creditLimitType.getAuthDigitsLowerLimit());
							modelCreditLimit.setAuthDigitsUpperLimit(creditLimitType.getAuthDigitsUpperLimit());
							modelCreditLimit.setAuthStrategyId(creditLimitType.getAuthStrategyId());
							modelCreditLimit.setBarFactor(creditLimitType.getBarFactor());
							modelCreditLimit.setbNPLScore(creditLimitType.getBNPLScore());
							modelCreditLimit.setCollTimedAction(creditLimitType.getCollTimedAction());
							modelCreditLimit.setCreditLimitOutcomeCode(creditLimitType.getCreditLimitOutcomeCode());
							modelCreditLimit.setCreditLineReasonCode(creditLimitType.getCreditLineReasonCode());
							modelCreditLimit.setCreditRiskFactor(creditLimitType.getCreditRiskFactor());
							modelCreditLimit.setCustAlignedBehaviourScore(creditLimitType.getCustAlignedBehaviourScore());
							modelCreditLimit.setCustBehaviourScore(creditLimitType.getCustBehaviourScore());
							modelCreditLimit.setCustRawBehaviourScore(creditLimitType.getCustRawBehaviourScore());
							modelCreditLimit.setCustScorecardId(creditLimitType.getCustScorecardId());
							modelCreditLimit.setDaysProposedLimitExpires(creditLimitType.getDaysProposedLimitExpires());
							modelCreditLimit.setDerivedIncome(creditLimitType.getDerivedIncome());
							modelCreditLimit.setDerivedIncomeFlag(creditLimitType.getDerivedIncomeFlag());
							modelCreditLimit.setLimitCapValue(creditLimitType.getLimitCapValue());
							modelCreditLimit.setnDRAlignedBehaviourScore(creditLimitType.getNDRAlignedBehaviourScore());
							modelCreditLimit.setnDRRawBehaviourScore(creditLimitType.getNDRRawBehaviourScore());
							modelCreditLimit.setnDRScorecardId(creditLimitType.getNDRScorecardId());
							modelCreditLimit.setProposedCreditLimit(creditLimitType.getProposedCreditLimit());
							modelCreditLimit.setRawBehaviourScore(creditLimitType.getRawBehaviourScore());
							modelCreditLimit.setScorecardId(creditLimitType.getScorecardId());
							modelCreditLimit.setStatementMessage(creditLimitType.getStatementMessage());
							modelCreditLimit.setTriadBehaviourScorecardTypeCode(creditLimitType.getTriadBehaviourScorecardTypeCode());
						}
					}
				}
			}
		}
		LOGGER.debug("[AssessTriadTransformer -- transformCreditLimit] -- End");
		
	}

	private void transformAuth(AuthType modelAuth, ReassessTRIADARResponseType response) {
		LOGGER.debug("[AssessTriadTransformer -- transformAuth] -- Start");
		com.shopdirect.osb.reassesstriadar.ReassessTriadRespType reassessTriadRespType = response.getReassessTriadResp();
		if (reassessTriadRespType != null) {
			com.shopdirect.osb.reassesstriadar.TriadResponseType triadResponseType = reassessTriadRespType.getTriadResponse();
			if (triadResponseType != null) {
				com.shopdirect.osb.reassesstriadar.AccountResponseType accountResponseType = triadResponseType.getAccountResponse();
				if (accountResponseType != null) {
					com.shopdirect.osb.reassesstriadar.TriadDataType triadDataType = accountResponseType.getTriadData();
					if (triadDataType != null) {
						com.shopdirect.osb.reassesstriadar.AuthType authType = triadDataType.getAuth();
						if (authType != null) {
							modelAuth.setActualCreditMonetaryLimit(authType.getActualCreditMonetaryLimit());
							modelAuth.setAnnotationsTriadDecisionKeyAuth(authType.getAnnotationsTriadDecisionKeyAuth());
							modelAuth.setAuthApprovalActionOrder(authType.getAuthApprovalActionOrder());
							modelAuth.setAuthApprovalActionShadowLimit(authType.getAuthApprovalActionShadowLimit());
							modelAuth.setAuthDecision(authType.getAuthDecision());
							modelAuth.setAuthLetterAlpha(authType.getAuthLetterAlpha());
							modelAuth.setAuthLetterDigits(authType.getAuthLetterDigits());
							modelAuth.setAuthOverrideDecision(authType.getAuthOverrideDecision());
							modelAuth.setAuthOverrideRDLetterId(authType.getAuthOverrideRDLetterId());
							modelAuth.setAuthOverrideRDReason(authType.getAuthOverrideRDReason());
							modelAuth.setAuthReferDeclineLetterId(authType.getAuthReferDeclineLetterId());
							modelAuth.setAuthReferDeclineReason(authType.getAuthReferDeclineReason());
							modelAuth.setbNPLEligibility(authType.getBNPLEligibility());
							modelAuth.setShadowCreditMonetaryLimit(authType.getShadowCreditMonetaryLimit());
						}
					}
				}
			}
		}
		LOGGER.debug("[AssessTriadTransformer -- transformAuth] -- End");		
	}
	
	private BigInteger getBigIntValue(Double doubleVal) {
		BigInteger result = null;
		if (doubleVal != null && !doubleVal.equals(0.0)) {
			result = new BigDecimal(doubleVal).toBigInteger();
		}
		return result;
	}

	private String getStringValue(Double doubleVal) {
		String result = null;
		if (doubleVal != null && !doubleVal.equals(0.0)) {
			result = doubleVal.toString();
		}
		return result;
	}

	private BigDecimal getBigDecimalValue(Double doubleVal) {
		BigDecimal result = null;
		if (doubleVal != null && !doubleVal.equals(0.0)) {
			result = new BigDecimal(doubleVal);
			result = result.setScale(2, BigDecimal.ROUND_HALF_EVEN);
		}
		return result;
	}

}
