package com.shopdirect.nce.sp.model;

import java.math.BigDecimal;
import java.util.List;
import javax.xml.bind.annotation.XmlRootElement;
import com.shopdirect.fcm.xsd.forecastmodeller.CustomerAccountType;
import com.shopdirect.fcm.xsd.forecastmodeller.CurrentDDTWithTransactionsAndIncomesType;
import com.shopdirect.fcm.xsd.forecastmodeller.PeriodMovementsType;
import com.shopdirect.fcm.xsd.forecastmodeller.PseudoChargeInfoByCustomerType;

@XmlRootElement
public class ARPseudoChargeReqType {
	
	private CustomerAccountType customerAccountType;
	private String brandType;    
	private boolean stopFees;   
	private boolean stopInterest;    
	private boolean stopDefaultFees;    
	private BigDecimal minPayThreshold;   
	private BigDecimal minPayPercentageThreshold;	    
	private BigDecimal currentBalance;	    
	private BigDecimal currentArrearsAmount;	    
	private PeriodMovementsType currentPeriodMovements;	    
	private PseudoChargeInfoByCustomerType previousPseudoChargeInfo;    
	private List<CurrentDDTWithTransactionsAndIncomesType> drawdownTerms;
	
	
	public CustomerAccountType getCustomerAccountType() {
		return customerAccountType;
	}
	public void setCustomerAccountType(CustomerAccountType customerAccountType) {
		this.customerAccountType = customerAccountType;
	}
	public String getBrandType() {
		return brandType;
	}
	public void setBrandType(String brandType) {
		this.brandType = brandType;
	}
	public boolean isStopFees() {
		return stopFees;
	}
	public void setStopFees(boolean stopFees) {
		this.stopFees = stopFees;
	}
	public boolean isStopInterest() {
		return stopInterest;
	}
	public void setStopInterest(boolean stopInterest) {
		this.stopInterest = stopInterest;
	}
	public boolean isStopDefaultFees() {
		return stopDefaultFees;
	}
	public void setStopDefaultFees(boolean stopDefaultFees) {
		this.stopDefaultFees = stopDefaultFees;
	}
	public BigDecimal getMinPayThreshold() {
		return minPayThreshold;
	}
	public void setMinPayThreshold(BigDecimal minPayThreshold) {
		this.minPayThreshold = minPayThreshold;
	}
	public BigDecimal getMinPayPercentageThreshold() {
		return minPayPercentageThreshold;
	}
	public void setMinPayPercentageThreshold(BigDecimal minPayPercentageThreshold) {
		this.minPayPercentageThreshold = minPayPercentageThreshold;
	}
	public BigDecimal getCurrentBalance() {
		return currentBalance;
	}
	public void setCurrentBalance(BigDecimal currentBalance) {
		this.currentBalance = currentBalance;
	}
	public BigDecimal getCurrentArrearsAmount() {
		return currentArrearsAmount;
	}
	public void setCurrentArrearsAmount(BigDecimal currentArrearsAmount) {
		this.currentArrearsAmount = currentArrearsAmount;
	}
	public PeriodMovementsType getCurrentPeriodMovements() {
		return currentPeriodMovements;
	}
	public void setCurrentPeriodMovements(PeriodMovementsType currentPeriodMovements) {
		this.currentPeriodMovements = currentPeriodMovements;
	}
	public PseudoChargeInfoByCustomerType getPreviousPseudoChargeInfo() {
		return previousPseudoChargeInfo;
	}
	public void setPreviousPseudoChargeInfo(PseudoChargeInfoByCustomerType previousPseudoChargeInfo) {
		this.previousPseudoChargeInfo = previousPseudoChargeInfo;
	}
	public List<CurrentDDTWithTransactionsAndIncomesType> getDrawdownTerms() {
		return drawdownTerms;
	}
	public void setDrawdownTerms(List<CurrentDDTWithTransactionsAndIncomesType> drawdownTerms) {
		this.drawdownTerms = drawdownTerms;
	}

}
