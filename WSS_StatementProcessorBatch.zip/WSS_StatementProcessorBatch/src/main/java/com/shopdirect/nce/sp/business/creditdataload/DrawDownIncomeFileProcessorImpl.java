/**
 * 
 */
package com.shopdirect.nce.sp.business.creditdataload;

import java.io.File;
import java.io.FileReader;
import java.io.LineNumberReader;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.shopdirect.nce.sp.constants.CreditLoadDataConstants;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.dao.creditdataload.DrawDownIncomeDaoImpl;
import com.shopdirect.nce.sp.dao.creditdataload.SpCreditFilLoadControlDaoImpl;
import com.shopdirect.nce.sp.exception.BuisnessException;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.DrawdownIncome;
import com.shopdirect.nce.sp.util.FinFileBaseProcessor;
import com.shopdirect.nce.sp.util.StatementProcessorBatchUtil;

/**
 * @author AyantikaBiswas
 *
 */
public class DrawDownIncomeFileProcessorImpl extends FinFileBaseProcessor implements DataFileProcessor {

	private DrawDownIncomeDaoImpl drawDownIncomeDaoImpl;	

	public DrawDownIncomeFileProcessorImpl() throws StatementProcessorBatchException {
		super();
	}

	/**
	 * @param folder
	 * @return
	 * @throws StatementProcessorBatchException
	 */
	public boolean processFile(File folder, long batchID, int user, String batchRunDate) throws StatementProcessorBatchException {
		getLogger().debug("[DrawDownIncomeFileProcessorImpl -- processFile]  -- START");
		String fileName = StatementProcessorBatchUtil.generateFileName(CreditLoadDataConstants.DRAWDOWNINCOME,
				CreditLoadDataConstants.NEW_STATUS, batchRunDate);
		File file = getFile(folder, fileName);
		String line = "";
		String comma = ",";
		List<Map<String, Object>> columns = getColumns(StatementProcessorBatchConstants.DRAWDOWN_INCOME_DATA_MAPPING,
				StatementProcessorBatchConstants.DRAWDOWN_INCOME_MAP);
		String fileIdentifier = getCommonConfigHelper().readConfigData(getDataconfig(), "DRAWDOWNINCOME");
		String insertedMessage = null;
		String errorMessage = StatementProcessorBatchConstants.EMPTY_STRING;
		int insertCount;
		List<DrawdownIncome> drawdownIncomeRecords = null;
		boolean insertedDrawDownIncome = false;
		SpCreditFilLoadControlDaoImpl spCreditFilLoadControlDaoImpl = new SpCreditFilLoadControlDaoImpl();
		
		Object[] procReturnVal = new Object[2];
		int retCode = 0;
		String retMsg = null;

		try (LineNumberReader reader = new LineNumberReader(new FileReader(file))) {
			int records = getRecordsCount(this.getFinancierFilePath() + file.getName());
			/**
			 * Insert data in Control Table and pass the Batch Id
			 */
			insertSpLoadControlData(batchID, file.getName(), fileIdentifier, user);
			String header = reader.readLine();
			if(records == StatementProcessorBatchConstants.HEADER_RECORD){
				insertedDrawDownIncome = true ;
			}
			else {				
				while ((reader.getLineNumber()) < records) {
					drawdownIncomeRecords = new ArrayList<>();
					for (insertCount = 0; insertCount<getBatchInsertcount() ;insertCount++ ){					
						if ((line = reader.readLine())!= null){	
							String[] contents = line.split(comma, -1);
							//Check number of data in xml and .dat file is same or not
							if (columns.size() != contents.length) {
								throw new Exception(CreditLoadDataConstants.MISMATCH_ON_COLUMN_COUNT);
							}
							DrawdownIncome drawdownIncome = new DrawdownIncome();
							// Set batchId in DrawdownItem
							drawdownIncome.setBatchId(batchID);
							drawdownIncome.setCreatedByUser(Long.valueOf(user));
							drawdownIncomeRecords.add(drawdownIncome);
							constructObjects(contents, columns, drawdownIncome);
						} else{
							break;
						}
					}
					procReturnVal = getDrawDownIncomeDaoImpl().insertDrawDownIncomeData(drawdownIncomeRecords);
					retCode = (int) procReturnVal[0];
					retMsg = (String) procReturnVal[1];
					
					// update the CONTROL table and DELETE if INSERTION fails
					if (retCode == 0) {
						insertedDrawDownIncome = true;
					} else {
						insertedDrawDownIncome = false;
						errorMessage = retMsg;
					}				
				}
			}

			/**
			 * Update the CONTROL table with batch id and error messege
			 */
			spCreditFilLoadControlDaoImpl.updateControlData(batchID, insertedDrawDownIncome, errorMessage, fileIdentifier);

		} catch (Exception exception) {
			insertedMessage = exception.getMessage();
			errorMessage = insertedMessage;
			insertedDrawDownIncome = false;
			/**
			 * Update the CONTROL table with batch id and error messege
			 */
			try {
				spCreditFilLoadControlDaoImpl.updateControlData(batchID, insertedDrawDownIncome, errorMessage, fileIdentifier);
			} catch (BuisnessException buisnessException) {
				getLogger()
						.debug("[DrawDownIncomeFileProcessorImpl -- processFile] -- Control Table Update Exception: "
								+ buisnessException);
			} catch (SQLException sqlException) {
				getLogger()
						.debug("[DrawDownIncomeFileProcessorImpl -- processFile] -- Control Table Update Exception: "
								+ sqlException);
			} catch (Exception exception2) {
				getLogger()
						.debug("[DrawDownIncomeFileProcessorImpl -- processFile] -- Control Table Update Exception: "
								+ exception2);
			}

			getLogger()
					.error("[DrawDownIncomeFileProcessorImpl -- processFile] -- DrawDown Income insert Error occured");
			getLogger().debug(
					"[DrawDownIncomeFileProcessorImpl -- processFile] -- DrawDown Income Exception: " + exception);
			
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_BUSINESS_ERROR_CODE,
					"[DrawDownIncomeFileProcessorImpl-processDrawDownIncome] StatementProcessorBatchException Block",
					"DrawDown Income Exception " + errorMessage, null, null,
					new StatementProcessorBatchException());
		}
		getLogger().debug("[DrawDownIncomeFileProcessorImpl -- processFile]  -- END");
		return insertedDrawDownIncome;
	}
	
	/**
	 * @return the drawDownItemDaoImpl
	 * @throws StatementProcessorBatchException 
	 */
	public DrawDownIncomeDaoImpl getDrawDownIncomeDaoImpl() throws StatementProcessorBatchException {
		if(drawDownIncomeDaoImpl == null) {
			drawDownIncomeDaoImpl = new DrawDownIncomeDaoImpl();
		}
		return drawDownIncomeDaoImpl;
	}

	/**
	 * @param drawDownItemDaoImpl the drawDownItemDaoImpl to set
	 */
	public void setDrawDownIncomeDaoImpl(DrawDownIncomeDaoImpl drawDownItemDaoImpl) {
		this.drawDownIncomeDaoImpl = drawDownItemDaoImpl;
	}	
}
