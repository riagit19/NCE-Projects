package com.shopdirect.nce.sp.model;

import java.sql.Timestamp;

public class SpErrorLog {

	private Long errorLogId;

	private String programName;
	
	private String exeStat;
	
	private String statusMsg;
	
	private String stepNumber;
	
	private String stepDesc;
	
	private String stepStatus;
	
	private String errDesc;
	
	private Timestamp startDate;
	
	private Timestamp endDate;

	private String errCode;
	

	public Timestamp getEndDate() {
		return endDate;
	}


	public void setEndDate(Timestamp endDate) {
		this.endDate = endDate;
	}


	public String getProgramName() {
		return programName;
	}


	public void setProgramName(String programName) {
		this.programName = programName;
	}


	public String getExeStat() {
		return exeStat;
	}


	public void setExeStat(String exeStat) {
		this.exeStat = exeStat;
	}


	public String getStatusMsg() {
		return statusMsg;
	}


	public void setStatusMsg(String statusMsg) {
		this.statusMsg = statusMsg;
	}


	public String getStepNumber() {
		return stepNumber;
	}


	public void setStepNumber(String stepNumber) {
		this.stepNumber = stepNumber;
	}


	public String getStepDesc() {
		return stepDesc;
	}


	public void setStepDesc(String stepDesc) {
		this.stepDesc = stepDesc;
	}


	public String getStepStatus() {
		return stepStatus;
	}


	public void setStepStatus(String stepStatus) {
		this.stepStatus = stepStatus;
	}


	public String getErrDesc() {
		return errDesc;
	}


	public void setErrDesc(String errDesc) {
		this.errDesc = errDesc;
	}


	public Timestamp getStartDate() {
		return startDate;
	}


	public void setStartDate(Timestamp startDate) {
		this.startDate = startDate;
	}


	public String getErrCode() {
		return errCode;
	}


	public void setErrCode(String errCode) {
		this.errCode = errCode;
	}


	public Long getErrorLogId() {
		return errorLogId;
	}
	
	
	
}
