package com.shopdirect.nce.sp.model;

public class StatementProcessorBatchFault {
	
	private String operationName;
	private String faultErroCode; 
	private String faultErrorDesc;
	private String faultFactor;
	
	
	public StatementProcessorBatchFault(){
		
	}
	
	public StatementProcessorBatchFault(String operationName){
		this.operationName = operationName;
	}

	/**
	 * @return the operationName
	 */
	public String getOperationName() {
		return operationName;
	}

	/**
	 * @param operationName the operationName to set
	 */
	public void setOperationName(String operationName) {
		this.operationName = operationName;
	}

	/**
	 * @return the faultErroCode
	 */
	public String getFaultErroCode() {
		return faultErroCode;
	}

	/**
	 * @param faultErroCode the faultErroCode to set
	 */
	public void setFaultErroCode(String faultErroCode) {
		this.faultErroCode = faultErroCode;
	}

	/**
	 * @return the faultErrorDesc
	 */
	public String getFaultErrorDesc() {
		return faultErrorDesc;
	}

	/**
	 * @param faultErrorDesc the faultErrorDesc to set
	 */
	public void setFaultErrorDesc(String faultErrorDesc) {
		this.faultErrorDesc = faultErrorDesc;
	}

	/**
	 * @return the faultFactor
	 */
	public String getFaultFactor() {
		return faultFactor;
	}

	/**
	 * @param faultFactor the faultFactor to set
	 */
	public void setFaultFactor(String faultFactor) {
		this.faultFactor = faultFactor;
	}
	
	

}
