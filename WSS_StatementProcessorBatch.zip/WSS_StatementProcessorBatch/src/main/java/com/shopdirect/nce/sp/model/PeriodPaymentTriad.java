package com.shopdirect.nce.sp.model;

import java.math.BigDecimal;

public class PeriodPaymentTriad {

	private String agreementID;
	private BigDecimal paymentAmountCredit;
	private BigDecimal paymentAmountDebit;
	
	public String getAgreementID() {
		return agreementID;
	}
	public void setAgreementID(String agreementID) {
		this.agreementID = agreementID;
	}
	public BigDecimal getPaymentAmountCredit() {
		return paymentAmountCredit;
	}
	public void setPaymentAmountCredit(BigDecimal paymentAmountCredit) {
		this.paymentAmountCredit = paymentAmountCredit;
	}
	public BigDecimal getPaymentAmountDebit() {
		return paymentAmountDebit;
	}
	public void setPaymentAmountDebit(BigDecimal paymentAmountDebit) {
		this.paymentAmountDebit = paymentAmountDebit;
	}
	
}
