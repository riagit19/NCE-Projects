package com.shopdirect.nce.sp.model;

import java.util.Date;

public class Drawdown {
	
	private String drawdownId;
	
	private String agreementId;
	
	private Long agreementSeqNumber;
	
	private Date bnplEndDate;

	private Double defInterestAmount;
	
	private Date drawdownEndDate;
	
	private Double installmentAmount;
	
	private Double interestRate;
	
	private Double optOutAmount;
	
	private Double outstandingBalance;
	
	private Double outstandingCapital;
	
	private Double outstandingInterestAmount;
	
	private Double installmentAmt;
	
	private Double outBalanceInt;
	
	private Double outCapitalInt;
	
	private Double outInterest;
	
	private Integer period;
	
	private Integer drawdownTerm;
	
	private String prodCode;
	
	private String rateType;
	
	private Date startDate;
	
	private String statCode;
	
	private Double broughtForwardBalance;
	
	private Double bfInitialBalance;
	
	private Date closedDate;
	
	private String drawdownSettledInd;
	
	private Date promotionEndDate;
	
	private Double settlementFee;
	
	private Double prevInterestRate;
	
	private Long batchId;
	
	private String errorFlag;
	
	private String errorMessage;
	
	private Date creationDate;
	
	private Long createdByUser;
	
	private Date lastUpdateDate;
	
	private Long lastUpdateByUser;

	public String getDrawdownId() {
		return drawdownId;
	}

	public void setDrawdownId(String drawdownId) {
		this.drawdownId = drawdownId;
	}

	public String getAgreementId() {
		return agreementId;
	}

	public void setAgreementId(String agreementId) {
		this.agreementId = agreementId;
	}

	public Long getAgreementSeqNumber() {
		return agreementSeqNumber;
	}

	public void setAgreementSeqNumber(Long agreementSeqNumber) {
		this.agreementSeqNumber = agreementSeqNumber;
	}

	public Date getBnplEndDate() {
		return bnplEndDate;
	}

	public void setBnplEndDate(Date bnplEndDate) {
		this.bnplEndDate = bnplEndDate;
	}

	public Double getDefInterestAmount() {
		return defInterestAmount;
	}

	public void setDefInterestAmount(Double defInterestAmount) {
		this.defInterestAmount = defInterestAmount;
	}

	public Date getDrawdownEndDate() {
		return drawdownEndDate;
	}

	public void setDrawdownEndDate(Date drawdownEndDate) {
		this.drawdownEndDate = drawdownEndDate;
	}

	public Double getInstallmentAmount() {
		return installmentAmount;
	}

	public void setInstallmentAmount(Double installmentAmount) {
		this.installmentAmount = installmentAmount;
	}

	public Double getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(Double interestRate) {
		this.interestRate = interestRate;
	}

	public Double getOptOutAmount() {
		return optOutAmount;
	}

	public void setOptOutAmount(Double optOutAmount) {
		this.optOutAmount = optOutAmount;
	}

	public Double getOutstandingBalance() {
		return outstandingBalance;
	}

	public void setOutstandingBalance(Double outstandingBalance) {
		this.outstandingBalance = outstandingBalance;
	}

	public Double getOutstandingCapital() {
		return outstandingCapital;
	}

	public void setOutstandingCapital(Double outstandingCapital) {
		this.outstandingCapital = outstandingCapital;
	}

	public Double getOutstandingInterestAmount() {
		return outstandingInterestAmount;
	}

	public void setOutstandingInterestAmount(Double outstandingInterestAmount) {
		this.outstandingInterestAmount = outstandingInterestAmount;
	}

	public Double getInstallmentAmt() {
		return installmentAmt;
	}

	public void setInstallmentAmt(Double installmentAmt) {
		this.installmentAmt = installmentAmt;
	}

	public Double getOutBalanceInt() {
		return outBalanceInt;
	}

	public void setOutBalanceInt(Double outBalanceInt) {
		this.outBalanceInt = outBalanceInt;
	}

	public Double getOutCapitalInt() {
		return outCapitalInt;
	}

	public void setOutCapitalInt(Double outCapitalInt) {
		this.outCapitalInt = outCapitalInt;
	}

	public Double getOutInterest() {
		return outInterest;
	}

	public void setOutInterest(Double outInterest) {
		this.outInterest = outInterest;
	}

	public Integer getPeriod() {
		return period;
	}

	public void setPeriod(Integer period) {
		this.period = period;
	}

	public Integer getDrawdownTerm() {
		return drawdownTerm;
	}

	public void setDrawdownTerm(Integer drawdownTerm) {
		this.drawdownTerm = drawdownTerm;
	}

	public String getProdCode() {
		return prodCode;
	}

	public void setProdCode(String prodCode) {
		this.prodCode = prodCode;
	}

	public String getRateType() {
		return rateType;
	}

	public void setRateType(String rateType) {
		this.rateType = rateType;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public String getStatCode() {
		return statCode;
	}

	public void setStatCode(String statCode) {
		this.statCode = statCode;
	}

	public Double getBroughtForwardBalance() {
		return broughtForwardBalance;
	}

	public void setBroughtForwardBalance(Double broughtForwardBalance) {
		this.broughtForwardBalance = broughtForwardBalance;
	}

	public Double getBfInitialBalance() {
		return bfInitialBalance;
	}

	public void setBfInitialBalance(Double bfInitialBalance) {
		this.bfInitialBalance = bfInitialBalance;
	}

	public Date getClosedDate() {
		return closedDate;
	}

	public void setClosedDate(Date closedDate) {
		this.closedDate = closedDate;
	}

	public String getDrawdownSettledInd() {
		return drawdownSettledInd;
	}

	public void setDrawdownSettledInd(String drawdownSettledInd) {
		this.drawdownSettledInd = drawdownSettledInd;
	}

	public Date getPromotionEndDate() {
		return promotionEndDate;
	}

	public void setPromotionEndDate(Date promotionEndDate) {
		this.promotionEndDate = promotionEndDate;
	}

	public Double getSettlementFee() {
		return settlementFee;
	}

	public void setSettlementFee(Double settlementFee) {
		this.settlementFee = settlementFee;
	}

	public Long getBatchId() {
		return batchId;
	}

	public void setBatchId(Long batchId) {
		this.batchId = batchId;
	}

	public String getErrorFlag() {
		return errorFlag;
	}

	public void setErrorFlag(String errorFlag) {
		this.errorFlag = errorFlag;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public Long getCreatedByUser() {
		return createdByUser;
	}

	public void setCreatedByUser(Long createdByUser) {
		this.createdByUser = createdByUser;
	}

	public Date getLastUpdateDate() {
		return lastUpdateDate;
	}

	public void setLastUpdateDate(Date lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}

	public Long getLastUpdateByUser() {
		return lastUpdateByUser;
	}

	public void setLastUpdateByUser(Long lastUpdateByUser) {
		this.lastUpdateByUser = lastUpdateByUser;
	}

	public Double getPrevInterestRate() {
		return prevInterestRate;
	}

	public void setPrevInterestRate(Double prevInterestRate) {
		this.prevInterestRate = prevInterestRate;
	}
	
	

}
