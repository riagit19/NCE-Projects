/**
 * 
 */
package com.shopdirect.nce.sp.dao.creditdataload;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

import com.shopdirect.nce.common.extcnfg.ExternalFileDataConfiguration;
import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.Query;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.dao.AccountReassessmentBaseDao;
import com.shopdirect.nce.sp.exception.BuisnessException;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.util.CommonConfigHelper;
import com.shopdirect.nce.sp.util.UCPConnection;

/**
 * @author MeghnaBhattacharya
 *
 */
@SuppressWarnings("serial")
public class FinancierDataDeleteDaoImpl extends AccountReassessmentBaseDao {

	public FinancierDataDeleteDaoImpl() throws StatementProcessorBatchException {
		super();
		// TODO Auto-generated constructor stub
	}
	
	boolean isDeleteSuccess = false;
	Connection connection = null;
	int retCode = 0;
	String retMsg = null;
	CallableStatement statement = null;
	private static SDLoggerImpl logger = new SDLoggerImpl();
	long batchID = 0;
	
	/**
	 * @param agreementList
	 * @return
	 * @throws BuisnessException
	 * @throws StatementProcessorBatchException 
	 * @throws Exception
	 */
	public boolean deleteAllData(long batchID)
			throws BuisnessException, SQLException, StatementProcessorBatchException{
		logger.debug("[FinancierDataDeleteDaoImpl -- deleteAllData]  -- START");
		CommonConfigHelper commonConfigHelper = CommonConfigHelper.getInstance();
		try {
			connection = UCPConnection.getConnection();
			setSpMainSchema(getSchema(StatementProcessorBatchConstants.DB_SCHEMA_MAIN_SP_KEY));
			
			ExternalFileDataConfiguration Dbconfig = commonConfigHelper.loadPropertyConfig("spDbConfig");
			String DELETE_DATA_ALL_PACK = commonConfigHelper.readConfigData(Dbconfig, "CREDIT_DATA_LOAD_PACK");
			String PRC_DELETE_DATA_ALL = commonConfigHelper.readConfigData(Dbconfig, "PRC_DELETE_DATA_ALL");

			// Delete data from All tables
			String deleteQuery = Query.getDeleteDataQuery(getSpMainSchema(), DELETE_DATA_ALL_PACK, PRC_DELETE_DATA_ALL);
			
			statement = connection.prepareCall(deleteQuery);
			statement.setLong(1, batchID);
			statement.registerOutParameter(2, java.sql.Types.INTEGER);
			statement.registerOutParameter(3, java.sql.Types.CHAR);
		
			statement.executeUpdate();
			retCode = statement.getInt(2);
			retMsg = statement.getString(3);

			if (retCode == 0) {
				isDeleteSuccess = false;
			} else {
				isDeleteSuccess = true;

			}

			logger.debug("[FinancierDataDeleteDaoImpl -- deleteAllData]  -- END");

		} catch (SQLException sqlException) {
			isDeleteSuccess = false;
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_DB_ERROR_CODE,
					"[SpCreditFilLoadControlDaoImpl-deleteAllData] SQLException Block",
					"Database execution exception [SQLCode: " + sqlException.getSQLState() + "] , SQL Detail "
							+ sqlException.getMessage(),
					null, null, sqlException);

		} catch (Exception exception) {
			isDeleteSuccess = false;
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.CONNECTTION_DB_ERROR_CODE,
					"[SpCreditFilLoadControlDaoImpl-deleteAllData] Exception Block",
					"Database execution exception " + exception.getMessage(), null, null, exception);

		} finally {

			try {

				if (statement != null) {
					statement.close();
				}

				if (connection != null) {
					connection.close();
				}

			} catch (Exception e) {
				logger.debug("[SpCreditFilLoadControlDaoImpl-deleteAllData]  -- Exception Block, Database execution exception "+e.getMessage());					
			}
		}

		return isDeleteSuccess;
	}

}
