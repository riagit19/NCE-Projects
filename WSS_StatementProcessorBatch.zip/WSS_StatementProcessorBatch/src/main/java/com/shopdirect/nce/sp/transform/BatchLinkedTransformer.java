package com.shopdirect.nce.sp.transform;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.rule.model.Account;
import com.shopdirect.nce.sp.model.AccountingSnapshotTriad;
import com.shopdirect.nce.sp.model.AgreementTriad;
import com.shopdirect.nce.sp.model.BatchLinked;
import com.shopdirect.nce.sp.model.CustomerAccountInfo;
import com.shopdirect.nce.sp.model.CustomerContractTriad;
import com.shopdirect.nce.sp.model.RetailContractTriad;

public class BatchLinkedTransformer {

	private static SDLoggerImpl logger = new SDLoggerImpl();
	
	public List<BatchLinked> getBatchLinked(List<RetailContractTriad> retailContractTriadList,
			List<AccountingSnapshotTriad> accountingSnapshotTriadList,
			List<CustomerContractTriad> customerContractTriadList, List<AgreementTriad> agreementTriadList,
			CustomerAccountInfo accountInfo, Account accountRule) {
		
		logger.debug("[BatchLinkedTransformer - getBatchLinked] - Start");
		
		List<BatchLinked> batchLinkedList = new ArrayList<BatchLinked>();
		BatchLinked batchLinkedObj;
		for(int i = 0; i < customerContractTriadList.size(); i++) {

			batchLinkedObj = new BatchLinked();
			CustomerContractTriad custContTriad = customerContractTriadList.get(i);
			batchLinkedObj.setBatchLinkedOccurence(new BigDecimal(i));
			batchLinkedObj.setCustomerAccountNumber(accountInfo.getPublicAccountId());
			batchLinkedObj.setAccountTypeCode(custContTriad.getAccountTypeCode());
			batchLinkedObj.setDateStart(custContTriad.getStartDate());
			batchLinkedObj.setDateClosed(custContTriad.getAccountClosedDate());
			batchLinkedObj.setDateRestart(custContTriad.getAccountRestartDate());
			batchLinkedObj.setDateStartDelinquency(custContTriad.getStartDellDate());
			batchLinkedObj.setBlockCode(accountInfo.getSpecialAttCode());
			batchLinkedObj.setBehaviourScore(custContTriad.getAlignedBehaviourScore());
			batchLinkedObj.setAlignedBehaviourScore(custContTriad.getAlignedBehaviourScore());
			batchLinkedObj.setCreditRiskFactor(custContTriad.getCreditRiskFactor());
			batchLinkedObj.setRecruitmentCRF(custContTriad.getRecruitCrf());
			batchLinkedObj.setDateLastCreditLimitDecrease(custContTriad.getCredLimitDecDate());
			batchLinkedObj.setDateLastCreditLimitIncrease(custContTriad.getCreditLimitIncrDate());
			batchLinkedObj.setArrearsBucket1(new BigDecimal(0));
			batchLinkedObj.setArrearsBucket2(new BigDecimal(0));
			batchLinkedObj.setArrearsBucket3(new BigDecimal(0));
			batchLinkedObj.setArrearsBucket4(new BigDecimal(0));
			batchLinkedObj.setArrearsBucket5(new BigDecimal(0));
			batchLinkedObj.setArrearsBucket6(new BigDecimal(0));
			batchLinkedObj.setCreditLimitFrozenInd(custContTriad.getCreditLimitFrozenCode());
			batchLinkedObj.setAccountStatusCode(custContTriad.getAccountStatusCode());
			batchLinkedObj.setFidFlagDate(null);
			batchLinkedObj.setCreditStatusCode(custContTriad.getCreditStatusCode());
			batchLinkedObj.setCreditStatusSubCode(custContTriad.getCreditStatusSubCode());
			batchLinkedObj.setLastFollowUpCode(custContTriad.getLastFollowUpCode());
			batchLinkedObj.setCreditBand(custContTriad.getCreditBand());
			batchLinkedObj.setTotalUnchargedMvmts(new BigDecimal(0));
			batchLinkedObj.setMinPayment(accountRule.getMinPayment() != null ? accountRule.getMinPayment().getValue() : null);
			batchLinkedObj.setPastDue(BigDecimal.ONE);
			if (retailContractTriadList.size() > i) {
				
				RetailContractTriad retContTriad = retailContractTriadList.get(i);
				batchLinkedObj.setDateLastRetailOrder(retContTriad.getLastOrderDate());
				batchLinkedObj.setLastPaymentAmount(retContTriad.getLastPaymentAmt());
				batchLinkedObj.setPpiInd(retContTriad.getPpiInd());
				batchLinkedObj.setFidScoreDate(retContTriad.getFidScoreDate());
				batchLinkedObj.setFidScore(retContTriad.getFidScore());
				batchLinkedObj.setFidScoreWorst(retContTriad.getFidScoreWorst());
				batchLinkedObj.setCreditPaymentsTotal(retContTriad.getCreditPaymentsTotal());
				batchLinkedObj.setDateLastPayment(retContTriad.getDateLastPay());
				
			}
			
			if (agreementTriadList.size() > i) {
				
				AgreementTriad agrmntTriad = agreementTriadList.get(i);
				batchLinkedObj.setScheduledPaymentAmt(BigDecimal.ONE);
				batchLinkedObj.setDateLastZeroBalance(agrmntTriad.getLastZeroBal());
				batchLinkedObj.setCurrentBalance(agrmntTriad.getBalance());
				if (agrmntTriad.getPurchaseAmtTSP() != null && agrmntTriad.getReturnsAmtTSP() != null) {
					batchLinkedObj.setNetSalesValueTSPAmt(agrmntTriad.getPurchaseAmtTSP().add(agrmntTriad.getReturnsAmtTSP()));
				}
				batchLinkedObj.setReturnsAmountTSP(agrmntTriad.getReturnsAmtTSP());
				batchLinkedObj.setDebitAmount(new BigDecimal(0));
				batchLinkedObj.setOtherAdjustmentsAmountTSP(agrmntTriad.getOtherAdjAmtTSP());
				batchLinkedObj.setTotalFeesTSP(agrmntTriad.getTotFeesTSP());
				batchLinkedObj.setNumReturnedPaymentsTSP(agrmntTriad.getNumRetPayTSP());
				batchLinkedObj.setBnplBalance(agrmntTriad.getBnplBalance());
				batchLinkedObj.setScheduledPaymentsPastDue(BigDecimal.ONE);
				batchLinkedObj.setoTB(agrmntTriad.getAvailableToSpend());
				batchLinkedObj.setPaymentAmountTSP(agrmntTriad.getPayAmtTSP());
				batchLinkedObj.setCreditLimit(agrmntTriad.getCreditLimit());
				batchLinkedObj.setNumPaymentsTSP(agrmntTriad.getNumPayTSP());	
				
			}
			
			if (accountingSnapshotTriadList.size() > i) {
				
				AccountingSnapshotTriad accSnptTriad = accountingSnapshotTriadList.get(i);
				batchLinkedObj.setHighBalance(accSnptTriad.getHighBalanceAmt());
				batchLinkedObj.setHighDelq(accSnptTriad.getHighDelq());
				batchLinkedObj.setNumCycle1(accSnptTriad.getNumCycle1());
				batchLinkedObj.setNumCycle2(accSnptTriad.getNumCycle2());
				batchLinkedObj.setNumCycle3(accSnptTriad.getNumCycle3());
				batchLinkedObj.setNumCycle4(accSnptTriad.getNumCycle4());
				
			}
			
			batchLinkedList.add(batchLinkedObj);
		}
		
		logger.debug("[BatchLinkedTransformer - getBatchLinked] - End");
		return batchLinkedList;
	}
}
