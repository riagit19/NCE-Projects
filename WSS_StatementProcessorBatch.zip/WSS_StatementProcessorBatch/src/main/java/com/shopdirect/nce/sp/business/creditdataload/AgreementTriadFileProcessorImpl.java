package com.shopdirect.nce.sp.business.creditdataload;

import java.io.File;
import java.io.FileReader;
import java.io.LineNumberReader;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.shopdirect.nce.sp.constants.CreditLoadDataConstants;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.dao.creditdataload.AgreementTriadDaoImpl;
import com.shopdirect.nce.sp.dao.creditdataload.SpCreditFilLoadControlDaoImpl;
import com.shopdirect.nce.sp.exception.BuisnessException;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.AgreementTriadType;
import com.shopdirect.nce.sp.util.FinFileBaseProcessor;
import com.shopdirect.nce.sp.util.StatementProcessorBatchUtil;

public class AgreementTriadFileProcessorImpl extends FinFileBaseProcessor implements DataFileProcessor {
	
	private AgreementTriadDaoImpl agreementTriadDaoImpl;

	public AgreementTriadFileProcessorImpl() throws StatementProcessorBatchException {
		super();
	}
	
	public boolean processFile(File folder, long batchID, int user, String batchRunDate) throws StatementProcessorBatchException {
		getLogger().debug("[AgreementTriadFileProcessorImpl -- processFile]  -- START");
		List<Map<String, Object>> columns;
		final String fileName = StatementProcessorBatchUtil.generateFileName(CreditLoadDataConstants.AGREEMENTTRIAD,
				CreditLoadDataConstants.NEW_STATUS, batchRunDate);
		File file = getFile(folder, fileName);
		String line = "";
		String comma = ",";
		columns = getColumns(StatementProcessorBatchConstants.AGREEMENT_TRIAD_DATA_MAPPING,
				StatementProcessorBatchConstants.AGREEMENT_TRIAD_MAP);
		String fileIdentifier = getCommonConfigHelper().readConfigData(getDataconfig(), "AGREEMENTTRIAD");
		String insertedMessage = null;
		String errorMessage = StatementProcessorBatchConstants.EMPTY_STRING;
		int insertCount;
		List<AgreementTriadType> agreementTriadRecords = null;
		boolean insertedAgreementTriad = false;
		SpCreditFilLoadControlDaoImpl spCreditFilLoadControlDaoImpl = new SpCreditFilLoadControlDaoImpl();
		
		Object[] procReturnVal = new Object[2];
		int retCode = 0;
		String retMsg = null;

		try (LineNumberReader reader = new LineNumberReader(new FileReader(file))) {
			int records = getRecordsCount(this.getFinancierFilePath() + file.getName());
			/**
			 * Insert data in Control Table and pass the Batch Id
			 */
			insertSpLoadControlData(batchID, file.getName(), fileIdentifier, user);
			String header = reader.readLine();
			if(records == StatementProcessorBatchConstants.HEADER_RECORD){
				insertedAgreementTriad = true ;
			}
			else {
				while ((reader.getLineNumber()) < records) {
					agreementTriadRecords = new ArrayList<AgreementTriadType>();
					for (insertCount = 0; insertCount<getBatchInsertcount() ;insertCount++ ){					
						if ((line = reader.readLine())!= null){						
							String[] contents = line.split(comma, -1);
							//Check number of data in xml and .dat file is same or not
							if (columns.size() != contents.length) {
								throw new Exception(CreditLoadDataConstants.MISMATCH_ON_COLUMN_COUNT);
							}
							AgreementTriadType agreementTriad = new AgreementTriadType();
							// Set batchId in Agreement
							agreementTriad.setBatchId(batchID);
							agreementTriad.setCreatedByUser(Long.valueOf(user));
							agreementTriadRecords.add(agreementTriad);
							constructObjects(contents, columns, agreementTriad);	
						} else{
							break;
						}								
					}				
					
					procReturnVal = getAgreementTriadDaoImpl().insertAgreementTriadData(agreementTriadRecords);
					retCode = (int) procReturnVal[0];
					retMsg = (String) procReturnVal[1];
					
					// update the CONTROL table and DELETE if INSERTION fails
					if (retCode == 0) {
						insertedAgreementTriad = true;
					} else {
						insertedAgreementTriad = false;
						errorMessage = retMsg;
					}
					
				}
			}
			
			/**
			 * Update the CONTROL table with batch id and error messege
			 */
			spCreditFilLoadControlDaoImpl.updateControlData(batchID, insertedAgreementTriad, errorMessage, fileIdentifier);

		} catch (Exception exception) {
			insertedMessage = exception.getMessage();
			errorMessage = insertedMessage;
			insertedAgreementTriad = false;
			/**
			 * Update the CONTROL table with batch id and error messege
			 */
			try {
				spCreditFilLoadControlDaoImpl.updateControlData(batchID, insertedAgreementTriad, errorMessage, fileIdentifier);
			} catch (BuisnessException | SQLException ex) {
				getLogger()
						.debug("[AgreementTriadFileProcessorImpl -- processFile] -- Control Table Update Exception: "
								+ ex);
			}  catch (Exception exception2) {
				getLogger()
						.debug("[AgreementTriadFileProcessorImpl -- processFile] -- Control Table Update Exception: "
								+ exception2);
			}

			getLogger()
					.error("[AgreementTriadFileProcessorImpl -- processFile] -- Agreement Insert Error occured ");
			getLogger()
					.debug("[AgreementTriadFileProcessorImpl -- processFile] -- Agreement Exception: " + exception);
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_BUSINESS_ERROR_CODE,
					"[AgreementTriadFileProcessorImpl-processFile] StatementProcessorBatchException Block",
					"Agreement Triad Exception " + errorMessage, null, null,
					new StatementProcessorBatchException());
		}
		getLogger().debug("[AgreementFileProcessorImpl -- processFile]  -- END");
		return insertedAgreementTriad;
	}

	public AgreementTriadDaoImpl getAgreementTriadDaoImpl() throws StatementProcessorBatchException {
		if(agreementTriadDaoImpl == null) {
			agreementTriadDaoImpl = new AgreementTriadDaoImpl();
		}
		return agreementTriadDaoImpl;
	}

	public void setAgreementTriadDaoImpl(AgreementTriadDaoImpl agreementTriadDaoImpl) {
		this.agreementTriadDaoImpl = agreementTriadDaoImpl;
	}


}
