package com.shopdirect.nce.sp.model;

import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class CustomerAccountInfo {

	
	private String AccountInfoId ;
	private String PublicAccountId ;

	private String CreditAccountId ;
	private String RetailAccountId ;
	private Integer LinkedAccntIndex ;
	private Date StatementDate ;
	private Date PmtDueDate ;
	
	private Date PendingPdd ;
	private String StmtOffsetDaysFrmPdd ;
	private String BrandCode ;
	private String BrandType ;
	private String SpecialAttCode ;
	private String LateArrearsInd ;
	private Double CedtRiskFactor ;
	private String Title ;
	private String Surname ;
	private String Initials ;
	private String Forename ;
	private String Gender ;
	private String Email ;
	private String NationalDialCode ;
	private String MobileNumber ;
	private String AddressLine1 ;
	private String AddressLine2 ;
	private String AddressLine3 ;
	private String AddressLine4 ;
	private String PostCode ;
	private String DeliveryPtSuffix ;
	private String CountryName ;
	private String AccountStatus ;
	private String PrevAccountStatus ;
	private String CreditStatus ;
	private String DeliverNxtStatToOfc ;
	private String OnlineStmtInd ;
	private String DoNotPrintStmt ;
	private String Status ;
	private Date CreatedTimestmp ;
	private Date ModifiedTimestmp ;
	private Date DOB ;
	private Date DateAccntStatChng ; 
	private String customerId;
	private String auditLevel;
	private Date creditStartDate;

	public CustomerAccountInfo(){
		// Default Constructor
	}
	
	public CustomerAccountInfo(String accountInfoId, String publicAccountId, String creditAccountId,
			String retailAccountId, Integer linkedAccntIndex, Date statementDate, Date pmtDueDate, Date pendingPdd,
			String stmtOffsetDaysFrmPdd, String brandCode, String brandType, String specialAttCode,
			String lateArrearsInd, Double cedtRiskFactor, String title, String surname, String initials,
			String forename, String gender, String email, String nationalDialCode, String mobileNumber,
			String addressLine1, String addressLine2, String addressLine3, String addressLine4, String postCode,
			String deliveryPtSuffix, String countryName, String accountStatus, String prevAccountStatus,
			String creditStatus, String deliverNxtStatToOfc, String onlineStmtInd, String doNotPrintStmt, String status,
			Date createdTimestmp, Date modifiedTimestmp, Date dOB, Date dateAccntStatChng,String custId) {
	
		AccountInfoId = accountInfoId;
		PublicAccountId = publicAccountId;
		CreditAccountId = creditAccountId;
		RetailAccountId = retailAccountId;
		LinkedAccntIndex = linkedAccntIndex;
		StatementDate = statementDate;
		PmtDueDate = pmtDueDate;
		PendingPdd = pendingPdd;
		StmtOffsetDaysFrmPdd = stmtOffsetDaysFrmPdd;
		BrandCode = brandCode;
		BrandType = brandType;
		SpecialAttCode = specialAttCode;
		LateArrearsInd = lateArrearsInd;
		CedtRiskFactor = cedtRiskFactor;
		Title = title;
		Surname = surname;
		Initials = initials;
		Forename = forename;
		Gender = gender;
		Email = email;
		NationalDialCode = nationalDialCode;
		MobileNumber = mobileNumber;
		AddressLine1 = addressLine1;
		AddressLine2 = addressLine2;
		AddressLine3 = addressLine3;
		AddressLine4 = addressLine4;
		PostCode = postCode;
		DeliveryPtSuffix = deliveryPtSuffix;
		CountryName = countryName;
		AccountStatus = accountStatus;
		PrevAccountStatus = prevAccountStatus;
		CreditStatus = creditStatus;
		DeliverNxtStatToOfc = deliverNxtStatToOfc;
		OnlineStmtInd = onlineStmtInd;
		DoNotPrintStmt = doNotPrintStmt;
		Status = status;
		CreatedTimestmp = createdTimestmp;
		ModifiedTimestmp = modifiedTimestmp;
		DOB = dOB;
		DateAccntStatChng = dateAccntStatChng;
		customerId = custId;
	}
	
	
	
	

	public String getAccountInfoId() {
		return AccountInfoId;
	}

	public void setAccountInfoId(String accountInfoId) {
		AccountInfoId = accountInfoId;
	}

	/**
	 * @return the publicAccountId
	 */
	public String getPublicAccountId() {
		return PublicAccountId;
	}
	/**
	 * @param publicAccountId the publicAccountId to set
	 */
	public void setPublicAccountId(String publicAccountId) {
		PublicAccountId = publicAccountId;
	}
	/**
	 * @return the creditAccountId
	 */
	public String getCreditAccountId() {
		return CreditAccountId;
	}
	/**
	 * @param creditAccountId the creditAccountId to set
	 */
	public void setCreditAccountId(String creditAccountId) {
		CreditAccountId = creditAccountId;
	}
	/**
	 * @return the retailAccountId
	 */
	public String getRetailAccountId() {
		return RetailAccountId;
	}
	/**
	 * @param retailAccountId the retailAccountId to set
	 */
	public void setRetailAccountId(String retailAccountId) {
		RetailAccountId = retailAccountId;
	}
	/**
	 * @return the linkedAccntIndex
	 */
	public Integer getLinkedAccntIndex() {
		if(LinkedAccntIndex == null) {
			LinkedAccntIndex = 0;
		}
		return LinkedAccntIndex;
	}
	/**
	 * @param linkedAccntIndex the linkedAccntIndex to set
	 */
	public void setLinkedAccntIndex(Integer linkedAccntIndex) {
		LinkedAccntIndex = linkedAccntIndex;
	}
	/**
	 * @return the statementDate
	 */
	public Date getStatementDate() {
		return StatementDate;
	}
	/**
	 * @param statementDate the statementDate to set
	 */
	public void setStatementDate(Date statementDate) {
		StatementDate = statementDate;
	}
	/**
	 * @return the pmtDueDate
	 */
	public Date getPmtDueDate() {
		return PmtDueDate;
	}
	/**
	 * @param pmtDueDate the pmtDueDate to set
	 */
	public void setPmtDueDate(Date pmtDueDate) {
		PmtDueDate = pmtDueDate;
	}
	/**
	 * @return the pendingPdd
	 */
	public Date getPendingPdd() {
		return PendingPdd;
	}
	/**
	 * @param pendingPdd the pendingPdd to set
	 */
	public void setPendingPdd(Date pendingPdd) {
		PendingPdd = pendingPdd;
	}
	/**
	 * @return the stmtOffsetDaysFrmPdd
	 */
	public String getStmtOffsetDaysFrmPdd() {
		return StmtOffsetDaysFrmPdd;
	}
	/**
	 * @param stmtOffsetDaysFrmPdd the stmtOffsetDaysFrmPdd to set
	 */
	public void setStmtOffsetDaysFrmPdd(String stmtOffsetDaysFrmPdd) {
		StmtOffsetDaysFrmPdd = stmtOffsetDaysFrmPdd;
	}
	/**
	 * @return the brandCode
	 */
	public String getBrandCode() {
		return BrandCode;
	}
	/**
	 * @param brandCode the brandCode to set
	 */
	public void setBrandCode(String brandCode) {
		BrandCode = brandCode;
	}
	/**
	 * @return the brandType
	 */
	public String getBrandType() {
		return BrandType;
	}
	/**
	 * @param brandType the brandType to set
	 */
	public void setBrandType(String brandType) {
		BrandType = brandType;
	}
	/**
	 * @return the specialAttCode
	 */
	public String getSpecialAttCode() {
		return SpecialAttCode;
	}
	/**
	 * @param specialAttCode the specialAttCode to set
	 */
	public void setSpecialAttCode(String specialAttCode) {
		SpecialAttCode = specialAttCode;
	}
	/**
	 * @return the lateArrearsInd
	 */
	public String getLateArrearsInd() {
		return LateArrearsInd;
	}
	/**
	 * @param lateArrearsInd the lateArrearsInd to set
	 */
	public void setLateArrearsInd(String lateArrearsInd) {
		LateArrearsInd = lateArrearsInd;
	}
	/**
	 * @return the cedtRiskFactor
	 */
	public Double getCedtRiskFactor() {
		return CedtRiskFactor;
	}
	/**
	 * @param cedtRiskFactor the cedtRiskFactor to set
	 */
	public void setCedtRiskFactor(Double cedtRiskFactor) {
		CedtRiskFactor = cedtRiskFactor;
	}
	/**
	 * @return the title
	 */
	public String getTitle() {
		return Title;
	}
	/**
	 * @param title the title to set
	 */
	public void setTitle(String title) {
		Title = title;
	}
	/**
	 * @return the surname
	 */
	public String getSurname() {
		return Surname;
	}
	/**
	 * @param surname the surname to set
	 */
	public void setSurname(String surname) {
		Surname = surname;
	}
	/**
	 * @return the initials
	 */
	public String getInitials() {
		return Initials;
	}
	/**
	 * @param initials the initials to set
	 */
	public void setInitials(String initials) {
		Initials = initials;
	}
	/**
	 * @return the forename
	 */
	public String getForename() {
		return Forename;
	}
	/**
	 * @param forename the forename to set
	 */
	public void setForename(String forename) {
		Forename = forename;
	}
	/**
	 * @return the gender
	 */
	public String getGender() {
		return Gender;
	}
	/**
	 * @param gender the gender to set
	 */
	public void setGender(String gender) {
		Gender = gender;
	}
	/**
	 * @return the email
	 */
	public String getEmail() {
		return Email;
	}
	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		Email = email;
	}
	/**
	 * @return the nationalDialCode
	 */
	public String getNationalDialCode() {
		return NationalDialCode;
	}
	/**
	 * @param nationalDialCode the nationalDialCode to set
	 */
	public void setNationalDialCode(String nationalDialCode) {
		NationalDialCode = nationalDialCode;
	}
	/**
	 * @return the mobileNumber
	 */
	public String getMobileNumber() {
		return MobileNumber;
	}
	/**
	 * @param mobileNumber the mobileNumber to set
	 */
	public void setMobileNumber(String mobileNumber) {
		MobileNumber = mobileNumber;
	}
	/**
	 * @return the addressLine1
	 */
	public String getAddressLine1() {
		return AddressLine1;
	}
	/**
	 * @param addressLine1 the addressLine1 to set
	 */
	public void setAddressLine1(String addressLine1) {
		AddressLine1 = addressLine1;
	}
	/**
	 * @return the addressLine2
	 */
	public String getAddressLine2() {
		return AddressLine2;
	}
	/**
	 * @param addressLine2 the addressLine2 to set
	 */
	public void setAddressLine2(String addressLine2) {
		AddressLine2 = addressLine2;
	}
	/**
	 * @return the addressLine3
	 */
	public String getAddressLine3() {
		return AddressLine3;
	}
	/**
	 * @param addressLine3 the addressLine3 to set
	 */
	public void setAddressLine3(String addressLine3) {
		AddressLine3 = addressLine3;
	}
	/**
	 * @return the addressLine4
	 */
	public String getAddressLine4() {
		return AddressLine4;
	}
	/**
	 * @param addressLine4 the addressLine4 to set
	 */
	public void setAddressLine4(String addressLine4) {
		AddressLine4 = addressLine4;
	}
	/**
	 * @return the postCode
	 */
	public String getPostCode() {
		return PostCode;
	}
	/**
	 * @param postCode the postCode to set
	 */
	public void setPostCode(String postCode) {
		PostCode = postCode;
	}
	/**
	 * @return the deliveryPtSuffix
	 */
	public String getDeliveryPtSuffix() {
		return DeliveryPtSuffix;
	}
	/**
	 * @param deliveryPtSuffix the deliveryPtSuffix to set
	 */
	public void setDeliveryPtSuffix(String deliveryPtSuffix) {
		DeliveryPtSuffix = deliveryPtSuffix;
	}
	/**
	 * @return the countryName
	 */
	public String getCountryName() {
		return CountryName;
	}
	/**
	 * @param countryName the countryName to set
	 */
	public void setCountryName(String countryName) {
		CountryName = countryName;
	}
	/**
	 * @return the accountStatus
	 */
	public String getAccountStatus() {
		return AccountStatus;
	}
	/**
	 * @param accountStatus the accountStatus to set
	 */
	public void setAccountStatus(String accountStatus) {
		AccountStatus = accountStatus;
	}
	/**
	 * @return the prevAccountStatus
	 */
	public String getPrevAccountStatus() {
		return PrevAccountStatus;
	}
	/**
	 * @param prevAccountStatus the prevAccountStatus to set
	 */
	public void setPrevAccountStatus(String prevAccountStatus) {
		PrevAccountStatus = prevAccountStatus;
	}
	/**
	 * @return the creditStatus
	 */
	public String getCreditStatus() {
		return CreditStatus;
	}
	/**
	 * @param creditStatus the creditStatus to set
	 */
	public void setCreditStatus(String creditStatus) {
		CreditStatus = creditStatus;
	}
	/**
	 * @return the deliverNxtStatToOfc
	 */
	public String getDeliverNxtStatToOfc() {
		return DeliverNxtStatToOfc;
	}
	/**
	 * @param deliverNxtStatToOfc the deliverNxtStatToOfc to set
	 */
	public void setDeliverNxtStatToOfc(String deliverNxtStatToOfc) {
		DeliverNxtStatToOfc = deliverNxtStatToOfc;
	}
	/**
	 * @return the onlineStmtInd
	 */
	public String getOnlineStmtInd() {
		return OnlineStmtInd;
	}
	/**
	 * @param onlineStmtInd the onlineStmtInd to set
	 */
	public void setOnlineStmtInd(String onlineStmtInd) {
		OnlineStmtInd = onlineStmtInd;
	}
	/**
	 * @return the doNotPrintStmt
	 */
	public String getDoNotPrintStmt() {
		return DoNotPrintStmt;
	}
	/**
	 * @param doNotPrintStmt the doNotPrintStmt to set
	 */
	public void setDoNotPrintStmt(String doNotPrintStmt) {
		DoNotPrintStmt = doNotPrintStmt;
	}
	/**
	 * @return the status
	 */
	public String getStatus() {
		return Status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		Status = status;
	}
	/**
	 * @return the createdTimestmp
	 */
	public Date getCreatedTimestmp() {
		return CreatedTimestmp;
	}
	/**
	 * @param createdTimestmp the createdTimestmp to set
	 */
	public void setCreatedTimestmp(Date createdTimestmp) {
		CreatedTimestmp = createdTimestmp;
	}
	/**
	 * @return the modifiedTimestmp
	 */
	public Date getModifiedTimestmp() {
		return ModifiedTimestmp;
	}
	/**
	 * @param modifiedTimestmp the modifiedTimestmp to set
	 */
	public void setModifiedTimestmp(Date modifiedTimestmp) {
		ModifiedTimestmp = modifiedTimestmp;
	}
	/**
	 * @return the dOB
	 */
	public Date getDOB() {
		return DOB;
	}
	/**
	 * @param dOB the dOB to set
	 */
	public void setDOB(Date dOB) {
		DOB = dOB;
	}
	/**
	 * @return the dateAccntStatChng
	 */
	public Date getDateAccntStatChng() {
		return DateAccntStatChng;
	}
	/**
	 * @param dateAccntStatChng the dateAccntStatChng to set
	 */
	public void setDateAccntStatChng(Date dateAccntStatChng) {
		DateAccntStatChng = dateAccntStatChng;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getAuditLevel() {
		return auditLevel;
	}

	public void setAuditLevel(String auditLevel) {
		this.auditLevel = auditLevel;
	}

	public Date getCreditStartDate() {
		return creditStartDate;
	}

	public void setCreditStartDate(Date creditStartDate) {
		this.creditStartDate = creditStartDate;
	}
}
