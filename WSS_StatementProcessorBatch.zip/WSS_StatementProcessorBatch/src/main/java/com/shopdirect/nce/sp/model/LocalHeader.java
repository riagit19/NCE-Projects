/**
 * 
 */
package com.shopdirect.nce.sp.model;

/**
 * @author amitkumar4
 *
 */
public class LocalHeader {
	
	private String callingApp;
	private String auditLevel;
	private String version;
	private String transactionId;

	/**
	 * 
	 */
	public LocalHeader() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @return the callingApp
	 */
	public String getCallingApp() {
		return callingApp;
	}

	/**
	 * @param callingApp the callingApp to set
	 */
	public void setCallingApp(String callingApp) {
		this.callingApp = callingApp;
	}

	/**
	 * @return the auditLevel
	 */
	public String getAuditLevel() {
		return auditLevel;
	}

	/**
	 * @param auditLevel the auditLevel to set
	 */
	public void setAuditLevel(String auditLevel) {
		this.auditLevel = auditLevel;
	}

	/**
	 * @return the version
	 */
	public String getVersion() {
		return version;
	}

	/**
	 * @param version the version to set
	 */
	public void setVersion(String version) {
		this.version = version;
	}

	/**
	 * @return the transactionId
	 */
	public String getTransactionId() {
		return transactionId;
	}

	/**
	 * @param transactionId the transactionId to set
	 */
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

}
