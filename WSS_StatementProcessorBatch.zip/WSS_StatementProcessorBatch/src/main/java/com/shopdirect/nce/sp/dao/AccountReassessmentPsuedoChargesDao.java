/**
 * 
 */
package com.shopdirect.nce.sp.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import com.shopdirect.fcm.xsd.forecastmodeller.BrandCreditProductType;
import com.shopdirect.fcm.xsd.forecastmodeller.CreditProductType;
import com.shopdirect.fcm.xsd.forecastmodeller.CurrentDDTWithTransactionsAndIncomesType;
import com.shopdirect.fcm.xsd.forecastmodeller.CustomerAccountType;
import com.shopdirect.fcm.xsd.forecastmodeller.DailyRateType;
import com.shopdirect.fcm.xsd.forecastmodeller.DrawdownTermItemType;
import com.shopdirect.fcm.xsd.forecastmodeller.PaymentType;
import com.shopdirect.fcm.xsd.forecastmodeller.PeriodMovementsType;
import com.shopdirect.fcm.xsd.forecastmodeller.SPPDRate;
import com.shopdirect.nce.common.extcnfg.ExternalFileDataConfiguration;
import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.Query;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.ARPseudoChargeReqType;
import com.shopdirect.nce.sp.model.AccountReassessmentPseudoChargeReqType;
import com.shopdirect.nce.sp.util.CommonConfigHelper;
import com.shopdirect.nce.sp.util.UCPConnection;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.internal.OracleTypes;

/**
 * @author VijayaprakashPrathip
 *
 */
public class AccountReassessmentPsuedoChargesDao extends AccountReassessmentBaseDao {

	private static final SDLoggerImpl LOGGER = new SDLoggerImpl();
	private static final String ACC_REASSESSMENT_PACK = "ACC_REASSESSMENT_PACK";
	private static final String CALL_SP = "{call ";
	
	public AccountReassessmentPsuedoChargesDao() throws StatementProcessorBatchException{
		super();
		setStgSchema(getSchema(StatementProcessorBatchConstants.DB_SCHEMA_STG_KEY));
		setSpMainSchema(getSchema(StatementProcessorBatchConstants.DB_SCHEMA_MAIN_SP_KEY));
	}
	
	public List<AccountReassessmentPseudoChargeReqType> getCalculatePseudoCharges(String creditAcctNumber) throws StatementProcessorBatchException {
	
		List<AccountReassessmentPseudoChargeReqType> accountReassessmentPseudoChargeReqTypeList = new ArrayList<>();
		Connection con = null;
		ResultSet pseudochargeResultset = null;
		PreparedStatement  stmt = null;
		
		CustomerAccountType customerAccountType = new CustomerAccountType();
		CurrentDDTWithTransactionsAndIncomesType drawdownTermType = new CurrentDDTWithTransactionsAndIncomesType();
		CreditProductType creditProductType = null;
		BrandCreditProductType brandCreditProductType = new BrandCreditProductType();
		DailyRateType dailyRateType = new DailyRateType();
		DrawdownTermItemType drawdownTermItemType = new DrawdownTermItemType();
		PaymentType paymentType = new PaymentType();
		Calendar calendar = Calendar.getInstance();
		Calendar calendar_dt = Calendar.getInstance();
		Calendar calendar_enddt = Calendar.getInstance();
		Calendar calendar_bnpl_dt = Calendar.getInstance();
		Calendar calendar_paymnt_dt = Calendar.getInstance();
		Calendar calendar_sprate_dt = Calendar.getInstance();
		long diffBtwnDts, resultent_dates;
		String uniqueID;
		SPPDRate sppdRateType = new SPPDRate();
		
		    try {
		    	con = UCPConnection.getConnection();    	
		    	String queryStr = Query.getPseudoChagesCalQuery().toString();
			    stmt = con.prepareStatement(queryStr);
			    //stmt.setNString(1, creditAcctNumber);
			    stmt.setString(1, creditAcctNumber);
			    pseudochargeResultset = stmt.executeQuery();
			
				    while(pseudochargeResultset.next()){
				    	AccountReassessmentPseudoChargeReqType pseudoChargeReqType = new AccountReassessmentPseudoChargeReqType();
				    	//customerAccountType object info..
				    	//customerAccountType.setBrandType(pseudochargeResultset.getString("BRAND"));
				    	calendar.setTime(pseudochargeResultset.getDate("PAYMENT_DUE_DATE"));
				    	customerAccountType.setPaymentDayOfMonth(calendar.get(Calendar.DAY_OF_MONTH));
				    	customerAccountType.setPaymentPeriod((int) pseudochargeResultset.getLong("STMT_OFFSET_DAYS_FRM_PDD"));
				    	customerAccountType.setStopFees(pseudochargeResultset.getBoolean(0));
				    	customerAccountType.setStopInterest(pseudochargeResultset.getBoolean(0));
				    	customerAccountType.setStopDefaultFees(pseudochargeResultset.getBoolean(0));
				    	customerAccountType.setMinPayThreshold(pseudochargeResultset.getBigDecimal("MINIMUM_PAYMENT"));
				    	customerAccountType.setMinPayPercentageThreshold(pseudochargeResultset.getBigDecimal("MINIMUM_PAYMENT_PERCENTAGE"));
				    	//customerAccountType.setCurrentOTB(pseudochargeResultset.getBigDecimal("AVAILABLE_TO_SPEND"));
				    	//customerAccountType.setCurrentBalance(pseudochargeResultset.getBigDecimal(""));
				    	customerAccountType.setCurrentArrearsAmount(pseudochargeResultset.getBigDecimal("ARREARS_AMOUNT"));
				    	
				    	//drawdownTermType object info..
				    	drawdownTermType.setCashPrice(pseudochargeResultset.getBigDecimal(""));
				    	//drawdownTermType.setCurrentBalance(pseudochargeResultset.getBigDecimal("OUTSTANDING_BALANCE"));
				    	
				    	//creditProductType object info..
				    	//brandCreditProductType object info..
				    	uniqueID = UUID.randomUUID().toString();
				    	brandCreditProductType.setID(pseudochargeResultset.getString(uniqueID));
				    	//brandCreditProductType.setType(creditProductType.valueOf(pseudochargeResultset.getString("ITEM_TYPE")));
				    	calendar_dt.setTime(pseudochargeResultset.getDate("START_DATE"));
				    	//brandCreditProductType.setChargeDate(calendar_dt);
				    	//brandCreditProductType.setTermInDays((int) pseudochargeResultset.getLong(""));
				    	calendar_bnpl_dt.setTime(pseudochargeResultset.getDate("BNPL_END_DATE"));
				    	//no of days in between two different dates..
				    	diffBtwnDts = calendar_bnpl_dt.getTimeInMillis() - calendar_dt.getTimeInMillis();
				    	resultent_dates = diffBtwnDts / (24 * 60 * 60 * 1000);
				    	//brandCreditProductType.setDefferedTermInDays((int) resultent_dates);
				    	brandCreditProductType.setTermInMonths((int) pseudochargeResultset.getLong(""));
				    	//brandCreditProductType.setDeferredTermInMonthsdeferredTermInMonths((int) pseudochargeResultset.getLong(""));
		    	
				    	//dailyRateType object info..
				    	dailyRateType.setRate(pseudochargeResultset.getBigDecimal("DAILY_INTEREST_RATE"));
				    	calendar_dt.setTime(pseudochargeResultset.getDate("START_DATE"));
				    	dailyRateType.setStartDate(calendar_dt);
				    	calendar_enddt.setTime(pseudochargeResultset.getDate(""));
				    	//dailyRateType.setEndDate(calendar_enddt);
				    	
				    	//drawdownTermItemType object info..
				    	drawdownTermItemType.setCashPrice(pseudochargeResultset.getBigDecimal("CASH_PRICE"));
				    	
				    	//paymentType object info...
				    	paymentType.setAmount(pseudochargeResultset.getBigDecimal(""));
				    	calendar_paymnt_dt.setTime(pseudochargeResultset.getDate(""));
				    	paymentType.setDate(calendar_paymnt_dt);
				    	
				    	//sppdRateType object info..
				    	sppdRateType.setRate(pseudochargeResultset.getBigDecimal(""));
				    	calendar_sprate_dt.setTime(pseudochargeResultset.getDate(""));
				    	sppdRateType.setCreated(calendar_sprate_dt);
				    	
				    	pseudoChargeReqType.setCustomerAccountType(customerAccountType);
				    	pseudoChargeReqType.setDrawdownTermType(drawdownTermType);
				    	pseudoChargeReqType.setBrandCreditProductType(brandCreditProductType);
				    	pseudoChargeReqType.setDailyRateType(dailyRateType);
				    	pseudoChargeReqType.setDrawdownTermItemType(drawdownTermItemType);
				    	pseudoChargeReqType.setPaymentType(paymentType);
				    	pseudoChargeReqType.setSppdRateType(sppdRateType);
								
				    	accountReassessmentPseudoChargeReqTypeList.add(pseudoChargeReqType);
				    }
				    
		    } catch (SQLException sqlException) {
		    	
				throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_DB_ERROR_CODE,
						"[AccountReassessmentPsuedoChargesDao-getCalculatePseudoCharges] SQLException Block",
						"Database execution exception [SQLCode: "+ sqlException.getSQLState() + "] , SQL Detail "+sqlException.getMessage(),
						null, null,sqlException);
			      
			       
			 }catch(Exception exception){
					throw new StatementProcessorBatchException(StatementProcessorBatchConstants.CONNECTTION_DB_ERROR_CODE,
							"[AccountReassessmentPsuedoChargesDao-getCalculatePseudoCharges] Exception Block",
							"Database execution exception "+ exception.getMessage(),
							null, null,exception);
			 }finally {
				   
				   try {
					   if(pseudochargeResultset != null){
						   pseudochargeResultset.close();
					   }
					   if(stmt != null){
						   stmt.close();
					   }
					 
						   if (con != null) {
								con.close();
							}
					    
				} catch (Exception e) {
					getLogger().error("[AccountReassessmentPsuedoChargesDao - getCalculatePseudoCharges] finally Block: failed to close DB objects . "+e.getMessage());
				}
			    }
			return accountReassessmentPseudoChargeReqTypeList;
	}
	
	
	public List<ARPseudoChargeReqType> getCalculatePseudoCharges(String creditAcctNumber, Date statementDate) throws StatementProcessorBatchException {
		List<ARPseudoChargeReqType> accountReassessmentPseudoChargeReqTypeList = new ArrayList<>();
		Calendar calendar = Calendar.getInstance();
		Calendar calendar_paymnt_dt = Calendar.getInstance();
		CustomerAccountType customerAccountType = new CustomerAccountType();
		PeriodMovementsType periodMovementsType=new PeriodMovementsType();
		LOGGER.debug("[AccountReassessmentPsuedoChargesDao -- getCalculatePseudoCharges] -- Start");	
		final String pack = "PACK_PSEUSOCHARGE";
		final String procedure = "getPseudoCharge_EXT";
		Connection connection = null;
		CallableStatement stmt = null;
		final String spDetail = CALL_SP + pack + "." + procedure + "(?,?,?,?,?,?)}";
		try{
			java.sql.Date sqlDate=null;
			if (statementDate != null) {
				sqlDate=new java.sql.Date(statementDate.getTime());
			}
			
			connection = UCPConnection.getConnection();
			stmt = connection.prepareCall(spDetail);
			stmt.setString(1, creditAcctNumber);
			stmt.setDate(2,sqlDate);
			stmt.registerOutParameter(3, OracleTypes.CURSOR);
			stmt.registerOutParameter(4, OracleTypes.CURSOR);
			stmt.registerOutParameter(5, OracleTypes.CURSOR);
			stmt.registerOutParameter(6, OracleTypes.CURSOR);
			stmt.execute();
			ResultSet custAcc = ((OracleCallableStatement)stmt).getCursor(3);
			
			while(custAcc.next()){
		    	//customerAccountType.setBrandType(custAcc.getString("BRAND_TYPE"));
		    	calendar.setTime(custAcc.getDate("PAYMENT_DAY_OF_MONTH"));
		    	customerAccountType.setPaymentDayOfMonth(calendar.get(Calendar.DAY_OF_MONTH));
		    	customerAccountType.setPaymentPeriod((int) custAcc.getLong("PAYMENT_PERIOD"));
		    	customerAccountType.setStopFees(custAcc.getBoolean(0));
		    	customerAccountType.setStopInterest(custAcc.getBoolean(0));
		    	customerAccountType.setStopDefaultFees(custAcc.getBoolean(0));
		    	customerAccountType.setMinPayThreshold(custAcc.getBigDecimal("MINPAY_THERESHOLD"));
		    	customerAccountType.setMinPayPercentageThreshold(custAcc.getBigDecimal("MINPAY_PER_THERESHOLD"));
		    	//customerAccountType.setCurrentOTB(custAcc.getBigDecimal("OUTSTANDING_BALANCE"));
		    	//customerAccountType.setCurrentBalance(custAcc.getBigDecimal("CURRENT_BALANCE"));
		    	customerAccountType.setCurrentArrearsAmount(custAcc.getBigDecimal("ARREARS_AMOUNT"));
			}
			
			ResultSet currPrdMvmt = ((OracleCallableStatement)stmt).getCursor(4);
			
			while(currPrdMvmt.next()){	
				if(currPrdMvmt.getString("PAYMENT_TYPE")!=null){
					if(currPrdMvmt.getString("PAYMENT_TYPE").equalsIgnoreCase("01")){
						PaymentType paymentType = new PaymentType();
						paymentType.setAmount(currPrdMvmt.getBigDecimal("PAYMENT_AMOUNT"));
				    	calendar_paymnt_dt.setTime(currPrdMvmt.getDate("DATE_PAID"));
				    	paymentType.setDate(calendar_paymnt_dt);
				    	periodMovementsType.getPayments().add(paymentType);
					}else if(currPrdMvmt.getString("PAYMENT_TYPE").equalsIgnoreCase("02")){
						PaymentType feeType = new PaymentType();
						feeType.setAmount(currPrdMvmt.getBigDecimal("PAYMENT_AMOUNT"));
				    	calendar_paymnt_dt.setTime(currPrdMvmt.getDate("DATE_PAID"));
				    	feeType.setDate(calendar_paymnt_dt);
				    	periodMovementsType.getFees().add(feeType);
					}else if(currPrdMvmt.getString("PAYMENT_TYPE").equalsIgnoreCase("03")){
						PaymentType adjustmentType = new PaymentType();
						adjustmentType.setAmount(currPrdMvmt.getBigDecimal("PAYMENT_AMOUNT"));
				    	calendar_paymnt_dt.setTime(currPrdMvmt.getDate("DATE_PAID"));
				    	adjustmentType.setDate(calendar_paymnt_dt);
				    	periodMovementsType.getAdjusments().add(adjustmentType);
					}else if(currPrdMvmt.getString("PAYMENT_TYPE").equalsIgnoreCase("04")){
						PaymentType calcellationType = new PaymentType();
						calcellationType.setAmount(currPrdMvmt.getBigDecimal("PAYMENT_AMOUNT"));
				    	calendar_paymnt_dt.setTime(currPrdMvmt.getDate("DATE_PAID"));
				    	calcellationType.setDate(calendar_paymnt_dt);
				    	periodMovementsType.getCancellations().add(calcellationType);
					}else if(currPrdMvmt.getString("PAYMENT_TYPE").equalsIgnoreCase("05")){
						PaymentType returnType = new PaymentType();
						returnType.setAmount(currPrdMvmt.getBigDecimal("PAYMENT_AMOUNT"));
				    	calendar_paymnt_dt.setTime(currPrdMvmt.getDate("DATE_PAID"));
				    	returnType.setDate(calendar_paymnt_dt);
				    	periodMovementsType.getReturns().add(returnType);
					}
				}	
			}
			
			ResultSet drawDownTerms = ((OracleCallableStatement)stmt).getCursor(5);
			while(drawDownTerms.next()){
				System.out.println("DRAWDOWN_CODE : "+drawDownTerms.getString("DRAWDOWN_CODE"));
				System.out.println("CASH_PRICE : "+drawDownTerms.getString("CASH_PRICE"));
				System.out.println("TYPE : "+drawDownTerms.getString("TYPE"));
				System.out.println("CHARGE_DATE : "+drawDownTerms.getString("CHARGE_DATE"));
				System.out.println("BNPL_END_DATE : "+drawDownTerms.getString("BNPL_END_DATE"));
				System.out.println("DAILY_INTEREST_RATE : "+drawDownTerms.getString("DAILY_INTEREST_RATE"));
				System.out.println("DT_DEFERRED_DATE : "+drawDownTerms.getString("DT_DEFERRED_DATE"));
			}
			
			ResultSet targetPayment = ((OracleCallableStatement)stmt).getCursor(6);
			while(targetPayment.next()){
				System.out.println("TYPE : "+targetPayment.getString("TYPE"));
				System.out.println("TARGETED_PAYMENT_AMOUNT : "+targetPayment.getString("TARGETED_PAYMENT_AMOUNT"));
				System.out.println("TARGETED_PAYMENT_DATE : "+targetPayment.getString("TARGETED_PAYMENT_DATE"));
				
				if(currPrdMvmt.getString("TYPE")!=null){
					if(currPrdMvmt.getString("TYPE").equalsIgnoreCase("01")){
						PaymentType paymentType = new PaymentType();
						paymentType.setAmount(currPrdMvmt.getBigDecimal("TARGETED_PAYMENT_AMOUNT"));
				    	calendar_paymnt_dt.setTime(currPrdMvmt.getDate("TARGETED_PAYMENT_DATE"));
				    	paymentType.setDate(calendar_paymnt_dt);
				    	periodMovementsType.getPayments().add(paymentType);
					}else if(currPrdMvmt.getString("TYPE").equalsIgnoreCase("02")){
						PaymentType feeType = new PaymentType();
						feeType.setAmount(currPrdMvmt.getBigDecimal("TARGETED_PAYMENT_AMOUNT"));
				    	calendar_paymnt_dt.setTime(currPrdMvmt.getDate("TARGETED_PAYMENT_DATE"));
				    	feeType.setDate(calendar_paymnt_dt);
				    	periodMovementsType.getFees().add(feeType);
					}else if(currPrdMvmt.getString("TYPE").equalsIgnoreCase("03")){
						PaymentType adjustmentType = new PaymentType();
						adjustmentType.setAmount(currPrdMvmt.getBigDecimal("TARGETED_PAYMENT_AMOUNT"));
				    	calendar_paymnt_dt.setTime(currPrdMvmt.getDate("TARGETED_PAYMENT_DATE"));
				    	adjustmentType.setDate(calendar_paymnt_dt);
				    	periodMovementsType.getAdjusments().add(adjustmentType);
					}else if(currPrdMvmt.getString("TYPE").equalsIgnoreCase("04")){
						PaymentType calcellationType = new PaymentType();
						calcellationType.setAmount(currPrdMvmt.getBigDecimal("TARGETED_PAYMENT_AMOUNT"));
				    	calendar_paymnt_dt.setTime(currPrdMvmt.getDate("TARGETED_PAYMENT_DATE"));
				    	calcellationType.setDate(calendar_paymnt_dt);
				    	periodMovementsType.getCancellations().add(calcellationType);
					}else if(currPrdMvmt.getString("TYPE").equalsIgnoreCase("05")){
						PaymentType returnType = new PaymentType();
						returnType.setAmount(currPrdMvmt.getBigDecimal("TARGETED_PAYMENT_AMOUNT"));
				    	calendar_paymnt_dt.setTime(currPrdMvmt.getDate("TARGETED_PAYMENT_DATE"));
				    	returnType.setDate(calendar_paymnt_dt);
				    	periodMovementsType.getReturns().add(returnType);
					}
				}	
			}
			
		} catch(Exception exception){
				throw new StatementProcessorBatchException(StatementProcessorBatchConstants.CONNECTTION_DB_ERROR_CODE,
						"[AccountReassessmentPsuedoChargesDao-getCalculatePseudoCharges] Exception Block",
						"Database execution exception "+ exception.getMessage(),
						null, null,exception);
		 }finally {
			 try {
					if (stmt != null) {
						stmt.close();
					}

					if (connection != null) {
						connection.close();
					}
				} catch (Exception e) {
					LOGGER.error("[AccountReassessmentPsuedoChargesDao -- getCalculatePseudoCharges] -- Exception in finally block: " + e);
				}
		 }
		
		return accountReassessmentPseudoChargeReqTypeList;
	}
	
	private String getConfigValue(String key) throws StatementProcessorBatchException {
		CommonConfigHelper commonConfigHelper = CommonConfigHelper.getInstance();
		ExternalFileDataConfiguration dbconfig = commonConfigHelper
				.loadPropertyConfig(StatementProcessorBatchConstants.DATABASE_CONFIGURATION_FILE_KEY);
		return commonConfigHelper.readConfigData(dbconfig, key);
	}
}
