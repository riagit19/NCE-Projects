package com.shopdirect.nce.sp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.Query;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.util.UCPConnection;

public class AccountInfoStatusDaoImpl extends AccountReassessmentBaseDao  {

private SDLoggerImpl logger = new SDLoggerImpl();
	
	
	public AccountInfoStatusDaoImpl() throws StatementProcessorBatchException{
		super();
		setSpMainSchema(getSchema(StatementProcessorBatchConstants.DB_SCHEMA_MAIN_SP_KEY));
	}
		
	public int updateCimAccountInfoStatus(String pubAccNo, String statementDate, String updateStatus) throws StatementProcessorBatchException, SQLException {
		logger.debug("[CustomerDetailsDao -- updateAccountdetails]  -- START");
		
		Connection con = null;
		int status = -1;
		PreparedStatement  stmt = null;
	    try {
			con = UCPConnection.getConnection();
	    	con.setAutoCommit(false);

	    	String queryStr = Query.getUpdateCimAccountInfoStatus(getSpMainSchema());
	    	logger.info("***********************"+queryStr);
	    	int i = 0;
	    	  if(pubAccNo != null && !pubAccNo.isEmpty() && statementDate != null && !statementDate.isEmpty()){
			     stmt = con.prepareStatement(queryStr);
			     stmt.setString(++i, updateStatus);
			     stmt.setString(++i, pubAccNo);
			     stmt.setString(++i, statementDate);
			     status = stmt.executeUpdate();
			    con.commit();
	    	  }
	    } catch(StatementProcessorBatchException batchEx){
	    	throw batchEx;
	    } catch (SQLException sqlException) {
	    	if(con != null){
	    		try {
					con.rollback();
				} catch (SQLException e) {
					getLogger().error("[CustomerDetailsDao -- updateAccountdetails] finally Block: failed to Rollback DB objects. " + e);
				}
	    	}
	    	
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_DB_ERROR_CODE,
					"[CustomerDetailsDao -- updateAccountdetails] SQLException Block",
					"Database execution exception [SQLCode: "+ sqlException.getSQLState() + "] , SQL Detail "+sqlException.getMessage(),
					null, null,sqlException);
		      
		       
		 }catch(Exception exception){
				throw new StatementProcessorBatchException(StatementProcessorBatchConstants.CONNECTTION_DB_ERROR_CODE,
						"[CustomerDetailsDao -- updateAccountdetails] Exception Block",
						"Database execution exception "+ exception.getMessage(),
						null, null,exception);
		 }finally {
			   
			   try {
				   if(stmt != null){
					   stmt.close();
				   }
				 
				   if (con != null) {
						con.close();
					}
				    
				} catch (Exception e) {
					getLogger().error("[CustomerDetailsDao -- updateAccountdetails] finally Block: failed to close DB objects. " + e);
				}
		   }
		    
		    logger.debug("[CustomerDetailsDao -- updateAccountdetails]  -- START");
			return status;
	}
	
	/**
	 * @return the logger
	 */
	@Override
	public SDLoggerImpl getLogger() {
		return logger;
	}
	
}
