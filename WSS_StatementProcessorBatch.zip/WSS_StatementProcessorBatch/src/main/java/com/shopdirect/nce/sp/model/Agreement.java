package com.shopdirect.nce.sp.model;

import java.sql.Timestamp;
import java.util.Date;


public class Agreement {
	
	private String agreementId;
	
	private Long agreementSeq;
	
	private Date statementDate;
	
	private Double interestRate;
	
	private Double openingBalance;
	
	private Double closingBalance;
	
	private Double arrangementAmount;
	
	private Double minimumPayment;
	
	private Double minimumPaymentcalculatedBalance;
	
	private Double minimumPaymentPercentage;
	
	private Double fixedMinimumPayment;
	
	private Double directDebitAmount;
	
	private Double ppiAmount;
	
	private Double arrearsAmount;
	
	private Date nextpaymentDueDate;
	
	private Date previousPaymentDuedate;
	
	private Double creditLimit;
	
	private Double availableToSpend;
	
	private String agreementType;
	
	private Double takeAll;
	
	private Double agreementTypePaymentsTransferredIn;
	
	private Timestamp accountPromotionEndDate;
	
	private Integer missedMinPayInd;
	
	private Integer directDebitTypeInd;
	
	private Double scheduledPaymentAmount;	
	
	private Double scheduledPaymentPastDue;
	
	private Long batchId;
	
	private String errorFlag;
	
	private String errorMessage;
	
	private Date creationDate;
	
	private Long createdByUser;
	
	private Date lastUpdateDate;
	
	private Long lastUpdateByUser;
	
	private String pendingItemInd;
	
	private String noInterestIndicator;
	
	
	public String getAgreementId() {
		return agreementId;
	}


	public void setAgreementId(String agreementId) {
		this.agreementId = agreementId;
	}


	public Long getAgreementSeq() {
		return agreementSeq;
	}


	public void setAgreementSeq(Long agreementSeq) {
		this.agreementSeq = agreementSeq;
	}


	public Date getStatementDate() {
		return statementDate;
	}


	public void setStatementDate(Date statementDate) {
		this.statementDate = statementDate;
	}


	public Double getInterestRate() {
		return interestRate;
	}


	public void setInterestRate(Double interestRate) {
		this.interestRate = interestRate;
	}

	public Double getOpeningBalance() {
		return openingBalance;
	}


	public void setOpeningBalance(Double openingBalance) {
		this.openingBalance = openingBalance;
	}


	public Double getClosingBalance() {
		return closingBalance;
	}


	public void setClosingBalance(Double closingBalance) {
		this.closingBalance = closingBalance;
	}


	public Double getArrangementAmount() {
		return arrangementAmount;
	}


	public void setArrangementAmount(Double arrangementAmount) {
		this.arrangementAmount = arrangementAmount;
	}


	public Double getMinimumPayment() {
		return minimumPayment;
	}


	public void setMinimumPayment(Double minimumPayment) {
		this.minimumPayment = minimumPayment;
	}


	public Double getMinimumPaymentcalculatedBalance() {
		return minimumPaymentcalculatedBalance;
	}


	public void setMinimumPaymentcalculatedBalance(Double minimumPaymentcalculatedBalance) {
		this.minimumPaymentcalculatedBalance = minimumPaymentcalculatedBalance;
	}


	public Double getMinimumPaymentPercentage() {
		return minimumPaymentPercentage;
	}


	public void setMinimumPaymentPercentage(Double minimumPaymentPercentage) {
		this.minimumPaymentPercentage = minimumPaymentPercentage;
	}


	public Double getFixedMinimumPayment() {
		return fixedMinimumPayment;
	}


	public void setFixedMinimumPayment(Double fixedMinimumPayment) {
		this.fixedMinimumPayment = fixedMinimumPayment;
	}


	public Double getDirectDebitAmount() {
		return directDebitAmount;
	}


	public void setDirectDebitAmount(Double directDebitAmount) {
		this.directDebitAmount = directDebitAmount;
	}


	public Double getPpiAmount() {
		return ppiAmount;
	}


	public void setPpiAmount(Double ppiAmount) {
		this.ppiAmount = ppiAmount;
	}


	public Double getArrearsAmount() {
		return arrearsAmount;
	}


	public void setArrearsAmount(Double arrearsAmount) {
		this.arrearsAmount = arrearsAmount;
	}


	public Date getNextpaymentDueDate() {
		return nextpaymentDueDate;
	}


	public void setNextpaymentDueDate(Date nextpaymentDueDate) {
		this.nextpaymentDueDate = nextpaymentDueDate;
	}


	public Date getPreviousPaymentDuedate() {
		return previousPaymentDuedate;
	}


	public void setPreviousPaymentDuedate(Date previousPaymentDuedate) {
		this.previousPaymentDuedate = previousPaymentDuedate;
	}


	public Double getCreditLimit() {
		return creditLimit;
	}


	public void setCreditLimit(Double creditLimit) {
		this.creditLimit = creditLimit;
	}


	public Double getAvailableToSpend() {
		return availableToSpend;
	}


	public void setAvailableToSpend(Double availableToSpend) {
		this.availableToSpend = availableToSpend;
	}


	public String getAgreementType() {
		return agreementType;
	}


	public void setAgreementType(String agreementType) {
		this.agreementType = agreementType;
	}


	public Double getTakeAll() {
		return takeAll;
	}


	public void setTakeAll(Double takeAll) {
		this.takeAll = takeAll;
	}


	public Double getAgreementTypePaymentsTransferredIn() {
		return agreementTypePaymentsTransferredIn;
	}


	public void setAgreementTypePaymentsTransferredIn(Double agreementTypePaymentsTransferredIn) {
		this.agreementTypePaymentsTransferredIn = agreementTypePaymentsTransferredIn;
	}

	public Timestamp getAccountPromotionEndDate() {
		return accountPromotionEndDate;
	}


	public void setAccountPromotionEndDate(Timestamp accountPromotionEndDate) {
		this.accountPromotionEndDate = accountPromotionEndDate;
	}


	public Integer getMissedMinPayInd() {
		return missedMinPayInd;
	}


	public void setMissedMinPayInd(Integer missedMinPayInd) {
		this.missedMinPayInd = missedMinPayInd;
	}


	public Integer getDirectDebitTypeInd() {
		return directDebitTypeInd;
	}


	public void setDirectDebitTypeInd(Integer directDebitTypeInd) {
		this.directDebitTypeInd = directDebitTypeInd;
	}


	public Double getScheduledPaymentAmount() {
		return scheduledPaymentAmount;
	}


	public void setScheduledPaymentAmount(Double scheduledPaymentAmount) {
		this.scheduledPaymentAmount = scheduledPaymentAmount;
	}


	public Double getScheduledPaymentPastDue() {
		return scheduledPaymentPastDue;
	}


	public void setScheduledPaymentPastDue(Double scheduledPaymentPastDue) {
		this.scheduledPaymentPastDue = scheduledPaymentPastDue;
	}


	public Long getBatchId() {
		return batchId;
	}


	public void setBatchId(Long batchId) {
		this.batchId = batchId;
	}


	public String getErrorFlag() {
		return errorFlag;
	}


	public void setErrorFlag(String errorFlag) {
		this.errorFlag = errorFlag;
	}


	public String getErrorMessage() {
		return errorMessage;
	}


	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}


	public Date getCreationDate() {
		return creationDate;
	}


	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}


	public Long getCreatedByUser() {
		return createdByUser;
	}


	public void setCreatedByUser(Long createdByUser) {
		this.createdByUser = createdByUser;
	}


	public Date getLastUpdateDate() {
		return lastUpdateDate;
	}


	public void setLastUpdateDate(Date lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}


	public Long getLastUpdateByUser() {
		return lastUpdateByUser;
	}


	public void setLastUpdateByUser(Long lastUpdateByUser) {
		this.lastUpdateByUser = lastUpdateByUser;
	}
	
	public String getPendingItemInd() {
		return pendingItemInd;
	}

	public void setPendingItemInd(String pendingItemInd) {
		this.pendingItemInd = pendingItemInd;
	}


	@Override
	public String toString() {
		/*return "Agreement [agreementCode=" + agreementCode + ", brand=" + brand + ", openingBalance=" + openingBalance
				+ ", closingBalance=" + closingBalance + ", arrangementAmount=" + arrangementAmount
				+ ", minimumPayment=" + minimumPayment + ", fixedMinimumPayment=" + fixedMinimumPayment
				+ ", minimumPaymentPercentage=" + minimumPaymentPercentage + ", minimumPaymentcalculatedBalance="
				+ minimumPaymentcalculatedBalance + ", directDebitAmount=" + directDebitAmount + ", ppiAmount="
				+ ppiAmount + ", annualFee=, arrearsAmount=" + arrearsAmount + ", nextpaymentDueDate="
				+ nextpaymentDueDate + ", previousPaymentDuedate=" + previousPaymentDuedate + ", status=" 
				+ ", creditLimit=" + creditLimit + ", availableToSpend=" + availableToSpend + ", createdDateTime="
				+ createdDateTime + ", modifiedDateTime=" + modifiedDateTime + ", takeAll=" + takeAll
				+ ", agreementTypePaymentsTransferredIn=" + agreementTypePaymentsTransferredIn + ", statementDate="
				+ statementDate + ", forecastedInterest=" + forecastedInterest + ", agreementType=" + agreementType
				+ ", agreementTypeCode=" + agreementTypeCode + ", batchId=" + batchId + "]";*/
		
		return null;
	}


	public String getNoInterestIndicator() {
		return noInterestIndicator;
	}


	public void setNoInterestIndicator(String noInterestIndicator) {
		this.noInterestIndicator = noInterestIndicator;
	}
	
}
