package com.shopdirect.nce.sp.model;

import java.math.BigDecimal;
import java.sql.Date;

public class BatchDetails {

	private String accountTypeCode;
	private BigDecimal acdAlignedScore;
	private BigDecimal acdRawScore;
	private BigDecimal acdScorecardId;
	private BigDecimal alignedBehaviourScore;
	private BigDecimal annotationPeriodInd;
	private BigDecimal applicationCreditScore;
	private BigDecimal aPR;
	private BigDecimal behaviourRawScore;
	private BigDecimal behaviourScore;
	private String blockCode;
	private BigDecimal bnplBalance;
	private BigDecimal creditBandCodeInd;
	private BigDecimal collectionMethodCode;
	private String customerAccountNumber;
	private String retailAccountNumber;
	private String agreementNumber;
	private String creditBand;
	private BigDecimal creditLimit;
	private String creditStatusCode;
	private String creditStatusSubCode;
	private BigDecimal cRF;
	private BigDecimal currentBalance;
	private String currentBURef;
	private String accountStatusCode;
	private BigDecimal custAlignedScore;
	private BigDecimal custNoMailInd;
	private BigDecimal custRawScore;
	private BigDecimal custScorecardId;
	private BigDecimal customerType;
	private Date dateBankrupt;
	private Date todaysAccountingDate;
	private Date dateClosed;
	private Date dateLastZeroBalance;
	private Date dateSection87;
	private Date dateLastArrangement;
	private Date dateLastCreditLimitDecrease;
	private Date dateLastCreditLimitIncrease;
	private Date dateLastCreditOrder;
	private Date dateLastDelinquent;
	private Date dateLastRetailOrder;
	private Date dateLastPayment;
	private Date dateLastPhoneCheck;
	private Date dateLastStatement;
	private Date dateMigratedToCredit;
	private Date dateNextStatement;
	private Date dateNSF;
	private Date dateOfBirth;
	private Date datePaymentDue;
	private Date dateRestart;
	private Date dateRiskNavScoreUpdated;
	private Date dateStart;
	private Date dateStartDelinquency;
	private Date dateEndDelinquency;
	private Date accountStatusChangeDate;
	private BigDecimal dCAReturnCode;
	private BigDecimal debitSaleFlag;
	private BigDecimal deceasedInd;
	private String emailAddressInd;
	private String fidScore;
	private Date fidScoreDate;
	private String fidScoreWorst;
	private BigDecimal creditLimitFrozenInd;
	private BigDecimal highBalance;
	private BigDecimal highDelq;
	private BigDecimal homePhoneInd;
	private BigDecimal lastFollowUpCode;
	private String lastSpecialCommentCode;
	private BigDecimal creditLimitLastReview;
	private BigDecimal minPayment;
	private BigDecimal mobileNumInd;
	private BigDecimal ndrAlignedScore;
	private BigDecimal ndrRawScore;
	private BigDecimal ndrScorecardId;
	private BigDecimal nsfTodayInd;
	private BigDecimal numAccts;
	private BigDecimal numCashAccts;
	private BigDecimal numCreditAccts;
	private BigDecimal numCycle1;      
	private BigDecimal numCycle2;      
	private BigDecimal numCycle3;      
	private BigDecimal numCycle4;
	private BigDecimal numIBCAccts;
	private BigDecimal numPaymentsTSP;
	private BigDecimal numInstallmentsInArrears;
	private BigDecimal ordersDeclined3mths;
	private BigDecimal oTB;
	private BigDecimal otherAdjustmentsAmountTSP;
	private BigDecimal overIndebtScore;
	private BigDecimal pastDue;
	private BigDecimal lastPaymentAmount;
	private BigDecimal paymentCurrentInd;
	private BigDecimal lastPaymentMethod;
	private BigDecimal paymentPreviousInd;
	private BigDecimal paymentReschedInd;
	private BigDecimal creditPaymentsTotal;
	private BigDecimal ppiInd;
	private String principalBrand;
	private BigDecimal promiseToPayInd;
	private BigDecimal paymentsTSPInd;
	private BigDecimal paymtsSinceLastCollEntry;
	private BigDecimal recruitmentCRF;
	private BigDecimal recruitmentSource;
	private BigDecimal returnsAmountTSP;
	private BigDecimal riskNavScore;
	private BigDecimal scheduledPaymentAmt;
	private BigDecimal scorecardId;
	private BigDecimal screenBalance;
	private BigDecimal spid;
	private BigDecimal scheduledPaymentsPastDue;
	private BigDecimal tcuMonitorStatusCode;
	private BigDecimal totalPayments30Days;
	private BigDecimal paymentAmountTSP;
	private BigDecimal numPurchasesTSP;
	private BigDecimal totalFeesTSP;
	private BigDecimal otherDebits;
	private BigDecimal otherCredits;
	private BigDecimal numFailedPayments;
	private BigDecimal valueFailedPayments;
	private BigDecimal interestChargedAmtTSP;
	private BigDecimal purchaseAmountTSP;
	private BigDecimal numNSF;
	private BigDecimal rebatesAmountTSP;
	private BigDecimal netSalesValueTSPAmt;
	private BigDecimal totalNumCreditPayments;
	private BigDecimal daysInCollPeriod;
	private Date firstCollStmtDate;
	private BigDecimal inCollectionsInd;
	private BigDecimal inDebtManagerInd;
	private String annualSalary;
	private String householdIncome;
	private BigDecimal noOfDependants;
	private String employmentStatus;
	private String residentStatus;
	private String sixMonthIncomeVerificationCode;
	private String twelveMonthIncomeVerificationCode;
	private Date dateOfChangeRequest;
	private String previousAnnualSalary;
	private String previousHouseholdIncome;
	private BigDecimal derivedIncome;
	private BigDecimal optOutCreditLimitIncInd;
	private BigDecimal arrearsBucket1;
	private BigDecimal arrearsBucket2;
	private BigDecimal arrearsBucket3;
	private BigDecimal arrearsBucket4;
	private BigDecimal arrearsBucket5;
	private BigDecimal arrearsBucket6;
	private Date lastPhoneCheckDate;
	private String dmClassStatus0;  
	private String dmClassStatus1;  
	private String dmClassStatus2;  
	private String dmClassStatus3;  
	private String dmClassStatus4;
	private String collCreditBand;
	private String collAccountStatusCode;
	private Date collTCSStatusChangeDate;
	private String collCurrentBURef;
	private String collPrincipalBrand;
	private String collCreditStatusCode;
	private String collCreditStatusSubCode;
	private BigDecimal collDeceasedInd;
	private String collLastSpecialCommentCode;
	private BigDecimal collSPID;
	private BigDecimal collCustomerType;
	private BigDecimal collTransactionAmount;
	private BigDecimal collMinVal;
	private BigDecimal collNumPPI;
	private BigDecimal collDeptCode;
	private BigDecimal collAuthInd;
	private BigDecimal collNotFullPayInd;
	private String qcbDataPopulated;
	private String qcbRiskNavigator;
	private String qcbOverIndebtedness;
	private BigDecimal qcbAddChar1;
	private BigDecimal qcbAddChar2;
	private BigDecimal qcbAddChar3;
	private BigDecimal qcbAddChar4;
	private BigDecimal qcbAddChar5;
	private String qcbBSC410;
	private String qcbBSC413;
	private String qcbBSC435;
	private String qcbBSC437;
	private String qcbBSC438;
	private String qcbDSC435;
	private String qcbDSC437;
	private String qcbDSC438;
	private String qcbLSC250;
	private String qcbLSC556;
	private String qcbLSC557;
	private String qcbLSC887;
	private String qcbLSC888;
	private String qcbLSC547;
	private String qcbFSC402;
	private String qcbLSC320;
	private String qcbCSC4;
	private String qcbLSC251;
	private String qcbLSC173;
	private String qcbFSC308;
	private String qcbLSC157;
	private String qcbSSC4;
	private String qcbSSC2;
	private String qcbXPCF09;
	private String qcbDSC410;
	private String qcbDSC413;
	private String qcbFSC104;
	private String qcbFSC111;
	
	public BatchDetails() {
		super();
	}

	public BatchDetails(String accountTypeCode, BigDecimal acdAlignedScore, BigDecimal acdRawScore,
			BigDecimal acdScorecardId, BigDecimal alignedBehaviourScore, BigDecimal annotationPeriodInd,
			BigDecimal applicationCreditScore, BigDecimal aPR, BigDecimal behaviourRawScore, BigDecimal behaviourScore,
			String blockCode, BigDecimal bnplBalance, BigDecimal creditBandCodeInd, BigDecimal collectionMethodCode,
			String customerAccountNumber, String retailAccountNumber, String agreementNumber,
			String creditBand, BigDecimal creditLimit, String creditStatusCode, String creditStatusSubCode,
			BigDecimal cRF, BigDecimal currentBalance, String currentBURef, String accountStatusCode,
			BigDecimal custAlignedScore, BigDecimal custNoMailInd, BigDecimal custRawScore, BigDecimal custScorecardId,
			BigDecimal customerType, Date dateBankrupt, Date todaysAccountingDate, Date dateClosed,
			Date dateLastZeroBalance, Date dateSection87, Date dateLastArrangement, Date dateLastCreditLimitDecrease,
			Date dateLastCreditLimitIncrease, Date dateLastCreditOrder, Date dateLastDelinquent,
			Date dateLastRetailOrder, Date dateLastPayment, Date dateLastPhoneCheck, Date dateLastStatement,
			Date dateMigratedToCredit, Date dateNextStatement, Date dateNSF, Date dateOfBirth, Date datePaymentDue,
			Date dateRestart, Date dateRiskNavScoreUpdated, Date dateStart, Date dateStartDelinquency,
			Date dateEndDelinquency, Date accountStatusChangeDate, BigDecimal dCAReturnCode, BigDecimal debitSaleFlag,
			BigDecimal deceasedInd, String emailAddressInd, String fidScore, Date fidScoreDate, String fidScoreWorst,
			BigDecimal creditLimitFrozenInd, BigDecimal highBalance, BigDecimal highDelq, BigDecimal homePhoneInd,
			BigDecimal lastFollowUpCode, String lastSpecialCommentCode, BigDecimal creditLimitLastReview,
			BigDecimal minPayment, BigDecimal mobileNumInd, BigDecimal ndrAlignedScore, BigDecimal ndrRawScore,
			BigDecimal ndrScorecardId, BigDecimal nsfTodayInd, BigDecimal numAccts, BigDecimal numCashAccts,
			BigDecimal numCreditAccts, BigDecimal numCycle1, BigDecimal numCycle2, BigDecimal numCycle3,
			BigDecimal numCycle4, BigDecimal numIBCAccts, BigDecimal numPaymentsTSP,
			BigDecimal numInstallmentsInArrears, BigDecimal ordersDeclined3mths, BigDecimal oTB,
			BigDecimal otherAdjustmentsAmountTSP, BigDecimal overIndebtScore, BigDecimal pastDue,
			BigDecimal lastPaymentAmount, BigDecimal paymentCurrentInd, BigDecimal lastPaymentMethod,
			BigDecimal paymentPreviousInd, BigDecimal paymentReschedInd, BigDecimal creditPaymentsTotal,
			BigDecimal ppiInd, String principalBrand, BigDecimal promiseToPayInd, BigDecimal paymentsTSPInd,
			BigDecimal paymtsSinceLastCollEntry, BigDecimal recruitmentCRF, BigDecimal recruitmentSource,
			BigDecimal returnsAmountTSP, BigDecimal riskNavScore, BigDecimal scheduledPaymentAmt,
			BigDecimal scorecardId, BigDecimal screenBalance, BigDecimal spid, BigDecimal scheduledPaymentsPastDue,
			BigDecimal tcuMonitorStatusCode, BigDecimal totalPayments30Days, BigDecimal paymentAmountTSP,
			BigDecimal numPurchasesTSP, BigDecimal totalFeesTSP, BigDecimal otherDebits, BigDecimal otherCredits,
			BigDecimal numFailedPayments, BigDecimal valueFailedPayments, BigDecimal interestChargedAmtTSP,
			BigDecimal purchaseAmountTSP, BigDecimal numNSF, BigDecimal rebatesAmountTSP,
			BigDecimal netSalesValueTSPAmt, BigDecimal totalNumCreditPayments, BigDecimal daysInCollPeriod,
			Date firstCollStmtDate, BigDecimal inCollectionsInd, BigDecimal inDebtManagerInd, String annualSalary,
			String householdIncome, BigDecimal noOfDependants, String employmentStatus, String residentStatus,
			String sixMonthIncomeVerificationCode, String twelveMonthIncomeVerificationCode, Date dateOfChangeRequest,
			String previousAnnualSalary, String previousHouseholdIncome, BigDecimal derivedIncome,
			BigDecimal optOutCreditLimitIncInd, BigDecimal arrearsBucket1, BigDecimal arrearsBucket2,
			BigDecimal arrearsBucket3, BigDecimal arrearsBucket4, BigDecimal arrearsBucket5, BigDecimal arrearsBucket6,
			Date lastPhoneCheckDate, String dmClassStatus0, String dmClassStatus1, String dmClassStatus2,
			String dmClassStatus3, String dmClassStatus4, String collCreditBand, String collAccountStatusCode,
			Date collTCSStatusChangeDate, String collCurrentBURef, String collPrincipalBrand,
			String collCreditStatusCode, String collCreditStatusSubCode, BigDecimal collDeceasedInd,
			String collLastSpecialCommentCode, BigDecimal collSPID, BigDecimal collCustomerType,
			BigDecimal collTransactionAmount, BigDecimal collMinVal, BigDecimal collNumPPI, BigDecimal collDeptCode,
			BigDecimal collAuthInd, BigDecimal collNotFullPayInd, String qcbDataPopulated, String qcbRiskNavigator,
			String qcbOverIndebtedness, BigDecimal qcbAddChar1, BigDecimal qcbAddChar2, BigDecimal qcbAddChar3,
			BigDecimal qcbAddChar4, BigDecimal qcbAddChar5, String qcbBSC410, String qcbBSC413, String qcbBSC435,
			String qcbBSC437, String qcbBSC438, String qcbDSC435, String qcbDSC437, String qcbDSC438, String qcbLSC250,
			String qcbLSC556, String qcbLSC557, String qcbLSC887, String qcbLSC888, String qcbLSC547, String qcbFSC402,
			String qcbLSC320, String qcbCSC4, String qcbLSC251, String qcbLSC173, String qcbFSC308, String qcbLSC157,
			String qcbSSC4, String qcbSSC2, String qcbXPCF09, String qcbDSC410, String qcbDSC413, String qcbFSC104,
			String qcbFSC111) {
		super();
		this.accountTypeCode = accountTypeCode;
		this.acdAlignedScore = acdAlignedScore;
		this.acdRawScore = acdRawScore;
		this.acdScorecardId = acdScorecardId;
		this.alignedBehaviourScore = alignedBehaviourScore;
		this.annotationPeriodInd = annotationPeriodInd;
		this.applicationCreditScore = applicationCreditScore;
		this.aPR = aPR;
		this.behaviourRawScore = behaviourRawScore;
		this.behaviourScore = behaviourScore;
		this.blockCode = blockCode;
		this.bnplBalance = bnplBalance;
		this.creditBandCodeInd = creditBandCodeInd;
		this.collectionMethodCode = collectionMethodCode;
		this.customerAccountNumber = customerAccountNumber;
		this.retailAccountNumber = retailAccountNumber;
		this.agreementNumber = agreementNumber;
		this.creditBand = creditBand;
		this.creditLimit = creditLimit;
		this.creditStatusCode = creditStatusCode;
		this.creditStatusSubCode = creditStatusSubCode;
		this.cRF = cRF;
		this.currentBalance = currentBalance;
		this.currentBURef = currentBURef;
		this.accountStatusCode = accountStatusCode;
		this.custAlignedScore = custAlignedScore;
		this.custNoMailInd = custNoMailInd;
		this.custRawScore = custRawScore;
		this.custScorecardId = custScorecardId;
		this.customerType = customerType;
		this.dateBankrupt = dateBankrupt;
		this.todaysAccountingDate = todaysAccountingDate;
		this.dateClosed = dateClosed;
		this.dateLastZeroBalance = dateLastZeroBalance;
		this.dateSection87 = dateSection87;
		this.dateLastArrangement = dateLastArrangement;
		this.dateLastCreditLimitDecrease = dateLastCreditLimitDecrease;
		this.dateLastCreditLimitIncrease = dateLastCreditLimitIncrease;
		this.dateLastCreditOrder = dateLastCreditOrder;
		this.dateLastDelinquent = dateLastDelinquent;
		this.dateLastRetailOrder = dateLastRetailOrder;
		this.dateLastPayment = dateLastPayment;
		this.dateLastPhoneCheck = dateLastPhoneCheck;
		this.dateLastStatement = dateLastStatement;
		this.dateMigratedToCredit = dateMigratedToCredit;
		this.dateNextStatement = dateNextStatement;
		this.dateNSF = dateNSF;
		this.dateOfBirth = dateOfBirth;
		this.datePaymentDue = datePaymentDue;
		this.dateRestart = dateRestart;
		this.dateRiskNavScoreUpdated = dateRiskNavScoreUpdated;
		this.dateStart = dateStart;
		this.dateStartDelinquency = dateStartDelinquency;
		this.dateEndDelinquency = dateEndDelinquency;
		this.accountStatusChangeDate = accountStatusChangeDate;
		this.dCAReturnCode = dCAReturnCode;
		this.debitSaleFlag = debitSaleFlag;
		this.deceasedInd = deceasedInd;
		this.emailAddressInd = emailAddressInd;
		this.fidScore = fidScore;
		this.fidScoreDate = fidScoreDate;
		this.fidScoreWorst = fidScoreWorst;
		this.creditLimitFrozenInd = creditLimitFrozenInd;
		this.highBalance = highBalance;
		this.highDelq = highDelq;
		this.homePhoneInd = homePhoneInd;
		this.lastFollowUpCode = lastFollowUpCode;
		this.lastSpecialCommentCode = lastSpecialCommentCode;
		this.creditLimitLastReview = creditLimitLastReview;
		this.minPayment = minPayment;
		this.mobileNumInd = mobileNumInd;
		this.ndrAlignedScore = ndrAlignedScore;
		this.ndrRawScore = ndrRawScore;
		this.ndrScorecardId = ndrScorecardId;
		this.nsfTodayInd = nsfTodayInd;
		this.numAccts = numAccts;
		this.numCashAccts = numCashAccts;
		this.numCreditAccts = numCreditAccts;
		this.numCycle1 = numCycle1;
		this.numCycle2 = numCycle2;
		this.numCycle3 = numCycle3;
		this.numCycle4 = numCycle4;
		this.numIBCAccts = numIBCAccts;
		this.numPaymentsTSP = numPaymentsTSP;
		this.numInstallmentsInArrears = numInstallmentsInArrears;
		this.ordersDeclined3mths = ordersDeclined3mths;
		this.oTB = oTB;
		this.otherAdjustmentsAmountTSP = otherAdjustmentsAmountTSP;
		this.overIndebtScore = overIndebtScore;
		this.pastDue = pastDue;
		this.lastPaymentAmount = lastPaymentAmount;
		this.paymentCurrentInd = paymentCurrentInd;
		this.lastPaymentMethod = lastPaymentMethod;
		this.paymentPreviousInd = paymentPreviousInd;
		this.paymentReschedInd = paymentReschedInd;
		this.creditPaymentsTotal = creditPaymentsTotal;
		this.ppiInd = ppiInd;
		this.principalBrand = principalBrand;
		this.promiseToPayInd = promiseToPayInd;
		this.paymentsTSPInd = paymentsTSPInd;
		this.paymtsSinceLastCollEntry = paymtsSinceLastCollEntry;
		this.recruitmentCRF = recruitmentCRF;
		this.recruitmentSource = recruitmentSource;
		this.returnsAmountTSP = returnsAmountTSP;
		this.riskNavScore = riskNavScore;
		this.scheduledPaymentAmt = scheduledPaymentAmt;
		this.scorecardId = scorecardId;
		this.screenBalance = screenBalance;
		this.spid = spid;
		this.scheduledPaymentsPastDue = scheduledPaymentsPastDue;
		this.tcuMonitorStatusCode = tcuMonitorStatusCode;
		this.totalPayments30Days = totalPayments30Days;
		this.paymentAmountTSP = paymentAmountTSP;
		this.numPurchasesTSP = numPurchasesTSP;
		this.totalFeesTSP = totalFeesTSP;
		this.otherDebits = otherDebits;
		this.otherCredits = otherCredits;
		this.numFailedPayments = numFailedPayments;
		this.valueFailedPayments = valueFailedPayments;
		this.interestChargedAmtTSP = interestChargedAmtTSP;
		this.purchaseAmountTSP = purchaseAmountTSP;
		this.numNSF = numNSF;
		this.rebatesAmountTSP = rebatesAmountTSP;
		this.netSalesValueTSPAmt = netSalesValueTSPAmt;
		this.totalNumCreditPayments = totalNumCreditPayments;
		this.daysInCollPeriod = daysInCollPeriod;
		this.firstCollStmtDate = firstCollStmtDate;
		this.inCollectionsInd = inCollectionsInd;
		this.inDebtManagerInd = inDebtManagerInd;
		this.annualSalary = annualSalary;
		this.householdIncome = householdIncome;
		this.noOfDependants = noOfDependants;
		this.employmentStatus = employmentStatus;
		this.residentStatus = residentStatus;
		this.sixMonthIncomeVerificationCode = sixMonthIncomeVerificationCode;
		this.twelveMonthIncomeVerificationCode = twelveMonthIncomeVerificationCode;
		this.dateOfChangeRequest = dateOfChangeRequest;
		this.previousAnnualSalary = previousAnnualSalary;
		this.previousHouseholdIncome = previousHouseholdIncome;
		this.derivedIncome = derivedIncome;
		this.optOutCreditLimitIncInd = optOutCreditLimitIncInd;
		this.arrearsBucket1 = arrearsBucket1;
		this.arrearsBucket2 = arrearsBucket2;
		this.arrearsBucket3 = arrearsBucket3;
		this.arrearsBucket4 = arrearsBucket4;
		this.arrearsBucket5 = arrearsBucket5;
		this.arrearsBucket6 = arrearsBucket6;
		this.lastPhoneCheckDate = lastPhoneCheckDate;
		this.dmClassStatus0 = dmClassStatus0;
		this.dmClassStatus1 = dmClassStatus1;
		this.dmClassStatus2 = dmClassStatus2;
		this.dmClassStatus3 = dmClassStatus3;
		this.dmClassStatus4 = dmClassStatus4;
		this.collCreditBand = collCreditBand;
		this.collAccountStatusCode = collAccountStatusCode;
		this.collTCSStatusChangeDate = collTCSStatusChangeDate;
		this.collCurrentBURef = collCurrentBURef;
		this.collPrincipalBrand = collPrincipalBrand;
		this.collCreditStatusCode = collCreditStatusCode;
		this.collCreditStatusSubCode = collCreditStatusSubCode;
		this.collDeceasedInd = collDeceasedInd;
		this.collLastSpecialCommentCode = collLastSpecialCommentCode;
		this.collSPID = collSPID;
		this.collCustomerType = collCustomerType;
		this.collTransactionAmount = collTransactionAmount;
		this.collMinVal = collMinVal;
		this.collNumPPI = collNumPPI;
		this.collDeptCode = collDeptCode;
		this.collAuthInd = collAuthInd;
		this.collNotFullPayInd = collNotFullPayInd;
		this.qcbDataPopulated = qcbDataPopulated;
		this.qcbRiskNavigator = qcbRiskNavigator;
		this.qcbOverIndebtedness = qcbOverIndebtedness;
		this.qcbAddChar1 = qcbAddChar1;
		this.qcbAddChar2 = qcbAddChar2;
		this.qcbAddChar3 = qcbAddChar3;
		this.qcbAddChar4 = qcbAddChar4;
		this.qcbAddChar5 = qcbAddChar5;
		this.qcbBSC410 = qcbBSC410;
		this.qcbBSC413 = qcbBSC413;
		this.qcbBSC435 = qcbBSC435;
		this.qcbBSC437 = qcbBSC437;
		this.qcbBSC438 = qcbBSC438;
		this.qcbDSC435 = qcbDSC435;
		this.qcbDSC437 = qcbDSC437;
		this.qcbDSC438 = qcbDSC438;
		this.qcbLSC250 = qcbLSC250;
		this.qcbLSC556 = qcbLSC556;
		this.qcbLSC557 = qcbLSC557;
		this.qcbLSC887 = qcbLSC887;
		this.qcbLSC888 = qcbLSC888;
		this.qcbLSC547 = qcbLSC547;
		this.qcbFSC402 = qcbFSC402;
		this.qcbLSC320 = qcbLSC320;
		this.qcbCSC4 = qcbCSC4;
		this.qcbLSC251 = qcbLSC251;
		this.qcbLSC173 = qcbLSC173;
		this.qcbFSC308 = qcbFSC308;
		this.qcbLSC157 = qcbLSC157;
		this.qcbSSC4 = qcbSSC4;
		this.qcbSSC2 = qcbSSC2;
		this.qcbXPCF09 = qcbXPCF09;
		this.qcbDSC410 = qcbDSC410;
		this.qcbDSC413 = qcbDSC413;
		this.qcbFSC104 = qcbFSC104;
		this.qcbFSC111 = qcbFSC111;
	}

	public String getAccountTypeCode() {
		return accountTypeCode;
	}

	public void setAccountTypeCode(String accountTypeCode) {
		this.accountTypeCode = accountTypeCode;
	}

	public BigDecimal getAcdAlignedScore() {
		return acdAlignedScore;
	}

	public void setAcdAlignedScore(BigDecimal acdAlignedScore) {
		this.acdAlignedScore = acdAlignedScore;
	}

	public BigDecimal getAcdRawScore() {
		return acdRawScore;
	}

	public void setAcdRawScore(BigDecimal acdRawScore) {
		this.acdRawScore = acdRawScore;
	}

	public BigDecimal getAcdScorecardId() {
		return acdScorecardId;
	}

	public void setAcdScorecardId(BigDecimal acdScorecardId) {
		this.acdScorecardId = acdScorecardId;
	}

	public BigDecimal getAlignedBehaviourScore() {
		return alignedBehaviourScore;
	}

	public void setAlignedBehaviourScore(BigDecimal alignedBehaviourScore) {
		this.alignedBehaviourScore = alignedBehaviourScore;
	}

	public BigDecimal getAnnotationPeriodInd() {
		return annotationPeriodInd;
	}

	public void setAnnotationPeriodInd(BigDecimal annotationPeriodInd) {
		this.annotationPeriodInd = annotationPeriodInd;
	}

	public BigDecimal getApplicationCreditScore() {
		return applicationCreditScore;
	}

	public void setApplicationCreditScore(BigDecimal applicationCreditScore) {
		this.applicationCreditScore = applicationCreditScore;
	}

	public BigDecimal getaPR() {
		return aPR;
	}

	public void setaPR(BigDecimal aPR) {
		this.aPR = aPR;
	}

	public BigDecimal getBehaviourRawScore() {
		return behaviourRawScore;
	}

	public void setBehaviourRawScore(BigDecimal behaviourRawScore) {
		this.behaviourRawScore = behaviourRawScore;
	}

	public BigDecimal getBehaviourScore() {
		return behaviourScore;
	}

	public void setBehaviourScore(BigDecimal behaviourScore) {
		this.behaviourScore = behaviourScore;
	}

	public String getBlockCode() {
		return blockCode;
	}

	public void setBlockCode(String blockCode) {
		this.blockCode = blockCode;
	}

	public BigDecimal getBnplBalance() {
		return bnplBalance;
	}

	public void setBnplBalance(BigDecimal bnplBalance) {
		this.bnplBalance = bnplBalance;
	}

	public BigDecimal getCreditBandCodeInd() {
		return creditBandCodeInd;
	}

	public void setCreditBandCodeInd(BigDecimal creditBandCodeInd) {
		this.creditBandCodeInd = creditBandCodeInd;
	}

	public BigDecimal getCollectionMethodCode() {
		return collectionMethodCode;
	}

	public void setCollectionMethodCode(BigDecimal collectionMethodCode) {
		this.collectionMethodCode = collectionMethodCode;
	}

	public String getCustomerAccountNumber() {
		return customerAccountNumber;
	}

	public void setCustomerAccountNumber(String customerAccountNumber) {
		this.customerAccountNumber = customerAccountNumber;
	}

	public String getRetailAccountNumber() {
		return retailAccountNumber;
	}

	public void setRetailAccountNumber(String retailAccountNumber) {
		this.retailAccountNumber = retailAccountNumber;
	}

	public String getAgreementNumber() {
		return agreementNumber;
	}

	public void setAgreementNumber(String agreementNumber) {
		this.agreementNumber = agreementNumber;
	}

	public String getCreditBand() {
		return creditBand;
	}

	public void setCreditBand(String creditBand) {
		this.creditBand = creditBand;
	}

	public BigDecimal getCreditLimit() {
		return creditLimit;
	}

	public void setCreditLimit(BigDecimal creditLimit) {
		this.creditLimit = creditLimit;
	}

	public String getCreditStatusCode() {
		return creditStatusCode;
	}

	public void setCreditStatusCode(String creditStatusCode) {
		this.creditStatusCode = creditStatusCode;
	}

	public String getCreditStatusSubCode() {
		return creditStatusSubCode;
	}

	public void setCreditStatusSubCode(String creditStatusSubCode) {
		this.creditStatusSubCode = creditStatusSubCode;
	}

	public BigDecimal getcRF() {
		return cRF;
	}

	public void setcRF(BigDecimal cRF) {
		this.cRF = cRF;
	}

	public BigDecimal getCurrentBalance() {
		return currentBalance;
	}

	public void setCurrentBalance(BigDecimal currentBalance) {
		this.currentBalance = currentBalance;
	}

	public String getCurrentBURef() {
		return currentBURef;
	}

	public void setCurrentBURef(String currentBURef) {
		this.currentBURef = currentBURef;
	}

	public String getAccountStatusCode() {
		return accountStatusCode;
	}

	public void setAccountStatusCode(String accountStatusCode) {
		this.accountStatusCode = accountStatusCode;
	}

	public BigDecimal getCustAlignedScore() {
		return custAlignedScore;
	}

	public void setCustAlignedScore(BigDecimal custAlignedScore) {
		this.custAlignedScore = custAlignedScore;
	}

	public BigDecimal getCustNoMailInd() {
		return custNoMailInd;
	}

	public void setCustNoMailInd(BigDecimal custNoMailInd) {
		this.custNoMailInd = custNoMailInd;
	}

	public BigDecimal getCustRawScore() {
		return custRawScore;
	}

	public void setCustRawScore(BigDecimal custRawScore) {
		this.custRawScore = custRawScore;
	}

	public BigDecimal getCustScorecardId() {
		return custScorecardId;
	}

	public void setCustScorecardId(BigDecimal custScorecardId) {
		this.custScorecardId = custScorecardId;
	}

	public BigDecimal getCustomerType() {
		return customerType;
	}

	public void setCustomerType(BigDecimal customerType) {
		this.customerType = customerType;
	}

	public Date getDateBankrupt() {
		return dateBankrupt;
	}

	public void setDateBankrupt(Date dateBankrupt) {
		this.dateBankrupt = dateBankrupt;
	}

	public Date getTodaysAccountingDate() {
		return todaysAccountingDate;
	}

	public void setTodaysAccountingDate(Date todaysAccountingDate) {
		this.todaysAccountingDate = todaysAccountingDate;
	}

	public Date getDateClosed() {
		return dateClosed;
	}

	public void setDateClosed(Date dateClosed) {
		this.dateClosed = dateClosed;
	}

	public Date getDateLastZeroBalance() {
		return dateLastZeroBalance;
	}

	public void setDateLastZeroBalance(Date dateLastZeroBalance) {
		this.dateLastZeroBalance = dateLastZeroBalance;
	}

	public Date getDateSection87() {
		return dateSection87;
	}

	public void setDateSection87(Date dateSection87) {
		this.dateSection87 = dateSection87;
	}

	public Date getDateLastArrangement() {
		return dateLastArrangement;
	}

	public void setDateLastArrangement(Date dateLastArrangement) {
		this.dateLastArrangement = dateLastArrangement;
	}

	public Date getDateLastCreditLimitDecrease() {
		return dateLastCreditLimitDecrease;
	}

	public void setDateLastCreditLimitDecrease(Date dateLastCreditLimitDecrease) {
		this.dateLastCreditLimitDecrease = dateLastCreditLimitDecrease;
	}

	public Date getDateLastCreditLimitIncrease() {
		return dateLastCreditLimitIncrease;
	}

	public void setDateLastCreditLimitIncrease(Date dateLastCreditLimitIncrease) {
		this.dateLastCreditLimitIncrease = dateLastCreditLimitIncrease;
	}

	public Date getDateLastCreditOrder() {
		return dateLastCreditOrder;
	}

	public void setDateLastCreditOrder(Date dateLastCreditOrder) {
		this.dateLastCreditOrder = dateLastCreditOrder;
	}

	public Date getDateLastDelinquent() {
		return dateLastDelinquent;
	}

	public void setDateLastDelinquent(Date dateLastDelinquent) {
		this.dateLastDelinquent = dateLastDelinquent;
	}

	public Date getDateLastRetailOrder() {
		return dateLastRetailOrder;
	}

	public void setDateLastRetailOrder(Date dateLastRetailOrder) {
		this.dateLastRetailOrder = dateLastRetailOrder;
	}

	public Date getDateLastPayment() {
		return dateLastPayment;
	}

	public void setDateLastPayment(Date dateLastPayment) {
		this.dateLastPayment = dateLastPayment;
	}

	public Date getDateLastPhoneCheck() {
		return dateLastPhoneCheck;
	}

	public void setDateLastPhoneCheck(Date dateLastPhoneCheck) {
		this.dateLastPhoneCheck = dateLastPhoneCheck;
	}

	public Date getDateLastStatement() {
		return dateLastStatement;
	}

	public void setDateLastStatement(Date dateLastStatement) {
		this.dateLastStatement = dateLastStatement;
	}

	public Date getDateMigratedToCredit() {
		return dateMigratedToCredit;
	}

	public void setDateMigratedToCredit(Date dateMigratedToCredit) {
		this.dateMigratedToCredit = dateMigratedToCredit;
	}

	public Date getDateNextStatement() {
		return dateNextStatement;
	}

	public void setDateNextStatement(Date dateNextStatement) {
		this.dateNextStatement = dateNextStatement;
	}

	public Date getDateNSF() {
		return dateNSF;
	}

	public void setDateNSF(Date dateNSF) {
		this.dateNSF = dateNSF;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public Date getDatePaymentDue() {
		return datePaymentDue;
	}

	public void setDatePaymentDue(Date datePaymentDue) {
		this.datePaymentDue = datePaymentDue;
	}

	public Date getDateRestart() {
		return dateRestart;
	}

	public void setDateRestart(Date dateRestart) {
		this.dateRestart = dateRestart;
	}

	public Date getDateRiskNavScoreUpdated() {
		return dateRiskNavScoreUpdated;
	}

	public void setDateRiskNavScoreUpdated(Date dateRiskNavScoreUpdated) {
		this.dateRiskNavScoreUpdated = dateRiskNavScoreUpdated;
	}

	public Date getDateStart() {
		return dateStart;
	}

	public void setDateStart(Date dateStart) {
		this.dateStart = dateStart;
	}

	public Date getDateStartDelinquency() {
		return dateStartDelinquency;
	}

	public void setDateStartDelinquency(Date dateStartDelinquency) {
		this.dateStartDelinquency = dateStartDelinquency;
	}

	public Date getDateEndDelinquency() {
		return dateEndDelinquency;
	}

	public void setDateEndDelinquency(Date dateEndDelinquency) {
		this.dateEndDelinquency = dateEndDelinquency;
	}

	public Date getAccountStatusChangeDate() {
		return accountStatusChangeDate;
	}

	public void setAccountStatusChangeDate(Date accountStatusChangeDate) {
		this.accountStatusChangeDate = accountStatusChangeDate;
	}

	public BigDecimal getdCAReturnCode() {
		return dCAReturnCode;
	}

	public void setdCAReturnCode(BigDecimal dCAReturnCode) {
		this.dCAReturnCode = dCAReturnCode;
	}

	public BigDecimal getDebitSaleFlag() {
		return debitSaleFlag;
	}

	public void setDebitSaleFlag(BigDecimal debitSaleFlag) {
		this.debitSaleFlag = debitSaleFlag;
	}

	public BigDecimal getDeceasedInd() {
		return deceasedInd;
	}

	public void setDeceasedInd(BigDecimal deceasedInd) {
		this.deceasedInd = deceasedInd;
	}

	public String getEmailAddressInd() {
		return emailAddressInd;
	}

	public void setEmailAddressInd(String emailAddressInd) {
		this.emailAddressInd = emailAddressInd;
	}

	public String getFidScore() {
		return fidScore;
	}

	public void setFidScore(String fidScore) {
		this.fidScore = fidScore;
	}

	public Date getFidScoreDate() {
		return fidScoreDate;
	}

	public void setFidScoreDate(Date fidScoreDate) {
		this.fidScoreDate = fidScoreDate;
	}

	public String getFidScoreWorst() {
		return fidScoreWorst;
	}

	public void setFidScoreWorst(String fidScoreWorst) {
		this.fidScoreWorst = fidScoreWorst;
	}

	public BigDecimal getCreditLimitFrozenInd() {
		return creditLimitFrozenInd;
	}

	public void setCreditLimitFrozenInd(BigDecimal creditLimitFrozenInd) {
		this.creditLimitFrozenInd = creditLimitFrozenInd;
	}

	public BigDecimal getHighBalance() {
		return highBalance;
	}

	public void setHighBalance(BigDecimal highBalance) {
		this.highBalance = highBalance;
	}

	public BigDecimal getHighDelq() {
		return highDelq;
	}

	public void setHighDelq(BigDecimal highDelq) {
		this.highDelq = highDelq;
	}

	public BigDecimal getHomePhoneInd() {
		return homePhoneInd;
	}

	public void setHomePhoneInd(BigDecimal homePhoneInd) {
		this.homePhoneInd = homePhoneInd;
	}

	public BigDecimal getLastFollowUpCode() {
		return lastFollowUpCode;
	}

	public void setLastFollowUpCode(BigDecimal lastFollowUpCode) {
		this.lastFollowUpCode = lastFollowUpCode;
	}

	public String getLastSpecialCommentCode() {
		return lastSpecialCommentCode;
	}

	public void setLastSpecialCommentCode(String lastSpecialCommentCode) {
		this.lastSpecialCommentCode = lastSpecialCommentCode;
	}

	public BigDecimal getCreditLimitLastReview() {
		return creditLimitLastReview;
	}

	public void setCreditLimitLastReview(BigDecimal creditLimitLastReview) {
		this.creditLimitLastReview = creditLimitLastReview;
	}

	public BigDecimal getMinPayment() {
		return minPayment;
	}

	public void setMinPayment(BigDecimal minPayment) {
		this.minPayment = minPayment;
	}

	public BigDecimal getMobileNumInd() {
		return mobileNumInd;
	}

	public void setMobileNumInd(BigDecimal mobileNumInd) {
		this.mobileNumInd = mobileNumInd;
	}

	public BigDecimal getNdrAlignedScore() {
		return ndrAlignedScore;
	}

	public void setNdrAlignedScore(BigDecimal ndrAlignedScore) {
		this.ndrAlignedScore = ndrAlignedScore;
	}

	public BigDecimal getNdrRawScore() {
		return ndrRawScore;
	}

	public void setNdrRawScore(BigDecimal ndrRawScore) {
		this.ndrRawScore = ndrRawScore;
	}

	public BigDecimal getNdrScorecardId() {
		return ndrScorecardId;
	}

	public void setNdrScorecardId(BigDecimal ndrScorecardId) {
		this.ndrScorecardId = ndrScorecardId;
	}

	public BigDecimal getNsfTodayInd() {
		return nsfTodayInd;
	}

	public void setNsfTodayInd(BigDecimal nsfTodayInd) {
		this.nsfTodayInd = nsfTodayInd;
	}

	public BigDecimal getNumAccts() {
		return numAccts;
	}

	public void setNumAccts(BigDecimal numAccts) {
		this.numAccts = numAccts;
	}

	public BigDecimal getNumCashAccts() {
		return numCashAccts;
	}

	public void setNumCashAccts(BigDecimal numCashAccts) {
		this.numCashAccts = numCashAccts;
	}

	public BigDecimal getNumCreditAccts() {
		return numCreditAccts;
	}

	public void setNumCreditAccts(BigDecimal numCreditAccts) {
		this.numCreditAccts = numCreditAccts;
	}

	public BigDecimal getNumCycle1() {
		return numCycle1;
	}

	public void setNumCycle1(BigDecimal numCycle1) {
		this.numCycle1 = numCycle1;
	}

	public BigDecimal getNumCycle2() {
		return numCycle2;
	}

	public void setNumCycle2(BigDecimal numCycle2) {
		this.numCycle2 = numCycle2;
	}

	public BigDecimal getNumCycle3() {
		return numCycle3;
	}

	public void setNumCycle3(BigDecimal numCycle3) {
		this.numCycle3 = numCycle3;
	}

	public BigDecimal getNumCycle4() {
		return numCycle4;
	}

	public void setNumCycle4(BigDecimal numCycle4) {
		this.numCycle4 = numCycle4;
	}

	public BigDecimal getNumIBCAccts() {
		return numIBCAccts;
	}

	public void setNumIBCAccts(BigDecimal numIBCAccts) {
		this.numIBCAccts = numIBCAccts;
	}

	public BigDecimal getNumPaymentsTSP() {
		return numPaymentsTSP;
	}

	public void setNumPaymentsTSP(BigDecimal numPaymentsTSP) {
		this.numPaymentsTSP = numPaymentsTSP;
	}

	public BigDecimal getNumInstallmentsInArrears() {
		return numInstallmentsInArrears;
	}

	public void setNumInstallmentsInArrears(BigDecimal numInstallmentsInArrears) {
		this.numInstallmentsInArrears = numInstallmentsInArrears;
	}

	public BigDecimal getOrdersDeclined3mths() {
		return ordersDeclined3mths;
	}

	public void setOrdersDeclined3mths(BigDecimal ordersDeclined3mths) {
		this.ordersDeclined3mths = ordersDeclined3mths;
	}

	public BigDecimal getoTB() {
		return oTB;
	}

	public void setoTB(BigDecimal oTB) {
		this.oTB = oTB;
	}

	public BigDecimal getOtherAdjustmentsAmountTSP() {
		return otherAdjustmentsAmountTSP;
	}

	public void setOtherAdjustmentsAmountTSP(BigDecimal otherAdjustmentsAmountTSP) {
		this.otherAdjustmentsAmountTSP = otherAdjustmentsAmountTSP;
	}

	public BigDecimal getOverIndebtScore() {
		return overIndebtScore;
	}

	public void setOverIndebtScore(BigDecimal overIndebtScore) {
		this.overIndebtScore = overIndebtScore;
	}

	public BigDecimal getPastDue() {
		return pastDue;
	}

	public void setPastDue(BigDecimal pastDue) {
		this.pastDue = pastDue;
	}

	public BigDecimal getLastPaymentAmount() {
		return lastPaymentAmount;
	}

	public void setLastPaymentAmount(BigDecimal lastPaymentAmount) {
		this.lastPaymentAmount = lastPaymentAmount;
	}

	public BigDecimal getPaymentCurrentInd() {
		return paymentCurrentInd;
	}

	public void setPaymentCurrentInd(BigDecimal paymentCurrentInd) {
		this.paymentCurrentInd = paymentCurrentInd;
	}

	public BigDecimal getLastPaymentMethod() {
		return lastPaymentMethod;
	}

	public void setLastPaymentMethod(BigDecimal lastPaymentMethod) {
		this.lastPaymentMethod = lastPaymentMethod;
	}

	public BigDecimal getPaymentPreviousInd() {
		return paymentPreviousInd;
	}

	public void setPaymentPreviousInd(BigDecimal paymentPreviousInd) {
		this.paymentPreviousInd = paymentPreviousInd;
	}

	public BigDecimal getPaymentReschedInd() {
		return paymentReschedInd;
	}

	public void setPaymentReschedInd(BigDecimal paymentReschedInd) {
		this.paymentReschedInd = paymentReschedInd;
	}

	public BigDecimal getCreditPaymentsTotal() {
		return creditPaymentsTotal;
	}

	public void setCreditPaymentsTotal(BigDecimal creditPaymentsTotal) {
		this.creditPaymentsTotal = creditPaymentsTotal;
	}

	public BigDecimal getPpiInd() {
		return ppiInd;
	}

	public void setPpiInd(BigDecimal ppiInd) {
		this.ppiInd = ppiInd;
	}

	public String getPrincipalBrand() {
		return principalBrand;
	}

	public void setPrincipalBrand(String principalBrand) {
		this.principalBrand = principalBrand;
	}

	public BigDecimal getPromiseToPayInd() {
		return promiseToPayInd;
	}

	public void setPromiseToPayInd(BigDecimal promiseToPayInd) {
		this.promiseToPayInd = promiseToPayInd;
	}

	public BigDecimal getPaymentsTSPInd() {
		return paymentsTSPInd;
	}

	public void setPaymentsTSPInd(BigDecimal paymentsTSPInd) {
		this.paymentsTSPInd = paymentsTSPInd;
	}

	public BigDecimal getPaymtsSinceLastCollEntry() {
		return paymtsSinceLastCollEntry;
	}

	public void setPaymtsSinceLastCollEntry(BigDecimal paymtsSinceLastCollEntry) {
		this.paymtsSinceLastCollEntry = paymtsSinceLastCollEntry;
	}

	public BigDecimal getRecruitmentCRF() {
		return recruitmentCRF;
	}

	public void setRecruitmentCRF(BigDecimal recruitmentCRF) {
		this.recruitmentCRF = recruitmentCRF;
	}

	public BigDecimal getRecruitmentSource() {
		return recruitmentSource;
	}

	public void setRecruitmentSource(BigDecimal recruitmentSource) {
		this.recruitmentSource = recruitmentSource;
	}

	public BigDecimal getReturnsAmountTSP() {
		return returnsAmountTSP;
	}

	public void setReturnsAmountTSP(BigDecimal returnsAmountTSP) {
		this.returnsAmountTSP = returnsAmountTSP;
	}

	public BigDecimal getRiskNavScore() {
		return riskNavScore;
	}

	public void setRiskNavScore(BigDecimal riskNavScore) {
		this.riskNavScore = riskNavScore;
	}

	public BigDecimal getScheduledPaymentAmt() {
		return scheduledPaymentAmt;
	}

	public void setScheduledPaymentAmt(BigDecimal scheduledPaymentAmt) {
		this.scheduledPaymentAmt = scheduledPaymentAmt;
	}

	public BigDecimal getScorecardId() {
		return scorecardId;
	}

	public void setScorecardId(BigDecimal scorecardId) {
		this.scorecardId = scorecardId;
	}

	public BigDecimal getScreenBalance() {
		return screenBalance;
	}

	public void setScreenBalance(BigDecimal screenBalance) {
		this.screenBalance = screenBalance;
	}

	public BigDecimal getSpid() {
		return spid;
	}

	public void setSpid(BigDecimal spid) {
		this.spid = spid;
	}

	public BigDecimal getScheduledPaymentsPastDue() {
		return scheduledPaymentsPastDue;
	}

	public void setScheduledPaymentsPastDue(BigDecimal scheduledPaymentsPastDue) {
		this.scheduledPaymentsPastDue = scheduledPaymentsPastDue;
	}

	public BigDecimal getTcuMonitorStatusCode() {
		return tcuMonitorStatusCode;
	}

	public void setTcuMonitorStatusCode(BigDecimal tcuMonitorStatusCode) {
		this.tcuMonitorStatusCode = tcuMonitorStatusCode;
	}

	public BigDecimal getTotalPayments30Days() {
		return totalPayments30Days;
	}

	public void setTotalPayments30Days(BigDecimal totalPayments30Days) {
		this.totalPayments30Days = totalPayments30Days;
	}

	public BigDecimal getPaymentAmountTSP() {
		return paymentAmountTSP;
	}

	public void setPaymentAmountTSP(BigDecimal paymentAmountTSP) {
		this.paymentAmountTSP = paymentAmountTSP;
	}

	public BigDecimal getNumPurchasesTSP() {
		return numPurchasesTSP;
	}

	public void setNumPurchasesTSP(BigDecimal numPurchasesTSP) {
		this.numPurchasesTSP = numPurchasesTSP;
	}

	public BigDecimal getTotalFeesTSP() {
		return totalFeesTSP;
	}

	public void setTotalFeesTSP(BigDecimal totalFeesTSP) {
		this.totalFeesTSP = totalFeesTSP;
	}

	public BigDecimal getOtherDebits() {
		return otherDebits;
	}

	public void setOtherDebits(BigDecimal otherDebits) {
		this.otherDebits = otherDebits;
	}

	public BigDecimal getOtherCredits() {
		return otherCredits;
	}

	public void setOtherCredits(BigDecimal otherCredits) {
		this.otherCredits = otherCredits;
	}

	public BigDecimal getNumFailedPayments() {
		return numFailedPayments;
	}

	public void setNumFailedPayments(BigDecimal numFailedPayments) {
		this.numFailedPayments = numFailedPayments;
	}

	public BigDecimal getValueFailedPayments() {
		return valueFailedPayments;
	}

	public void setValueFailedPayments(BigDecimal valueFailedPayments) {
		this.valueFailedPayments = valueFailedPayments;
	}

	public BigDecimal getInterestChargedAmtTSP() {
		return interestChargedAmtTSP;
	}

	public void setInterestChargedAmtTSP(BigDecimal interestChargedAmtTSP) {
		this.interestChargedAmtTSP = interestChargedAmtTSP;
	}

	public BigDecimal getPurchaseAmountTSP() {
		return purchaseAmountTSP;
	}

	public void setPurchaseAmountTSP(BigDecimal purchaseAmountTSP) {
		this.purchaseAmountTSP = purchaseAmountTSP;
	}

	public BigDecimal getNumNSF() {
		return numNSF;
	}

	public void setNumNSF(BigDecimal numNSF) {
		this.numNSF = numNSF;
	}

	public BigDecimal getRebatesAmountTSP() {
		return rebatesAmountTSP;
	}

	public void setRebatesAmountTSP(BigDecimal rebatesAmountTSP) {
		this.rebatesAmountTSP = rebatesAmountTSP;
	}

	public BigDecimal getNetSalesValueTSPAmt() {
		return netSalesValueTSPAmt;
	}

	public void setNetSalesValueTSPAmt(BigDecimal netSalesValueTSPAmt) {
		this.netSalesValueTSPAmt = netSalesValueTSPAmt;
	}

	public BigDecimal getTotalNumCreditPayments() {
		return totalNumCreditPayments;
	}

	public void setTotalNumCreditPayments(BigDecimal totalNumCreditPayments) {
		this.totalNumCreditPayments = totalNumCreditPayments;
	}

	public BigDecimal getDaysInCollPeriod() {
		return daysInCollPeriod;
	}

	public void setDaysInCollPeriod(BigDecimal daysInCollPeriod) {
		this.daysInCollPeriod = daysInCollPeriod;
	}

	public Date getFirstCollStmtDate() {
		return firstCollStmtDate;
	}

	public void setFirstCollStmtDate(Date firstCollStmtDate) {
		this.firstCollStmtDate = firstCollStmtDate;
	}

	public BigDecimal getInCollectionsInd() {
		return inCollectionsInd;
	}

	public void setInCollectionsInd(BigDecimal inCollectionsInd) {
		this.inCollectionsInd = inCollectionsInd;
	}

	public BigDecimal getInDebtManagerInd() {
		return inDebtManagerInd;
	}

	public void setInDebtManagerInd(BigDecimal inDebtManagerInd) {
		this.inDebtManagerInd = inDebtManagerInd;
	}

	public String getAnnualSalary() {
		return annualSalary;
	}

	public void setAnnualSalary(String annualSalary) {
		this.annualSalary = annualSalary;
	}

	public String getHouseholdIncome() {
		return householdIncome;
	}

	public void setHouseholdIncome(String householdIncome) {
		this.householdIncome = householdIncome;
	}

	public BigDecimal getNoOfDependants() {
		return noOfDependants;
	}

	public void setNoOfDependants(BigDecimal noOfDependants) {
		this.noOfDependants = noOfDependants;
	}

	public String getEmploymentStatus() {
		return employmentStatus;
	}

	public void setEmploymentStatus(String employmentStatus) {
		this.employmentStatus = employmentStatus;
	}

	public String getResidentStatus() {
		return residentStatus;
	}

	public void setResidentStatus(String residentStatus) {
		this.residentStatus = residentStatus;
	}

	public String getSixMonthIncomeVerificationCode() {
		return sixMonthIncomeVerificationCode;
	}

	public void setSixMonthIncomeVerificationCode(String sixMonthIncomeVerificationCode) {
		this.sixMonthIncomeVerificationCode = sixMonthIncomeVerificationCode;
	}

	public String getTwelveMonthIncomeVerificationCode() {
		return twelveMonthIncomeVerificationCode;
	}

	public void setTwelveMonthIncomeVerificationCode(String twelveMonthIncomeVerificationCode) {
		this.twelveMonthIncomeVerificationCode = twelveMonthIncomeVerificationCode;
	}

	public Date getDateOfChangeRequest() {
		return dateOfChangeRequest;
	}

	public void setDateOfChangeRequest(Date dateOfChangeRequest) {
		this.dateOfChangeRequest = dateOfChangeRequest;
	}

	public String getPreviousAnnualSalary() {
		return previousAnnualSalary;
	}

	public void setPreviousAnnualSalary(String previousAnnualSalary) {
		this.previousAnnualSalary = previousAnnualSalary;
	}

	public String getPreviousHouseholdIncome() {
		return previousHouseholdIncome;
	}

	public void setPreviousHouseholdIncome(String previousHouseholdIncome) {
		this.previousHouseholdIncome = previousHouseholdIncome;
	}

	public BigDecimal getDerivedIncome() {
		return derivedIncome;
	}

	public void setDerivedIncome(BigDecimal derivedIncome) {
		this.derivedIncome = derivedIncome;
	}

	public BigDecimal getOptOutCreditLimitIncInd() {
		return optOutCreditLimitIncInd;
	}

	public void setOptOutCreditLimitIncInd(BigDecimal optOutCreditLimitIncInd) {
		this.optOutCreditLimitIncInd = optOutCreditLimitIncInd;
	}

	public BigDecimal getArrearsBucket1() {
		return arrearsBucket1;
	}

	public void setArrearsBucket1(BigDecimal arrearsBucket1) {
		this.arrearsBucket1 = arrearsBucket1;
	}

	public BigDecimal getArrearsBucket2() {
		return arrearsBucket2;
	}

	public void setArrearsBucket2(BigDecimal arrearsBucket2) {
		this.arrearsBucket2 = arrearsBucket2;
	}

	public BigDecimal getArrearsBucket3() {
		return arrearsBucket3;
	}

	public void setArrearsBucket3(BigDecimal arrearsBucket3) {
		this.arrearsBucket3 = arrearsBucket3;
	}

	public BigDecimal getArrearsBucket4() {
		return arrearsBucket4;
	}

	public void setArrearsBucket4(BigDecimal arrearsBucket4) {
		this.arrearsBucket4 = arrearsBucket4;
	}

	public BigDecimal getArrearsBucket5() {
		return arrearsBucket5;
	}

	public void setArrearsBucket5(BigDecimal arrearsBucket5) {
		this.arrearsBucket5 = arrearsBucket5;
	}

	public BigDecimal getArrearsBucket6() {
		return arrearsBucket6;
	}

	public void setArrearsBucket6(BigDecimal arrearsBucket6) {
		this.arrearsBucket6 = arrearsBucket6;
	}

	public Date getLastPhoneCheckDate() {
		return lastPhoneCheckDate;
	}

	public void setLastPhoneCheckDate(Date lastPhoneCheckDate) {
		this.lastPhoneCheckDate = lastPhoneCheckDate;
	}

	public String getDmClassStatus0() {
		return dmClassStatus0;
	}

	public void setDmClassStatus0(String dmClassStatus0) {
		this.dmClassStatus0 = dmClassStatus0;
	}

	public String getDmClassStatus1() {
		return dmClassStatus1;
	}

	public void setDmClassStatus1(String dmClassStatus1) {
		this.dmClassStatus1 = dmClassStatus1;
	}

	public String getDmClassStatus2() {
		return dmClassStatus2;
	}

	public void setDmClassStatus2(String dmClassStatus2) {
		this.dmClassStatus2 = dmClassStatus2;
	}

	public String getDmClassStatus3() {
		return dmClassStatus3;
	}

	public void setDmClassStatus3(String dmClassStatus3) {
		this.dmClassStatus3 = dmClassStatus3;
	}

	public String getDmClassStatus4() {
		return dmClassStatus4;
	}

	public void setDmClassStatus4(String dmClassStatus4) {
		this.dmClassStatus4 = dmClassStatus4;
	}

	public String getCollCreditBand() {
		return collCreditBand;
	}

	public void setCollCreditBand(String collCreditBand) {
		this.collCreditBand = collCreditBand;
	}

	public String getCollAccountStatusCode() {
		return collAccountStatusCode;
	}

	public void setCollAccountStatusCode(String collAccountStatusCode) {
		this.collAccountStatusCode = collAccountStatusCode;
	}

	public Date getCollTCSStatusChangeDate() {
		return collTCSStatusChangeDate;
	}

	public void setCollTCSStatusChangeDate(Date collTCSStatusChangeDate) {
		this.collTCSStatusChangeDate = collTCSStatusChangeDate;
	}

	public String getCollCurrentBURef() {
		return collCurrentBURef;
	}

	public void setCollCurrentBURef(String collCurrentBURef) {
		this.collCurrentBURef = collCurrentBURef;
	}

	public String getCollPrincipalBrand() {
		return collPrincipalBrand;
	}

	public void setCollPrincipalBrand(String collPrincipalBrand) {
		this.collPrincipalBrand = collPrincipalBrand;
	}

	public String getCollCreditStatusCode() {
		return collCreditStatusCode;
	}

	public void setCollCreditStatusCode(String collCreditStatusCode) {
		this.collCreditStatusCode = collCreditStatusCode;
	}

	public String getCollCreditStatusSubCode() {
		return collCreditStatusSubCode;
	}

	public void setCollCreditStatusSubCode(String collCreditStatusSubCode) {
		this.collCreditStatusSubCode = collCreditStatusSubCode;
	}

	public BigDecimal getCollDeceasedInd() {
		return collDeceasedInd;
	}

	public void setCollDeceasedInd(BigDecimal collDeceasedInd) {
		this.collDeceasedInd = collDeceasedInd;
	}

	public String getCollLastSpecialCommentCode() {
		return collLastSpecialCommentCode;
	}

	public void setCollLastSpecialCommentCode(String collLastSpecialCommentCode) {
		this.collLastSpecialCommentCode = collLastSpecialCommentCode;
	}

	public BigDecimal getCollSPID() {
		return collSPID;
	}

	public void setCollSPID(BigDecimal collSPID) {
		this.collSPID = collSPID;
	}

	public BigDecimal getCollCustomerType() {
		return collCustomerType;
	}

	public void setCollCustomerType(BigDecimal collCustomerType) {
		this.collCustomerType = collCustomerType;
	}

	public BigDecimal getCollTransactionAmount() {
		return collTransactionAmount;
	}

	public void setCollTransactionAmount(BigDecimal collTransactionAmount) {
		this.collTransactionAmount = collTransactionAmount;
	}

	public BigDecimal getCollMinVal() {
		return collMinVal;
	}

	public void setCollMinVal(BigDecimal collMinVal) {
		this.collMinVal = collMinVal;
	}

	public BigDecimal getCollNumPPI() {
		return collNumPPI;
	}

	public void setCollNumPPI(BigDecimal collNumPPI) {
		this.collNumPPI = collNumPPI;
	}

	public BigDecimal getCollDeptCode() {
		return collDeptCode;
	}

	public void setCollDeptCode(BigDecimal collDeptCode) {
		this.collDeptCode = collDeptCode;
	}

	public BigDecimal getCollAuthInd() {
		return collAuthInd;
	}

	public void setCollAuthInd(BigDecimal collAuthInd) {
		this.collAuthInd = collAuthInd;
	}

	public BigDecimal getCollNotFullPayInd() {
		return collNotFullPayInd;
	}

	public void setCollNotFullPayInd(BigDecimal collNotFullPayInd) {
		this.collNotFullPayInd = collNotFullPayInd;
	}

	public String getQcbDataPopulated() {
		return qcbDataPopulated;
	}

	public void setQcbDataPopulated(String qcbDataPopulated) {
		this.qcbDataPopulated = qcbDataPopulated;
	}

	public String getQcbRiskNavigator() {
		return qcbRiskNavigator;
	}

	public void setQcbRiskNavigator(String qcbRiskNavigator) {
		this.qcbRiskNavigator = qcbRiskNavigator;
	}

	public String getQcbOverIndebtedness() {
		return qcbOverIndebtedness;
	}

	public void setQcbOverIndebtedness(String qcbOverIndebtedness) {
		this.qcbOverIndebtedness = qcbOverIndebtedness;
	}

	public BigDecimal getQcbAddChar1() {
		return qcbAddChar1;
	}

	public void setQcbAddChar1(BigDecimal qcbAddChar1) {
		this.qcbAddChar1 = qcbAddChar1;
	}

	public BigDecimal getQcbAddChar2() {
		return qcbAddChar2;
	}

	public void setQcbAddChar2(BigDecimal qcbAddChar2) {
		this.qcbAddChar2 = qcbAddChar2;
	}

	public BigDecimal getQcbAddChar3() {
		return qcbAddChar3;
	}

	public void setQcbAddChar3(BigDecimal qcbAddChar3) {
		this.qcbAddChar3 = qcbAddChar3;
	}

	public BigDecimal getQcbAddChar4() {
		return qcbAddChar4;
	}

	public void setQcbAddChar4(BigDecimal qcbAddChar4) {
		this.qcbAddChar4 = qcbAddChar4;
	}

	public BigDecimal getQcbAddChar5() {
		return qcbAddChar5;
	}

	public void setQcbAddChar5(BigDecimal qcbAddChar5) {
		this.qcbAddChar5 = qcbAddChar5;
	}

	public String getQcbBSC410() {
		return qcbBSC410;
	}

	public void setQcbBSC410(String qcbBSC410) {
		this.qcbBSC410 = qcbBSC410;
	}

	public String getQcbBSC413() {
		return qcbBSC413;
	}

	public void setQcbBSC413(String qcbBSC413) {
		this.qcbBSC413 = qcbBSC413;
	}

	public String getQcbBSC435() {
		return qcbBSC435;
	}

	public void setQcbBSC435(String qcbBSC435) {
		this.qcbBSC435 = qcbBSC435;
	}

	public String getQcbBSC437() {
		return qcbBSC437;
	}

	public void setQcbBSC437(String qcbBSC437) {
		this.qcbBSC437 = qcbBSC437;
	}

	public String getQcbBSC438() {
		return qcbBSC438;
	}

	public void setQcbBSC438(String qcbBSC438) {
		this.qcbBSC438 = qcbBSC438;
	}

	public String getQcbDSC435() {
		return qcbDSC435;
	}

	public void setQcbDSC435(String qcbDSC435) {
		this.qcbDSC435 = qcbDSC435;
	}

	public String getQcbDSC437() {
		return qcbDSC437;
	}

	public void setQcbDSC437(String qcbDSC437) {
		this.qcbDSC437 = qcbDSC437;
	}

	public String getQcbDSC438() {
		return qcbDSC438;
	}

	public void setQcbDSC438(String qcbDSC438) {
		this.qcbDSC438 = qcbDSC438;
	}

	public String getQcbLSC250() {
		return qcbLSC250;
	}

	public void setQcbLSC250(String qcbLSC250) {
		this.qcbLSC250 = qcbLSC250;
	}

	public String getQcbLSC556() {
		return qcbLSC556;
	}

	public void setQcbLSC556(String qcbLSC556) {
		this.qcbLSC556 = qcbLSC556;
	}

	public String getQcbLSC557() {
		return qcbLSC557;
	}

	public void setQcbLSC557(String qcbLSC557) {
		this.qcbLSC557 = qcbLSC557;
	}

	public String getQcbLSC887() {
		return qcbLSC887;
	}

	public void setQcbLSC887(String qcbLSC887) {
		this.qcbLSC887 = qcbLSC887;
	}

	public String getQcbLSC888() {
		return qcbLSC888;
	}

	public void setQcbLSC888(String qcbLSC888) {
		this.qcbLSC888 = qcbLSC888;
	}

	public String getQcbLSC547() {
		return qcbLSC547;
	}

	public void setQcbLSC547(String qcbLSC547) {
		this.qcbLSC547 = qcbLSC547;
	}

	public String getQcbFSC402() {
		return qcbFSC402;
	}

	public void setQcbFSC402(String qcbFSC402) {
		this.qcbFSC402 = qcbFSC402;
	}

	public String getQcbLSC320() {
		return qcbLSC320;
	}

	public void setQcbLSC320(String qcbLSC320) {
		this.qcbLSC320 = qcbLSC320;
	}

	public String getQcbCSC4() {
		return qcbCSC4;
	}

	public void setQcbCSC4(String qcbCSC4) {
		this.qcbCSC4 = qcbCSC4;
	}

	public String getQcbLSC251() {
		return qcbLSC251;
	}

	public void setQcbLSC251(String qcbLSC251) {
		this.qcbLSC251 = qcbLSC251;
	}

	public String getQcbLSC173() {
		return qcbLSC173;
	}

	public void setQcbLSC173(String qcbLSC173) {
		this.qcbLSC173 = qcbLSC173;
	}

	public String getQcbFSC308() {
		return qcbFSC308;
	}

	public void setQcbFSC308(String qcbFSC308) {
		this.qcbFSC308 = qcbFSC308;
	}

	public String getQcbLSC157() {
		return qcbLSC157;
	}

	public void setQcbLSC157(String qcbLSC157) {
		this.qcbLSC157 = qcbLSC157;
	}

	public String getQcbSSC4() {
		return qcbSSC4;
	}

	public void setQcbSSC4(String qcbSSC4) {
		this.qcbSSC4 = qcbSSC4;
	}

	public String getQcbSSC2() {
		return qcbSSC2;
	}

	public void setQcbSSC2(String qcbSSC2) {
		this.qcbSSC2 = qcbSSC2;
	}

	public String getQcbXPCF09() {
		return qcbXPCF09;
	}

	public void setQcbXPCF09(String qcbXPCF09) {
		this.qcbXPCF09 = qcbXPCF09;
	}

	public String getQcbDSC410() {
		return qcbDSC410;
	}

	public void setQcbDSC410(String qcbDSC410) {
		this.qcbDSC410 = qcbDSC410;
	}

	public String getQcbDSC413() {
		return qcbDSC413;
	}

	public void setQcbDSC413(String qcbDSC413) {
		this.qcbDSC413 = qcbDSC413;
	}

	public String getQcbFSC104() {
		return qcbFSC104;
	}

	public void setQcbFSC104(String qcbFSC104) {
		this.qcbFSC104 = qcbFSC104;
	}

	public String getQcbFSC111() {
		return qcbFSC111;
	}

	public void setQcbFSC111(String qcbFSC111) {
		this.qcbFSC111 = qcbFSC111;
	}
	
	
	
}