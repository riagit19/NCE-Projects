/**
 * 
 */
package com.shopdirect.nce.sp.dao.creditdataload;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.Query;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.dao.AccountReassessmentBaseDao;
import com.shopdirect.nce.sp.exception.BuisnessException;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.SpCreditFilLoadControl;
import com.shopdirect.nce.sp.util.UCPConnection;

/**
 * @author MeghnaBhattacharya
 *
 */
@SuppressWarnings("serial")
public class SpCreditFilLoadControlDaoImpl extends AccountReassessmentBaseDao {

	public SpCreditFilLoadControlDaoImpl() throws StatementProcessorBatchException {
		super();
		// TODO Auto-generated constructor stub
	}

	boolean isInsertSuccess = false;
	Connection connection = null;
	int retCode = 0;
	String retMsg = null;
	SpCreditFilLoadControl spCreditFilLoadControl = null;
	PreparedStatement preparedStatement = null;
	private static SDLoggerImpl logger = new SDLoggerImpl();
	long batchID = 0;

	/**
	 * @param agreementList
	 * @return
	 * @throws BuisnessException
	 * @throws Exception
	 */
	@SuppressWarnings("deprecation")
	public long fetchBatchId() throws BuisnessException, SQLException, Exception {
		logger.debug("[SpCreditFilLoadControlDaoImpl -- fetchBatchId]  -- START");
		long seqBatchId = 0;

		try {
			connection = UCPConnection.getConnection();

			// Call the Sequence
			preparedStatement = connection.prepareStatement("SELECT SP_CRDT_FIL_LOAD_SEQ.NEXTVAL FROM DUAL");
			ResultSet resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				seqBatchId = resultSet.getLong(1);
			}

			logger.debug("[SpCreditFilLoadControlDaoImpl -- fetchBatchId]  -- END");

		} catch (SQLException sqlException) {

			logger.error("SpCreditFilLoadControlDaoImpl SQLException Exception =======" + sqlException);
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_DB_ERROR_CODE,
					"[SpCreditFilLoadControlDaoImpl-fetchBatchId] SQLException Block",
					"Database execution exception [SQLCode: " + sqlException.getSQLState() + "] , SQL Detail "
							+ sqlException.getMessage(),
					null, null, sqlException);

		} catch (Exception exception) {

			getLogger().error("[SpCreditFilLoadControlDaoImpl -- updateFile] -- Control Table Update -- Generic Exception: " + exception);
			
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.CONNECTTION_DB_ERROR_CODE,
					"[SpCreditFilLoadControlDaoImpl-fetchBatchId] Exception Block",
					"Database execution exception " + exception.getMessage(), null, null, exception);

		} finally {

			try {

				if (preparedStatement != null) {
					preparedStatement.close();
				}

				if (connection != null) {
					connection.close();
				}

			} catch (Exception e) {
				getLogger().error("[SpCreditFilLoadControlDaoImpl -- updateFile] -- Control Table Update -- Finally Block Exception: " + e.getMessage());
			}
		}

		return seqBatchId;
	}

	/**
	 * @param agreementList
	 * @return
	 * @throws BuisnessException
	 * @throws Exception
	 */
	@SuppressWarnings("deprecation")
	public boolean insertControlData(SpCreditFilLoadControl spCreditFilLoadControl)
			throws BuisnessException, SQLException, Exception {
		logger.debug("[SpCreditFilLoadControlDaoImpl -- insertControlData]  -- START");
		boolean isInsertSuccess = false;
		try {
			connection = UCPConnection.getConnection();
			setSpMainSchema(getSchema(StatementProcessorBatchConstants.DB_SCHEMA_MAIN_SP_KEY));

			// Insert data into Control table
			String insertQuery = Query.getInsertControlDataQuery(getSpMainSchema());

			preparedStatement = connection.prepareStatement(insertQuery);
			preparedStatement.setLong(1, spCreditFilLoadControl.getBatchId());
			preparedStatement.setString(2, spCreditFilLoadControl.getFileName());
			preparedStatement.setString(3, spCreditFilLoadControl.getFileRunStatus());
			preparedStatement.setString(4, spCreditFilLoadControl.getErrorMessage());
			preparedStatement.setDate(5, spCreditFilLoadControl.getCreatedDate());
			preparedStatement.setInt(6, spCreditFilLoadControl.getCreatedBy());
			preparedStatement.setString(7, spCreditFilLoadControl.getFileIdentifier());
			preparedStatement.setString(8, spCreditFilLoadControl.getProcessName());

			int rowReturned = preparedStatement.executeUpdate();

			if (rowReturned == 0) {
				isInsertSuccess = false;
			} else {
				isInsertSuccess = true;

			}

			logger.debug("[SpCreditFilLoadControlDaoImpl -- insertControlData]  -- END");

		} catch (SQLException sqlException) {

			logger.error("SpCreditFilLoadControlDaoImpl SQLException Exception =======" + sqlException);
			
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_DB_ERROR_CODE,
					"[SpCreditFilLoadControlDaoImpl-insertControlData] SQLException Block",
					"Database execution exception [SQLCode: " + sqlException.getSQLState() + "] , SQL Detail "
							+ sqlException.getMessage(),
					null, null, sqlException);

		} catch (Exception exception) {

			getLogger().error("[SpCreditFilLoadControlDaoImpl -- updateFile] -- Control Table Update -- Generic Exception: " + exception);
			
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.CONNECTTION_DB_ERROR_CODE,
					"[SpCreditFilLoadControlDaoImpl-insertControlData] Exception Block",
					"Database execution exception " + exception.getMessage(), null, null, exception);

		} finally {

			try {

				if (preparedStatement != null) {
					preparedStatement.close();
				}

				if (connection != null) {
					connection.close();
				}

			} catch (Exception e) {
				getLogger().error("[SpCreditFilLoadControlDaoImpl -- updateFile] -- Control Table Update -- Finally Block Exception: " + e.getMessage());
			}
		}

		return isInsertSuccess;
	}

	/**
	 * @param agreementList
	 * @return
	 * @throws BuisnessException
	 * @throws Exception
	 */
	@SuppressWarnings("deprecation")
	public boolean updateControlData(long batchID, boolean insertSuccess, String errorMessege, String fileIdentifier)
			throws BuisnessException, SQLException, Exception {
		logger.debug("[SpCreditFilLoadControlDaoImpl -- updateControlData]  -- START");
		boolean isUpdateSuccess = false;
		Date currentDate = new Date();
		java.sql.Date lastDBUpdatedDate = null;
		setSpMainSchema(getSchema(StatementProcessorBatchConstants.DB_SCHEMA_MAIN_SP_KEY));

		lastDBUpdatedDate = new java.sql.Date(currentDate.getTime());

		String messege = StatementProcessorBatchConstants.EMPTY_STRING;
		String fileRunStatus = StatementProcessorBatchConstants.EMPTY_STRING;

		if (insertSuccess == false) {
//			messege = errorMessege;
			fileRunStatus = StatementProcessorBatchConstants.RUN_STATUS_FAILED;
		} else {
			fileRunStatus = StatementProcessorBatchConstants.RUN_STATUS_SUCCESS;
		}
		
		messege = errorMessege;

		try {
			connection = UCPConnection.getConnection();

			// Update data into Control table
			String updateQuery = Query.getUpdateControlDataQuery(getSpMainSchema());

			preparedStatement = connection.prepareStatement(updateQuery);
			preparedStatement.setString(1, fileRunStatus);
			preparedStatement.setString(2, messege);
			preparedStatement.setDate(3, lastDBUpdatedDate);
			preparedStatement.setLong(4, batchID);
			preparedStatement.setString(5, fileIdentifier);

			int rowReturned = preparedStatement.executeUpdate();

			if (rowReturned == 0) {
				isUpdateSuccess = false;
			} else {
				isUpdateSuccess = true;
			}

			logger.debug("[SpCreditFilLoadControlDaoImpl -- updateControlData]  -- END");

		} catch (SQLException sqlException) {

			getLogger().error("[SpCreditFilLoadControlDaoImpl -- updateFile] -- Control Table Update -- SQL Exception: " + sqlException);
			
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_DB_ERROR_CODE,
					"[SpCreditFilLoadControlDaoImpl-updateControlData] SQLException Block",
					"Database execution exception [SQLCode: " + sqlException.getSQLState() + "] , SQL Detail "
							+ sqlException.getMessage(),
					null, null, sqlException);

		} catch (Exception exception) {

			getLogger().error("[SpCreditFilLoadControlDaoImpl -- updateFile] -- Control Table Update -- Generic Exception: " + exception);
			
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.CONNECTTION_DB_ERROR_CODE,
					"[SpCreditFilLoadControlDaoImpl-updateControlData] Exception Block",
					"Database execution exception " + exception.getMessage(), null, null, exception);

		} finally {

			try {

				if (preparedStatement != null) {
					preparedStatement.close();
				}

				if (connection != null) {
					connection.close();
				}

			} catch (Exception e) {
				getLogger().error("[SpCreditFilLoadControlDaoImpl -- updateFile] -- Control Table Update -- Finally Block Exception: " + e.getMessage());
			}
		}

		return isUpdateSuccess;
	}

}
