package com.shopdirect.nce.sp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.Query;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.exception.BuisnessException;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.SpErrorLog;
import com.shopdirect.nce.sp.util.UCPConnection;

public class SPErrorLogDaoImpl extends AccountReassessmentBaseDao {

	public SPErrorLogDaoImpl() throws StatementProcessorBatchException {
		super();
		setSpMainSchema(getSchema(StatementProcessorBatchConstants.DB_SCHEMA_MAIN_SP_KEY));
		// TODO Auto-generated constructor stub
	}

	Connection connection = null;
	private static SDLoggerImpl logger = new SDLoggerImpl();
	
	

	public void insertErrorLogData (SpErrorLog spErrLog)
				throws BuisnessException, StatementProcessorBatchException{

		logger.debug("[SPErrorLogDaoImpl -- insertErrorLogData]  -- START");

		PreparedStatement  stmt = null;
		
		try {
			connection = UCPConnection.getConnection();
			
	    	String queryStr = Query.insertErrorLog(getSpMainSchema());	    	
	    	stmt = connection.prepareStatement(queryStr);
	    	stmt.setString(1, spErrLog.getProgramName());
			stmt.setString(2, spErrLog.getExeStat());
			stmt.setString(3, spErrLog.getStatusMsg());
			stmt.setString(4, spErrLog.getStepNumber());
			stmt.setString(5, spErrLog.getStepDesc());
			stmt.setString(6, spErrLog.getStepStatus());
			stmt.setString(7, spErrLog.getErrDesc());
			stmt.setTimestamp(8, spErrLog.getStartDate());	
			stmt.setTimestamp(9, spErrLog.getEndDate());
			stmt.setString(10, spErrLog.getErrCode());
			
			stmt.executeUpdate();

			logger.debug("[SPErrorLogDaoImpl -- insertErrorLogData]  -- END");

		} catch (SQLException sqlException) {

			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_DB_ERROR_CODE,
					"[SPErrorLogDaoImpl-insertErrorLogData] SQLException Block",
					"Database execution exception [SQLCode: " + sqlException.getSQLState() + "] , SQL Detail "
							+ sqlException.getMessage(),
					null, null, sqlException);

		} catch (Exception exception) {
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.CONNECTTION_DB_ERROR_CODE,
					"[SPErrorLogDaoImpl-insertErrorLogData] Exception Block",
					"Database execution exception " + exception.getMessage(), null, null, exception);
		} finally {

			try {

				if (stmt != null) {
					stmt.close();
				}

				if (connection != null) {
					connection.close();
				}

			} catch (Exception e) {
				logger.debug("[SPErrorLogDaoImpl-insertErrorLogData]  -- Exception Block, Database execution exception "+e.getMessage());				
			}
		}

	}
	/*
	 * This is utility method for getting current Date
	 */
	private static java.sql.Date getDate(java.util.Date inputDate) {
		if(inputDate!=null){
		return new java.sql.Date(inputDate.getTime());
		}
		else return null;
	}		
}
