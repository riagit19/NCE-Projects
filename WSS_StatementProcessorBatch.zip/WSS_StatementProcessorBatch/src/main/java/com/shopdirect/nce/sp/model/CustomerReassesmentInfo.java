package com.shopdirect.nce.sp.model;

import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * 
 * @author SudiptaRoy
 *
 */

@XmlRootElement
public class CustomerReassesmentInfo {

	private String publicAccountId;
	private Date statementDate;
	private String accountInfoId;
	private boolean isDormant;
	private String retailAccNum;

	public CustomerReassesmentInfo() {
	}

	public CustomerReassesmentInfo(String publicAccountId, Date statementDate, String accountInfoId, boolean isDormant, String retailAccNum) {
		this.publicAccountId = publicAccountId;
		this.statementDate = statementDate;
		this.accountInfoId = accountInfoId;
		this.isDormant = isDormant;
		this.retailAccNum = retailAccNum;
	}

	public String getPublicAccountId() {
		return publicAccountId;
	}

	public void setPublicAccountId(String publicAccountId) {
		this.publicAccountId = publicAccountId;
	}

	public Date getStatementDate() {
		return statementDate;
	}

	public void setStatementDate(Date statementDate) {
		this.statementDate = statementDate;
	}

	public String getAccountInfoId() {
		return accountInfoId;
	}

	public void setAccountInfoId(String accountInfoId) {
		this.accountInfoId = accountInfoId;
	}

	public boolean isDormant() {
		return isDormant;
	}

	public void setDormant(boolean isDormant) {
		this.isDormant = isDormant;
	}

	public String getRetailAccNum() {
		return retailAccNum;
	}

	public void setRetailAccNum(String retailAccNum) {
		this.retailAccNum = retailAccNum;
	}
	

}
