package com.shopdirect.nce.sp.business.creditdataload;

import java.io.File;
import java.io.FileReader;
import java.io.LineNumberReader;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.shopdirect.nce.sp.constants.CreditLoadDataConstants;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.dao.creditdataload.SpCreditFilLoadControlDaoImpl;
import com.shopdirect.nce.sp.dao.creditdataload.TargetedPaymentDaoImpl;
import com.shopdirect.nce.sp.exception.BuisnessException;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.TargetedPayment;
import com.shopdirect.nce.sp.util.FinFileBaseProcessor;
import com.shopdirect.nce.sp.util.StatementProcessorBatchUtil;

public class TargetedPmntFileProcessorImpl extends FinFileBaseProcessor implements DataFileProcessor {


	private TargetedPaymentDaoImpl tpDaoImpl;
	
	public TargetedPmntFileProcessorImpl() throws StatementProcessorBatchException {
		super();
	}

	/**
	 * @param folder
	 * @return
	 * @throws StatementProcessorBatchException
	 */
	public boolean processFile(File folder, long batchID, int user, String batchRunDate) throws StatementProcessorBatchException {
		
		getLogger().debug("[TargetedPmntFileProcessorImpl -- processFile]  -- START");
		String fileName = StatementProcessorBatchUtil.generateFileName(CreditLoadDataConstants.TARGETEDPAYMENT,
				CreditLoadDataConstants.NEW_STATUS, batchRunDate);
		File file = getFile(folder, fileName);
		String line = "";
		String comma = ",";
		List<Map<String, Object>> columns = getColumns(StatementProcessorBatchConstants.TARGET_PAYMENT_DATA_MAPPING,
				StatementProcessorBatchConstants.TARGET_PAYMENT_MAP);
		String fileIdentifier = getCommonConfigHelper().readConfigData(getDataconfig(), "TARGETEDPAYMENT");
		String insertedMessege = null;
		String errorMessege = StatementProcessorBatchConstants.EMPTY_STRING;
		int insertCount;
		List<TargetedPayment> targetedPaymentRecords = null;
		boolean insertedTp = false;
		SpCreditFilLoadControlDaoImpl spCreditFilLoadControlDaoImpl = new SpCreditFilLoadControlDaoImpl();
		
		Object[] procReturnVal = new Object[2];
		int retCode = 0;
		String retMsg = null;

		try (LineNumberReader reader = new LineNumberReader(new FileReader(file))) {
			int records = getRecordsCount(this.getFinancierFilePath() + file.getName());
			/**
			 * Insert data in Control Table and pass the Batch Id
			 */
			insertSpLoadControlData(batchID, file.getName(), fileIdentifier, user);
			String header = reader.readLine();
			if(records == StatementProcessorBatchConstants.HEADER_RECORD){
				insertedTp = true ;
			}
			else{			
				while ((reader.getLineNumber()) < records) {
					targetedPaymentRecords = new ArrayList<>();
					for (insertCount = 0; insertCount<getBatchInsertcount() ;insertCount++ ){					
						if ((line = reader.readLine())!= null){	
							String[] contents = line.split(comma, -1);
							//Check number of data in xml and .dat file is same or not
							if (columns.size() != contents.length) {
								throw new Exception(CreditLoadDataConstants.MISMATCH_ON_COLUMN_COUNT);
							}
							TargetedPayment targetedPayment = new TargetedPayment();
							// Set batchId in TargetedPayment
							targetedPayment.setBatchId(batchID);
							targetedPayment.setCreatedByUser(Long.valueOf(user));
							targetedPaymentRecords.add(targetedPayment);
							constructObjects(contents, columns, targetedPayment);
						} else{
							break;
						}
					}
					procReturnVal = getTpDaoImpl().insertTargetedPaymentData(targetedPaymentRecords);
					retCode = (int) procReturnVal[0];
					retMsg = (String) procReturnVal[1];
					
					// update the CONTROL table and DELETE if INSERTION fails
					if (retCode == 0) {
						insertedTp = true;
					} else {
						insertedTp = false;
						errorMessege = retMsg;
					}				
				}
			}

			/**
			 * Update the CONTROL table with batch id and error messege
			 */
			spCreditFilLoadControlDaoImpl.updateControlData(batchID, insertedTp, errorMessege, fileIdentifier);
		} catch (Exception exception) {
			insertedMessege = exception.getMessage();
			errorMessege = insertedMessege;
			insertedTp = false;
			/**
			 * Update the CONTROL table with batch id and error messege
			 */
			try {
				spCreditFilLoadControlDaoImpl.updateControlData(batchID, insertedTp, errorMessege, fileIdentifier);
			} catch (BuisnessException | SQLException ex) {
				getLogger()
						.debug("[TargetedPmntFileProcessorImpl -- processFile] -- Control Table Update Exception: "
								+ ex);
			} catch (Exception exception2) {
				getLogger()
						.debug("[TargetedPmntFileProcessorImpl -- processFile] -- Control Table Update Exception: "
								+ exception2);
			}

			getLogger()
					.error("[TargetedPmntFileProcessorImpl -- processFile] -- Target Payment Insert Error occured ");
			getLogger().debug("[TargetedPmntFileProcessorImpl -- processFile] -- Target Payment Exception: "
					+ exception);
			
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_BUSINESS_ERROR_CODE,
					"[TargetedPmntFileProcessorImpl-processFile] StatementProcessorBatchException Block",
					"Target Payment Exception " + errorMessege, null, null,
					new StatementProcessorBatchException());
		}
		getLogger().debug("[TargetedPmntFileProcessorImpl -- processFile]  -- END");
		return insertedTp;
	}




	/**
	 * @return the tpDaoImpl
	 * @throws StatementProcessorBatchException 
	 */
	public TargetedPaymentDaoImpl getTpDaoImpl() throws StatementProcessorBatchException {
		if(tpDaoImpl == null) {
			tpDaoImpl = new TargetedPaymentDaoImpl();
		}
		return tpDaoImpl;
	}

	/**
	 * @param tpDaoImpl the tpDaoImpl to set
	 */
	public void setTpDaoImpl(TargetedPaymentDaoImpl tpDaoImpl) {
		this.tpDaoImpl = tpDaoImpl;
	}
	
}
