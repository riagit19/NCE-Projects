package com.shopdirect.nce.sp.model;

import java.util.Date;

public class PPIStatement {
		
	private Date renewalDate;
	
	private String typeofCover;
	
	private Double costPercentage;
	
	private Double previousYearPPIPremium;
		
    private String agreementId;
    
    private Long agreementSeq;
    
    private Date startDate;
    
    private Double openingBalance;
    
    private Double closingBalance;
	
	private Double avgMonthlyChrg;
	
	private Double creditLimit;
	
	private Double prevYrPpiBalAmt;
	
	private Long batchId;
	
	private String errorFlag;
	
	private String errorMessage;
	
	private Date creationDate;
	
	private Long createdByUser;
	
	private Date lastUpdateDate;
	
	private Long lastUpdateByUser;
	
	private String insuranceProdRefNo;

	public Date getRenewalDate() {
		return renewalDate;
	}

	public void setRenewalDate(Date renewalDate) {
		this.renewalDate = renewalDate;
	}

	public String getTypeofCover() {
		return typeofCover;
	}

	public void setTypeofCover(String typeofCover) {
		this.typeofCover = typeofCover;
	}

	public Double getCostPercentage() {
		return costPercentage;
	}

	public void setCostPercentage(Double costPercentage) {
		this.costPercentage = costPercentage;
	}

	public Double getPreviousYearPPIPremium() {
		return previousYearPPIPremium;
	}

	public void setPreviousYearPPIPremium(Double previousYearPPIPremium) {
		this.previousYearPPIPremium = previousYearPPIPremium;
	}

	public String getAgreementId() {
		return agreementId;
	}

	public void setAgreementId(String agreementId) {
		this.agreementId = agreementId;
	}

	public Long getAgreementSeq() {
		return agreementSeq;
	}

	public void setAgreementSeq(Long agreementSeq) {
		this.agreementSeq = agreementSeq;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Double getOpeningBalance() {
		return openingBalance;
	}

	public void setOpeningBalance(Double openingBalance) {
		this.openingBalance = openingBalance;
	}

	public Double getClosingBalance() {
		return closingBalance;
	}

	public void setClosingBalance(Double closingBalance) {
		this.closingBalance = closingBalance;
	}

	public Double getAvgMonthlyChrg() {
		return avgMonthlyChrg;
	}

	public void setAvgMonthlyChrg(Double avgMonthlyChrg) {
		this.avgMonthlyChrg = avgMonthlyChrg;
	}

	public Double getCreditLimit() {
		return creditLimit;
	}

	public void setCreditLimit(Double creditLimit) {
		this.creditLimit = creditLimit;
	}

	public Double getPrevYrPpiBalAmt() {
		return prevYrPpiBalAmt;
	}

	public void setPrevYrPpiBalAmt(Double prevYrPpiBalAmt) {
		this.prevYrPpiBalAmt = prevYrPpiBalAmt;
	}

	public Long getBatchId() {
		return batchId;
	}

	public void setBatchId(Long batchId) {
		this.batchId = batchId;
	}

	public String getErrorFlag() {
		return errorFlag;
	}

	public void setErrorFlag(String errorFlag) {
		this.errorFlag = errorFlag;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public Long getCreatedByUser() {
		return createdByUser;
	}

	public void setCreatedByUser(Long createdByUser) {
		this.createdByUser = createdByUser;
	}

	public Date getLastUpdateDate() {
		return lastUpdateDate;
	}

	public void setLastUpdateDate(Date lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}

	public Long getLastUpdateByUser() {
		return lastUpdateByUser;
	}

	public void setLastUpdateByUser(Long lastUpdateByUser) {
		this.lastUpdateByUser = lastUpdateByUser;
	}

	public String getInsuranceProdRefNo() {
		return insuranceProdRefNo;
	}

	public void setInsuranceProdRefNo(String insuranceProdRefNo) {
		this.insuranceProdRefNo = insuranceProdRefNo;
	}
	
}
