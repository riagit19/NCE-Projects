package com.shopdirect.nce.sp.transform;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.rule.businees.BatchRuleDataBusinessImpl;
import com.shopdirect.nce.rule.businees.GenerateRuleDataBusinessImpl;
import com.shopdirect.nce.rule.model.Account;
import com.shopdirect.nce.rule.model.AuthorisationData;
import com.shopdirect.nce.rule.model.AvPTB3;
import com.shopdirect.nce.rule.model.AvPTB6;
import com.shopdirect.nce.rule.model.AvWklyPayment2Sched12;
import com.shopdirect.nce.rule.model.AvWklyPayment2Sched6;
import com.shopdirect.nce.rule.model.Bal2Remits3;
import com.shopdirect.nce.rule.model.Bal2Remits6;
import com.shopdirect.nce.rule.model.ClearBalWeeks;
import com.shopdirect.nce.rule.model.CumRemits2Sales;
import com.shopdirect.nce.rule.model.DateLastOrder;
import com.shopdirect.nce.rule.model.DateLastPayment;
import com.shopdirect.nce.rule.model.Forecast;
import com.shopdirect.nce.rule.model.InterestPaymentTree;
import com.shopdirect.nce.rule.model.LastOrderWks;
import com.shopdirect.nce.rule.model.LastTransWks;
import com.shopdirect.nce.rule.model.NumCode2;
import com.shopdirect.nce.rule.model.PaidPaymentTree;
import com.shopdirect.nce.sp.model.AccountingSnapshotTriad;
import com.shopdirect.nce.sp.model.AgreementTriad;
import com.shopdirect.nce.sp.model.CurrentAccoutingSnapshotTriad;
import com.shopdirect.nce.sp.model.CustomerAccountInfo;
import com.shopdirect.nce.sp.model.CustomerContractTriad;
import com.shopdirect.nce.sp.model.RetailContractTriad;

public class AccountRuleTransformer {
	
	private static SDLoggerImpl logger = new SDLoggerImpl();
	
	public void setAllJavaRuleVal(Account accountRule, CustomerAccountInfo accountInfo,
			List<RetailContractTriad> retailContractTriadList,
			List<CustomerContractTriad> customerContractTriadList, List<AgreementTriad> agreementTriadList,
			CurrentAccoutingSnapshotTriad currentAccSnapshotTriad, String callType, List<AccountingSnapshotTriad> accountingSnapshotTriadList) throws Exception {	
		
		logger.debug("[AccountRuleTransformer -- setAllJavaRuleVal] -- Start");
		AvWklyPayment2Sched6 avWklyPayment2Sched6 = new AvWklyPayment2Sched6();
		AvWklyPayment2Sched12 avWklyPayment2Sched12 = new AvWklyPayment2Sched12();
		com.shopdirect.nce.rule.model.AccountingSnapshot accountingSnapshot = new com.shopdirect.nce.rule.model.AccountingSnapshot();
		List<com.shopdirect.nce.rule.model.AccountingSnapshot> accSnapshotList = new ArrayList<com.shopdirect.nce.rule.model.AccountingSnapshot>();
		CumRemits2Sales cumRemits2Sales = new CumRemits2Sales();
		LastOrderWks lastOrderWks = new LastOrderWks();
		DateLastOrder dateLastOrder = new DateLastOrder();
		LastTransWks lastTransWks = new LastTransWks();
		ClearBalWeeks clearBalWeeks = new ClearBalWeeks();
		NumCode2 numCode2 = new NumCode2();
		AvPTB3 avPTB3 = new AvPTB3();
		AvPTB6 avPTB6 = new AvPTB6();
		PaidPaymentTree paidPaymentTree = new PaidPaymentTree();
		InterestPaymentTree interestPaymentTree = new InterestPaymentTree();
		Bal2Remits3 bal2Remits3 = new Bal2Remits3();
		Bal2Remits6 bal2Remits6 = new Bal2Remits6();
		
		AuthorisationData authorisationData = new AuthorisationData();
		List<BigDecimal> intChargeTSPList = new ArrayList<BigDecimal>();
		Forecast forecast = new Forecast();
		for (int i = 0; i < customerContractTriadList.size(); i++) {
			accountingSnapshot = new com.shopdirect.nce.rule.model.AccountingSnapshot();
			CustomerContractTriad custContTriad = customerContractTriadList.get(i);
			avWklyPayment2Sched6.setTodaysAccountingDate(convertCalendar(custContTriad.getAccountingDate()));
			accountingSnapshot.setDateTCAccounting(convertCalendar(custContTriad.getEndDellDate()));
			paidPaymentTree.setTodaysAccountingDate(convertCalendar(custContTriad.getAccountingDate()));
			interestPaymentTree.setTodaysAccountingDate(convertCalendar(custContTriad.getAccountingDate()));
			interestPaymentTree.setNumCreditAccts(custContTriad.getNumCredAccts());
			interestPaymentTree.setDateStart(convertCalendar(custContTriad.getStartDate()));
			accountRule.setDateStart(convertCalendar(custContTriad.getStartDate()));
			if (agreementTriadList.size() > i) {
				AgreementTriad agrmntTriad = agreementTriadList.get(i);
				accountingSnapshot.setScheduledPaymentsPastDue(agrmntTriad.getScheduledPaymentPastDue());
				forecast.setScheduledPaymentsPastDue(agrmntTriad.getScheduledPaymentPastDue());
				accountingSnapshot.setScheduledPaymentAmount(agrmntTriad.getScheduledPaymentAmt());
				forecast.setScheduledPaymentAmount(agrmntTriad.getScheduledPaymentAmt());
				accountingSnapshot.setPastDue(agrmntTriad.getPastDueAmt());
				accountingSnapshot.setPaymentAmountTSP(agrmntTriad.getPayAmtTSP());
				accountingSnapshot.setDateTCAccounting(convertCalendar(custContTriad.getAccountingDate()));
				accountingSnapshot.setClosingBalance(agrmntTriad.getBalance());
				accountingSnapshot.setInterestChargedAmount(agrmntTriad.getIntChargedTSP());
				accountingSnapshot.setPurchaseAmountTSP(agrmntTriad.getPurchaseAmtTSP());
				accountingSnapshot.setSalesFor12Months(currentAccSnapshotTriad.getSalesFor12Months());
				accountingSnapshot.setNumPaymentsTSP(currentAccSnapshotTriad.getNumPaymentsTSP());
				intChargeTSPList.add(agrmntTriad.getIntChargedTSP());
			}
			accSnapshotList.add(accountingSnapshot);
		}
		
		
		forecast.setAdjustedPastDue(BigDecimal.ONE);
		forecast.setPastDueAmount(accountingSnapshot.getPastDue());
		forecast.setAdjustedSPPDRate(BigDecimal.ONE);
		forecast.setSppdRate(BigDecimal.ONE);
		accountRule.setScheduledPayPastDue(forecast);
		accountRule.setScheduledPayAmt(forecast);
		accountRule.setPastDue(forecast);
		avWklyPayment2Sched6.setAccSnapshotList(accSnapshotList);
		avWklyPayment2Sched12.setAccSnapshotList(accSnapshotList);
		clearBalWeeks.setAccSnapshotList(accSnapshotList);
		avPTB3.setAccSnapshotList(accSnapshotList);
		avPTB6.setAccSnapshotList(accSnapshotList);
		paidPaymentTree.setAccountingSnapshotList(accSnapshotList);
		interestPaymentTree.setAccountingSnapshotList(accSnapshotList);
		bal2Remits3.setAccSnapshotList(accSnapshotList);
		bal2Remits6.setAccSnapshotList(accSnapshotList);
		
		lastOrderWks.setDateLastOrder(dateLastOrder);
		lastTransWks.setDateLastOrder(dateLastOrder);
		
		if (!retailContractTriadList.isEmpty()) {
			RetailContractTriad retailContTraid = retailContractTriadList.get(0);
			cumRemits2Sales.setTotalPaymentsYear(retailContTraid.getCreditPaymentsTotal());
			dateLastOrder.setDateLastOrderCredit(convertCalendar(retailContTraid.getLastOrderDate()));
			dateLastOrder.setDateLastOrderRetail(convertCalendar(retailContTraid.getLastOrderDate()));
		}
		if (!customerContractTriadList.isEmpty()) {
			CustomerContractTriad custContTriad = customerContractTriadList.get(0);
			lastOrderWks.setTodaysAccountingDate(convertCalendar(custContTriad.getAccountingDate()));
			lastTransWks.setTodaysAccountingDate(convertCalendar(custContTriad.getAccountingDate()));
			numCode2.setNumCode2InYear(custContTriad.getNumCode2());
			numCode2.setDateLastNumCode60(convertCalendar(custContTriad.getLastNumCode60Date()));
			bal2Remits3.setTcWks(custContTriad.getTcWks());
			bal2Remits6.setTcWks(custContTriad.getTcWks());
			accountRule.setAccountType(custContTriad.getAccountTypeCode());
		}
		DateLastPayment dateLastPayment = new DateLastPayment();
		if (!agreementTriadList.isEmpty()) {
			AgreementTriad agrmntTriad = agreementTriadList.get(0);
			numCode2.setDateLastStatement(convertCalendar(agrmntTriad.getLastStatementDate()));
			numCode2.setDateLastPayment(convertCalendar(agrmntTriad.getLastPayDate()));
			dateLastPayment.setDateLastPaymentCredit(convertCalendar(agrmntTriad.getLastPayDate()));
			dateLastPayment.setDateLastPaymentRetail(convertCalendar(agrmntTriad.getLastPayDate()));
		}
		if (!accountingSnapshotTriadList.isEmpty()) {
			AccountingSnapshotTriad accountingSnapshotTriad = accountingSnapshotTriadList.get(0);
			accountRule.setCurrentBalance(accountingSnapshotTriad.getClosingBalanceAmtSigned());
			accountRule.setScheduledPaymentsPastDue(accountingSnapshotTriad.getScheduledPaymentAmt());
		}
		
		
		accountRule.setDateLastPayment(dateLastPayment);
		
		accountRule.setAccountNumber(accountInfo.getPublicAccountId());
		accountRule.setAvWklyPayment2Sched6(avWklyPayment2Sched6);
		accountRule.setAvWklyPayment2Sched12(avWklyPayment2Sched12);
		accountRule.setCumRemits2Sales(cumRemits2Sales);
		accountRule.setLastOrderWks(lastOrderWks);
		accountRule.setLastTransWks(lastTransWks);
		accountRule.setClearBalWeeks(clearBalWeeks);
		accountRule.setNumCode2(numCode2);
		accountRule.setAvPTB3(avPTB3);
		accountRule.setAvPTB6(avPTB6);
		accountRule.setPaidPaymentTree(paidPaymentTree);
		accountRule.setInterestPaymentTree(interestPaymentTree);
		accountRule.setBal2Remits3(bal2Remits3);
		accountRule.setBal2Remits6(bal2Remits6);
		
		authorisationData.getAccountList().add(accountRule);
		
		BigDecimal callTypeIntValue = null;
		if (callType != null) {
			try {
				callTypeIntValue = new BigDecimal(callType);
			} catch (NumberFormatException nfe){
				logger.error("[AccountRuleTransformer -- setAllJavaRuleVale] - callType should be int " + nfe);
			}
		}
		
		authorisationData.setCallType(callTypeIntValue);
		
		try {
			GenerateRuleDataBusinessImpl generateRuleDataBusinessImpl = new GenerateRuleDataBusinessImpl();
			generateRuleDataBusinessImpl.generateRuleData(authorisationData);
			BatchRuleDataBusinessImpl batchRuleDataBusinessImpl = new BatchRuleDataBusinessImpl();
			batchRuleDataBusinessImpl.generateRuleData(authorisationData);
		} catch (Exception e) {
			logger.error("[AccountRuleTransformer -- setAllJavaRuleVale] - error while applying TRIAD rule " + e);
		}
	
		logger.debug("[AccountRuleTransformer -- setAllJavaRuleVal] -- End");
	}
	
	private Calendar convertCalendar(java.sql.Date date) {
		
		if (date == null) {
			return null;
		}
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		return cal;
	}
}
