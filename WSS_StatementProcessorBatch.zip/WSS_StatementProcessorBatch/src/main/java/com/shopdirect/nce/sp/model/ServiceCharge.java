package com.shopdirect.nce.sp.model;

import java.util.Date;


public class ServiceCharge {
	
	private String serviceChargeId;
	
	private String agreemntId;
	
	private Long agreemntSeq;
	
	private String drawdownId;
	
	private Date serviceChargeDate;
	
	private Double serviceChargeAmount;
	
	private Double mivCode;
	
	private String mivSubCode;
	
	private Double dailyInterestRate;
	
	private String defaultSumnInArrearsNotice;
	
	private String chargeType;
	
	private String ddtDType;
	
	private String reasnCd;
	
	private Long batchId;
	
	private String errorFlag;
	
	private String errorMessage;
	
	private Date creationDate;
	
	private Long createdByUser;
	
	private Date lastUpdateDate;
	
	private Long lastUpdateByUser;
	
	private String insuranceProdRefNo;

	public String getServiceChargeId() {
		return serviceChargeId;
	}

	public void setServiceChargeId(String serviceChargeId) {
		this.serviceChargeId = serviceChargeId;
	}

	public String getAgreemntId() {
		return agreemntId;
	}

	public void setAgreemntId(String agreemntId) {
		this.agreemntId = agreemntId;
	}

	public Long getAgreemntSeq() {
		return agreemntSeq;
	}

	public void setAgreemntSeq(Long agreemntSeq) {
		this.agreemntSeq = agreemntSeq;
	}

	public String getDrawdownId() {
		return drawdownId;
	}

	public void setDrawdownId(String drawdownId) {
		this.drawdownId = drawdownId;
	}

	public Date getServiceChargeDate() {
		return serviceChargeDate;
	}

	public void setServiceChargeDate(Date serviceChargeDate) {
		this.serviceChargeDate = serviceChargeDate;
	}

	public Double getServiceChargeAmount() {
		return serviceChargeAmount;
	}

	public void setServiceChargeAmount(Double serviceChargeAmount) {
		this.serviceChargeAmount = serviceChargeAmount;
	}

	public Double getMivCode() {
		return mivCode;
	}

	public void setMivCode(Double mivCode) {
		this.mivCode = mivCode;
	}

	public String getMivSubCode() {
		return mivSubCode;
	}

	public void setMivSubCode(String mivSubCode) {
		this.mivSubCode = mivSubCode;
	}

	public Double getDailyInterestRate() {
		return dailyInterestRate;
	}

	public void setDailyInterestRate(Double dailyInterestRate) {
		this.dailyInterestRate = dailyInterestRate;
	}

	public String getDefaultSumnInArrearsNotice() {
		return defaultSumnInArrearsNotice;
	}

	public void setDefaultSumnInArrearsNotice(String defaultSumnInArrearsNotice) {
		this.defaultSumnInArrearsNotice = defaultSumnInArrearsNotice;
	}

	public String getChargeType() {
		return chargeType;
	}

	public void setChargeType(String chargeType) {
		this.chargeType = chargeType;
	}

	public Long getBatchId() {
		return batchId;
	}

	public void setBatchId(Long batchId) {
		this.batchId = batchId;
	}

	public String getErrorFlag() {
		return errorFlag;
	}

	public void setErrorFlag(String errorFlag) {
		this.errorFlag = errorFlag;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public Long getCreatedByUser() {
		return createdByUser;
	}

	public void setCreatedByUser(Long createdByUser) {
		this.createdByUser = createdByUser;
	}

	public Date getLastUpdateDate() {
		return lastUpdateDate;
	}

	public void setLastUpdateDate(Date lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}

	public Long getLastUpdateByUser() {
		return lastUpdateByUser;
	}

	public void setLastUpdateByUser(Long lastUpdateByUser) {
		this.lastUpdateByUser = lastUpdateByUser;
	}

	public String getInsuranceProdRefNo() {
		return insuranceProdRefNo;
	}

	public void setInsuranceProdRefNo(String insuranceProdRefNo) {
		this.insuranceProdRefNo = insuranceProdRefNo;
	}

	/**
	 * @return the ddtDType
	 */
	public String getDdtDType() {
		return ddtDType;
	}

	/**
	 * @param ddtDType the ddtDType to set
	 */
	public void setDdtDType(String ddtDType) {
		this.ddtDType = ddtDType;
	}

	/**
	 * @return the reasnCd
	 */
	public String getReasnCd() {
		return reasnCd;
	}

	/**
	 * @param reasnCd the reasnCd to set
	 */
	public void setReasnCd(String reasnCd) {
		this.reasnCd = reasnCd;
	}
	
}
