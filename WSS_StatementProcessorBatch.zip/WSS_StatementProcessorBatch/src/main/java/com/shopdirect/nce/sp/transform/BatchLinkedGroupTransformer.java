package com.shopdirect.nce.sp.transform;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.model.AccountingSnapshot;
import com.shopdirect.nce.sp.model.BatchLinkedGroup;

public class BatchLinkedGroupTransformer {

	private static SDLoggerImpl logger = new SDLoggerImpl();
	
	public List<BatchLinkedGroup> getBatchLinkedGroup(List<AccountingSnapshot> accountingSnapshotList) {
		
		logger.debug("[BatchLinkedGroupTransformer - getBatchLinkedGroup] - Start");
		
		List<BatchLinkedGroup> batchLinkedGroupList = new ArrayList<BatchLinkedGroup>();
		BatchLinkedGroup batchLinkedGroupObj;
		
		for (int i = 0; i < accountingSnapshotList.size(); i++) {
			batchLinkedGroupObj = new BatchLinkedGroup();
			
			batchLinkedGroupObj.setCustomerAccountNumber(accountingSnapshotList.get(i).getCustomerAccountNumber());
			batchLinkedGroupObj.setBatchLinkedGroupOccurence(new BigDecimal(i+1));
			if (i == 1 || i > 4) {
				batchLinkedGroupObj.setValFees(new BigDecimal(0));
			} else {
				if (accountingSnapshotList.get(i).getScheduledPaymentsPastDue() != null) {
					batchLinkedGroupObj.setValFees(new BigDecimal(Math.max(Math.min(accountingSnapshotList.get(i).getScheduledPaymentsPastDue().intValue(), 9), 0)));
				}
			}
			batchLinkedGroupObj.setDelqNumCycles(new BigDecimal(i+1));
			
			batchLinkedGroupList.add(batchLinkedGroupObj);
		}
		
		logger.debug("[BatchLinkedGroupTransformer - getBatchLinkedGroup] - End");
		return batchLinkedGroupList;
	}
}
