package com.shopdirect.nce.sp.business.creditdataload;

import java.io.File;
import java.io.FileReader;
import java.io.LineNumberReader;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.shopdirect.nce.sp.constants.CreditLoadDataConstants;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.dao.creditdataload.DrawDownDaoImpl;
import com.shopdirect.nce.sp.dao.creditdataload.SpCreditFilLoadControlDaoImpl;
import com.shopdirect.nce.sp.exception.BuisnessException;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.Drawdown;
import com.shopdirect.nce.sp.util.FinFileBaseProcessor;
import com.shopdirect.nce.sp.util.StatementProcessorBatchUtil;

public class DrawDownFileProcessorImpl extends FinFileBaseProcessor implements DataFileProcessor{
	
	private DrawDownDaoImpl drawdownDaoImpl;
	
	public DrawDownFileProcessorImpl() throws StatementProcessorBatchException {
		super();
	}

	/**
	 * @param folder
	 * @throws StatementProcessorBatchException
	 */
	public boolean processFile(File folder, long batchID, int user , String batchRunDate) throws StatementProcessorBatchException {
		
		getLogger().debug("[DrawDownFileProcessorImpl -- processFile]  -- START");
		List<Map<String, Object>> columns;
		File file;
		String line;
		final String fileName = StatementProcessorBatchUtil.generateFileName(CreditLoadDataConstants.DRAWDOWN,
				CreditLoadDataConstants.NEW_STATUS, batchRunDate);
		file = getFile(folder, fileName);
		line = "";
		String comma = ",";
		columns = getColumns(StatementProcessorBatchConstants.DRAWDOWN_DATA_MAPPING,
				StatementProcessorBatchConstants.DRAWDOWN_MAP);
		String fileIdentifier = getCommonConfigHelper().readConfigData(getDataconfig(), "DRAWDOWN");
		String insertedMessage = null;
		String errorMessage = StatementProcessorBatchConstants.EMPTY_STRING;
		int insertCount;
		List<Drawdown> drawdownRecords = null;
		boolean insertedDrawdown = false;
		SpCreditFilLoadControlDaoImpl spCreditFilLoadControlDaoImpl = new SpCreditFilLoadControlDaoImpl();
		
		Object[] procReturnVal = new Object[2];
		int retCode = 0;
		String retMsg = null;

		try (LineNumberReader reader = new LineNumberReader(new FileReader(file))) {
			int records = getRecordsCount(this.getFinancierFilePath() + file.getName());
			/**
			 * Insert data in Control Table and pass the Batch Id
			 */
			insertSpLoadControlData(batchID, file.getName(), fileIdentifier, user);
			String header = reader.readLine();
			if(records == StatementProcessorBatchConstants.HEADER_RECORD){
				insertedDrawdown = true ;
			}
			else {			
				while ((reader.getLineNumber()) < records) {
					drawdownRecords = new ArrayList<>();
					for (insertCount = 0; insertCount<getBatchInsertcount() ;insertCount++ ){					
						if ((line = reader.readLine())!= null){						
							String[] contents = line.split(comma, -1);
							//Check number of data in xml and .dat file is same or not
							if (columns.size() != contents.length) {
								throw new Exception(CreditLoadDataConstants.MISMATCH_ON_COLUMN_COUNT);
							}
							Drawdown drawDown = new Drawdown();
							drawDown.setCreatedByUser(Long.valueOf(user));
							// Set batchId in DrawdownTerm
							drawDown.setBatchId(batchID);
							drawdownRecords.add(drawDown);
							constructObjects(contents, columns, drawDown);
						} else{
							break;
						}
					}
					
					procReturnVal = getDrawdownDaoImpl().insertDrawDownData(drawdownRecords);
					retCode = (int) procReturnVal[0];
					retMsg = (String) procReturnVal[1];
					
					// update the CONTROL table and DELETE if INSERTION fails
					if (retCode == 0) {
						insertedDrawdown = true;
					} else {
						insertedDrawdown = false;
						errorMessage = retMsg;
					}
				}
			}

			/**
			 * Update the CONTROL table with batch id and error message
			 */
			spCreditFilLoadControlDaoImpl.updateControlData(batchID, insertedDrawdown, errorMessage, fileIdentifier);

		} catch (Exception exception) {
			insertedMessage = exception.getMessage();
			errorMessage = insertedMessage;
			insertedDrawdown = false;
			/**
			 * Update the CONTROL table with batch id and error messege
			 */
			try {
				spCreditFilLoadControlDaoImpl.updateControlData(batchID, insertedDrawdown, errorMessage, fileIdentifier);
			}  catch (BuisnessException | SQLException ex) {
				getLogger()
				.debug("[DrawDownFileProcessorImpl -- processFile] -- Control Table Update Exception: "
						+ ex);
			} catch (Exception exception2) {
				getLogger()
						.debug("[DrawDownFileProcessorImpl -- processFile] -- Control Table Update Exception: "
								+ exception2);
			}

			getLogger()
					.error("[DrawDownFileProcessorImpl -- processFile] -- Drawdown  insert Error occured ");
			getLogger().debug(
					"[DrawDownFileProcessorImpl -- processFile] -- Drawdown Exception: " + exception);
			
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_BUSINESS_ERROR_CODE,
					"[DrawDownFileProcessorImpl-processFile] StatementProcessorBatchException Block",
					"Drawdown Exception " + errorMessage, null, null,
					new StatementProcessorBatchException());
		}
		getLogger().debug("[DrawDownFileProcessorImpl -- processFile]  -- END");
		return insertedDrawdown;
	}

	
	/**
	 * @return the drawDownDaoImpl
	 * @throws StatementProcessorBatchException 
	 */
	public DrawDownDaoImpl getDrawdownDaoImpl() throws StatementProcessorBatchException {
		if(drawdownDaoImpl == null) {
			drawdownDaoImpl = new DrawDownDaoImpl();
		}
		return drawdownDaoImpl;
	}

	/**
	 * @param drawDownDaoImpl the drawDownDaoImpl to set
	 */
	public void setDrawdownTermDaoImpl(DrawDownDaoImpl drawdownTermDaoImpl) {
		this.drawdownDaoImpl = drawdownTermDaoImpl;
	}	

}
