package com.shopdirect.nce.sp.transform;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.ParseException;
import java.util.List;

import javax.xml.datatype.DatatypeConfigurationException;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.rule.model.Account;
import com.shopdirect.nce.sp.model.AgreementTriad;
import com.shopdirect.nce.sp.model.BatchDetails;
import com.shopdirect.nce.sp.model.BatchGroup;
import com.shopdirect.nce.sp.model.BatchLinked;
import com.shopdirect.nce.sp.model.BatchLinkedGroup;
import com.shopdirect.nce.sp.model.BatchLinkedMonth;
import com.shopdirect.nce.sp.model.BatchMonth;
import com.shopdirect.nce.sp.model.CustomerAccountInfo;
import com.shopdirect.nce.sp.model.CustomerContractTriad;
import com.shopdirect.nce.sp.model.RetailContractTriad;
import com.shopdirect.nce.sp.util.StatementProcessorBatchUtil;
import com.shopdirect.osb.reassesstriadar.BatchDetailsType;
import com.shopdirect.osb.reassesstriadar.BatchGroupType;
import com.shopdirect.osb.reassesstriadar.BatchLinkedGroupType;
import com.shopdirect.osb.reassesstriadar.BatchLinkedMonthType;
import com.shopdirect.osb.reassesstriadar.BatchLinkedType;
import com.shopdirect.osb.reassesstriadar.BatchMonthType;
import com.shopdirect.osb.reassesstriadar.CustomerRiskDataType;
import com.shopdirect.osb.reassesstriadar.CustomerType;
import com.shopdirect.osb.reassesstriadar.ReassessTRIADARType;
import com.shopdirect.osb.reassesstriadar.ScoringBlockType;
import com.shopdirect.osb.reassesstriadar.TransformSams200CRequestType;
import com.shopdirect.osb.reassesstriadar.TriadBatchDataResponseType;

public class Sams200RequestTransformer {

	private static SDLoggerImpl logger = new SDLoggerImpl();
	
	public void transformSams200CRequestType(ReassessTRIADARType reassessTriadType, 
			BatchDetails batchDetails, List<BatchGroup> batchGroupList,
			List<BatchMonth> batchMonthList, List<BatchLinked> batchLinkedList,
			List<BatchLinkedGroup> batchLinkedGroupList, List<BatchLinkedMonth> batchLinkedMonthList, 
			CustomerAccountInfo accountInfo, CustomerContractTriad customerContractTriad,
			AgreementTriad agreementTriad, RetailContractTriad retailContractTriad, Account accountRule
			, String callType) 
					throws DatatypeConfigurationException, ParseException {
		
		logger.debug("[Sams200RequestTransformer -- transformSams200CRequestType] -- Start");
		
		TransformSams200CRequestType transformSams200CRequestType = new TransformSams200CRequestType();
		CustomerRiskDataType customerRiskDataType = new CustomerRiskDataType();
		CustomerType customerType = new CustomerType();
		transformSams200CRequestType.setCustomer(customerType);
		
		BigInteger callTypeIntValue = null;
		if (callType != null) {
			try {
				callTypeIntValue = new BigInteger(callType);
			} catch (NumberFormatException nfe){
				logger.error("[CRDRDataTransformer -- transformCRDRDataType] - callType should be int " + nfe);
			}
		}
		
		customerType.setAccountNumber(accountInfo.getPublicAccountId());
		customerType.setCallType(callTypeIntValue);
		customerType.setCreditBand(batchDetails.getCreditBand());
		customerType.setCurrentBURef(batchDetails.getCurrentBURef());
		customerType.setPrincipalBrand(batchDetails.getPrincipalBrand());
		customerType.setCreditStatusCode(batchDetails.getCreditStatusCode());
		customerType.setCreditStatusSubCode(batchDetails.getCreditStatusSubCode());
		customerType.setDeceasedInd(batchDetails.getDeceasedInd() != null ? batchDetails.getDeceasedInd().toBigInteger() : null);
		
		customerRiskDataType.setCallType(callTypeIntValue);
		customerType.getCustomerRiskData().add(customerRiskDataType);
		
		TriadBatchDataResponseType triadBatchDataResponseType = new TriadBatchDataResponseType();
		transformSams200CRequestType.setTriadBatchDataResponse(triadBatchDataResponseType);
		
		BatchDetailsType batchDetailsType = new BatchDetailsType();
		triadBatchDataResponseType.setBatchDetails(batchDetailsType);
		
		batchDetailsType.setAccountNumber(accountInfo.getPublicAccountId());
		batchDetailsType.setAccountTypeCode(batchDetails.getAccountTypeCode());
		batchDetailsType.setDateOfBirth(StatementProcessorBatchUtil.getDate(batchDetails.getDateOfBirth()));
		batchDetailsType.setExclusionInd(BigInteger.ZERO);
		batchDetailsType.setDateLastDelinquent(StatementProcessorBatchUtil.getDate(batchDetails.getDateLastDelinquent()));
		batchDetailsType.setPaymentMethod(batchDetails.getLastPaymentMethod() != null ? batchDetails.getLastPaymentMethod().toString() : null);
		batchDetailsType.setPhoneAddressInd(customerContractTriad.getPhoneAddressInd() != null ? customerContractTriad.getPhoneAddressInd().toBigInteger() : null);
		if (batchDetails.getEmailAddressInd() == null){
			batchDetailsType.setEmailAddressInd(BigInteger.ZERO);
		} else {
			batchDetailsType.setEmailAddressInd(BigInteger.ONE);
		}
		batchDetailsType.setCustNoMailInd(batchDetails.getCustNoMailInd() != null ? batchDetails.getCustNoMailInd().toBigInteger() : null);
		batchDetailsType.setApplicationCreditScore(batchDetails.getApplicationCreditScore());
		batchDetailsType.setCustomerType(batchDetails.getCustomerType() != null ? batchDetails.getCustomerType().toString() : null);
		batchDetailsType.setCurrentBalance(batchDetails.getCurrentBalance());
		batchDetailsType.setDateCompleted(StatementProcessorBatchUtil.getDate(batchDetails.getDateClosed()));
		batchDetailsType.setDateLastIncentiveSchmClaim(null); //Obsolete
		batchDetailsType.setDateLastPayment(StatementProcessorBatchUtil.getDate(batchDetails.getDateLastPayment()));
		//batchDetailsType.setDateLastOrder(accountRule.getDateLastOrder() != null ? accountRule.getDateLastOrder().getValue() : null); //aa
		batchDetailsType.setDateStart(StatementProcessorBatchUtil.getDate(batchDetails.getDateStart()));
		batchDetailsType.setDateRestart(StatementProcessorBatchUtil.getDate(batchDetails.getDateRestart()));
		batchDetailsType.setDatePaymentDue(StatementProcessorBatchUtil.getDate(batchDetails.getDatePaymentDue()));
		batchDetailsType.setDateStartDelinquency(StatementProcessorBatchUtil.getDate(batchDetails.getDateStartDelinquency()));
		batchDetailsType.setDateEndDelinquency(StatementProcessorBatchUtil.getDate(batchDetails.getDateEndDelinquency()));
		batchDetailsType.setDateLastStatement(StatementProcessorBatchUtil.getDate(batchDetails.getDateLastStatement()));
		batchDetailsType.setDateNextStatement(StatementProcessorBatchUtil.getDate(batchDetails.getDateNextStatement()));
		batchDetailsType.setDateDefaultNotice(StatementProcessorBatchUtil.getDate(batchDetails.getDateSection87()));
		batchDetailsType.setDateNSF(StatementProcessorBatchUtil.getDate(batchDetails.getDateNSF()));
		batchDetailsType.setDateBankrupt(StatementProcessorBatchUtil.getDate(batchDetails.getDateBankrupt()));
		batchDetailsType.setDateLastCreditLineIncrease(StatementProcessorBatchUtil.getDate(batchDetails.getDateLastCreditLimitIncrease()));
		batchDetailsType.setDateLastCreditLineDecrease(StatementProcessorBatchUtil.getDate(batchDetails.getDateLastCreditLimitDecrease()));
		batchDetailsType.setDateMigration(StatementProcessorBatchUtil.getDate(batchDetails.getDateMigratedToCredit()));
		batchDetailsType.setRiskNavScore(batchDetails.getRiskNavScore() != null ? batchDetails.getRiskNavScore().toBigInteger() : null);
		batchDetailsType.setScheduledPaymentAmt(batchDetails.getScheduledPaymentAmt());
		batchDetailsType.setSPPD(batchDetails.getScheduledPaymentsPastDue());
		batchDetailsType.setPastDue(batchDetails.getPastDue());
		batchDetailsType.setTUM(BigDecimal.ZERO);
		batchDetailsType.setPPIInd(batchDetails.getPpiInd() != null ? batchDetails.getPpiInd().toBigInteger() : null);
		batchDetailsType.setCreditLimit(batchDetails.getCreditLimit());
		batchDetailsType.setBNPLBalance(batchDetails.getBnplBalance());
		batchDetailsType.setTimestampCreated(StatementProcessorBatchUtil.getDate(accountInfo.getStatementDate()));
		batchDetailsType.setRecruitmentCRF(batchDetails.getRecruitmentCRF());
		batchDetailsType.setLastFollowUpCode(batchDetails.getLastFollowUpCode() != null ? batchDetails.getLastFollowUpCode().toBigInteger() : null);
		batchDetailsType.setNumCreditAccts(batchDetails.getNumCreditAccts() != null ? batchDetails.getNumCreditAccts().toBigInteger() : null);
		batchDetailsType.setNumAccts(batchDetails.getNumAccts() != null ? batchDetails.getNumAccts().toBigInteger() : null);
		batchDetailsType.setOverIndebtScore(batchDetails.getOverIndebtScore() != null ? batchDetails.getOverIndebtScore().toBigInteger() : null);
		batchDetailsType.setCustomerRating(BigInteger.ZERO);
		batchDetailsType.setPaymentReschedInd(batchDetails.getPaymentReschedInd());
		batchDetailsType.setAPR(batchDetails.getaPR());
		batchDetailsType.setBlockCode(batchDetails.getBlockCode());
		batchDetailsType.setBehaviourScore(batchDetails.getBehaviourScore() != null ? batchDetails.getBehaviourScore().toBigInteger() : null);
		batchDetailsType.setBehaviourRawScore(batchDetails.getBehaviourRawScore() != null ? batchDetails.getBehaviourRawScore().toBigInteger() : null);
		batchDetailsType.setScorecardId(batchDetails.getScorecardId() != null ? batchDetails.getScorecardId().toBigInteger() : null);
		batchDetailsType.setPromiseToPayInd(batchDetails.getPromiseToPayInd() != null ? batchDetails.getPromiseToPayInd().toBigInteger() : null);
		batchDetailsType.setNSFTodayInd(batchDetails.getNsfTodayInd() != null ? batchDetails.getNsfTodayInd().toBigInteger() : null);
		batchDetailsType.setOTB(batchDetails.getoTB());
		batchDetailsType.setAnnotationFlag(batchDetails.getAnnotationPeriodInd() != null ? batchDetails.getAnnotationPeriodInd().toBigInteger() : null);
		batchDetailsType.setLimitLastReview(batchDetails.getCreditLimitLastReview() != null ? batchDetails.getCreditLimitLastReview().toBigInteger() : null);
		batchDetailsType.setCollectionMethodCode(batchDetails.getCollectionMethodCode() != null ? batchDetails.getCollectionMethodCode().toBigInteger() : null);
		batchDetailsType.setCommissionAmount(BigDecimal.ZERO);
		batchDetailsType.setMobileNumInd(batchDetails.getMobileNumInd() != null ? batchDetails.getMobileNumInd().toBigInteger() : null);
		batchDetailsType.setInsufficientStrategySegment(BigInteger.ZERO);
		batchDetailsType.setLastCollectionsInd(BigInteger.ZERO);
		try {
			batchDetailsType.setFIDScore(batchDetails.getFidScore() != null ? new BigInteger(batchDetails.getFidScore()) : null);
		} catch (Exception e) {
			logger.error("FID Score should be integer" + e);
		}
		batchDetailsType.setCAAReceived(batchDetails.getCreditBandCodeInd() != null ? batchDetails.getCreditBandCodeInd().toBigInteger() : null);
		batchDetailsType.setOrdersDeclined3Mths(batchDetails.getOrdersDeclined3mths());
		batchDetailsType.setRecruitmentSource(batchDetails.getRecruitmentSource() != null ? batchDetails.getRecruitmentSource().toBigInteger() : null);
		batchDetailsType.setDCAReturnCode(batchDetails.getdCAReturnCode() != null ? batchDetails.getdCAReturnCode().toString() : null);
		batchDetailsType.setTotalPayments30Days(batchDetails.getTotalPayments30Days());
		batchDetailsType.setNumStatementsArrears(batchDetails.getNumInstallmentsInArrears() != null ? batchDetails.getNumInstallmentsInArrears().toBigInteger() : null);
		batchDetailsType.setDateLastArrangement(StatementProcessorBatchUtil.getDate(batchDetails.getDateLastArrangement()));
		batchDetailsType.setCreditBand(batchDetails.getCreditBand());
		batchDetailsType.setFrozenLimitInd(batchDetails.getCreditLimitFrozenInd() != null ? batchDetails.getCreditLimitFrozenInd().toBigInteger() : null);
		batchDetailsType.setValuePayments(batchDetails.getPaymentAmountTSP());
		batchDetailsType.setDateDebitBalance(StatementProcessorBatchUtil.getDate(batchDetails.getDateLastZeroBalance()));
		batchDetailsType.setReturnsAmount(batchDetails.getReturnsAmountTSP());
		batchDetailsType.setOtherAdjustmentssAmount(batchDetails.getOtherAdjustmentsAmountTSP());
		batchDetailsType.setHighBalance(batchDetails.getHighBalance());
		batchDetailsType.setHighDelq(batchDetails.getHighDelq() != null ? batchDetails.getHighDelq().toBigInteger() : null);
		batchDetailsType.setNumCycle1(batchDetails.getNumCycle1() != null ? batchDetails.getNumCycle1().toBigInteger() : null);
		batchDetailsType.setNumCycle2(batchDetails.getNumCycle2() != null ? batchDetails.getNumCycle2().toBigInteger() : null);
		batchDetailsType.setNumCycle3(batchDetails.getNumCycle3() != null ? batchDetails.getNumCycle3().toBigInteger() : null);
		batchDetailsType.setNumCycle4(batchDetails.getNumCycle4() != null ? batchDetails.getNumCycle4().toBigInteger() : null);
		batchDetailsType.setPaymentAmount(batchDetails.getLastPaymentAmount());
		batchDetailsType.setTCUMonitorStatusCode(batchDetails.getTcuMonitorStatusCode() != null ? batchDetails.getTcuMonitorStatusCode().toBigInteger() : null);
		batchDetailsType.setScreenBalance(batchDetails.getScreenBalance());
		batchDetailsType.setAlignedScore(batchDetails.getAlignedBehaviourScore() != null ? batchDetails.getAlignedBehaviourScore().toBigInteger() : null);
		batchDetailsType.setDebitSaleFlag(batchDetails.getDebitSaleFlag() != null ? batchDetails.getDebitSaleFlag().toBigInteger() : null);
		batchDetailsType.setPaymentPreviousInd(batchDetails.getPaymentPreviousInd() != null ? batchDetails.getPaymentPreviousInd().toBigInteger() : null);
		batchDetailsType.setPaymentCurrentInd(batchDetails.getPaymentCurrentInd() != null ? batchDetails.getPaymentCurrentInd().toBigInteger() : null);
		batchDetailsType.setDateLastPhoneCheck(StatementProcessorBatchUtil.getDate(batchDetails.getDateLastPhoneCheck()));
		batchDetailsType.setCRF(batchDetails.getcRF());
		batchDetailsType.setHomePhoneInd(batchDetails.getHomePhoneInd() != null ? batchDetails.getHomePhoneInd().toBigInteger() : null);
		batchDetailsType.setPaymtsSinceLastCollEntry(batchDetails.getPaymtsSinceLastCollEntry() != null ? batchDetails.getPaymtsSinceLastCollEntry().toBigInteger() : null);
		batchDetailsType.setPaymtsSinceLastBilling(batchDetails.getPaymentsTSPInd() != null ? batchDetails.getPaymentsTSPInd().toBigInteger() : null);
		batchDetailsType.setNumIBCAccts(batchDetails.getNumIBCAccts() != null ? batchDetails.getNumIBCAccts().toBigInteger() : null);
		//batchDetailsType.setFIDFlagDate(value); // Obsolete
		batchDetailsType.setFIDScoreDate(StatementProcessorBatchUtil.getDate(batchDetails.getFidScoreDate()));
		batchDetailsType.setFIDScoreWorst(new BigInteger(batchDetails.getFidScoreWorst() != null ? batchDetails.getFidScoreWorst() : "0"));
		batchDetailsType.setMinPayment(batchDetails.getMinPayment());
		batchDetailsType.setPaymentsTotal(batchDetails.getCreditPaymentsTotal());
		batchDetailsType.setACDScorecardId(batchDetails.getAcdScorecardId() != null ? batchDetails.getAcdScorecardId().toBigInteger() : null);
		batchDetailsType.setACDRawScore(batchDetails.getAcdRawScore() != null ? batchDetails.getAcdRawScore().toBigInteger() : null);
		batchDetailsType.setACDAlignedScore(batchDetails.getAcdAlignedScore() != null ? batchDetails.getAcdAlignedScore().toBigInteger() : null);
		batchDetailsType.setNDRScorecardId(batchDetails.getNdrScorecardId() != null ? batchDetails.getNdrScorecardId().toBigInteger() : null);
		batchDetailsType.setNDRRawScore(batchDetails.getNdrRawScore() != null ? batchDetails.getNdrRawScore().toBigInteger() : null);
		batchDetailsType.setNDRAlignedScore(batchDetails.getNdrAlignedScore() != null ? batchDetails.getNdrAlignedScore().toBigInteger() : null);
		batchDetailsType.setCustScorecardId(batchDetails.getCustScorecardId() != null ? batchDetails.getCustScorecardId().toBigInteger() : null);
		batchDetailsType.setCustRawScore(batchDetails.getCustRawScore() != null ? batchDetails.getCustRawScore().toBigInteger() : null);
		batchDetailsType.setCustAlignedScore(batchDetails.getCustAlignedScore() != null ? batchDetails.getCustAlignedScore().toBigInteger() : null);
		batchDetailsType.setNumPurchases(batchDetails.getNumPurchasesTSP() != null ? batchDetails.getNumPurchasesTSP().toBigInteger() : null);
		batchDetailsType.setTotalFees(batchDetails.getTotalFeesTSP());
		batchDetailsType.setOtherDebits(batchDetails.getOtherDebits());
		batchDetailsType.setNumPayments(batchDetails.getNumPaymentsTSP() != null ? batchDetails.getNumPaymentsTSP().toBigInteger() : null);
		batchDetailsType.setOtherCredits(batchDetails.getOtherCredits());
		batchDetailsType.setNumFailedPayments(batchDetails.getNumFailedPayments() != null ? batchDetails.getNumFailedPayments().toBigInteger() : null);
		batchDetailsType.setValueFailedPayments(batchDetails.getValueFailedPayments());
		batchDetailsType.setInterestChargedAmt(batchDetails.getInterestChargedAmtTSP());
		batchDetailsType.setValuePurchases(batchDetails.getPurchaseAmountTSP());
		batchDetailsType.setNumNSF(batchDetails.getNumNSF() != null ? batchDetails.getNumNSF().toBigInteger() : null);
		batchDetailsType.setRebatesAmount(batchDetails.getRebatesAmountTSP());
		batchDetailsType.setT6Sales(batchDetails.getNetSalesValueTSPAmt());
		batchDetailsType.setNumPymntsLf(batchDetails.getTotalNumCreditPayments() != null ? batchDetails.getTotalNumCreditPayments().toBigInteger() : null);
		batchDetailsType.setDaysInCollPeriod(batchDetails.getDaysInCollPeriod() != null ? batchDetails.getDaysInCollPeriod().toBigInteger() : null);
		batchDetailsType.setFirstCollStmtDate(StatementProcessorBatchUtil.getDate(batchDetails.getFirstCollStmtDate()));
		if (batchDetails.getInCollectionsInd() == BigDecimal.ONE) {
			batchDetailsType.setInCollectionsInd(true);
		} else {
			batchDetailsType.setInCollectionsInd(false);
		}
		batchDetailsType.setArrearsBucket1(batchDetails.getArrearsBucket1());
		batchDetailsType.setArrearsBucket2(batchDetails.getArrearsBucket2());
		batchDetailsType.setArrearsBucket3(batchDetails.getArrearsBucket3());
		batchDetailsType.setArrearsBucket4(batchDetails.getArrearsBucket4());
		batchDetailsType.setArrearsBucket5(batchDetails.getArrearsBucket5());
		batchDetailsType.setArrearsBucket6(batchDetails.getArrearsBucket6());
		batchDetailsType.setAnnualSalary(new BigInteger(batchDetails.getAnnualSalary() != null ? batchDetails.getAnnualSalary() : "0"));
		batchDetailsType.setHouseholdIncome(new BigInteger(batchDetails.getHouseholdIncome() != null ? batchDetails.getHouseholdIncome() : "0"));
		batchDetailsType.setNoofDependents(batchDetails.getNoOfDependants() != null ? batchDetails.getNoOfDependants().toBigInteger() : null);
		try {
			batchDetailsType.setEmploymentStatus(batchDetails.getEmploymentStatus() != null ? new BigInteger(batchDetails.getEmploymentStatus()) : null);
			batchDetailsType.setResidentStatus(batchDetails.getResidentStatus() != null ? new BigInteger(batchDetails.getResidentStatus()) : null);
		} catch (Exception e) {
			logger.error("Employment status or reisdent status should be integer " + e);
		}
		batchDetailsType.setDateofLastCreditLimitChange(StatementProcessorBatchUtil.getDate(customerContractTriad.getCreatedTimestamp()));
		batchDetailsType.setSixMonthIncomeVerificationCode(batchDetails.getSixMonthIncomeVerificationCode());
		batchDetailsType.setTwelveMonthIncomeVerificationCode(batchDetails.getTwelveMonthIncomeVerificationCode());
		batchDetailsType.setDateofChangeRequest(StatementProcessorBatchUtil.getDate(batchDetails.getDateOfChangeRequest()));
		batchDetailsType.setPreviousAnnualSalary(new BigInteger(batchDetails.getPreviousAnnualSalary() != null ? batchDetails.getPreviousAnnualSalary() : "0"));
		batchDetailsType.setPreviousHouseholdIncome(new BigInteger(batchDetails.getPreviousHouseholdIncome() != null ? batchDetails.getPreviousHouseholdIncome() : "0"));
		batchDetailsType.setDerivedIncome(batchDetails.getDerivedIncome() != null ? batchDetails.getDerivedIncome().toBigInteger() : null);
		if (batchDetails.getOptOutCreditLimitIncInd() == BigDecimal.ONE) {
			batchDetailsType.setOptOutCreditLimitIncreaseInd(true);
		} else {
			batchDetailsType.setOptOutCreditLimitIncreaseInd(false);
		}
		
		ScoringBlockType scoringBlockType = new ScoringBlockType();
		batchDetailsType.setScoringBlock(scoringBlockType);
		
		scoringBlockType.setScorCreditBand(customerContractTriad.getCreditBandScore());
		scoringBlockType.setWeeksLastFollowUp(customerContractTriad.getWksLastFollowUp() != null ? customerContractTriad.getWksLastFollowUp().toBigInteger() : null);
		scoringBlockType.setAvWklyPayment2Sched6(accountRule.getAvWklyPayment2Sched6() != null ? accountRule.getAvWklyPayment2Sched6().getValue() : null);
		scoringBlockType.setAvWklyPayment2Sched12(accountRule.getAvWklyPayment2Sched12() != null ? accountRule.getAvWklyPayment2Sched12().getValue() : null);
		scoringBlockType.setCumRemits2Sales(accountRule.getCumRemits2Sales() != null ? accountRule.getCumRemits2Sales().getValue() : null);
		scoringBlockType.setTCWks(customerContractTriad.getTcWks() != null ? customerContractTriad.getTcWks().toBigInteger() : null);
		scoringBlockType.setLastOrderWks(accountRule.getLastOrderWks().getValue() != null ? accountRule.getLastOrderWks().getValue().toBigInteger() : null);
		scoringBlockType.setLastTransWks(accountRule.getLastTransWks().getValue() != null ? accountRule.getLastTransWks().getValue().toBigInteger() : null);
		scoringBlockType.setClearBalWks(accountRule.getClearBalWeeks().getValue() != null ? accountRule.getClearBalWeeks().getValue().toBigInteger() : null);
		scoringBlockType.setClearBalMRRWks(BigInteger.ZERO);
		scoringBlockType.setDovsRisk(BigDecimal.ZERO);
		scoringBlockType.setNumCode2(accountRule.getNumCode2().getValue() != null ? accountRule.getNumCode2().getValue().toBigInteger() : null);
		scoringBlockType.setNumCode4(customerContractTriad.getNumCode4() != null ? customerContractTriad.getNumCode4().toBigInteger() : null);
		scoringBlockType.setNumCode5(customerContractTriad.getNumCode4() != null ? customerContractTriad.getNumCode4().toBigInteger() : null);
		scoringBlockType.setHighFUP6M(customerContractTriad.getHighFup6M() != null ? customerContractTriad.getHighFup6M().toBigInteger() : null);
		scoringBlockType.setHighFUP12M(customerContractTriad.getHighFup12M() != null ? customerContractTriad.getHighFup12M().toBigInteger() : null);
		scoringBlockType.setMRR(BigDecimal.ZERO);
		scoringBlockType.setCode5Last12(customerContractTriad.getCode5Last12() != null ? customerContractTriad.getCode5Last12().toBigInteger() : null);
		scoringBlockType.setAvPTB3(accountRule.getAvPTB3().getValue());
		scoringBlockType.setAvPTB6(accountRule.getAvPTB6().getValue());
		scoringBlockType.setLastArrearsWks(agreementTriad.getLastArrearsWks() != null ? agreementTriad.getLastArrearsWks().toBigInteger() : null);
		scoringBlockType.setCreditRejectsValue(retailContractTriad.getCreditRejectsVal());
		scoringBlockType.setCreditLimitUtil(agreementTriad.getCreditLimitUtil());
		scoringBlockType.setDRDInd(BigInteger.ZERO);
		scoringBlockType.setPaidPaymentTree(accountRule.getPaidPaymentTree().getValue() != null ? accountRule.getPaidPaymentTree().getValue().toBigInteger() : null);
		scoringBlockType.setInterestPaymentTree(accountRule.getInterestPaymentTree().getValue() != null ? accountRule.getInterestPaymentTree().getValue().toBigInteger() : null);
		scoringBlockType.setCreditStatus(customerContractTriad.getCreditStatusScore());
		scoringBlockType.setWorstFUP(customerContractTriad.getWorstFollowUpCode() != null ? customerContractTriad.getWorstFollowUpCode().toBigInteger() : null);
		scoringBlockType.setLastFUPDays(customerContractTriad.getLastFollowUpDays() != null ? customerContractTriad.getLastFollowUpDays().toBigInteger() : null);
		scoringBlockType.setTCDays(customerContractTriad.getTcDays() != null ? customerContractTriad.getTcDays().toBigInteger() : null);
		scoringBlockType.setMthlySalesAv(accountRule.getMthlyAvSales() != null ? accountRule.getMthlyAvSales().getValue() : null);
		scoringBlockType.setWorstCRF3(customerContractTriad.getWorstCrf3Score());
		scoringBlockType.setWorstCRF5(customerContractTriad.getWorstCrf5Score());
		scoringBlockType.setLastPaymentDays(agreementTriad.getLastPaymentDays() != null ? agreementTriad.getLastPaymentDays().toBigInteger() : null);
		scoringBlockType.setNilBalanceDays(agreementTriad.getNillBalanceDays() != null ? agreementTriad.getNillBalanceDays().toBigInteger() : null);
		scoringBlockType.setRemits2Sales(customerContractTriad.getRemit2Sales() != null ? customerContractTriad.getRemit2Sales().toBigInteger() : null);
		scoringBlockType.setBal2Remits6(accountRule.getBal2Remits6().getValue() != null ? accountRule.getBal2Remits6().getValue().toBigInteger() : null);
		scoringBlockType.setBal2Remits3(accountRule.getBal2Remits3().getValue() != null ? accountRule.getBal2Remits3().getValue().toBigInteger() : null);
		
		for (BatchGroup batchGroup : batchGroupList) {
		
			BatchGroupType batchGroupType = new BatchGroupType();			
			batchGroupType.setBatchGroupOccurence(batchGroup.getBatchGroupOccurence() != null ? batchGroup.getBatchGroupOccurence().toBigInteger() : null);
			batchGroupType.setValFees(batchGroup.getValFees());
			batchGroupType.setDelqNumCycles(batchGroup.getDelqNumCycles() != null ? batchGroup.getDelqNumCycles().toBigInteger() : null);			
			batchDetailsType.getBatchGroup().add(batchGroupType);
		}
		
		for (BatchMonth batchMonth : batchMonthList) {
		
			BatchMonthType batchMonthType = new BatchMonthType();
			batchMonthType.setBatchMonthOccurence(batchMonth.getBatchMonthOccurence() != null ? batchMonth.getBatchMonthOccurence().toBigInteger() : null);
			batchMonthType.setSPPD(batchMonth.getScheduledPaymentsPastDue());
			batchMonthType.setInterestChargedAmt(batchMonth.getInterestChargedAmtTSP());
			batchMonthType.setNumPurchases(batchMonth.getNumPurchasesTSP() != null ? batchMonth.getNumPurchasesTSP().toBigInteger() : null);
			batchMonthType.setRiskNavScore(batchMonth.getRiskNavScore() != null ? batchMonth.getRiskNavScore().toBigInteger() : null);
			batchMonthType.setOverIndebtScore(batchMonth.getOverIndebtScore() != null ? batchMonth.getOverIndebtScore().toBigInteger() : null);
			batchMonthType.setFeesAmount(batchMonth.getTotalFeesTSP());
			batchMonthType.setRebatesAmount(batchMonth.getRebatesAmountTSP());
			batchMonthType.setBalance(batchMonth.getoTB());
			batchMonthType.setNumPayments(batchMonth.getNumPaymentsTSP() != null ? batchMonth.getNumPaymentsTSP().toBigInteger() : null);
			batchMonthType.setNumNSF(batchMonth.getNumNSF() != null ? batchMonth.getNumNSF().toBigInteger() : null);
			batchMonthType.setDateStatement(StatementProcessorBatchUtil.getDate(batchMonth.getDateStatement()));
			batchMonthType.setBlockCode(batchMonth.getBlockCode());
			batchMonthType.setClosingBalance(batchMonth.getCurrentBalance());
			batchMonthType.setValuePurchases(batchMonth.getPurchaseAmountTSP());
			batchMonthType.setOtherDebits(batchMonth.getOtherDebits());
			batchMonthType.setTotalFees(batchMonth.getTotalFeesTSP());
			batchMonthType.setValuePayments(batchMonth.getPaymentAmountTSP());
			batchMonthType.setOtherCredits(batchMonth.getOtherCredits());
			batchMonthType.setNumFailedPayments(batchMonth.getNumFailedPayments() != null ? batchMonth.getNumFailedPayments().toBigInteger() : null);
			batchMonthType.setValueFailedPayments(batchMonth.getValueFailedPayments());
			batchMonthType.setTUM(BigDecimal.ZERO);
			batchMonthType.setMinPayment(batchMonth.getMinPayment());
			batchMonthType.setPastDue(batchMonth.getPastDue());
			batchMonthType.setCreditLimit(batchMonth.getCreditLimit());
			batchMonthType.setBehaviourScore(batchMonth.getBehaviourScore() != null ? batchMonth.getBehaviourScore().toBigInteger() : null);
			batchMonthType.setFIDScoreWorst(new BigInteger(batchMonth.getFidScoreWorst() != null ? batchMonth.getFidScoreWorst() : "0"));
			batchMonthType.setPreDelqInd(BigInteger.ZERO);
			batchMonthType.setCreditRiskFactor(batchMonth.getcRF());
			batchMonthType.setBNPLBalance(batchMonth.getBnplBalance());
			batchMonthType.setReturnsAmount(batchMonth.getReturnsAmountTSP());
			batchMonthType.setScorecardId(batchMonth.getScorecardId() != null ? batchMonth.getScorecardId().toBigInteger() : null);
			batchMonthType.setRawScore(batchMonth.getBehaviourRawScore() != null ? batchMonth.getBehaviourRawScore().toBigInteger() : null);
			batchMonthType.setAlignedScore(batchMonth.getAlignedBehaviourScore() != null ? batchMonth.getAlignedBehaviourScore().toBigInteger() : null);
			batchMonthType.setACDScorecardId(batchMonth.getAcdScorecardId() != null ? batchMonth.getAcdScorecardId().toBigInteger() : null);
			batchMonthType.setACDRawScore(batchMonth.getAcdRawScore() != null ? batchMonth.getAcdRawScore().toBigInteger() : null);
			batchMonthType.setACDAlignedScore(batchMonth.getAcdAlignedScore() != null ? batchMonth.getAcdAlignedScore().toBigInteger() : null);
			batchMonthType.setNDRScorecardId(batchMonth.getNdrScorecardId() != null ? batchMonth.getNdrScorecardId().toBigInteger() : null);
			batchMonthType.setNDRRawScore(batchMonth.getNdrRawScore() != null ? batchMonth.getNdrRawScore().toBigInteger() : null);
			batchMonthType.setNDRAlignedScore(batchMonth.getNdrAlignedScore() != null ? batchMonth.getNdrAlignedScore().toBigInteger() : null);
			batchMonthType.setCustScorecardId(batchMonth.getCustScorecardId() != null ? batchMonth.getCustScorecardId().toBigInteger() : null);
			batchMonthType.setCustRawScore(batchMonth.getCustRawScore() != null ? batchMonth.getCustRawScore().toBigInteger() : null);
			batchMonthType.setCustAlignedScore(batchMonth.getCustAlignedScore() != null ? batchMonth.getCustAlignedScore().toBigInteger() : null);
			batchMonthType.setT6Sales(batchMonth.getNetSalesValueTSPAmt());
			batchMonthType.setValuePurchases(batchMonth.getPurchaseAmountTSP());
			
			batchDetailsType.getBatchMonth().add(batchMonthType);
		}
		
		for (BatchLinked batchLinked : batchLinkedList) {
			
			BatchLinkedType batchLinkedType = new BatchLinkedType();
			batchLinkedType.setBatchLinkedOccurence(batchLinked.getBatchLinkedOccurence() != null ? batchLinked.getBatchLinkedOccurence().toBigInteger() : null);
			batchLinkedType.setAccountNumber(batchLinked.getCustomerAccountNumber());
			batchLinkedType.setAccountTypeCode(batchLinked.getAccountTypeCode());
			batchLinkedType.setDateStart(StatementProcessorBatchUtil.getDate(batchLinked.getDateStart()));
			batchLinkedType.setDateCompleted(StatementProcessorBatchUtil.getDate(batchLinked.getDateClosed()));
			batchLinkedType.setDateRestart(StatementProcessorBatchUtil.getDate(batchLinked.getDateRestart()));
			//batchLinkedType.setDateLastOrder(StatementProcessorBatchUtil.getDate(accountRule.getDateLastOrder().getValue())); //aa
			//batchLinkedType.setDateLastPayment(StatementProcessorBatchUtil.getDate(accountRule.getDateLastPayment().getValue())); //aa
			batchLinkedType.setScheduledPaymentAmt(batchLinked.getScheduledPaymentAmt());
			batchLinkedType.setDateStartDelinquency(StatementProcessorBatchUtil.getDate(batchLinked.getDateStartDelinquency()));
			batchLinkedType.setDateDebitBalance(StatementProcessorBatchUtil.getDate(batchLinked.getDateLastZeroBalance()));
			batchLinkedType.setCurrentBalance(batchLinked.getCurrentBalance());
			batchLinkedType.setNetSalesValueTSPAmt(batchLinked.getNetSalesValueTSPAmt());
			batchLinkedType.setBlockCode(batchLinked.getBlockCode());
			batchLinkedType.setPaymentAmount(batchLinked.getPaymentAmountTSP());
			batchLinkedType.setMinPayment(batchLinked.getMinPayment());
			batchLinkedType.setReturnsAmount(batchLinked.getReturnsAmountTSP());
			batchLinkedType.setDebitAmount(batchLinked.getDebitAmount());
			batchLinkedType.setOtherAdjustmentssAmount(batchLinked.getOtherAdjustmentsAmountTSP());
			batchLinkedType.setTotalFees(batchLinked.getTotalFeesTSP());
			batchLinkedType.setNumReturnedPayments(batchLinked.getNumReturnedPaymentsTSP() != null ? batchLinked.getNumReturnedPaymentsTSP().toBigInteger() : null);
			batchLinkedType.setBehaviourScore(batchLinked.getBehaviourScore() != null ? batchLinked.getBehaviourScore().toBigInteger() : null);
			batchLinkedType.setCreditRiskFactor(batchLinked.getCreditRiskFactor());
			batchLinkedType.setRecruitmentCRF(batchLinked.getRecruitmentCRF());
			batchLinkedType.setBNPLBalance(batchLinked.getBnplBalance());
			batchLinkedType.setPPIInd(batchLinked.getPpiInd() != null ? batchLinked.getPpiInd().toBigInteger() : null);
			batchLinkedType.setSPPD(batchLinked.getScheduledPaymentsPastDue());
			batchLinkedType.setDateCreditLimitDecrease(StatementProcessorBatchUtil.getDate(batchLinked.getDateLastCreditLimitDecrease()));
			batchLinkedType.setDateCreditLimitIncrease(StatementProcessorBatchUtil.getDate(batchLinked.getDateLastCreditLimitIncrease()));
			batchLinkedType.setArrearsBucket1(batchLinked.getArrearsBucket1());
			batchLinkedType.setArrearsBucket2(batchLinked.getArrearsBucket2());
			batchLinkedType.setArrearsBucket3(batchLinked.getArrearsBucket3());
			batchLinkedType.setArrearsBucket4(batchLinked.getArrearsBucket4());
			batchLinkedType.setArrearsBucket5(batchLinked.getArrearsBucket5());
			batchLinkedType.setArrearsBucket6(batchLinked.getArrearsBucket6());
			batchLinkedType.setFrozenLimitInd(batchLinked.getCreditLimitFrozenInd() != null ? batchLinked.getCreditLimitFrozenInd().toString() : null);
			batchLinkedType.setTCStatus(batchLinked.getAccountStatusCode());
			batchLinkedType.setFIDFlagDate(StatementProcessorBatchUtil.getDate(batchLinked.getFidFlagDate()));
			batchLinkedType.setFIDScoreDate(StatementProcessorBatchUtil.getDate(batchLinked.getFidScoreDate()));
			try {
				batchLinkedType.setFIDScore(new BigInteger(batchLinked.getFidScore() != null ? batchLinked.getFidScore() : "0"));
			} catch (Exception e) {
				logger.error("FID Score should be integer" + e);
			}
			batchLinkedType.setFIDScoreWorst(new BigInteger(batchLinked.getFidScoreWorst() != null ? batchLinked.getFidScoreWorst() : "0"));
			batchLinkedType.setCreditStatusCode(batchLinked.getCreditStatusCode());
			batchLinkedType.setCreditStatusSubCode(batchLinked.getCreditStatusSubCode());
			batchLinkedType.setPastDue(batchLinked.getPastDue());
			batchLinkedType.setFollowUpCode(batchLinked.getLastFollowUpCode() != null ? batchLinked.getLastFollowUpCode().toBigInteger() : null);
			batchLinkedType.setOTB(batchLinked.getoTB());
			batchLinkedType.setPaymentsTotal(batchLinked.getCreditPaymentsTotal());
			batchLinkedType.setCreditBand(batchLinked.getCreditBand());
			batchLinkedType.setValuePayments(batchLinked.getPaymentAmountTSP());
			batchLinkedType.setTotalUnchargedMvmts(BigDecimal.ZERO);
			batchLinkedType.setCreditLimit(batchLinked.getCreditLimit());
			batchLinkedType.setHighBalance(batchLinked.getHighBalance());
			batchLinkedType.setHighDelq(batchLinked.getHighDelq() != null ? batchLinked.getHighDelq().toBigInteger() : null);
			batchLinkedType.setNumCycle1(batchLinked.getNumCycle1() != null ? batchLinked.getNumCycle1().toBigInteger() : null);
			batchLinkedType.setNumCycle2(batchLinked.getNumCycle2() != null ? batchLinked.getNumCycle2().toBigInteger() : null);
			batchLinkedType.setNumCycle3(batchLinked.getNumCycle3() != null ? batchLinked.getNumCycle3().toBigInteger() : null);
			batchLinkedType.setNumCycle4(batchLinked.getNumCycle4() != null ? batchLinked.getNumCycle4().toBigInteger() : null);
			batchLinkedType.setNumPayments(batchLinked.getNumPaymentsTSP() != null ? batchLinked.getNumPaymentsTSP().toBigInteger() : null);
			batchLinkedType.setInterestChargedAmt(batchLinked.getInterestChargedAmtTSP());
			batchLinkedType.setDateLastStatement(StatementProcessorBatchUtil.getDate(batchLinked.getDateLastStatement()));
			
			for (BatchLinkedGroup batchLinkedGroup : batchLinkedGroupList) {
				
				BatchLinkedGroupType batchLinkedGroupType = new BatchLinkedGroupType();
				batchLinkedGroupType.setBatchLinkedGroupOccurence(batchLinkedGroup.getBatchLinkedGroupOccurence() != null ? batchLinkedGroup.getBatchLinkedGroupOccurence().toBigInteger() : null);
				batchLinkedGroupType.setValFees(batchLinkedGroup.getValFees());
				batchLinkedGroupType.setDelqNumCycles(batchLinkedGroup.getDelqNumCycles() != null ? batchLinkedGroup.getDelqNumCycles().toBigInteger() : null);
				
				batchLinkedType.getBatchLinkedGroup().add(batchLinkedGroupType);
			}
			
			for (BatchLinkedMonth batchLinkedMonth : batchLinkedMonthList) {
				
				BatchLinkedMonthType batchLinkedMonthType = new BatchLinkedMonthType();
				batchLinkedMonthType.setBatchLinkedMonthOccurence(batchLinkedMonth.getBatchLinkedMonthOccurence() != null ? batchLinkedMonth.getBatchLinkedMonthOccurence().toBigInteger() : null);
				batchLinkedMonthType.setDateStatement(StatementProcessorBatchUtil.getDate(batchLinkedMonth.getDateStatement()));
				batchLinkedMonthType.setBlockCode(batchLinkedMonth.getBlockCode());
				batchLinkedMonthType.setClosingBalance(batchLinkedMonth.getCurrentBalance());
				batchLinkedMonthType.setMinPayment(batchLinkedMonth.getMinPayment());
				batchLinkedMonthType.setPastDue(batchLinkedMonth.getPastDue());
				batchLinkedMonthType.setNumPurchases(batchLinkedMonth.getNumPurchasesTSP() != null ? batchLinkedMonth.getNumPurchasesTSP().toBigInteger() : null);
				batchLinkedMonthType.setValuePurchases(batchLinkedMonth.getPurchaseAmountTSP());
				batchLinkedMonthType.setTotalFees(batchLinkedMonth.getTotalFeesTSP());
				batchLinkedMonthType.setOtherDebits(batchLinkedMonth.getOtherDebits());
				batchLinkedMonthType.setNumPayments(batchLinkedMonth.getNumPaymentsTSP() != null ? batchLinkedMonth.getNumPaymentsTSP().toBigInteger() : null);
				batchLinkedMonthType.setValuePayments(batchLinkedMonth.getPaymentAmountTSP());
				batchLinkedMonthType.setOtherCredits(batchLinkedMonth.getOtherCredits());
				batchLinkedMonthType.setNumFailedPayments(batchLinkedMonth.getNumFailedPayments() != null ? batchLinkedMonth.getNumFailedPayments().toBigInteger() : null);
				batchLinkedMonthType.setValueFailedPayments(batchLinkedMonth.getValueFailedPayments());
				batchLinkedMonthType.setCreditLimit(batchLinkedMonth.getCreditLimit());
				batchLinkedMonthType.setInterestChargedAmt(batchLinkedMonth.getInterestChargedAmtTSP());
				batchLinkedMonthType.setBehaviourScore(batchLinkedMonth.getBehaviourScore() != null ? batchLinkedMonth.getBehaviourScore().toBigInteger() : null);
				batchLinkedMonthType.setCreditRiskFactor(batchLinkedMonth.getcRF());
				batchLinkedMonthType.setFIDScoreWorst(new BigInteger(batchLinkedMonth.getFidScoreWorst() != null ? batchLinkedMonth.getFidScoreWorst() : "0"));
				batchLinkedMonthType.setBNPLBalance(batchLinkedMonth.getBnplBalance());
				batchLinkedMonthType.setScheduledPaymentsPastDue(batchLinkedMonth.getScheduledPaymentsPastDue());
				batchLinkedMonthType.setPreDelqInd(BigInteger.ZERO);
				batchLinkedMonthType.setReturnsAmount(batchLinkedMonth.getReturnsAmountTSP());
				batchLinkedMonthType.setTUM(BigDecimal.ZERO);
				batchLinkedMonthType.setT6Sales(batchLinkedMonth.getNetSalesValueTSPAmt());
				
				batchLinkedType.getBatchLinkedMonth().add(batchLinkedMonthType);
			}
			
			batchDetailsType.getBatchLinked().add(batchLinkedType);
		}
		
		reassessTriadType.setTransformSams200CRequest(transformSams200CRequestType);
		logger.debug("[Sams200RequestTransformer -- transformSams200CRequestType] -- End");
	}
}
