package com.shopdirect.nce.sp.model;

import java.util.Date;

public class DrawdownIncome {
	
	private String drawdownId;
	
	private String incomeType;
	
	private Integer agrPaymentPeriod;
	
	private Double outstandingAmount;
	
	private Double outstandingCapital;
	
	private Double outstandingCharge;
	
	private Double outstandingInterest;
	
	private Long batchId;
	
	private String errorFlag;
	
	private String errorMessage;
	
	private Date creationDate;
	
	private Long createdByUser;
	
	private Date lastUpdateDate;
	
	private Long lastUpdateByUser;

	public String getDrawdownId() {
		return drawdownId;
	}

	public void setDrawdownId(String drawdownId) {
		this.drawdownId = drawdownId;
	}

	public String getIncomeType() {
		return incomeType;
	}

	public void setIncomeType(String incomeType) {
		this.incomeType = incomeType;
	}

	public Integer getAgrPaymentPeriod() {
		return agrPaymentPeriod;
	}

	public void setAgrPaymentPeriod(Integer agrPaymentPeriod) {
		this.agrPaymentPeriod = agrPaymentPeriod;
	}

	public Double getOutstandingAmount() {
		return outstandingAmount;
	}

	public void setOutstandingAmount(Double outstandingAmount) {
		this.outstandingAmount = outstandingAmount;
	}

	public Double getOutstandingCapital() {
		return outstandingCapital;
	}

	public void setOutstandingCapital(Double outstandingCapital) {
		this.outstandingCapital = outstandingCapital;
	}

	public Double getOutstandingCharge() {
		return outstandingCharge;
	}

	public void setOutstandingCharge(Double outstandingCharge) {
		this.outstandingCharge = outstandingCharge;
	}

	public Double getOutstandingInterest() {
		return outstandingInterest;
	}

	public void setOutstandingInterest(Double outstandingInterest) {
		this.outstandingInterest = outstandingInterest;
	}

	public Long getBatchId() {
		return batchId;
	}

	public void setBatchId(Long batchId) {
		this.batchId = batchId;
	}

	public String getErrorFlag() {
		return errorFlag;
	}

	public void setErrorFlag(String errorFlag) {
		this.errorFlag = errorFlag;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public Long getCreatedByUser() {
		return createdByUser;
	}

	public void setCreatedByUser(Long createdByUser) {
		this.createdByUser = createdByUser;
	}

	public Date getLastUpdateDate() {
		return lastUpdateDate;
	}

	public void setLastUpdateDate(Date lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}

	public Long getLastUpdateByUser() {
		return lastUpdateByUser;
	}

	public void setLastUpdateByUser(Long lastUpdateByUser) {
		this.lastUpdateByUser = lastUpdateByUser;
	}
	
	

}
