package com.shopdirect.nce.sp.dao.creditdataload;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;

import com.shopdirect.nce.common.extcnfg.ExternalFileDataConfiguration;
import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.Query;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.dao.AccountReassessmentBaseDao;
import com.shopdirect.nce.sp.exception.BuisnessException;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.Agreement;
import com.shopdirect.nce.sp.util.CommonConfigHelper;
import com.shopdirect.nce.sp.util.StatementProcessorBatchUtil;
import com.shopdirect.nce.sp.util.UCPConnection;

import oracle.jdbc.OracleTypes;
import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;

/**
 * This class interacts with Database for inserting or updating data into the SP
 * DB.
 * 
 * @author ibm
 *
 */

public class AgreementDaoImpl extends AccountReassessmentBaseDao {

	boolean isInsertSuccess = false;
	Connection connection = null;
	int retCode = 0;
	String retMsg = null;
	Agreement agreement = null;
	CallableStatement callStmt = null;
	private static SDLoggerImpl logger = new SDLoggerImpl();
	Object[] procReturnVal = new Object[2];
	String errMsg = null;

	public AgreementDaoImpl() throws StatementProcessorBatchException {
		super();
	}

	
	/**
	 * @param agreementList
	 * @return
	 * @throws BuisnessException
	 * @throws StatementProcessorBatchException 
	 * @throws Exception
	 */
	public Object[] insertAgreementData(List<Agreement> agreementList) throws StatementProcessorBatchException{

		logger.debug("[AgreementDaoImpl -- insertAgreementData]  -- START");
		String isInsertSuccessMessege = null;
		CommonConfigHelper commonConfigHelper = CommonConfigHelper.getInstance();
		ExternalFileDataConfiguration Dbconfig = commonConfigHelper.loadPropertyConfig("spDbConfig");
		String CREDIT_DATA_LOAD_PACK = commonConfigHelper.readConfigData(Dbconfig, "CREDIT_DATA_LOAD_PACK");
		String PROC_POPULATE_AGREEMENT = commonConfigHelper.readConfigData(Dbconfig, "PROC_POPULATE_AGREEMENT");
		setSpMainSchema(getSchema(StatementProcessorBatchConstants.DB_SCHEMA_MAIN_SP_KEY));

		try {
			connection = UCPConnection.getConnection();
			String callQueryStr = Query.getInsertFinDataQuery(CREDIT_DATA_LOAD_PACK, PROC_POPULATE_AGREEMENT);
			callStmt = connection.prepareCall(callQueryStr);
			
			java.sql.Struct agreementStructArray[] = new java.sql.Struct[agreementList.size()];
			
			int ctr = 0;
			for (Agreement agreement : agreementList) {
				
				Object[] agreementObj = new Object[] { agreement.getAgreementId(),agreement.getAgreementSeq(),StatementProcessorBatchUtil.convertJavaDateToSqlDate(agreement.getStatementDate()),
						agreement.getInterestRate(),  agreement.getOpeningBalance(),
						agreement.getClosingBalance(), agreement.getArrangementAmount(), agreement.getMinimumPayment(),
						agreement.getMinimumPaymentcalculatedBalance(), agreement.getMinimumPaymentPercentage(),
						agreement.getFixedMinimumPayment(), agreement.getDirectDebitAmount(), agreement.getPpiAmount(),
						agreement.getArrearsAmount(), StatementProcessorBatchUtil.convertJavaDateToSqlDate(agreement.getNextpaymentDueDate()),StatementProcessorBatchUtil.convertJavaDateToSqlDate(agreement.getPreviousPaymentDuedate()), 
						agreement.getCreditLimit(), agreement.getAvailableToSpend(), agreement.getAgreementType(),
						agreement.getTakeAll(), agreement.getAgreementTypePaymentsTransferredIn(),
						StatementProcessorBatchUtil.convertJavaDateToSqlDate(agreement.getAccountPromotionEndDate()),
						agreement.getMissedMinPayInd(), agreement.getDirectDebitTypeInd(),
						agreement.getScheduledPaymentAmount(), agreement.getScheduledPaymentPastDue(),agreement.getBatchId(),
						agreement.getCreatedByUser(), agreement.getPendingItemInd(), agreement.getNoInterestIndicator()};

				java.sql.Struct agreementStructObj = connection.createStruct("TY_OBJ_INST_CREDIT_AGR", agreementObj);
				agreementStructArray[ctr++] = agreementStructObj;
			}
			ArrayDescriptor desc = ArrayDescriptor.createDescriptor("TY_TAB_INST_CREDIT_AGR", connection);
			ARRAY agreementArray = new ARRAY(desc, connection, agreementStructArray);
			logger.debug("agreementStructArray=======" + Arrays.toString(agreementStructArray));
			callStmt.setArray(1, agreementArray);
			callStmt.registerOutParameter(2, OracleTypes.ARRAY, "TY_TAB_INST_CREDIT_AGR_OUT");
			callStmt.registerOutParameter(3, java.sql.Types.INTEGER);
			callStmt.registerOutParameter(4, java.sql.Types.CHAR);
			callStmt.executeUpdate();

			retCode = callStmt.getInt(3);
			retMsg = callStmt.getString(4);
			ARRAY outArray = (ARRAY) callStmt.getArray(2);
			Object[] outList = (Object[]) outArray.getArray();
			
			if (retCode == 0) {
				isInsertSuccess = true;
			} else {
				if (outList.length > 29)
					errMsg = (String) outList[29];
				else
					errMsg = retMsg + "[ID]";
				logger.debug("Agreement Insertion Exception errMsg=========" + errMsg);
				isInsertSuccess = false;
				throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_BUSINESS_ERROR_CODE,
						"[AgreementDaoImpl-insertAgreementData] StatementProcessorBatchException Block",
						"Database Failed Insertion execution exception " + errMsg, null, null,
						new StatementProcessorBatchException());
			}
			
			isInsertSuccessMessege = retMsg;
			procReturnVal[0]= retCode;
			procReturnVal[1]= retMsg;
			
			
			
//			if (retCode == 1) {
//				isInsertSuccess = true;
//				isInsertSuccessMessege = null;
//			} else {
//				logger.debug("Agreement Insertion Exception retMsg=========" + retMsg);
//				isInsertSuccess = false;
//				isInsertSuccessMessege = retMsg;
//				throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_BUSINESS_ERROR_CODE,
//						"[AgreementDaoImpl-insertAgreementData] StatementProcessorBatchException Block",
//						"Database Failed Insertion execution exception " + isInsertSuccessMessege, null, null,
//						new StatementProcessorBatchException());
//			}
			logger.debug("isInsertSuccess=======" + isInsertSuccess);
			logger.debug("[AgreementDaoImpl -- insertAgreementData]  -- END");

		} catch (SQLException sqlException) {
			isInsertSuccess = false;
			isInsertSuccessMessege = sqlException.getMessage();
			logger.error("Agreement SQLException Exception =======" + isInsertSuccessMessege);
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_DB_ERROR_CODE,
					"[AgreementDaoImpl-insertAgreementData] SQLException Block",
					"Database execution exception [SQLCode: " + sqlException.getSQLState() + "] , SQL Detail "
							+ sqlException.getMessage(),
					null, null, sqlException);

		} catch (Exception exception) {
			isInsertSuccess = false;
			isInsertSuccessMessege = exception.getMessage();
			logger.error("Agreement Generic Exception =======" + isInsertSuccessMessege);
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.CONNECTTION_DB_ERROR_CODE,
					"[AgreementDaoImpl-insertAgreementData] Exception Block",
					"Database execution exception " + exception.getMessage(), null, null, exception);
		} finally {

			try {

				/**
				 * UPDATE the CONTROL TABLE PROVIDING IF INSERT IN AGREEMENT
				 * TABLE IS SUCCESS OR FAILURE
				 */

				if (callStmt != null) {
					callStmt.close();
				}

				if (connection != null) {
					connection.close();
				}

			} catch (Exception e) {
				logger.error("[AgreementDaoImpl-insertAgreementData]  -- Exception Block, Database execution exception "+e.getMessage());					
			}
		}

		return procReturnVal;
	}

}