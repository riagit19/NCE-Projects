package com.shopdirect.nce.sp.model;

import java.math.BigDecimal;

public class BatchLinkedGroup {

	private String customerAccountNumber;
	private BigDecimal batchLinkedGroupOccurence;
	private BigDecimal valFees;
	private BigDecimal delqNumCycles;
	
	public BatchLinkedGroup() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BatchLinkedGroup(String customerAccountNumber, BigDecimal batchLinkedGroupOccurence, BigDecimal valFees,
			BigDecimal delqNumCycles) {
		super();
		this.customerAccountNumber = customerAccountNumber;
		this.batchLinkedGroupOccurence = batchLinkedGroupOccurence;
		this.valFees = valFees;
		this.delqNumCycles = delqNumCycles;
	}

	public String getCustomerAccountNumber() {
		return customerAccountNumber;
	}

	public void setCustomerAccountNumber(String customerAccountNumber) {
		this.customerAccountNumber = customerAccountNumber;
	}

	public BigDecimal getBatchLinkedGroupOccurence() {
		return batchLinkedGroupOccurence;
	}

	public void setBatchLinkedGroupOccurence(BigDecimal batchLinkedGroupOccurence) {
		this.batchLinkedGroupOccurence = batchLinkedGroupOccurence;
	}

	public BigDecimal getValFees() {
		return valFees;
	}

	public void setValFees(BigDecimal valFees) {
		this.valFees = valFees;
	}

	public BigDecimal getDelqNumCycles() {
		return delqNumCycles;
	}

	public void setDelqNumCycles(BigDecimal delqNumCycles) {
		this.delqNumCycles = delqNumCycles;
	}
	
	
}
