package com.shopdirect.nce.sp.constants;




/**
 * This class contains all the static constant values used in the application.
 * @author ibm
 *
 */
public class CreditLoadDataConstants {
	
		
	public static final String AGREEMENT_CODE = "agreement.AgreementCode";
	public static final String AGREEMENT_TYPE = "agreement.agreementType";
	public static final String AGREEMENT_PAYMENTS_TRANSFERRED_IN = "agreement.payments.transferred.in";
	public static final String AGREEMENT_ANNUAL_FEE = "agreement.annual.fee";
	public static final String AGREEMENT_ARRANGEMENT_AMOUNT = "agreement.arrangement.amount";
	public static final String AGREEMENT_AVAILABLE_TO_SPEND = "agreement.available.to.spend";
	public static final String AGREEMENT_BRAND = "agreement.brand";
	public static final String AGREEMENT_CLOSING_BALANCE = "agreement.closing.balance";
	public static final String AGREEMENT_CREATED_DATETIME = "agreemnt.created.dateTime";
	public static final String AGREEMENT_CREDIT_LIMIT = "agreement.credit.limit";
	public static final String AGREEMENT_DIRECT_DEBIT_AMOUNT = "agreement.direct.debit.amount";
	public static final String AGREEMENT_FIXED_MINIMUM_PAYMENT = "agreement.fixed.minimum.payment";
	public static final String AGREEMENT_FORECASTED_INTEREST = "agreement.forecasted.interest";
	public static final String AGREEMENT_MINIMUM_PAYMENT = "agreement.minimum.payment";
	public static final String AGREEMENT_MINIMUM_PAYMENT_CALCULATED_BALANCE = "agreement.minimum.payment.calculated.balance";
	public static final String AGREEMENT_MINIMUM_PAYMENT_PERCENTAGE = "agreement.minimum.payment.percentage";	
	public static final String AGREEMENT_MODIFIED_DATETIME = "agreement.modified.dateTime";
	public static final String AGREEMENT_NEXT_PAYMENT_DUE_DATE = "agreement.next.payment.due.date";
	public static final String AGREEMENT_OPENING_BALANCE = "agreement.opening.balance";
	public static final String AGREEMENT_PPI_AMOUNT = "agreement.ppi.amount";
	public static final String AGREEMENT_PREVIOUS_PAYMENT_DUE_DATE = "agreement.previous.payment.due.date";
	public static final String AGREEMENT_STATEMENT_DATE = "agreement.statement.date";
	public static final String AGREEMENT_STATUS = "agreement.status";
	public static final String AGREEMENT_TAKE_ALL = "agreement.take.all";
	public static final String AGREEMENT_ARREARS_AMOUNT = "agreement.arrears.amount";
	public static final String AGREEMENT_SCHEDULED_PAYMENT_AMT = "agreement.scheduled.payment.amt";
	
	//DrawdownTerm
	public static final String DRAWDOWNTERM_ANNUAL_INTEREST_RATE = "drawdownTerm.annual.interest.rate";
	public static final String DRAWDOWNTERM_BNPL_END_DATE = "drawdownTerm.bnpl.end.date";
	public static final String DRAWDOWNTERM_BNPL_ESTIMATED_INTEREST = "drawdownTerm.estimated.interest";
	public static final String DRAWDOWNTERM_BRAND_CREDIT_PRODUCT_CODE = "drawdownTerm.brand.credit.product.code";
	public static final String DRAWDOWNTERM_CREDIT_AUTHORIZATION_DATE = "drawdownTerm.credit.authorization.date";
	public static final String DRAWDOWNTERM_CREDIT_PRODUCT_CATEGORY_CODE = "drawdownTerm.credit.product.category.code";
	public static final String DRAWDOWNTERM_DAILY_INTEREST_RATE = "drawdownTerm.daily.interest.rate";
	public static final String DRAWDOWNTERM_DRAWDOWN_CODE = "drawdownTerm.drawdown.code";
	public static final String DRADOWNTERM_ROLL_ON_DRAWDOWN_CODE = "drawdownTerm.roll.on.drawdown.code";
	public static final String DRAWDOWNTERM_DRAWDOWN_SEQUENCE = "drawdownTerm.drawdown.sequence";
	public static final String DRAWDOWNTERM_DRAWDOWN_TYPE = "drawdownTerm.drawdown.type";
	public static final String DRAWDOWNTERM_PRODUCT_CATEGORY = "drawdownTerm.product.category";
	public static final String DRAWDOWNTERM_SOURCE = "drawdownTerm.source";
	public static final String DRAWDOWNTERM_STATUS = "drawdownTerm.status";
	public static final String DRAWDOWNTERM_OUTSTANDING_BALANCE = "drawdownTerm.outstanding.balance";
	public static final String DRAWDOWNTERM_DRAWDOWN_TERM = "drawdownTerm.drawdown.term";
	public static final String DRAWDOWNTERM_DRAWDOWN_TERM_UNIT = "drawdownTerm.drawdown.term.unit";
	public static final String DRAWDOWNTERM_DRAWDOWN_SETTLED_IND = "drawdownTerm.drawdown.settled.ind";
	public static final String DRAWDOWNTERM_PRODUCT_DESCRIPTION = "drawdownTerm.product.description";
	public static final String DRAWDOWNTERM_INTEREST_CHARGED_THIS_PERIOD = "drawdownTerm.interest.charged.this.period";	
	public static final String DRAWDOWNTERM_PROMOTION_END_DATE = "drawdownTerm.promotion.end.date";
	public static final String DRAWDOWNTERM_SETTLEMENT_FEE = "drawdownTerm.settlement.fee";
	public static final String DRAWDOWNTERM_START_DATE = "drawdownTerm.start.date";
	//DrawdownItem
	public static final String DRAWDOWNITEM_DRAWDOWN_CODE = "drawdownItem.drawdown.code";
	public static final String DRAWDOWNITEM_DRAWDOWN_ITEM_CODE = "drawdownItem.order.item.code";
	public static final String DRAWDOWNITEM_ORDER_LINE_ID = "drawdownItem.order.line.id";
	public static final String DRAWDOWNITEM_CASH_PRICE = "drawdownItem.cash.price";
	public static final String DRAWDOWNITEM_ITEM_DESCRIPTION = "drawdownItem.item.description";
	public static final String DRAWDOWNITEM_ID = "drawdownItem.drawdownItemId";
    public static final String DRAWDOWNITEM_ORDER_ID = "drawdownItem.order.id";
    public static final String DRAWDOWNITEM_MIV_SUBCODE = "drawdownItem.miv.subcode";
    public static final String DRAWDOWNITEM_MIV_CODE = "drawdownItem.miv.code";
    public static final String DRAWDOWNITEM_ITEM_TYPE = "drawdownItem.item.type";
    public static final String DRAWDOWNITEM_ITEM_DATE = "drawdownItem.item.date";
	//DrawdownTransaction
	public static final String DRAWDOWNTRANSACTION_DRAWDOWN_CODE = "drawdownTransaction.drawdown.code";
	public static final String DRAWDOWNTRANSACTION_TRANSACTION_NUMBER = "drawdownTransaction.transaction.number";
	public static final String DRAWDOWNTRANSACTION_SETUP_FEE = "drawdownTransaction.setup.fee";
	public static final String DRAWDOWNTRANSACTION_SETTLEMENT_FEE = "drawdownTransaction.settlement.fee";
	public static final String DRAWDOWNTRANSACTION_RETURN = "drawdownTransaction.return";
	public static final String DRAWDOWNTRANSACTION_CANCELLATION = "drawdownTransaction.cancellation";
	public static final String DRAWDOWNTRANSACTION_ADJUSTEMENT = "drawdownTransaction.adjustment";
	public static final String DRAWDOWNTRANSACTION_TARGETED_PAYMENT = "drawdownTransaction.targeted.payment";
	public static final String DRAWDOWNTRANSACTION_INTEREST = "drawdownTransaction.interest";
	public static final String DRAWDOWNTRANSACTION_TRANSACTION_DATE = "drawdownTransaction.transaction.date";
	
	
	//Nosia
	public static final String NOSIA_AGREEMENT = "nosia.agreement";
	public static final String NOSIA_PREVIOUS_NOSIA_BALANCE = "nosia.previous.nosia.balance";
	public static final String NOSIA_PREVIUOS_NOSIA_ARREARS = "nosia.previous.nosia.arrears";
	public static final String NOSIA_DATE = "nosia.date";
	public static final String CLOSING_BALANCE = "nosia.closing.balance";
	public static final String ARREARS_AMOUNT = "nosia.arrears.amount";
	public static final String MOST_RECENT_PAYMENT_AMOUNT = "nosia.most.recent.payment.amount";
	public static final String NOSIA_PREVIOUS_PAYMENT_AMOUNT = "nosia.previous.payment.amount";
	

	//PeriodPayment
	public static final String PERIODPAYMENT_PERIOD_PAYMENT = "period.payment";
	public static final String PERIODPAYMENT_AGREEMENT_CODE = "periodPayment.agreement.code";
	public static final String PERIODPAYMENT_DATE_PAID = "periodPayment.date.paid";
	public static final String PERIODPAYMENT_PAYMENT_TYPE = "periodPayment.payment.type";
	public static final String PERIODPAYMENT_PAYMENT_AMOUNT = "periodPayment.payment.amount";
	public static final String PERIODPAYMENT_PAYMENT_SOURCE_TYPE = "periodPayment.payment.source.type";
	public static final String PERIODPAYMENT_BNPL_TARGET_AMOUNT = "periodPayment.bnpl.target.amount";
	public static final String PERIODPAYMENT_MIV_CODE = "periodPayment.miv.code";
	public static final String PERIODPAYMENT_MIV_SUB_CODE = "periodPayment.miv.sub.code";
	
	
	//PPIStatement
	public static final String PPISTATEMENT_PPI_STATEMENT = "ppi.statement";
	public static final String PPISTATEMENT_AGREEMENT_CODE = "ppiStatement.agreement.code";
	public static final String PPISTATEMENT_POLICY_NUMBER = "ppiStatement.policy.number";
	public static final String PPISTATEMENT_RENEWAL_DATE = "ppiStatement.renewal.date";
	public static final String PPISTATEMENT_TYPE_OF_COVER = "ppiStatement.type.of.cover";
	public static final String PPISTATEMENT_COST_PERCENTAGE = "ppiStatement.cost.percentage";
	public static final String PPISTATEMENT_PREVIOUS_YEAR_PPI_PREMIUM = "ppiStatement.previous.year.ppi.premium";
	public static final String PPISTATEMENT_AVERAGE_MONTHLY_CHARGE = "ppiStatement.ag.monthly.charge";
	public static final String PPISTATEMENT_CLOSING_BALANCE = "ppiStatement.closing.balance";
	public static final String PPISTATEMENT_CREDIT_LIMIT = "ppiStatement.credit.limit";
	public static final String PPISTATEMENT_OPENING_BALANCE = "ppiStatement.opening.balance";
	public static final String PPISTATEMENT_PREVIOUS_YEAR_PPI =  "ppiStatement.prev.year.ppi.balance.avg";
	public static final String PPISTATEMENT_START_DATE = "ppiStatement.start.date";
	//ServiceCharge
	public static final String SERVICECHARGE_AGREEMENT_CODE = "serviceCharge.agreement.code";
	public static final String SERVICECHARGE_SERVICE_CHARGE = "serviceCharge.service.charge";
	public static final String SERVICECHARGE_PAYMENT_METHOD_SURCHARGE = "serviceCharge.payment.method.surcharge";
	public static final String SERVICECHARGE_PAYMENT_FEE_TYPE = "serviceCharge.payment.fee.type";
	public static final String SERVICECHARGE_PAYMENT_FEE = "serviceCharge.payment.fee";
	public static final String SERVICECHARGE_DEBT_COLLECTION_FEE = "serviceCharge.debt.collection.fee";
	public static final String SERVICECHARGE_DEFAULT_SUM_IN_ARREARS_NOTICE= "serviceCharge.default.sum.in.arrears.notice";
	public static final String SERVICECHARGE_BNPL_INTEREST_CHARGE = "serviceCharge.bnpl.interest.charge";
	public static final String SERVICECHARGE_CHARGE_TYPE = "serviceCharge.charge.type";
	public static final String SERVICECHARGE_DATE = "serviceCharge.date";
	
	//TargetedPayment
	public static final String TARGETEDPAYMENT_AGREEMENT_CODE = "targetedPayment.agreement.code";
	public static final String TARGETEDPAYMENT_AMOUNT = "targetedPayment.amount";
	public static final String TARGETEDPAYMENT_DRAWDOWN_CODE = "targetedPayment.drawdown.code";
	public static final String TARGETEDPAYMENT_DATE = "targetedPayment.date"; 
	
	//AgreementTriad
	public static final String LAST_PAY_METHOD = "agreementTriad.last.pay.method";
	public static final String BALANCE = "agreementTriad.balance";
	public static final String NSF_IND = "agreementTriad.nsf.ind";
	public static final String DATE_LAST_MIV = "agreementTriad.date.last.miv";
	public static final String DATE_LAST_ORDER = "agreementTriad.date.last.order";
	public static final String DATE_LAST_PAY = "agreementTriad.date.last.pay";
	public static final String LAST_STATEMENT_DATE = "agreementTriad.last.statement.date";
	public static final String NEXT_STATEMENT_DATE = "agreementTriad.next.statemment.date";
	public static final String DATE_SECTION87 = "agreementTriad.date.section87";
	public static final String DATE_NSF = "agreementTriad.date.nsf";
	public static final String PAY_DATE_AMT_LIST = "agreementTriad.pay.date.amt.list";
	public static final String LAST_PAY_AMT = "agreementTriad.last.pay.amt";
	public static final String BNPL_BALANCE = "agreementTriad.bnpl.balance";
	public static final String APR = "agreementTriad.apr";
	public static final String TOT_PAY_30DAYS = "agreementTriad.tot.pay.30days";
	public static final String INST_ARREARS = "agreementTriad.inst.arrears";
	public static final String DATE_LAST_ARRANGEMENT = "agreementTriad.date.last.arrangement";
	public static final String PAY_AMT_TSP = "agreementTriad.pay.amt.tsp";
	public static final String DATE_LAST_ZERO_BAL = "agreementTriad.date.last.zero.bal";
	public static final String RETURNS_AMT_TSP = "agreementTriad.returns.amt.tsp";
	public static final String OTHER_ADJ_AMT_TSP = "agreementTriad.other.adj.amt.tsp";
	public static final String PAYMENT_PREVIOUS_IND = "agreementTriad.payment.previous.ind";
	public static final String PAYMENT_CURRENT_IND = "agreementTriad.payment.currentt.ind";
	public static final String NUM_PURCHASES_TSP = "agreementTriad.num.purchases.tsp";
	public static final String TOT_FEES_TSP = "agreementTriad.tot.fees.tsp";
	public static final String CUST_CREDITS_TSP = "agreementTriad.cust.credits.tsp";
	public static final String TOT_PAY_YEAR = "agreementTriad.tot.pay.year";
	public static final String NUM_PAY_TSP = "agreementTriad.num.pay.tsp";
	public static final String INT_CHARGED_TSP = "agreementTriad.int.charged.tsp";
	public static final String PURCHASE_AMT_TSP = "agreementTriad.purchase.amt.tsp";
	public static final String REBATES_AMT_TSP = "agreementTriad.rebates.amt.tsp";
	public static final String BNPL_INT_AMT_TSP = "agreementTriad.bnpl.int.amt.tsp";
	public static final String NUM_RATE_PAY_TSP = "agreementTriad.num.rate.pay.tsp";
	public static final String CUM_REMIT2_SALES = "agreementTriad.cum.remit2.sales";
	public static final String LAST_ARREARS_WKS = "agreementTriad.last.arrears.wks";
	public static final String CREDIT_LIMIT = "agreementTriad.credit.limit";
	public static final String LAST_PAYMENT_DAYS = "agreementTriad.last.payment.days";
	public static final String NIL_BALANCE_DAYS = "agreementTriad.nil.balance.days";
	
	
	public static final String FINANCIER_FILES_PATH  = "financier.files.path";
	
	public static final String PROCESSED_STATUS = "SUCCESS";
	public static final String NEW_STATUS = "New";
	public static final String AGREEMENT = "Agreement";
	public static final String DRAWDOWN = "Drawdown";
	public static final String DRAWDOWNITEM = "DrawdownItem";
	public static final String DRAWDOWNTRANSACTION = "DrawdownTransaction";
	public static final String NOSIA = "NOSIA";
	public static final String PERIODPAYMENT = "PeriodPayment";
	public static final String PPISTATEMENT = "PPI";
	public static final String SERVICECHARGE = "ServiceCharge";
	public static final String STATDELIVERY = "Statistics";
	public static final String RUNNINGACCOUNTAGREEMENT = "RUNNINGACCOUNTAGREEMENT";
	public static final String CONSOLIDATEDLOANSAGREEMENT = "CONSOLIDATEDLOANSAGREEMENT";
	public static final String TARGETEDPAYMENT = "TargetedPayment";
	public static final String ERROR_STATUS = "FAILED";
	public static final String ITEMTRANSACTIONLINK = "ItemTransactionLink";
	public static final String AGREEMENTTRIAD = "AgreementTriad";
	public static final String DRAWDOWNINCOME = "DrawdownIncome";
	public static final String BNPLALLOCATEDPAYMENT = "BnplAllocatedPayment";
	
	public static final String CUSTOMERACCOUNT_FILES_PATH  = "customerAccount.files.path";
	public static final String FIN_BATCH_COUNT = "FIN_BATCH_COUNT";
	
	//error code for financier file load
	public static final String MISMATCH_ON_RECORD_COUNT= "mismatch.on.record.count";
	public static final String MISMATCH_RECORD_COUNT_STATUS_MESSAGE="mismatch.recordcount.status.message";
	public static final String STEP_DESCRIPTION = "Load Financial Statement Data into SP Staging";
	public static final String FAIL = "FAIL";
	public static final String PROGRAMNAME = "Financier Data Load";
	public static final String STEPNUMBER = "1";
	public static final String STEPSTATUS="ERROR";
	public static final String FILENOTFOUNDERRORCODE = "2";
	public static final String FILENOTFOUNDERRORDESC = "No such file found with this batch run date.";
	public static final String MISMATCH_ON_COLUMN_COUNT="Number of column is mismatch, please reverify your file.";
	
	private CreditLoadDataConstants() {
		//Private Constructor of Constant Class
	}
}
