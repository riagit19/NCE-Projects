package com.shopdirect.nce.sp.model;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.SQLData;
import java.sql.SQLException;
import java.sql.SQLInput;
import java.sql.SQLOutput;

public class DebtManagerTriad implements SQLData {

	private String sqlType;
	private BigDecimal triadDMDetailSID;         
	private Date createdTimestamp;           
	private BigDecimal recordID;         
	private Date creationDate;           
	private BigDecimal createdBy;         
	private BigDecimal lastUpdatedBy;         
	private Date lastUpdatedDate;           
	private String errorMessage; 
	private BigDecimal batchID;         
	private String interfaceStatus;   
	private String dmClassStatus0;  
	private String dmClassStatus1;  
	private String dmClassStatus2;  
	private String dmClassStatus3;  
	private String dmClassStatus4;  
	private Date lastPhoneCheckDate;           
	private BigDecimal arrBuck1;         
	private BigDecimal arrBuck2;         
	private BigDecimal arrBuck3;         
	private BigDecimal arrBuck4;         
	private BigDecimal arrBuck5;         
	private BigDecimal arrBuck6;         
	private String retailAccountNumber;   
	private String publicAccountNumber;   
	private Date statementProducedDate;
	
	public DebtManagerTriad() {
		//Default Constructor
	}
	
	
	public DebtManagerTriad(BigDecimal triadDMDetailSID, Date createdTimestamp, BigDecimal recordID, Date creationDate,
			BigDecimal createdBy, BigDecimal lastUpdatedBy, Date lastUpdatedDate, String errorMessage,
			BigDecimal batchID, String interfaceStatus, String dmClassStatus0, String dmClassStatus1,
			String dmClassStatus2, String dmClassStatus3, String dmClassStatus4, Date lastPhoneCheckDate,
			BigDecimal arrBuck1, BigDecimal arrBuck2, BigDecimal arrBuck3, BigDecimal arrBuck4, BigDecimal arrBuck5,
			BigDecimal arrBuck6, String retailAccountNumber, String publicAccountNumber, Date statementProducedDate) {

		this.triadDMDetailSID = triadDMDetailSID;
		this.createdTimestamp = createdTimestamp;
		this.recordID = recordID;
		this.creationDate = creationDate;
		this.createdBy = createdBy;
		this.lastUpdatedBy = lastUpdatedBy;
		this.lastUpdatedDate = lastUpdatedDate;
		this.errorMessage = errorMessage;
		this.batchID = batchID;
		this.interfaceStatus = interfaceStatus;
		this.dmClassStatus0 = dmClassStatus0;
		this.dmClassStatus1 = dmClassStatus1;
		this.dmClassStatus2 = dmClassStatus2;
		this.dmClassStatus3 = dmClassStatus3;
		this.dmClassStatus4 = dmClassStatus4;
		this.lastPhoneCheckDate = lastPhoneCheckDate;
		this.arrBuck1 = arrBuck1;
		this.arrBuck2 = arrBuck2;
		this.arrBuck3 = arrBuck3;
		this.arrBuck4 = arrBuck4;
		this.arrBuck5 = arrBuck5;
		this.arrBuck6 = arrBuck6;
		this.retailAccountNumber = retailAccountNumber;
		this.publicAccountNumber = publicAccountNumber;
		this.statementProducedDate = statementProducedDate;
	}


	@Override
	public void readSQL(SQLInput stream, String typeName) throws SQLException {
		
		sqlType = typeName;
		setTriadDMDetailSID(stream.readBigDecimal());
		setCreatedTimestamp(stream.readDate());
		setRecordID(stream.readBigDecimal());
		setInterfaceStatus(stream.readString());
		setDmClassStatus0(stream.readString());
		setDmClassStatus1(stream.readString());
		setDmClassStatus2(stream.readString());
		setDmClassStatus3(stream.readString());
		setDmClassStatus4(stream.readString());
		setLastPhoneCheckDate(stream.readDate());
		setArrBuck1(stream.readBigDecimal());
		setArrBuck2(stream.readBigDecimal());
		setArrBuck3(stream.readBigDecimal());
		setArrBuck4(stream.readBigDecimal());
		setArrBuck5(stream.readBigDecimal());
		setArrBuck6(stream.readBigDecimal());
		setRetailAccountNumber(stream.readString());
		setPublicAccountNumber(stream.readString());
		setStatementProducedDate(stream.readDate());
		
	}
	
	@Override
	public void writeSQL(SQLOutput stream) throws SQLException {
		
	}

	@Override
	public String getSQLTypeName() throws SQLException {
		return sqlType;
	}

	public String getSqlType() {
		return sqlType;
	}

	public void setSqlType(String sqlType) {
		this.sqlType = sqlType;
	}

	public BigDecimal getTriadDMDetailSID() {
		return triadDMDetailSID;
	}
	public void setTriadDMDetailSID(BigDecimal triadDMDetailSID) {
		this.triadDMDetailSID = triadDMDetailSID;
	}
	public Date getCreatedTimestamp() {
		return createdTimestamp;
	}
	public void setCreatedTimestamp(Date createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}
	public BigDecimal getRecordID() {
		return recordID;
	}
	public void setRecordID(BigDecimal recordID) {
		this.recordID = recordID;
	}
	public Date getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}
	public BigDecimal getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(BigDecimal createdBy) {
		this.createdBy = createdBy;
	}
	public BigDecimal getLastUpdatedBy() {
		return lastUpdatedBy;
	}
	public void setLastUpdatedBy(BigDecimal lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}
	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}
	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public BigDecimal getBatchID() {
		return batchID;
	}
	public void setBatchID(BigDecimal batchID) {
		this.batchID = batchID;
	}
	public String getInterfaceStatus() {
		return interfaceStatus;
	}
	public void setInterfaceStatus(String interfaceStatus) {
		this.interfaceStatus = interfaceStatus;
	}
	public String getDmClassStatus0() {
		return dmClassStatus0;
	}
	public void setDmClassStatus0(String dmClassStatus0) {
		this.dmClassStatus0 = dmClassStatus0;
	}
	public String getDmClassStatus1() {
		return dmClassStatus1;
	}
	public void setDmClassStatus1(String dmClassStatus1) {
		this.dmClassStatus1 = dmClassStatus1;
	}
	public String getDmClassStatus2() {
		return dmClassStatus2;
	}
	public void setDmClassStatus2(String dmClassStatus2) {
		this.dmClassStatus2 = dmClassStatus2;
	}
	public String getDmClassStatus3() {
		return dmClassStatus3;
	}
	public void setDmClassStatus3(String dmClassStatus3) {
		this.dmClassStatus3 = dmClassStatus3;
	}
	public String getDmClassStatus4() {
		return dmClassStatus4;
	}
	public void setDmClassStatus4(String dmClassStatus4) {
		this.dmClassStatus4 = dmClassStatus4;
	}
	public Date getLastPhoneCheckDate() {
		return lastPhoneCheckDate;
	}
	public void setLastPhoneCheckDate(Date lastPhoneCheckDate) {
		this.lastPhoneCheckDate = lastPhoneCheckDate;
	}
	public BigDecimal getArrBuck1() {
		return arrBuck1;
	}
	public void setArrBuck1(BigDecimal arrBuck1) {
		this.arrBuck1 = arrBuck1;
	}
	public BigDecimal getArrBuck2() {
		return arrBuck2;
	}
	public void setArrBuck2(BigDecimal arrBuck2) {
		this.arrBuck2 = arrBuck2;
	}
	public BigDecimal getArrBuck3() {
		return arrBuck3;
	}
	public void setArrBuck3(BigDecimal arrBuck3) {
		this.arrBuck3 = arrBuck3;
	}
	public BigDecimal getArrBuck4() {
		return arrBuck4;
	}
	public void setArrBuck4(BigDecimal arrBuck4) {
		this.arrBuck4 = arrBuck4;
	}
	public BigDecimal getArrBuck5() {
		return arrBuck5;
	}
	public void setArrBuck5(BigDecimal arrBuck5) {
		this.arrBuck5 = arrBuck5;
	}
	public BigDecimal getArrBuck6() {
		return arrBuck6;
	}
	public void setArrBuck6(BigDecimal arrBuck6) {
		this.arrBuck6 = arrBuck6;
	}
	public String getRetailAccountNumber() {
		return retailAccountNumber;
	}
	public void setRetailAccountNumber(String retailAccountNumber) {
		this.retailAccountNumber = retailAccountNumber;
	}
	public String getPublicAccountNumber() {
		return publicAccountNumber;
	}
	public void setPublicAccountNumber(String publicAccountNumber) {
		this.publicAccountNumber = publicAccountNumber;
	}
	public Date getStatementProducedDate() {
		return statementProducedDate;
	}
	public void setStatementProducedDate(Date statementProducedDate) {
		this.statementProducedDate = statementProducedDate;
	}
}
