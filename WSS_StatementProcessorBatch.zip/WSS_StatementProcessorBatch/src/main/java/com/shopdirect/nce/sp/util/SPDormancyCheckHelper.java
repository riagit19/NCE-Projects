package com.shopdirect.nce.sp.util;

import java.sql.SQLException;
import java.util.Date;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.dao.AccountDormancyCheckDao;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;

/**
 * @author AyantikaBiswas
 *
 */
public class SPDormancyCheckHelper {
	
   private SDLoggerImpl logger = new SDLoggerImpl();

   private AccountDormancyCheckDao dormancyCheckDao = null;	
	
	
	public SPDormancyCheckHelper() throws StatementProcessorBatchException , SQLException {
		dormancyCheckDao = new AccountDormancyCheckDao();
	}
	
	public String checkCreditStatus(String custAccountId) throws StatementProcessorBatchException {
		return dormancyCheckDao.getCreditStatus(custAccountId);
			
	}
	public int calculateTime(Date firstDate , Date lastDate) {
		return (int) ((firstDate.getTime() - lastDate.getTime())/(1000*60*60*24));	
	}

	public Date checkLastTransactionDt(String contractNumber , Date statementDate) throws StatementProcessorBatchException {
		return dormancyCheckDao.getLastTransDt(contractNumber, getDate(statementDate));
	}

	public double checkAccountBalance(String creditAccountNo) throws StatementProcessorBatchException {
		return dormancyCheckDao.getAccountBalance(creditAccountNo);
	}

	public Integer updateStatus(String custAccountInfoId,String creditAccountNo, int statusCode) throws StatementProcessorBatchException {
			return dormancyCheckDao.updateAccountStatus(custAccountInfoId,creditAccountNo,statusCode) ;
	}
	public Date checkAccntOpened(String custAccountInfoId) throws StatementProcessorBatchException{
		return dormancyCheckDao.getAccountOpenedDate(custAccountInfoId);
	}
	public Date getLastOrderDate(String publicAccountNo,Date accountCreationDate) throws StatementProcessorBatchException {
		return dormancyCheckDao.getLastOrderDate(publicAccountNo, getDate(accountCreationDate));
	}
	/*
	 * This is utility method for getting current Date
	 */
	private static java.sql.Date getDate(java.util.Date inputDate) {
		return new java.sql.Date(inputDate.getTime());
	}


	/**
	 * @return the logger
	 */
	public SDLoggerImpl getLogger() {
		return logger;
	}

	public AccountDormancyCheckDao getDormancyCheckDao() {
		return dormancyCheckDao;
	}

	public void setDormancyCheckDao(AccountDormancyCheckDao dormancyCheckDao) {
		this.dormancyCheckDao = dormancyCheckDao;
	}		

}
