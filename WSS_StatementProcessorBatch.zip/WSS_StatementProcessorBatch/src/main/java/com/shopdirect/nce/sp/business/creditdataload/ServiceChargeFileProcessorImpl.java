/**
 * 
 */
package com.shopdirect.nce.sp.business.creditdataload;

import java.io.File;
import java.io.FileReader;
import java.io.LineNumberReader;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.shopdirect.nce.sp.constants.CreditLoadDataConstants;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.dao.creditdataload.ServiceChargeDaoImpl;
import com.shopdirect.nce.sp.dao.creditdataload.SpCreditFilLoadControlDaoImpl;
import com.shopdirect.nce.sp.exception.BuisnessException;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.ServiceCharge;
import com.shopdirect.nce.sp.util.FinFileBaseProcessor;
import com.shopdirect.nce.sp.util.StatementProcessorBatchUtil;

/**
 * @author AyantikaBiswas
 *
 */
public class ServiceChargeFileProcessorImpl extends FinFileBaseProcessor implements DataFileProcessor {
	

	private ServiceChargeDaoImpl scDaoImpl;
	
	public ServiceChargeFileProcessorImpl() throws StatementProcessorBatchException {
		super();
	}

	/**
	 * @param folder
	 * @throws StatementProcessorBatchException
	 */
	public boolean processFile(File folder, long batchID, int user, String batchRunDate) throws StatementProcessorBatchException {
		
		getLogger().debug("[ServiceChargeFileProcessorImpl -- processFile]  -- START");
		String fileName = StatementProcessorBatchUtil.generateFileName(CreditLoadDataConstants.SERVICECHARGE,
				CreditLoadDataConstants.NEW_STATUS, batchRunDate);
		File file = getFile(folder, fileName);
		String line = "";
		String comma = ",";	
		List<Map<String, Object>> columns = getColumns(StatementProcessorBatchConstants.SERVICE_CHARGE_DATA_MAPPING,
				StatementProcessorBatchConstants.SERVICE_CHARGE_MAP);
		String fileIdentifier = getCommonConfigHelper().readConfigData(getDataconfig(), "SERVICECHARGE");
		String insertedMessage = null;
		String errorMessage = StatementProcessorBatchConstants.EMPTY_STRING;
		int insertCount;
		List<ServiceCharge> serviceChargeRecords = null;
		boolean insertedServiceCharge = false;
		SpCreditFilLoadControlDaoImpl spCreditFilLoadControlDaoImpl = new SpCreditFilLoadControlDaoImpl();
		
		Object[] procReturnVal = new Object[2];
		int retCode = 0;
		String retMsg = null;
	

		try (LineNumberReader reader = new LineNumberReader(new FileReader(file))) {
			int records = getRecordsCount(this.getFinancierFilePath() + file.getName());
			/**
			 * Insert data in Control Table and pass the Batch Id
			 */
			insertSpLoadControlData(batchID, file.getName(), fileIdentifier, user);
			String header = reader.readLine();
			if(records == 1){
				insertedServiceCharge = true ;
			}
			else{
				while ((reader.getLineNumber()) < records) {
					serviceChargeRecords = new ArrayList<>();
					for (insertCount = 0; insertCount<getBatchInsertcount() ;insertCount++ ){					
						if ((line = reader.readLine())!= null){	
							String[] contents = line.split(comma, -1);
							//Check number of data in xml and .dat file is same or not
							if (columns.size() != contents.length) {
								throw new Exception(CreditLoadDataConstants.MISMATCH_ON_COLUMN_COUNT);
							}
							ServiceCharge serviceCharge = new ServiceCharge();
							// Set batchId in ServiceCharge
							serviceCharge.setBatchId(batchID);
							serviceCharge.setCreatedByUser(Long.valueOf(user));
							serviceChargeRecords.add(serviceCharge);
							constructObjects(contents, columns, serviceCharge);
						} else{
							break;
						}
					}
					procReturnVal = getScDaoImpl().insertServiceChargeData(serviceChargeRecords);
					retCode = (int) procReturnVal[0];
					retMsg = (String) procReturnVal[1];
					
					// update the CONTROL table and DELETE if INSERTION fails
					if (retCode == 0) {
						insertedServiceCharge = true;
					} else {
						insertedServiceCharge = false;
						errorMessage = retMsg;
					}				
				}
			}

			/**
			 * Update the CONTROL table with batch id and error messege
			 */
			spCreditFilLoadControlDaoImpl.updateControlData(batchID, insertedServiceCharge, errorMessage, fileIdentifier);

		} catch (Exception exception) {
			insertedMessage = exception.getMessage();
			errorMessage = insertedMessage;
			insertedServiceCharge = false;
			/**
			 * Update the CONTROL table with batch id and error messege
			 */
			try {
				spCreditFilLoadControlDaoImpl.updateControlData(batchID, insertedServiceCharge, errorMessage, fileIdentifier);
			} catch (BuisnessException | SQLException ex) {
				getLogger()
						.debug("[ServiceChargeFileProcessorImpl -- processFile] -- Control Table Update Exception: "
								+ ex);
			} catch (Exception exception2) {
				getLogger()
						.debug("[ServiceChargeFileProcessorImpl -- processFile] -- Control Table Update Exception: "
								+ exception2);
			}

			getLogger()
					.error("[ServiceChargeFileProcessorImpl -- processFile] -- Service Charge Insert Error occured");
			getLogger().debug("[ServiceChargeFileProcessorImpl -- processFile] -- Service Charge Exception: "
					+ exception);
			
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_BUSINESS_ERROR_CODE,
					"[ServiceChargeFileProcessorImpl-processFile] StatementProcessorBatchException Block",
					"Service Charge Exception " + errorMessage, null, null,
					new StatementProcessorBatchException());
		}
		getLogger().debug("[ServiceChargeFileProcessorImpl -- processFile]  -- END");
		return insertedServiceCharge;
	}


	/**
	 * @return the scDaoImpl
	 * @throws StatementProcessorBatchException 
	 */
	public ServiceChargeDaoImpl getScDaoImpl() throws StatementProcessorBatchException {
		if(scDaoImpl == null) {
			scDaoImpl = new ServiceChargeDaoImpl();
		}
		return scDaoImpl;
	}

	/**
	 * @param scDaoImpl the scDaoImpl to set
	 */
	public void setScDaoImpl(ServiceChargeDaoImpl scDaoImpl) {
		this.scDaoImpl = scDaoImpl;
	}
	
}
