package com.shopdirect.nce.sp.externalclient;

import java.util.List;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.jms.QueueSend;
import com.shopdirect.nce.sp.model.CustomerAccountInfo;
import com.shopdirect.nce.sp.parser.StatementProcessorParser;

/**
 * @author GouravChakraborty
 * Sends XML Data over Queue
 */
public class CustomerARProcessMsgSend {
	private static SDLoggerImpl logger = new SDLoggerImpl();
	
	private CustomerARProcessMsgSend() {
		
	}
	
	/**
	 * Called from business layer for putting data over queue
	 * @param customerAccountInfoList
	 */
	public static void customerMsgPut(List<CustomerAccountInfo> customerAccountInfoList) throws StatementProcessorBatchException {		
		logger.debug("[CustomerARProcessMsgSend -- customerMsgPut] -- Start"); 
		QueueSend queueSend=new QueueSend();
		String message=null;
		try{
			for(CustomerAccountInfo customerAccountInfo : customerAccountInfoList){
				message=StatementProcessorParser.daoToXml(customerAccountInfo);
				if(message!=null){
					queueSend.sendAsyncMessage(message,customerAccountInfo.getCustomerId(),customerAccountInfo.getStatementDate(), "REQ_QUEUE");
				}	
			}
		}catch(Exception e){
			logger.debug("[CustomerARProcessMsgSend -- customerMsgPut] -- Exception: " + e.getMessage());
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_BUSINESS_ERROR_CODE,"[CustomerARProcessMsgSend-customerMsgPut]","Problem in sending message in queue",null, null, e);
		
		}
		logger.debug("[CustomerARProcessMsgSend -- customerMsgPut] -- End"); 
	}	
}
