/**
 * 
 */
package com.shopdirect.nce.sp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.Query;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.CustomerAccountInfo;
import com.shopdirect.nce.sp.util.UCPConnection;

/**
 * 
 * @author SudiptaRoy
 *
 */
public class AccountReassementProcessDao extends AccountReassessmentBaseDao {
	
	private static final SDLoggerImpl logger = new SDLoggerImpl();
	
	public AccountReassementProcessDao() throws StatementProcessorBatchException{
		super();
		setStgSchema(getSchema(StatementProcessorBatchConstants.DB_SCHEMA_STG_KEY));
		setSpMainSchema(getSchema(StatementProcessorBatchConstants.DB_SCHEMA_MAIN_SP_KEY));
	}

	
	public List<CustomerAccountInfo> getCustomerDetails(String custID, String inputStmtDate)
			throws StatementProcessorBatchException {
		logger.debug("[AccountReassementProcessDao -- getCustomerDetails] -- Start");
		Connection con = null;
		ResultSet accountInfoResultset = null;
		List<CustomerAccountInfo> customerAccountInfoList = new ArrayList<>();
		try {
			con = UCPConnection.getConnection();
			String queryStr = Query.getCustrAccountDetailsJMSMsgQuery(getSpMainSchema()).toString();
			logger.debug("[AccountReassementProcessDao -- getCustomerDetails] -- Query: " + queryStr);

			try (PreparedStatement stmt = con.prepareStatement(queryStr)) {
				stmt.setString(1, inputStmtDate);
				stmt.setString(2, custID);
				accountInfoResultset = stmt.executeQuery();

				while (accountInfoResultset.next()) {
					CustomerAccountInfo custAccountInfo = new CustomerAccountInfo();

					custAccountInfo.setAccountInfoId(accountInfoResultset.getString("CIM_ACCOUNT_INFO_ID"));
					custAccountInfo.setPublicAccountId(accountInfoResultset.getString("PUBLIC_ACCOUNT_NUMBER"));
					custAccountInfo.setCreditAccountId(accountInfoResultset.getString("CREDIT_ACCOUNT_NUMBER"));
					custAccountInfo.setRetailAccountId(accountInfoResultset.getString("RETAIL_ACCOUNT_NUMBER"));
					custAccountInfo.setLinkedAccntIndex(accountInfoResultset.getInt("LINKED_ACCOUNT_IND"));
					custAccountInfo.setStatementDate(accountInfoResultset.getDate("STATEMENT_DATE"));
					custAccountInfo.setCreditStatus(accountInfoResultset.getString("CREDIT_STATUS"));
					custAccountInfo.setAccountStatus(accountInfoResultset.getString("ACCOUNT_STATUS"));
					custAccountInfo.setBrandCode(accountInfoResultset.getString("BRAND_CODE"));
					custAccountInfo.setCreditStartDate(accountInfoResultset.getDate("CREDIT_START_DATE"));
					custAccountInfo.setCustomerId(custID);
					customerAccountInfoList.add(custAccountInfo);
				}
			}

		} catch (Exception e) {
			logger.error("[AccountReassementProcessDao -- getCustomerDetails] -- Exception: " + e.getMessage());
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_BUSINESS_ERROR_CODE,
					"[StartAccountReassessmentBusinessImpl-startAR] Exception Block",
					"Business exception generated at time to process the data collection " + e.getMessage(), null, null,
					e);
		} finally {
			 try {
				   if(accountInfoResultset != null){
					   accountInfoResultset.close();
				   }
					if (con != null) {
						con.close();
					}
				} catch (Exception e) {
					getLogger().error("[AccountReassementProcessDao - getCustomerDetails] Finally: Failed to close DB objects. " + e);
				}
		}
		logger.debug("[AccountReassementProcessDao -- getCustomerDetails] -- End");
		return customerAccountInfoList;
	}
}
