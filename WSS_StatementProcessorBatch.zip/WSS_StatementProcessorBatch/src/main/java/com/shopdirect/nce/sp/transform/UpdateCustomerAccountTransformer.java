package com.shopdirect.nce.sp.transform;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.model.CustomerAccountInfo;
import com.shopdirect.osb.xsd.updatecustomeraccount.AccountArrearsGroupType;
import com.shopdirect.osb.xsd.updatecustomeraccount.AccountStatusGroupType;
import com.shopdirect.osb.xsd.updatecustomeraccount.UpdateCustomerAccountReqType;
import com.shopdirect.osb.xsd.updatecustomeraccount.UpdateCustomerAccountRequestType;

public class UpdateCustomerAccountTransformer {

	private static final SDLoggerImpl LOGGER = new SDLoggerImpl();

	public UpdateCustomerAccountRequestType transformRequest(CustomerAccountInfo customerAccountInfo,
			String updateStatus, String arrearsStatus) {
		LOGGER.debug("[UpdateCustomerAccountTransformer -- transformRequest] -- Start");

		UpdateCustomerAccountRequestType updateCustomerAccountRequestType = new UpdateCustomerAccountRequestType();
		UpdateCustomerAccountReqType updateCustomerAccountReqType = new UpdateCustomerAccountReqType();
		updateCustomerAccountRequestType.setUpdateCustomerAccountReq(updateCustomerAccountReqType);

		updateCustomerAccountReqType.setPublicAccountNumber(customerAccountInfo.getPublicAccountId());
		updateCustomerAccountReqType.setAgreementReference(customerAccountInfo.getCreditAccountId());

		AccountStatusGroupType accountStatusGroupType = new AccountStatusGroupType();
		updateCustomerAccountReqType.setAccountStatusGroup(accountStatusGroupType);

		accountStatusGroupType.setOldAccountStatus(customerAccountInfo.getAccountStatus());
		accountStatusGroupType.setNewAccountStatus(updateStatus);

		AccountArrearsGroupType accountArrearsGroupType = new AccountArrearsGroupType();
		updateCustomerAccountReqType.setAccountArrearsGroup(accountArrearsGroupType);

		accountArrearsGroupType.setArrearsStatus(arrearsStatus);

		String status = null;
		if (updateStatus.equals(StatementProcessorBatchConstants.STATUS_CODE_SEVENTY)
				|| updateStatus.equals(StatementProcessorBatchConstants.STATUS_CODE_SEVENTYONE)
				|| updateStatus.equals(StatementProcessorBatchConstants.STATUS_CODE_SEVENTYTWO)
				|| updateStatus.equals(StatementProcessorBatchConstants.STATUS_CODE_SEVENTYTHREE)) {
			status = StatementProcessorBatchConstants.DORM;
		}
		updateCustomerAccountReqType.setStatusChange(status);

		LOGGER.debug("[UpdateCustomerAccountTransformer -- transformRequest] -- End");

		return updateCustomerAccountRequestType;

	}

}
