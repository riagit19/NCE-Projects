package com.shopdirect.nce.sp.model;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.SQLData;
import java.sql.SQLException;
import java.sql.SQLInput;
import java.sql.SQLOutput;

public class RetailContractTriad implements SQLData {

	private String sqlType;
	private BigDecimal triadCAMDetailSID;
	private Date createdTimestamp;
	private BigDecimal recordID;
	private Date creationDate;
	private BigDecimal createdBy;
	private BigDecimal lastUpdatedBy;
	private Date lastUpdatedDate;
	private String errorMessage;
	private BigDecimal batchID;
	private String interfaceStatus;
	private BigDecimal creditRejectsVal;
	private String currentBUReferenceColl;
	private Date lastDelinquentDate;
	private Date lastOrderDate;
	private BigDecimal ppiInd;
	private BigDecimal numCreditPayments;
	private BigDecimal numRetailPayments;
	private BigDecimal annotationPeriodInd;
	private BigDecimal riskNavScore;
	private Date riskOIScoreUpdatedDate;
	private BigDecimal overIndebtScore;
	private Date rnOIScoreUpdatedDate;
	private String annualSalary;
	private String householdIncome;
	private BigDecimal noOfDependants;
	private String employmentStatus;
	private String residentStatus;
	private String sixCode;
	private String twelveCode;
	private Date dateOfRequest;
	private String previousSalary;
	private String previousIncome;
	private BigDecimal derivedIncome;
	private BigDecimal optOutCreditLimitIncInd;
	private String fidScore;
	private BigDecimal ordersDeclined3Mths;
	private Date fidScoreDate;
	private String fidScoreWorst;
	private BigDecimal creditPaymentsTotal;
	private String currentBUReference;
	private BigDecimal numPpi;
	private BigDecimal qcbAddChar1;
	private BigDecimal qcbAddChar2;
	private BigDecimal qcbAddChar3;
	private BigDecimal qcbAddChar4;
	private BigDecimal qcbAddChar5;
	private String qcbBSC410;
	private String qcbBSC413;
	private String qcbBSC435;
	private String qcbBSC437;
	private String qcbBSC438;
	private String qcbDSC435;
	private String qcbDSC437;
	private String qcbDSC438;
	private String qcbLSC250;
	private String qcbLSC556;
	private String qcbLSC557;
	private String qcbLSC887;
	private String qcbLSC888;
	private String qcbLSC547;
	private String qcbFSC402;
	private String qcbLSC320;
	private String qcbCSC4;
	private String qcbLSC251;
	private String qcbLSC173;
	private String qcbFSC308;
	private String qcbLSC157;
	private String qcbSSC4;
	private String qcbSSC2;
	private String qcbXPCF09;
	private String qcbDSC410;
	private String qcbDSC413;
	private String qcbFSC104;
	private String qcbFSC111;
	private String currency;
	private BigDecimal lastPaymentAmt;
	private BigDecimal pendingRefAmt;
	private BigDecimal fpwoAmt;
	private BigDecimal cashPayTot;
	private Date rnsUpdDate;
	private BigDecimal gaugeScore;
	private BigDecimal recruitmentSource;
	private BigDecimal prevAnnSal;
	private BigDecimal prevHouseInc;
	private BigDecimal bnplTermMax;
	private BigDecimal transactionType;
	private String retailAccountNumber;
	private Date statementProducedDate;
	private Date dateLastMIV;
	private Date dateLastPay;
	private BigDecimal nsfInd;
	private Date dateNSF;
	private BigDecimal payPointPOAmt;
	private BigDecimal dvAdminAmt;
	
	
	public RetailContractTriad() {
		//Default Constructor
	}
	
	

	public RetailContractTriad(BigDecimal triadCAMDetailSID, Date createdTimestamp, BigDecimal recordID,
			Date creationDate, BigDecimal createdBy, BigDecimal lastUpdatedBy, Date lastUpdatedDate,
			String errorMessage, BigDecimal batchID, String interfaceStatus, BigDecimal creditRejectsVal,
			String currentBUReferenceColl, Date lastDelinquentDate, Date lastOrderDate, BigDecimal ppiInd,
			BigDecimal numCreditPayments, BigDecimal numRetailPayments, BigDecimal annotationPeriodInd,
			BigDecimal riskNavScore, Date riskOIScoreUpdatedDate, BigDecimal overIndebtScore, Date rnOIScoreUpdatedDate,
			String annualSalary, String householdIncome, BigDecimal noOfDependants, String employmentStatus,
			String residentStatus, String sixCode, String twelveCode, Date dateOfRequest, String previousSalary,
			String previousIncome, BigDecimal derivedIncome, BigDecimal optOutCreditLimitIncInd, String fidScore,
			BigDecimal ordersDeclined3Mths, Date fidScoreDate, String fidScoreWorst, BigDecimal creditPaymentsTotal,
			String currentBUReference, BigDecimal numPpi, BigDecimal qcbAddChar1, BigDecimal qcbAddChar2,
			BigDecimal qcbAddChar3, BigDecimal qcbAddChar4, BigDecimal qcbAddChar5, String qcbBSC410, String qcbBSC413,
			String qcbBSC435, String qcbBSC437, String qcbBSC438, String qcbDSC435, String qcbDSC437, String qcbDSC438,
			String qcbLSC250, String qcbLSC556, String qcbLSC557, String qcbLSC887, String qcbLSC888, String qcbLSC547,
			String qcbFSC402, String qcbLSC320, String qcbCSC4, String qcbLSC251, String qcbLSC173, String qcbFSC308,
			String qcbLSC157, String qcbSSC4, String qcbSSC2, String qcbXPCF09, String qcbDSC410, String qcbDSC413,
			String qcbFSC104, String qcbFSC111, String currency, BigDecimal lastPaymentAmt, BigDecimal pendingRefAmt,
			BigDecimal fpwoAmt, BigDecimal cashPayTot, Date rnsUpdDate, BigDecimal gaugeScore,
			BigDecimal recruitmentSource, BigDecimal prevAnnSal, BigDecimal prevHouseInc, BigDecimal bnplTermMax,
			BigDecimal transactionType, String retailAccountNumber, Date statementProducedDate, Date dateLastMIV, Date dateLastPay,
			BigDecimal nsfInd, Date dateNSF, BigDecimal payPointPOAmt, BigDecimal dvAdminAmt) {
		super();
		this.triadCAMDetailSID = triadCAMDetailSID;
		this.createdTimestamp = createdTimestamp;
		this.recordID = recordID;
		this.creationDate = creationDate;
		this.createdBy = createdBy;
		this.lastUpdatedBy = lastUpdatedBy;
		this.lastUpdatedDate = lastUpdatedDate;
		this.errorMessage = errorMessage;
		this.batchID = batchID;
		this.interfaceStatus = interfaceStatus;
		this.creditRejectsVal = creditRejectsVal;
		this.currentBUReferenceColl = currentBUReferenceColl;
		this.lastDelinquentDate = lastDelinquentDate;
		this.lastOrderDate = lastOrderDate;
		this.ppiInd = ppiInd;
		this.numCreditPayments = numCreditPayments;
		this.numRetailPayments = numRetailPayments;
		this.annotationPeriodInd = annotationPeriodInd;
		this.riskNavScore = riskNavScore;
		this.riskOIScoreUpdatedDate = riskOIScoreUpdatedDate;
		this.overIndebtScore = overIndebtScore;
		this.rnOIScoreUpdatedDate = rnOIScoreUpdatedDate;
		this.annualSalary = annualSalary;
		this.householdIncome = householdIncome;
		this.noOfDependants = noOfDependants;
		this.employmentStatus = employmentStatus;
		this.residentStatus = residentStatus;
		this.sixCode = sixCode;
		this.twelveCode = twelveCode;
		this.dateOfRequest = dateOfRequest;
		this.previousSalary = previousSalary;
		this.previousIncome = previousIncome;
		this.derivedIncome = derivedIncome;
		this.optOutCreditLimitIncInd = optOutCreditLimitIncInd;
		this.fidScore = fidScore;
		this.ordersDeclined3Mths = ordersDeclined3Mths;
		this.fidScoreDate = fidScoreDate;
		this.fidScoreWorst = fidScoreWorst;
		this.creditPaymentsTotal = creditPaymentsTotal;
		this.currentBUReference = currentBUReference;
		this.numPpi = numPpi;
		this.qcbAddChar1 = qcbAddChar1;
		this.qcbAddChar2 = qcbAddChar2;
		this.qcbAddChar3 = qcbAddChar3;
		this.qcbAddChar4 = qcbAddChar4;
		this.qcbAddChar5 = qcbAddChar5;
		this.qcbBSC410 = qcbBSC410;
		this.qcbBSC413 = qcbBSC413;
		this.qcbBSC435 = qcbBSC435;
		this.qcbBSC437 = qcbBSC437;
		this.qcbBSC438 = qcbBSC438;
		this.qcbDSC435 = qcbDSC435;
		this.qcbDSC437 = qcbDSC437;
		this.qcbDSC438 = qcbDSC438;
		this.qcbLSC250 = qcbLSC250;
		this.qcbLSC556 = qcbLSC556;
		this.qcbLSC557 = qcbLSC557;
		this.qcbLSC887 = qcbLSC887;
		this.qcbLSC888 = qcbLSC888;
		this.qcbLSC547 = qcbLSC547;
		this.qcbFSC402 = qcbFSC402;
		this.qcbLSC320 = qcbLSC320;
		this.qcbCSC4 = qcbCSC4;
		this.qcbLSC251 = qcbLSC251;
		this.qcbLSC173 = qcbLSC173;
		this.qcbFSC308 = qcbFSC308;
		this.qcbLSC157 = qcbLSC157;
		this.qcbSSC4 = qcbSSC4;
		this.qcbSSC2 = qcbSSC2;
		this.qcbXPCF09 = qcbXPCF09;
		this.qcbDSC410 = qcbDSC410;
		this.qcbDSC413 = qcbDSC413;
		this.qcbFSC104 = qcbFSC104;
		this.qcbFSC111 = qcbFSC111;
		this.currency = currency;
		this.lastPaymentAmt = lastPaymentAmt;
		this.pendingRefAmt = pendingRefAmt;
		this.fpwoAmt = fpwoAmt;
		this.cashPayTot = cashPayTot;
		this.rnsUpdDate = rnsUpdDate;
		this.gaugeScore = gaugeScore;
		this.recruitmentSource = recruitmentSource;
		this.prevAnnSal = prevAnnSal;
		this.prevHouseInc = prevHouseInc;
		this.bnplTermMax = bnplTermMax;
		this.transactionType = transactionType;
		this.retailAccountNumber = retailAccountNumber;
		this.statementProducedDate = statementProducedDate;
		this.dateLastMIV = dateLastMIV;
		this.dateLastPay = dateLastPay;
		this.nsfInd = nsfInd;
		this.dateNSF = dateNSF;
		this.payPointPOAmt = payPointPOAmt;
		this.dvAdminAmt = dvAdminAmt;
	}



	@Override
	public void readSQL(SQLInput stream, String typeName) throws SQLException {
		
		sqlType = typeName;
		setTriadCAMDetailSID(stream.readBigDecimal());
		setCreditRejectsVal(stream.readBigDecimal());
		setCurrentBUReferenceColl(stream.readString());
		setLastDelinquentDate(stream.readDate());
		setLastOrderDate(stream.readDate());
		setPpiInd(stream.readBigDecimal());
		setNumCreditPayments(stream.readBigDecimal());
		setNumRetailPayments(stream.readBigDecimal());
		setAnnotationPeriodInd(stream.readBigDecimal());
		setRiskNavScore(stream.readBigDecimal());
		setRiskOIScoreUpdatedDate(stream.readDate());
		setOverIndebtScore(stream.readBigDecimal());
		setRnOIScoreUpdatedDate(stream.readDate());
		setAnnualSalary(stream.readString());
		setHouseholdIncome(stream.readString());
		setNoOfDependants(stream.readBigDecimal());
		setEmploymentStatus(stream.readString());
		setResidentStatus(stream.readString());
		setSixCode(stream.readString());
		setTwelveCode(stream.readString());
		setDateOfRequest(stream.readDate());
		setPreviousSalary(stream.readString());
		setPreviousIncome(stream.readString());
		setDerivedIncome(stream.readBigDecimal());
		setOptOutCreditLimitIncInd(stream.readBigDecimal());
		setFidScore(stream.readString());
		setOrdersDeclined3Mths(stream.readBigDecimal());
		setFidScoreDate(stream.readDate());
		setFidScoreWorst(stream.readString());
		setCreditPaymentsTotal(stream.readBigDecimal());
		setCurrentBUReference(stream.readString());
		setNumPpi(stream.readBigDecimal());
		setQcbAddChar1(stream.readBigDecimal());
		setQcbAddChar2(stream.readBigDecimal());
		setQcbAddChar3(stream.readBigDecimal());
		setQcbAddChar4(stream.readBigDecimal());
		setQcbAddChar5(stream.readBigDecimal());
		setQcbBSC410(stream.readString());
		setQcbBSC413(stream.readString());
		setQcbBSC435(stream.readString());
		setQcbBSC437(stream.readString());
		setQcbBSC438(stream.readString());
		setQcbDSC435(stream.readString());
		setQcbDSC437(stream.readString());
		setQcbDSC438(stream.readString());
		setQcbLSC250(stream.readString());
		setQcbLSC556(stream.readString());
		setQcbLSC557(stream.readString());
		setQcbLSC887(stream.readString());
		setQcbLSC888(stream.readString());
		setQcbLSC547(stream.readString());
		setQcbFSC402(stream.readString());
		setQcbLSC320(stream.readString());
		setQcbCSC4(stream.readString());
		setQcbLSC251(stream.readString());
		setQcbLSC173(stream.readString());
		setQcbFSC308(stream.readString());
		setQcbLSC157(stream.readString());
		setQcbSSC4(stream.readString());
		setQcbSSC2(stream.readString());
		setQcbXPCF09(stream.readString());
		setQcbDSC410(stream.readString());
		setQcbDSC413(stream.readString());
		setQcbFSC104(stream.readString());
		setQcbFSC111(stream.readString());
		setCurrency(stream.readString());
		setLastPaymentAmt(stream.readBigDecimal());
		setPendingRefAmt(stream.readBigDecimal());
		setFpwoAmt(stream.readBigDecimal());
		setCashPayTot(stream.readBigDecimal());
		setRnsUpdDate(stream.readDate());
		setGaugeScore(stream.readBigDecimal());
		setRecruitmentSource(stream.readBigDecimal());
		setPrevAnnSal(stream.readBigDecimal());
		setPrevHouseInc(stream.readBigDecimal());
		setBnplTermMax(stream.readBigDecimal());
		setTransactionType(stream.readBigDecimal());
		setRetailAccountNumber(stream.readString());
		setStatementProducedDate(stream.readDate());
		setDateLastMIV(stream.readDate());
		setDateLastPay(stream.readDate());
		setNsfInd(stream.readBigDecimal());
		setDateNSF(stream.readDate());
		setPayPointPOAmt(stream.readBigDecimal());
		setDvAdminAmt(stream.readBigDecimal());
	}
	
	@Override
	public void writeSQL(SQLOutput stream) throws SQLException {
		
	}

	@Override
	public String getSQLTypeName() throws SQLException {
		return sqlType;
	}

	public String getSqlType() {
		return sqlType;
	}

	public void setSqlType(String sqlType) {
		this.sqlType = sqlType;
	}
	
	public BigDecimal getTriadCAMDetailSID() {
		return triadCAMDetailSID;
	}
	public void setTriadCAMDetailSID(BigDecimal triadCAMDetailSID) {
		this.triadCAMDetailSID = triadCAMDetailSID;
	}
	public Date getCreatedTimestamp() {
		return createdTimestamp;
	}
	public void setCreatedTimestamp(Date createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}
	public BigDecimal getRecordID() {
		return recordID;
	}
	public void setRecordID(BigDecimal recordID) {
		this.recordID = recordID;
	}
	public Date getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}
	public BigDecimal getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(BigDecimal createdBy) {
		this.createdBy = createdBy;
	}
	public BigDecimal getLastUpdatedBy() {
		return lastUpdatedBy;
	}
	public void setLastUpdatedBy(BigDecimal lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}
	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}
	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public BigDecimal getBatchID() {
		return batchID;
	}
	public void setBatchID(BigDecimal batchID) {
		this.batchID = batchID;
	}
	public String getInterfaceStatus() {
		return interfaceStatus;
	}
	public void setInterfaceStatus(String interfaceStatus) {
		this.interfaceStatus = interfaceStatus;
	}
	public BigDecimal getCreditRejectsVal() {
		return creditRejectsVal;
	}



	public void setCreditRejectsVal(BigDecimal creditRejectsVal) {
		this.creditRejectsVal = creditRejectsVal;
	}



	public String getCurrentBUReferenceColl() {
		return currentBUReferenceColl;
	}
	public void setCurrentBUReferenceColl(String currentBUReferenceColl) {
		this.currentBUReferenceColl = currentBUReferenceColl;
	}
	public Date getLastDelinquentDate() {
		return lastDelinquentDate;
	}
	public void setLastDelinquentDate(Date lastDelinquentDate) {
		this.lastDelinquentDate = lastDelinquentDate;
	}
	public Date getLastOrderDate() {
		return lastOrderDate;
	}
	public void setLastOrderDate(Date lastOrderDate) {
		this.lastOrderDate = lastOrderDate;
	}
	public BigDecimal getPpiInd() {
		return ppiInd;
	}
	public void setPpiInd(BigDecimal ppiInd) {
		this.ppiInd = ppiInd;
	}
	public BigDecimal getNumCreditPayments() {
		return numCreditPayments;
	}
	public void setNumCreditPayments(BigDecimal numCreditPayments) {
		this.numCreditPayments = numCreditPayments;
	}
	public BigDecimal getNumRetailPayments() {
		return numRetailPayments;
	}
	public void setNumRetailPayments(BigDecimal numRetailPayments) {
		this.numRetailPayments = numRetailPayments;
	}
	public BigDecimal getAnnotationPeriodInd() {
		return annotationPeriodInd;
	}
	public void setAnnotationPeriodInd(BigDecimal annotationPeriodInd) {
		this.annotationPeriodInd = annotationPeriodInd;
	}
	public BigDecimal getRiskNavScore() {
		return riskNavScore;
	}
	public void setRiskNavScore(BigDecimal riskNavScore) {
		this.riskNavScore = riskNavScore;
	}
	public Date getRiskOIScoreUpdatedDate() {
		return riskOIScoreUpdatedDate;
	}
	public void setRiskOIScoreUpdatedDate(Date riskOIScoreUpdatedDate) {
		this.riskOIScoreUpdatedDate = riskOIScoreUpdatedDate;
	}
	public BigDecimal getOverIndebtScore() {
		return overIndebtScore;
	}
	public void setOverIndebtScore(BigDecimal overIndebtScore) {
		this.overIndebtScore = overIndebtScore;
	}
	public Date getRnOIScoreUpdatedDate() {
		return rnOIScoreUpdatedDate;
	}
	public void setRnOIScoreUpdatedDate(Date rnOIScoreUpdatedDate) {
		this.rnOIScoreUpdatedDate = rnOIScoreUpdatedDate;
	}
	public String getAnnualSalary() {
		return annualSalary;
	}
	public void setAnnualSalary(String annualSalary) {
		this.annualSalary = annualSalary;
	}
	public String getHouseholdIncome() {
		return householdIncome;
	}
	public void setHouseholdIncome(String householdIncome) {
		this.householdIncome = householdIncome;
	}
	public BigDecimal getNoOfDependants() {
		return noOfDependants;
	}
	public void setNoOfDependants(BigDecimal noOfDependants) {
		this.noOfDependants = noOfDependants;
	}
	public String getEmploymentStatus() {
		return employmentStatus;
	}
	public void setEmploymentStatus(String employmentStatus) {
		this.employmentStatus = employmentStatus;
	}
	public String getResidentStatus() {
		return residentStatus;
	}
	public void setResidentStatus(String residentStatus) {
		this.residentStatus = residentStatus;
	}
	public String getSixCode() {
		return sixCode;
	}
	public void setSixCode(String sixCode) {
		this.sixCode = sixCode;
	}
	public String getTwelveCode() {
		return twelveCode;
	}
	public void setTwelveCode(String twelveCode) {
		this.twelveCode = twelveCode;
	}
	public Date getDateOfRequest() {
		return dateOfRequest;
	}
	public void setDateOfRequest(Date dateOfRequest) {
		this.dateOfRequest = dateOfRequest;
	}
	public String getPreviousSalary() {
		return previousSalary;
	}
	public void setPreviousSalary(String previousSalary) {
		this.previousSalary = previousSalary;
	}
	public String getPreviousIncome() {
		return previousIncome;
	}
	public void setPreviousIncome(String previousIncome) {
		this.previousIncome = previousIncome;
	}
	public BigDecimal getDerivedIncome() {
		return derivedIncome;
	}
	public void setDerivedIncome(BigDecimal derivedIncome) {
		this.derivedIncome = derivedIncome;
	}
	public BigDecimal getOptOutCreditLimitIncInd() {
		return optOutCreditLimitIncInd;
	}
	public void setOptOutCreditLimitIncInd(BigDecimal optOutCreditLimitIncInd) {
		this.optOutCreditLimitIncInd = optOutCreditLimitIncInd;
	}
	public String getFidScore() {
		return fidScore;
	}
	public void setFidScore(String fidScore) {
		this.fidScore = fidScore;
	}
	public BigDecimal getOrdersDeclined3Mths() {
		return ordersDeclined3Mths;
	}
	public void setOrdersDeclined3Mths(BigDecimal ordersDeclined3Mths) {
		this.ordersDeclined3Mths = ordersDeclined3Mths;
	}
	public Date getFidScoreDate() {
		return fidScoreDate;
	}
	public void setFidScoreDate(Date fidScoreDate) {
		this.fidScoreDate = fidScoreDate;
	}
	public String getFidScoreWorst() {
		return fidScoreWorst;
	}
	public void setFidScoreWorst(String fidScoreWorst) {
		this.fidScoreWorst = fidScoreWorst;
	}
	public BigDecimal getCreditPaymentsTotal() {
		return creditPaymentsTotal;
	}
	public void setCreditPaymentsTotal(BigDecimal creditPaymentsTotal) {
		this.creditPaymentsTotal = creditPaymentsTotal;
	}
	public String getCurrentBUReference() {
		return currentBUReference;
	}
	public void setCurrentBUReference(String currentBUReference) {
		this.currentBUReference = currentBUReference;
	}
	public BigDecimal getNumPpi() {
		return numPpi;
	}
	public void setNumPpi(BigDecimal numPpi) {
		this.numPpi = numPpi;
	}
	public BigDecimal getQcbAddChar1() {
		return qcbAddChar1;
	}
	public void setQcbAddChar1(BigDecimal qcbAddChar1) {
		this.qcbAddChar1 = qcbAddChar1;
	}
	public BigDecimal getQcbAddChar2() {
		return qcbAddChar2;
	}
	public void setQcbAddChar2(BigDecimal qcbAddChar2) {
		this.qcbAddChar2 = qcbAddChar2;
	}
	public BigDecimal getQcbAddChar3() {
		return qcbAddChar3;
	}
	public void setQcbAddChar3(BigDecimal qcbAddChar3) {
		this.qcbAddChar3 = qcbAddChar3;
	}
	public BigDecimal getQcbAddChar4() {
		return qcbAddChar4;
	}
	public void setQcbAddChar4(BigDecimal qcbAddChar4) {
		this.qcbAddChar4 = qcbAddChar4;
	}
	public BigDecimal getQcbAddChar5() {
		return qcbAddChar5;
	}
	public void setQcbAddChar5(BigDecimal qcbAddChar5) {
		this.qcbAddChar5 = qcbAddChar5;
	}
	public String getQcbBSC410() {
		return qcbBSC410;
	}
	public void setQcbBSC410(String qcbBSC410) {
		this.qcbBSC410 = qcbBSC410;
	}
	public String getQcbBSC413() {
		return qcbBSC413;
	}
	public void setQcbBSC413(String qcbBSC413) {
		this.qcbBSC413 = qcbBSC413;
	}
	public String getQcbBSC435() {
		return qcbBSC435;
	}
	public void setQcbBSC435(String qcbBSC435) {
		this.qcbBSC435 = qcbBSC435;
	}
	public String getQcbBSC437() {
		return qcbBSC437;
	}
	public void setQcbBSC437(String qcbBSC437) {
		this.qcbBSC437 = qcbBSC437;
	}
	public String getQcbBSC438() {
		return qcbBSC438;
	}
	public void setQcbBSC438(String qcbBSC438) {
		this.qcbBSC438 = qcbBSC438;
	}
	public String getQcbDSC435() {
		return qcbDSC435;
	}
	public void setQcbDSC435(String qcbDSC435) {
		this.qcbDSC435 = qcbDSC435;
	}
	public String getQcbDSC437() {
		return qcbDSC437;
	}
	public void setQcbDSC437(String qcbDSC437) {
		this.qcbDSC437 = qcbDSC437;
	}
	public String getQcbDSC438() {
		return qcbDSC438;
	}
	public void setQcbDSC438(String qcbDSC438) {
		this.qcbDSC438 = qcbDSC438;
	}
	public String getQcbLSC250() {
		return qcbLSC250;
	}
	public void setQcbLSC250(String qcbLSC250) {
		this.qcbLSC250 = qcbLSC250;
	}
	public String getQcbLSC556() {
		return qcbLSC556;
	}
	public void setQcbLSC556(String qcbLSC556) {
		this.qcbLSC556 = qcbLSC556;
	}
	public String getQcbLSC557() {
		return qcbLSC557;
	}
	public void setQcbLSC557(String qcbLSC557) {
		this.qcbLSC557 = qcbLSC557;
	}
	public String getQcbLSC887() {
		return qcbLSC887;
	}
	public void setQcbLSC887(String qcbLSC887) {
		this.qcbLSC887 = qcbLSC887;
	}
	public String getQcbLSC888() {
		return qcbLSC888;
	}
	public void setQcbLSC888(String qcbLSC888) {
		this.qcbLSC888 = qcbLSC888;
	}
	public String getQcbLSC547() {
		return qcbLSC547;
	}
	public void setQcbLSC547(String qcbLSC547) {
		this.qcbLSC547 = qcbLSC547;
	}
	public String getQcbFSC402() {
		return qcbFSC402;
	}
	public void setQcbFSC402(String qcbFSC402) {
		this.qcbFSC402 = qcbFSC402;
	}
	public String getQcbLSC320() {
		return qcbLSC320;
	}
	public void setQcbLSC320(String qcbLSC320) {
		this.qcbLSC320 = qcbLSC320;
	}
	public String getQcbCSC4() {
		return qcbCSC4;
	}
	public void setQcbCSC4(String qcbCSC4) {
		this.qcbCSC4 = qcbCSC4;
	}
	public String getQcbLSC251() {
		return qcbLSC251;
	}
	public void setQcbLSC251(String qcbLSC251) {
		this.qcbLSC251 = qcbLSC251;
	}
	public String getQcbLSC173() {
		return qcbLSC173;
	}
	public void setQcbLSC173(String qcbLSC173) {
		this.qcbLSC173 = qcbLSC173;
	}
	public String getQcbFSC308() {
		return qcbFSC308;
	}
	public void setQcbFSC308(String qcbFSC308) {
		this.qcbFSC308 = qcbFSC308;
	}
	public String getQcbLSC157() {
		return qcbLSC157;
	}
	public void setQcbLSC157(String qcbLSC157) {
		this.qcbLSC157 = qcbLSC157;
	}
	public String getQcbSSC4() {
		return qcbSSC4;
	}
	public void setQcbSSC4(String qcbSSC4) {
		this.qcbSSC4 = qcbSSC4;
	}
	public String getQcbSSC2() {
		return qcbSSC2;
	}
	public void setQcbSSC2(String qcbSSC2) {
		this.qcbSSC2 = qcbSSC2;
	}
	public String getQcbXPCF09() {
		return qcbXPCF09;
	}
	public void setQcbXPCF09(String qcbXPCF09) {
		this.qcbXPCF09 = qcbXPCF09;
	}
	public String getQcbDSC410() {
		return qcbDSC410;
	}
	public void setQcbDSC410(String qcbDSC410) {
		this.qcbDSC410 = qcbDSC410;
	}
	public String getQcbDSC413() {
		return qcbDSC413;
	}
	public void setQcbDSC413(String qcbDSC413) {
		this.qcbDSC413 = qcbDSC413;
	}
	public String getQcbFSC104() {
		return qcbFSC104;
	}
	public void setQcbFSC104(String qcbFSC104) {
		this.qcbFSC104 = qcbFSC104;
	}
	public String getQcbFSC111() {
		return qcbFSC111;
	}
	public void setQcbFSC111(String qcbFSC111) {
		this.qcbFSC111 = qcbFSC111;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public BigDecimal getLastPaymentAmt() {
		return lastPaymentAmt;
	}
	public void setLastPaymentAmt(BigDecimal lastPaymentAmt) {
		this.lastPaymentAmt = lastPaymentAmt;
	}
	public BigDecimal getPendingRefAmt() {
		return pendingRefAmt;
	}
	public void setPendingRefAmt(BigDecimal pendingRefAmt) {
		this.pendingRefAmt = pendingRefAmt;
	}
	public BigDecimal getFpwoAmt() {
		return fpwoAmt;
	}
	public void setFpwoAmt(BigDecimal fpwoAmt) {
		this.fpwoAmt = fpwoAmt;
	}
	public BigDecimal getCashPayTot() {
		return cashPayTot;
	}
	public void setCashPayTot(BigDecimal cashPayTot) {
		this.cashPayTot = cashPayTot;
	}
	public Date getRnsUpdDate() {
		return rnsUpdDate;
	}
	public void setRnsUpdDate(Date rnsUpdDate) {
		this.rnsUpdDate = rnsUpdDate;
	}
	public BigDecimal getGaugeScore() {
		return gaugeScore;
	}
	public void setGaugeScore(BigDecimal gaugeScore) {
		this.gaugeScore = gaugeScore;
	}
	public BigDecimal getRecruitmentSource() {
		return recruitmentSource;
	}
	public void setRecruitmentSource(BigDecimal recruitmentSource) {
		this.recruitmentSource = recruitmentSource;
	}
	public BigDecimal getPrevAnnSal() {
		return prevAnnSal;
	}
	public void setPrevAnnSal(BigDecimal prevAnnSal) {
		this.prevAnnSal = prevAnnSal;
	}
	public BigDecimal getPrevHouseInc() {
		return prevHouseInc;
	}
	public void setPrevHouseInc(BigDecimal prevHouseInc) {
		this.prevHouseInc = prevHouseInc;
	}
	public BigDecimal getBnplTermMax() {
		return bnplTermMax;
	}
	public void setBnplTermMax(BigDecimal bnplTermMax) {
		this.bnplTermMax = bnplTermMax;
	}
	public BigDecimal getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(BigDecimal transactionType) {
		this.transactionType = transactionType;
	}
	public String getRetailAccountNumber() {
		return retailAccountNumber;
	}
	public void setRetailAccountNumber(String retailAccountNumber) {
		this.retailAccountNumber = retailAccountNumber;
	}
	public Date getStatementProducedDate() {
		return statementProducedDate;
	}
	public void setStatementProducedDate(Date statementProducedDate) {
		this.statementProducedDate = statementProducedDate;
	}



	public Date getDateLastMIV() {
		return dateLastMIV;
	}



	public void setDateLastMIV(Date dateLastMIV) {
		this.dateLastMIV = dateLastMIV;
	}



	public Date getDateLastPay() {
		return dateLastPay;
	}



	public void setDateLastPay(Date dateLastPay) {
		this.dateLastPay = dateLastPay;
	}



	public BigDecimal getNsfInd() {
		return nsfInd;
	}



	public void setNsfInd(BigDecimal nsfInd) {
		this.nsfInd = nsfInd;
	}



	public Date getDateNSF() {
		return dateNSF;
	}



	public void setDateNSF(Date dateNSF) {
		this.dateNSF = dateNSF;
	}



	public BigDecimal getPayPointPOAmt() {
		return payPointPOAmt;
	}



	public void setPayPointPOAmt(BigDecimal payPointPOAmt) {
		this.payPointPOAmt = payPointPOAmt;
	}



	public BigDecimal getDvAdminAmt() {
		return dvAdminAmt;
	}



	public void setDvAdminAmt(BigDecimal dvAdminAmt) {
		this.dvAdminAmt = dvAdminAmt;
	}
}
