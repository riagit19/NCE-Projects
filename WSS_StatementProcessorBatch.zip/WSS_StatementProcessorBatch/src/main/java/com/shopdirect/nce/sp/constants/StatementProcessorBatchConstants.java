package com.shopdirect.nce.sp.constants;

public interface StatementProcessorBatchConstants {
	
	
	String SERVICE_NAME = "spb";

	// do not remove or rename the AUDITLOG_ entries
	// used in the WSW audit log handler code
	// configuration file type
	String LOAD_FINANCIERDATA_CONFIGURATION_FILE_KEY="financierFileLoadConfig";
	String AUDITLOG_CONFIGURATION_TYPE = "propertiesConfigClassName";
	// key matching entry in master configuration for configuration file
	// filename
	String AUDITLOG_CONFIGURATION_FILE_KEY = "serviceConfiguration";
	//File Name of external Client
	String EXTERNAL_CONFIGURATION_FILE_KEY = "externalClientConfig";
	//File Name of  database configuration
	String DATABASE_CONFIGURATION_FILE_KEY = "spDbConfig";
	//File Name of data conmfig
	String DATA_CONFIGURATION_FILE_KEY = "dataConfig";

	String AUDITLOG_REQUEST = "auditLogRequest";
	String AUDITLOG_REQUEST_MASK = "auditLogRequestMask";
	String AUDITLOG_REQUEST_MASK_FIELDS = "auditLogRequestMaskFields";

	String AUDITLOG_RESPONSE = "auditLogResponse";
	String AUDITLOG_RESPONSE_MASK = "auditLogResponseMask";
	String AUDITLOG_RESPONSE_MASK_FIELDS = "auditLogResponseMaskFields";

	// configuration file type
	String VALIDATOR_CONFIGURATION_TYPE = "propertiesConfigClassName";
	// key matching entry in master configuration for configuration file
	// filename
	String VALIDATOR_CONFIG_KEY_ERROR_MESSAGES = "someMeaningfulKeyFromPropertyFile";

	// configuration file type
	String BUSINESS_CONFIGURATION_TYPE = "xmlConfigClassName";
	
	// external Config variable name
	String EXTERNAL_CONFIG_VARIABLE_STARTCOUT = "startCount";
	String EXTERNAL_CONFIG_VARIABLE_ENDCOUT = "endCount";
	
	// All DB Schema Key Name
	String DB_SCHEMA_STG_KEY= "DB_SCHEMA_STG";
	String DB_SCHEMA_MAIN_SP_KEY = "DB_SCHEMA_SP";
	 
	// Empty String
	
	String EMPTY_STRING = "";
	
	int DEFAULT_INT_VAL = 0;
	
	//LInk account Index
	
	String LINKED_ACCOUNT_INDEX_KEY = "linkAccountIndex";
	
	/// Config Error Code 
	String SERVICE_EXCEPTION="1000";
	String FILE_CONFIG_ERROR_CODE="1001";
	
	
	String GENERIC_WEBSERVICE_TRANSFPORMATION_ERROR_CODE="2000";
	String GENERIC_BUSINESS_ERROR_CODE="3000";
	String PSEUDOCHARGE_BUSINESS_ERROR_CODE="3010";
	String DORMANCYCHECK_BUSINESS_ERROR_CODE="3020";
	String UPDATECUSTOMER_BUSINESS_ERROR_CODE="3030";
	String TRAID_BUSINESS_ERROR_CODE="3040";
	String ASSESS_ACCOUNT_ERROR_CODE="3050";
	String CHARGERATE_BUSINESS_ERROR_CODE="3060";
	
	
	//DB ERROR CODE 
	String CONNECTTION_DB_ERROR_CODE = "5000";
	String GENERIC_DB_ERROR_CODE = "5001";
	//External error code 
	String JMS_CONNECTION_ERROR_CODE = "4000";
	String JMS_GENERIC_ERROR_CODE = "4001";
	
	//MDB /Message Listener error code. 
	String MDB_MSG_LISTERNER_ERROR_CODE = "6000";
	String MDB_GENERIC_ERROR_CODE = "6001";
	//INT923
	String SERVICE_NAMESPACE_URI = "SERVICE_NAMESPACE_URI";
	String EXTERNAL_SERVICE_NAME = "EXTERNAL_SERVICE_NAME";
	String SERVICE_WSDL_PATH = "SERVICE_WSDL_PATH";
	String TRIAD_ENDPOINT_URL = "TRIAD_ENDPOINT_URL";
	
	String CREDIT_LIMIT_ACTION_CHANGE = "CREDIT_LIMIT_ACTION_CHANGE";
	String CREDIT_LIMIT_ACTION_NONE = "CREDIT_LIMIT_ACTION_NONE";
	String CL_STATUS = "CL_STATUS";
	String CALL_TYPE = "CALL_TYPE";
	String REASON_CODE = "REASON_CODE";
	
	//DB Configuration
	String SP_DB_CONFIG = "spDbConfig";
	
	String SPSTUB_CONFIGURATION_FILE_KEY="spStub";
	String SPSTUB_REASON="reason";
	String SPSTUB_CREDITLIMIT_ACTION_FLAG="actionFlag";
	String SPSTUB_REASONCODE="reasonCode";
	String SPSTUB_TRIADREASONCODE ="triadReadonCode";
	String SPSTUB_FROZEN_CODE="forzenCode";
	String SPSTUB_STATEMENT_NUMBER="statementNumber";
	String SPSTUB_MSG_TYPE_CODE="msgTypeCode";
	String SPSTUB_MSG_CODE="msgCode";
	String SPSTUB_CHORDIANTID="chordiantId";
	String SPSTUB_REFNUMBER="refNumber";
	String SPSTUB_CLERKREF ="clerkRef";
	String SPSTUB_SCOREDCM ="dcm";
	String SPSTUB_CREDITRISKFACTOR="riskfactor";
	String ERROR_CHANGERATES ="ERROR_CHANGERATES";

	String TYPE_CODE="typeCode";
	
	//INT695
	String CUSTOMERACCOUNT_ENDPOINT_URL = "CUSTOMERACCOUNT_ENDPOINT_URL";
	String CUSTOMERACCOUNT_EXTERNAL_SERVICE_NAME="CUSTOMERACCOUNT_EXTERNAL_SERVICE_NAME";
	String CUSTOMERACCOUNT_SERVICE_WSDL_PATH="CUSTOMERACCOUNT_SERVICE_WSDL_PATH";
	String CUSTOMERACCOUNT_SERVICE_NAMESPACE_URI="CUSTOMERACCOUNT_SERVICE_NAMESPACE_URI";
	
	//INT1171 Update Customer Account
	String UPDATECUSTOMERACCOUNT_ENDPOINT_URL = "UPDATECUSTOMERACCOUNT_ENDPOINT_URL";
	String UPDATECUSTOMERACCOUNT_EXTERNAL_SERVICE_NAME="UPDATECUSTOMERACCOUNT_EXTERNAL_SERVICE_NAME";
	String UPDATECUSTOMERACCOUNT_SERVICE_WSDL_PATH="UPDATECUSTOMERACCOUNT_SERVICE_WSDL_PATH";
	String UPDATECUSTOMERACCOUNT_SERVICE_NAMESPACE_URI="UPDATECUSTOMERACCOUNT_SERVICE_NAMESPACE_URI";
	String ARREARS_STATUS_CODE = "ARREARS_STATUS_CODE";
	String TRADING_CODE = "TRADING_CODE";
	
	String ERROR_PERSIST_AR_RESULTS = "ERROR_PERSIST_AR_RESULTS";
	String ERROR_DORM_CHECK = "ERROR_DORM_CHECK";
	String ERROR_PSEUDOCHARGE = "ERROR_PSEUDOCHARGE";
	String ERROR_CUST_STATUS = "ERROR_CUST_STATUS";
	String ERROR_TRIAD = "ERROR_TRIAD";
	
	String BUSINESS_FAILURE = "1";
	String FAILURE_STATUS_CODE = "2";
	String FAILURE_MESSAGE = "Failed";
	
	// CREDIT DATA LOAD
	String AGREEMENT_DATA_MAPPING = "AgreementDataMapping";
	String AGREEMENT_MAP = "AgreementMap";
	String AGREEMENT_TRIAD_DATA_MAPPING = "AgreementTriadDataMapping";
	String AGREEMENT_TRIAD_MAP = "AgreementTriadItemMap";
	String DRAWDOWN_DATA_MAPPING = "DrawdownDataMapping";
	String DRAWDOWN_MAP = "DrawdownMap";
	String DRAWDOWN_ITEM_DATA_MAPPING = "DrawdownItemDataMapping";
	String DRAWDOWN_ITEM_MAP = "DrawdownItemMap";
	String NOSIA_DATA_MAPPING = "NosiaDataMapping";
	String NOSIA_MAP = "NosiaMap"; 
	String PERIOD_PAYMENT_DATA_MAPPING = "PeriodPaymentDataMapping";
	String PERIOD_PAYMENT_MAP = "PeriodPaymentMap";
	String PPI_DATA_MAPPING = "PPIStatementDataMapping";
	String PPI_MAP = "PPIStatementMap";
	String SERVICE_CHARGE_DATA_MAPPING = "ServiceChargeDataMapping";
	String SERVICE_CHARGE_MAP = "ServiceChargeMap";
	String TARGET_PAYMENT_DATA_MAPPING = "TargetedPaymentDataMapping";
	String TARGET_PAYMENT_MAP = "TargetedPaymentMap";
	String RUN_STATUS_NOT_STARTED = "NOT STARTED";
	String RUN_STATUS_FAILED = "FAILED";
	String RUN_STATUS_SUCCESS = "SUCCESS";
	String DRAWDOWN_TRANSACTION_MAP = "DrawdownTransactionMap";
	String DRAWDOWN_TRANSACTION_DATA_MAPPING = "DrawdownTransactionDataMapping";
	String ITEM_TRANSACTION_LINK_MAP = "ItemTransactionLinkMap";
	String ITEM_TRANSACTION_LINK_DATA_MAPPING = "ItemTransactionLinkDataMapping";
	String DRAWDOWN_INCOME_DATA_MAPPING = "DrawdownIncomeDataMapping";
	String DRAWDOWN_INCOME_MAP = "DrawdownIncomeDataMap";
	String BNPL_ALLOCATED_PAYMENT_DATA_MAPPING = "BnplAllocatedPaymentDataMapping";
	String BNPL_ALLOCATED_PAYMENT_MAP = "BnplAllocatedPaymentMap";
	int HEADER_RECORD = 1;
	String FINANCIER_DATA_LOAD_PROCESS_NAME = "CreditDataLoad";
	
	
	//INT936
	String ASSESS_ACCNT_ENDPOINT_URL = "ASSESS_ACCNT_ENDPOINT_URL";	
	String ASSESS_SERVICE_NAMESPACE_URI = "ASSESS_SERVICE_NAMESPACE_URI";
	String ASSESS_EXTERNAL_SERVICE_NAME = "ASSESS_EXTERNAL_SERVICE_NAME";
	String ASSESS_SERVICE_WSDL_PATH = "ASSESS_SERVICE_WSDL_PATH";
	
	String FAIL = "FAIL";
	String PROGRAMNAME = "AccountReassessment";
	String ERROR="ERROR";
	
	
	String TRAN_PRCH = "PRCH";
	
	//INT1171
	String PACK_ACCOUNT_ARREARS = "PACK_ACCOUNT_ARREARS";
	String PROC_ACCOUNT_ARREARS_STATUS = "PROC_ACCOUNT_ARREARS_STATUS";
	String STATUS_CODE_SEVENTY = "70";
	String STATUS_CODE_SEVENTYONE = "71";
	String STATUS_CODE_SEVENTYTWO = "72";
	String STATUS_CODE_SEVENTYTHREE = "73";
	String DORM = "DORM";
	
	//INT1146
	String PACK_ACC_RSMT_DATA_RET = "PACK_ACC_RSMT_DATA_RET";
	String GET_ALL_ACCT_REASMNT = "GET_ALL_ACCT_REASMNT";
	String TY_TAB_RETAIL_CONTRACT_TRIAD = "ty_tab_retail_contract_triad";
	String TY_TAB_ACCT_SNAPSHOT_TRIAD = "ty_tab_acct_snapshot_triad";
	String TY_TAB_CUST_CON_TRIAD = "TY_TAB_CUST_CON_TRIAD";
	String TY_TAB_AGREEMENT_TRIAD = "TY_TAB_AGREEMENT_TRIAD";
	String TY_TAB_CURACCT_SNAPSHOT_TRIAD = "TY_TAB_CURACCT_SNAPSHOT_TRIAD";
	String TY_TAB_LINKED_ACCOUNT = "TY_TAB_LINKED_ACCOUNT";
	String TY_TAB_PERIOD_PAYMENT_TRIAD = "TY_TAB_PERIOD_PAYMENT_TRIAD";
	String TY_OBJ_RETAIL_CONTRACT_TRIAD = "TY_OBJ_RETAIL_CONTRACT_TRIAD";
	String TY_OBJ_LINKED_ACCOUNT = "ty_obj_linked_account";
	
	String AR_STATUS_COMPLETED = "AR_Completed";
	String AR_STATUS_ERROR = "AR_Error";
	
	//Advanced Queue
	String AQ_CONNECTION_FACTORY = "aq/SP_FCM_ForeignConnectionFactory";
	String AQ_DESTINATION = "aq/SP_FCM_ForeignQueue";
	String AQ_ACK_MODE = "Auto-acknowledge";
}
