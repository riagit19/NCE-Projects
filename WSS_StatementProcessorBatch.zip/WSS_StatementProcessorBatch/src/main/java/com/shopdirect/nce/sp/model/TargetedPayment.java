package com.shopdirect.nce.sp.model;

import java.util.Date;

public class TargetedPayment {
	
    private String targetedPaymentId;

	private String periodPaymentId;
	
	private String drawdownId;
	
	private Double amount;
	
	private Date targetedPaymentDate;
	
	private String tranType;
	
	private String ddtDtype;
	
	private String payStatus;
	
	private String revPaymentId;
	
	private String internalTrxInd;
	
	private Long batchId;
	
	private String errorFlag;
	
	private String errorMessage;
	
	private Date creationDate;
	
	private Long createdByUser;
	
	private Date lastUpdateDate;
	
	private Long lastUpdateByUser;

	public String getTargetedPaymentId() {
		return targetedPaymentId;
	}

	public void setTargetedPaymentId(String targetedPaymentId) {
		this.targetedPaymentId = targetedPaymentId;
	}

	public String getPeriodPaymentId() {
		return periodPaymentId;
	}

	public void setPeriodPaymentId(String periodPaymentId) {
		this.periodPaymentId = periodPaymentId;
	}

	public String getDrawdownId() {
		return drawdownId;
	}

	public void setDrawdownId(String drawdownId) {
		this.drawdownId = drawdownId;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public Date getTargetedPaymentDate() {
		return targetedPaymentDate;
	}

	public void setTargetedPaymentDate(Date targetedPaymentDate) {
		this.targetedPaymentDate = targetedPaymentDate;
	}

	public Long getBatchId() {
		return batchId;
	}

	public void setBatchId(Long batchId) {
		this.batchId = batchId;
	}

	public String getErrorFlag() {
		return errorFlag;
	}

	public void setErrorFlag(String errorFlag) {
		this.errorFlag = errorFlag;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public Long getCreatedByUser() {
		return createdByUser;
	}

	public void setCreatedByUser(Long createdByUser) {
		this.createdByUser = createdByUser;
	}

	public Date getLastUpdateDate() {
		return lastUpdateDate;
	}

	public void setLastUpdateDate(Date lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}

	public Long getLastUpdateByUser() {
		return lastUpdateByUser;
	}

	public void setLastUpdateByUser(Long lastUpdateByUser) {
		this.lastUpdateByUser = lastUpdateByUser;
	}

	public String getTranType() {
		return tranType;
	}

	public void setTranType(String tranType) {
		this.tranType = tranType;
	}

	public String getDdtDtype() {
		return ddtDtype;
	}

	public void setDdtDtype(String ddtDtype) {
		this.ddtDtype = ddtDtype;
	}

	public String getPayStatus() {
		return payStatus;
	}

	public void setPayStatus(String payStatus) {
		this.payStatus = payStatus;
	}

	public String getRevPaymentId() {
		return revPaymentId;
	}

	public void setRevPaymentId(String revPaymentId) {
		this.revPaymentId = revPaymentId;
	}

	public String getInternalTrxInd() {
		return internalTrxInd;
	}

	public void setInternalTrxInd(String internalTrxInd) {
		this.internalTrxInd = internalTrxInd;
	}	
	
	
}
