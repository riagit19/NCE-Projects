/**
 * 
 */
package com.shopdirect.nce.sp.model;

import java.sql.Date;

/**
 * @author MeghnaBhattacharya
 *
 */
public class SpCreditFilLoadControl {
	
	private long batchId;
	
	private String fileName;
	
	private String fileRunStatus;
	
	private String errorMessage;
	
	private Date createdDate;
	
	private int createdBy;
	
	private Date lastUpdatedDate;
	
	private int lastUpdatedBy;
	
	private String fileIdentifier;
	
	private String processName;
	

	/**
	 * @return the batchId
	 */
	public long getBatchId() {
		return batchId;
	}
	
	/**
	 * @return the fileName
	 */
	public String getFileName() {
		return fileName;
	}
	
	/**
	 * @return the fileRunStatus
	 */
	public String getFileRunStatus() {
		return fileRunStatus;
	}
	
	/**
	 * @return the errorMessage
	 */
	public String getErrorMessage() {
		return errorMessage;
	}
	
	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return createdDate;
	}
	
	/**
	 * @return the createdBy
	 */
	public int getCreatedBy() {
		return createdBy;
	}
	
	/**
	 * @return the lastUpdatedDate
	 */
	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}	
	
	/**
	 * @return the lastUpdatedBy
	 */
	public int getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	/**
	 * @param batchId the batchId to set
	 */
	public void setBatchId(long batchId) {
		this.batchId = batchId;
	}


	/**
	 * @param fileName the fileName to set
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}


	/**
	 * @param fileRunStatus the fileRunStatus to set
	 */
	public void setFileRunStatus(String fileRunStatus) {
		this.fileRunStatus = fileRunStatus;
	}


	/**
	 * @param errorMessage the errorMessage to set
	 */
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}


	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}


	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}


	/**
	 * @param lastUpdatedDate the lastUpdatedDate to set
	 */
	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}


	/**
	 * @param lastUpdatedBy the lastUpdatedBy to set
	 */
	public void setLastUpdatedBy(int lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}
	

	/**
	 * @return the fileIdentifier
	 */
	public String getFileIdentifier() {
		return fileIdentifier;
	}

	/**
	 * @param fileIdentifier the fileIdentifier to set
	 */
	public void setFileIdentifier(String fileIdentifier) {
		this.fileIdentifier = fileIdentifier;
	}


	@Override
	public String toString() {
		return "SpCreditFilLoadControl [batchId=" + batchId + ", fileName=" + fileName + ", fileRunStatus="
				+ fileRunStatus + ", errorMessage=" + errorMessage + ", createdDate=" + createdDate + ", createdBy="
				+ createdBy + ", lastUpdatedDate=" + lastUpdatedDate + ", lastUpdatedBy=" + lastUpdatedBy + ", fileIdentifier=" + fileIdentifier + "]";
	}

	public String getProcessName() {
		return processName;
	}

	public void setProcessName(String processName) {
		this.processName = processName;
	}
	
	

}
