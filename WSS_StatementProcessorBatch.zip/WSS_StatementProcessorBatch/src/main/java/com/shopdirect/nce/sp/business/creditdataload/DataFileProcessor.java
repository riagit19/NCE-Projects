package com.shopdirect.nce.sp.business.creditdataload;
import java.io.File;
import java.lang.reflect.InvocationTargetException;
import java.text.ParseException;
import java.util.List;
import java.util.Map;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;



/**
 * @author AyantikaBiswas
 *
 */
public interface DataFileProcessor {
	
	public static boolean processFile(File folder, long batchID, int user) throws StatementProcessorBatchException{
		return false;}	
	
	public static boolean isValidFile(File file) {
		return false;
	}
	
	/**
	 * @return
	 * @throws StatementProcessorBatchException
	 */
	static List<Map<String, Object>> getColumns(String mappingFile, String rootNode){
		return null;
	}

	public static void constructObjects(String[] contents, List<Map<String, Object>> columns, Object instance)
			throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, ParseException {}



	/**
	 * @param content
	 * @return
	 */
	public static boolean isValidContent(String content) {
		return false;}



	/**
	 * This method renames all the file status to <processed> after the load and
	 * BR validations.
	 * @param status 
	 */
	public static void renameFiles(String status) {}

	public static boolean isValidFileName() {
		return false;}

	public static boolean validateDate(String dateToValidate) {
		return false;}
	

}
