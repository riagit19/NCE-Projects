package com.shopdirect.nce.sp.dao;

import java.sql.Array;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.shopdirect.nce.common.extcnfg.ExternalFileDataConfiguration;
import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.AccountConfirmationModel;
import com.shopdirect.nce.sp.util.CommonConfigHelper;
import com.shopdirect.nce.sp.util.UCPConnection;

public class AccountForecastInterestRetreivalDao extends AccountReassessmentBaseDao{
	
	private static final String BUSINESS_EXCEPTION_TEXT = "Business exception generated at time to process the data collection ";
	private static final SDLoggerImpl LOGGER = new SDLoggerImpl();
	
	public AccountForecastInterestRetreivalDao() throws StatementProcessorBatchException{
		super();
		setStgSchema(getSchema(StatementProcessorBatchConstants.DB_SCHEMA_STG_KEY));
		setSpMainSchema(getSchema(StatementProcessorBatchConstants.DB_SCHEMA_MAIN_SP_KEY));
	}
	
	public void callMargePreformatSP(String statementDate,String accountNo, String dateFormat)throws StatementProcessorBatchException {
		LOGGER.debug("[AccountForecastInterestRetreivalDao -- callMargePreformatSP] -- Start"); 
		
		CommonConfigHelper commonConfigHelper = CommonConfigHelper.getInstance();
		ExternalFileDataConfiguration dbconfig = commonConfigHelper.loadPropertyConfig("spDbConfig");
		
		Connection con = null;
		CallableStatement stmt = null;
		
		final String pack = commonConfigHelper.readConfigData(dbconfig, "PACK_MERGE_PREFORMAT");
		final String procedure = commonConfigHelper.readConfigData(dbconfig, "PROC_POPULATE_DATA_MAIN");
		String spDetail="{call " + pack + "." + procedure + "(?, ?)}";
		try {
	    	con = UCPConnection.getConnection();
			stmt = con.prepareCall(spDetail);
			SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
			Date stmtDate = sdf.parse(statementDate); 
			stmt.setDate(1,new java.sql.Date(stmtDate.getTime()));
			stmt.setString(2, accountNo);
			stmt.executeUpdate();
		}catch (Exception e) {
			LOGGER.error("[AccountForecastInterestRetreivalDao -- callMargePreformatSP] -- Exception: " + e);
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_BUSINESS_ERROR_CODE,
					"[AccountForecastInterestRetreivalDao-callMargePreformatSP] Exception Block",
					BUSINESS_EXCEPTION_TEXT + e, null, null,
					e);
		} finally {
			try {
				if(stmt!=null){
					stmt.close();
				}
				
				if (con != null) {
					con.close();
				}
			} catch (Exception e) {
				LOGGER.error("[AccountForecastInterestRetreivalDao -- callMargePreformatSP] -- Exception in finally block: " + e);
			}
		}	
		LOGGER.debug("[AccountForecastInterestRetreivalDao -- callMargePreformatSP] -- End"); 
	}

	public List <AccountConfirmationModel> getForcastRequestData(String publicAccNum, String statementDate, String cimAccInfoId, String dateFormat) throws StatementProcessorBatchException {
		
		LOGGER.debug("[AccountForecastInterestRetreivalDao -- getAccountReassessmentData] -- Start"); 
		
		CommonConfigHelper commonConfigHelper = CommonConfigHelper.getInstance();
		ExternalFileDataConfiguration dbconfig = commonConfigHelper.loadPropertyConfig("spDbConfig");
		final String pack = commonConfigHelper.readConfigData(dbconfig, "PACK_EST_INT");
		final String procedure = commonConfigHelper.readConfigData(dbconfig, "PRC_EST_INT");
		List <AccountConfirmationModel> modelList = new ArrayList<>();
		
		Connection connection = null;
		CallableStatement stmt = null;
		final String spDetail = "{call " + pack + "." + procedure + "(?, ?, ?, ?, ?)}";
		try {
			connection = UCPConnection.getConnection();
			
			SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
			Date stmtDate = sdf.parse(statementDate);
			java.sql.Date sqlDate = null;
			if (stmtDate != null) {
				sqlDate = new java.sql.Date(stmtDate.getTime());
			}

			final String typeName = "ty_obj_est_det";
			final String typeTableName = "ty_tab_obj_est_det";

			stmt = connection.prepareCall(spDetail);
			stmt.setString(1, publicAccNum);
			stmt.setString(2, cimAccInfoId);
			stmt.setDate(3, sqlDate);
			stmt.registerOutParameter(4, Types.ARRAY, typeTableName.toUpperCase());
			stmt.registerOutParameter(5, Types.VARCHAR);
			stmt.execute();

			Array confirmationArray = stmt.getArray(4);
			String status = stmt.getString(5);
			Map<String, Class<?>> confirmationMap = connection.getTypeMap();
			confirmationMap.put(typeName.toUpperCase(), com.shopdirect.nce.sp.model.AccountConfirmationModel.class);
			Object[] values = (Object[]) confirmationArray.getArray();
			if (values.length > 0) {
				for(int index = 0; index < values.length; index++) {
					AccountConfirmationModel model = (AccountConfirmationModel) values[index];
					modelList.add(model);
				}
			}
		} catch (Exception  exception) {
			LOGGER.error("[AccountForecastInterestRetreivalDao -- getAccountReassessmentData] -- Exception: " + exception);
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_BUSINESS_ERROR_CODE,
					"[AccountForecastInterestRetreivalDao-getAccountReassessmentData] Exception",
					BUSINESS_EXCEPTION_TEXT + exception.getMessage(), null, null,
					exception);
		} 
		finally {
			try {
				if (stmt != null) {
					stmt.close();
				}

				if (connection != null) {
					connection.close();
				}
			} catch (Exception e) {
				LOGGER.error("[AccountForecastInterestRetreivalDao -- getAccountReassessmentData] -- Exception in finally block: " + e);
			}
		}
		LOGGER.debug("[AccountForecastInterestRetreivalDao -- getAccountReassessmentData] -- End"); 
		return modelList;
	}

	
}