package com.shopdirect.nce.sp.business.creditdataload;

import java.io.File;
import java.io.FileReader;
import java.io.LineNumberReader;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.shopdirect.nce.sp.constants.CreditLoadDataConstants;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.dao.creditdataload.PPIStatementDaoImpl;
import com.shopdirect.nce.sp.dao.creditdataload.SpCreditFilLoadControlDaoImpl;
import com.shopdirect.nce.sp.exception.BuisnessException;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.PPIStatement;
import com.shopdirect.nce.sp.util.FinFileBaseProcessor;
import com.shopdirect.nce.sp.util.StatementProcessorBatchUtil;

public class PPIStatementFileProcessorImpl extends FinFileBaseProcessor implements DataFileProcessor {

	private PPIStatementDaoImpl pPIStatmentDaoImpl;
	
	public PPIStatementFileProcessorImpl() throws StatementProcessorBatchException {
		super();
	}

	/**
	 * @param folder
	 * @return
	 * @throws StatementProcessorBatchException
	 */
	public boolean processFile(File folder, long batchID, int user , String batchRunDate) throws StatementProcessorBatchException {
		
		getLogger().debug("[PPIStatementFileProcessorImpl -- processFile]  -- START");
		String fileName = StatementProcessorBatchUtil.generateFileName(CreditLoadDataConstants.PPISTATEMENT,
				CreditLoadDataConstants.NEW_STATUS, batchRunDate);
		File file = getFile(folder, fileName);
		String line = "";
		String comma = ",";		
		List<Map<String, Object>> columns = getColumns(StatementProcessorBatchConstants.PPI_DATA_MAPPING,
				StatementProcessorBatchConstants.PPI_MAP);
		String fileIdentifier = getCommonConfigHelper().readConfigData(getDataconfig(), "PPISTATEMENT");
		String insertedMessage = null;
		String errorMessage = StatementProcessorBatchConstants.EMPTY_STRING;
		int insertCount;
		boolean insertedPPIStmt = false;
		List<PPIStatement> ppiStatementRecords = null;
		SpCreditFilLoadControlDaoImpl spCreditFilLoadControlDaoImpl = new SpCreditFilLoadControlDaoImpl();
		
		Object[] procReturnVal = new Object[2];
		int retCode = 0;
		String retMsg = null;

		try (LineNumberReader reader = new LineNumberReader(new FileReader(file))) {
			int records = getRecordsCount(this.getFinancierFilePath() + file.getName());
			/**
			 * Insert data in Control Table and pass the Batch Id
			 */
			insertSpLoadControlData(batchID, file.getName(), fileIdentifier, user);
			String header = reader.readLine();
			if(records == StatementProcessorBatchConstants.HEADER_RECORD){
				insertedPPIStmt = true ;
			}
			else{
				while ((reader.getLineNumber()) < records) {
					ppiStatementRecords = new ArrayList<>();
					for (insertCount = 0; insertCount<getBatchInsertcount() ;insertCount++ ){					
						if ((line = reader.readLine())!= null){	
							String[] contents = line.split(comma, -1);
							//Check number of data in xml and .dat file is same or not
							if (columns.size() != contents.length) {
								throw new Exception(CreditLoadDataConstants.MISMATCH_ON_COLUMN_COUNT);
							}
							PPIStatement ppiStatement = new PPIStatement();
							// Set batchId in PPIStatement
							ppiStatement.setCreatedByUser(Long.valueOf(user));
							ppiStatement.setBatchId(batchID);
							ppiStatementRecords.add(ppiStatement);
							constructObjects(contents, columns, ppiStatement);
						} else{
							break;
						}
					}
					procReturnVal = getpPIStatmentDaoImpl().insertPpiStatementData(ppiStatementRecords);
					retCode = (int) procReturnVal[0];
					retMsg = (String) procReturnVal[1];
					
					// update the CONTROL table and DELETE if INSERTION fails
					if (retCode == 0) {
						insertedPPIStmt = true;
					} else {
						insertedPPIStmt = false;
						errorMessage = retMsg;
					}				
				}
			}

			/**
			 * Update the CONTROL table with batch id and error messege
			 */
			spCreditFilLoadControlDaoImpl.updateControlData(batchID, insertedPPIStmt, errorMessage, fileIdentifier);

		} catch (Exception exception) {
			insertedMessage = exception.getMessage();
			errorMessage = insertedMessage;
			insertedPPIStmt = false;
			/**
			 * Update the CONTROL table with batch id and error messege
			 */
			try {
				spCreditFilLoadControlDaoImpl.updateControlData(batchID, insertedPPIStmt, errorMessage, fileIdentifier);
			} catch (BuisnessException | SQLException ex) {
				getLogger()
						.debug("[FinancierDataLoadBusinessImpl -- processFile] -- Control Table Update Exception: "
								+ ex);
			} catch (Exception exception2) {
				getLogger()
						.debug("[PPIStatementFileProcessorImpl -- processFile] -- Control Table Update Exception: "
								+ exception2);
			}

			getLogger()
					.error("[PPIStatementFileProcessorImpl -- processFile] -- PPI Statement Insert Error occured ");
			getLogger().debug(
					"[PPIStatementFileProcessorImpl -- processFile] -- PPI Statement Exception: " + exception);
			
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_BUSINESS_ERROR_CODE,
					"[PPIStatementFileProcessorImpl-processFile] StatementProcessorBatchException Block",
					"PPI Exception " + errorMessage, null, null,
					new StatementProcessorBatchException());
		}
		getLogger().debug("[PPIStatementFileProcessorImpl -- processFile]  -- END");
		return insertedPPIStmt;
	}


	/**
	 * @return the pPIStatmentDaoImpl
	 * @throws StatementProcessorBatchException 
	 */
	public PPIStatementDaoImpl getpPIStatmentDaoImpl() throws StatementProcessorBatchException {
		if(pPIStatmentDaoImpl == null) {
			pPIStatmentDaoImpl = new PPIStatementDaoImpl();
		}
		return pPIStatmentDaoImpl;
	}

	/**
	 * @param pPIStatmentDaoImpl the pPIStatmentDaoImpl to set
	 */
	public void setpPIStatmentDaoImpl(PPIStatementDaoImpl pPIStatmentDaoImpl) {
		this.pPIStatmentDaoImpl = pPIStatmentDaoImpl;
	}
	

}
