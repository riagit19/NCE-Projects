package com.shopdirect.nce.sp.model;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class DrawdownObj {

	private BigDecimal outStandingBalance;
	private Date startDate;
	private String itemType;
	private BigDecimal dailyIntRate;
	private BigDecimal drawdownCode;
	private String prodCategory;
	private BigDecimal drawdownTerm;
	private BigDecimal osCap;
	private BigDecimal instAmtInit;
	private Timestamp chargeDate;
	private String prodCode;
	private Date bnplEndDate;
	private BigDecimal plnCurTerm;
	private BigDecimal isOptOut;
	private BigDecimal termInMonths;
	private BigDecimal deffTermInMonths;
	private String tranType;
	private List<AirDir> airDirList;
	private List<DrawdownTransaction> ddTranList;
	private List<DrawdownIncome> ddIncomeList;

	public List<DrawdownIncome> getDdIncomeList() {
		if (ddIncomeList == null) {
			ddIncomeList = new ArrayList<>();
		}
		return ddIncomeList;
	}

	public void setDdIncomeList(List<DrawdownIncome> ddIncomeList) {
		this.ddIncomeList = ddIncomeList;
	}

	public List<DrawdownTransaction> getDdTranList() {
		if (ddTranList == null) {
			ddTranList = new ArrayList<>();
		}
		return ddTranList;
	}

	public void setDdTranList(List<DrawdownTransaction> ddTranList) {
		this.ddTranList = ddTranList;
	}

	public BigDecimal getOutStandingBalance() {
		return outStandingBalance;
	}

	public void setOutStandingBalance(BigDecimal outStandingBalance) {
		this.outStandingBalance = outStandingBalance;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public String getItemType() {
		return itemType;
	}

	public void setItemType(String itemType) {
		this.itemType = itemType;
	}

	public BigDecimal getDailyIntRate() {
		return dailyIntRate;
	}

	public void setDailyIntRate(BigDecimal dailyIntRate) {
		this.dailyIntRate = dailyIntRate;
	}

	public BigDecimal getDrawdownCode() {
		return drawdownCode;
	}

	public void setDrawdownCode(BigDecimal drawdownCode) {
		this.drawdownCode = drawdownCode;
	}

	public String getProdCategory() {
		return prodCategory;
	}

	public void setProdCategory(String prodCategory) {
		this.prodCategory = prodCategory;
	}

	public BigDecimal getDrawdownTerm() {
		return drawdownTerm;
	}

	public void setDrawdownTerm(BigDecimal drawdownTerm) {
		this.drawdownTerm = drawdownTerm;
	}

	public BigDecimal getOsCap() {
		return osCap;
	}

	public void setOsCap(BigDecimal osCap) {
		this.osCap = osCap;
	}

	public BigDecimal getInstAmtInit() {
		return instAmtInit;
	}

	public void setInstAmtInit(BigDecimal instAmtInit) {
		this.instAmtInit = instAmtInit;
	}

	public Timestamp getChargeDate() {
		return chargeDate;
	}

	public void setChargeDate(Timestamp chargeDate) {
		this.chargeDate = chargeDate;
	}

	public String getProdCode() {
		return prodCode;
	}

	public void setProdCode(String prodCode) {
		this.prodCode = prodCode;
	}

	public Date getBnplEndDate() {
		return bnplEndDate;
	}

	public void setBnplEndDate(Date bnplEndDate) {
		this.bnplEndDate = bnplEndDate;
	}

	public BigDecimal getPlnCurTerm() {
		return plnCurTerm;
	}

	public void setPlnCurTerm(BigDecimal plnCurTerm) {
		this.plnCurTerm = plnCurTerm;
	}

	public BigDecimal getIsOptOut() {
		return isOptOut;
	}

	public void setIsOptOut(BigDecimal isOptOut) {
		this.isOptOut = isOptOut;
	}

	public BigDecimal getTermInMonths() {
		return termInMonths;
	}

	public void setTermInMonths(BigDecimal termInMonths) {
		this.termInMonths = termInMonths;
	}

	public BigDecimal getDeffTermInMonths() {
		return deffTermInMonths;
	}

	public void setDeffTermInMonths(BigDecimal deffTermInMonths) {
		this.deffTermInMonths = deffTermInMonths;
	}

	public String getTranType() {
		return tranType;
	}

	public void setTranType(String tranType) {
		this.tranType = tranType;
	}

	public List<AirDir> getAirDirList() {
		if (airDirList == null) {
			airDirList = new ArrayList<>();
		}
		return airDirList;
	}

	public void setAirDirList(List<AirDir> airDirList) {
		this.airDirList = airDirList;
	}

}