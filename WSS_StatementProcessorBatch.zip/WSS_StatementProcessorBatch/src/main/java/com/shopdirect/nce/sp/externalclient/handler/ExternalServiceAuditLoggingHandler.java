/**
 * 
 */
package com.shopdirect.nce.sp.externalclient.handler;

import java.io.ByteArrayOutputStream;
import java.util.HashSet;
import java.util.Set;

import javax.xml.namespace.QName;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPFactory;
import javax.xml.soap.SOAPFault;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPMessage;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.soap.SOAPHandler;
import javax.xml.ws.handler.soap.SOAPMessageContext;

import com.shopdirect.nce.common.extcnfg.ExternalFileDataConfiguration;
import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.model.LocalHeader;
import com.shopdirect.nce.sp.model.StatementProcessorBatchFault;
import com.shopdirect.nce.sp.util.CommonConfigHelper;
import com.shopdirect.nce.sp.util.StatementProcessorBatchUtil;

/**
 * @author amitkumar4
 *
 */
public class ExternalServiceAuditLoggingHandler implements SOAPHandler<SOAPMessageContext>  {
	
	private static final String LOCAL_HEADER = "localheader";
	private static SDLoggerImpl logger = new SDLoggerImpl();
	private CommonConfigHelper commonConfigHelper;
	
	private static final String LOCAL_HEADER_NAMESPACE = "http://osb.shopdirect.com/xsd/Header";
	private LocalHeader localHeader;
	private StatementProcessorBatchFault batchFault;
	
	/**
	 * 
	 */
	public ExternalServiceAuditLoggingHandler() {
		commonConfigHelper = CommonConfigHelper.getInstance();
	}
	
	
	/* (non-Javadoc)
	 * @see javax.xml.ws.handler.Handler#handleMessage(javax.xml.ws.handler.MessageContext)
	 */
	@Override
	public boolean handleMessage(SOAPMessageContext smc) {
		Boolean logReqFlag =false;
		Boolean logRspFlag =false;
		Boolean isOutboundMessage = (Boolean) smc.get(SOAPMessageContext.MESSAGE_OUTBOUND_PROPERTY);
	
		try {
			ExternalFileDataConfiguration externalClientConfig = commonConfigHelper
					.loadPropertyConfig(StatementProcessorBatchConstants.AUDITLOG_CONFIGURATION_FILE_KEY);
			String extConfigVal = getCommonConfigHelper().readConfigData(externalClientConfig, StatementProcessorBatchConstants.AUDITLOG_REQUEST);
			
			if (extConfigVal != null) {
				logReqFlag = Boolean.parseBoolean(extConfigVal);
			}
			extConfigVal  =  getCommonConfigHelper().readConfigData(externalClientConfig,StatementProcessorBatchConstants.AUDITLOG_RESPONSE);
			if (extConfigVal != null) {
				logRspFlag = Boolean.parseBoolean(extConfigVal);
			}
		} catch (Exception e) {
			logger.error("Unable to log audit record: " + e);
		}
		
		doInboundAction(smc, isOutboundMessage, logReqFlag);
		
		doOutboundAction(smc, isOutboundMessage, logRspFlag);
		
		return true;
	}
	
	/**
	 * @param isOutboundMessage
	 * @param logRequest
	 * @param smc
	 */
	private void doOutboundAction(SOAPMessageContext smc,boolean isOutboundMessage, boolean logRequest){
		if(isOutboundMessage){
			addLocalHeader(smc);
		}
		print(smc);
	}
	
	/**
	 * @param isOutboundMessage
	 * @param logResponse
	 * @param smc
	 */
	private void doInboundAction(SOAPMessageContext smc,boolean isOutboundMessage, boolean logResponse){
		if(!isOutboundMessage && logResponse) {
			print(smc);
		}
	}
	
	/**
	 * @param smc
	 * @param maskKeyname
	 */
	private void print(SOAPMessageContext smc){
		try {
			SOAPMessage soapMessage = smc.getMessage();
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream(); 
			soapMessage.writeTo(outputStream);
			logger.info(outputStream.toString());
		} catch (Exception e) {
			getLogger().error("Unable to log audit record for external service: " + e);
		}
	}
	
	
	/**
	 * Populates the WS Security of EWS request.
	 * @param soapMessageContext
	 */
	private void addLocalHeader(SOAPMessageContext soapMessageContext){
		getLogger().debug("[addSecurityHeader] - The entry.");
			try {
				SOAPMessage message = soapMessageContext.getMessage();
			    SOAPHeader header = message.getSOAPPart().getEnvelope().getHeader();
			    if (header == null) {
			        header = message.getSOAPPart().getEnvelope().addHeader();
			    }
			    SOAPFactory sf = SOAPFactory.newInstance();
			    SOAPElement requestHeader = header.addChildElement(sf.createName("RequestHeader" , LOCAL_HEADER, LOCAL_HEADER_NAMESPACE));
			    
			    
			    SOAPElement callingAppNameElement = requestHeader.addChildElement(sf.createName("CallingApplicationName", LOCAL_HEADER, LOCAL_HEADER_NAMESPACE));
			    callingAppNameElement.setValue(getLocalHeader().getCallingApp());
			    
			    SOAPElement transactionId = requestHeader.addChildElement(sf.createName("TransactionId", LOCAL_HEADER, LOCAL_HEADER_NAMESPACE));
			    transactionId.setValue(getLocalHeader().getTransactionId());
			    
			    SOAPElement version = requestHeader.addChildElement(sf.createName("Version", LOCAL_HEADER, LOCAL_HEADER_NAMESPACE));
			    version.setValue(getLocalHeader().getVersion());
			    
			    SOAPElement auditLevel = requestHeader.addChildElement(sf.createName("AuditLevel", LOCAL_HEADER, LOCAL_HEADER_NAMESPACE));
			    auditLevel.setValue(getLocalHeader().getAuditLevel());

			    message.saveChanges();
			} catch (Exception e) {
				getLogger().error("Unable to create the header for external web service");
				StatementProcessorBatchUtil.printExceptionInformation(e);
			}
		getLogger().debug("[addSecurityHeader] - The exit.");
	}

	/**
	 * @return the logger
	 */
	public static SDLoggerImpl getLogger() {
		return logger;
	}

	@Override
	public boolean handleFault(SOAPMessageContext context) {
		try {
			print(context);
			SOAPFault fault = context.getMessage().getSOAPBody().getFault();
			if (fault != null) {
				getBatchFault().setFaultErroCode(fault.getFaultCode());
				getBatchFault().setFaultErrorDesc(fault.getFaultString());
				getLogger().debug("[handleFault] - Fault Code: " + fault.getFaultCode());
			}
			
		} catch (Exception exception) {
			getLogger().error("[handleFault] - Unable to capture the SOAP");
			StatementProcessorBatchUtil.printExceptionInformation(exception);
		}
		return false;

	}

	@Override
	public void close(MessageContext context) {
		// Not Implemented
	}

	@Override
	public Set<QName> getHeaders() {
		return new HashSet<>();
	}


	/**
	 * @return the commonConfigHelper
	 */
	public CommonConfigHelper getCommonConfigHelper() {
		return commonConfigHelper;
	}



	/**
	 * @param commonConfigHelper the commonConfigHelper to set
	 */
	public void setCommonConfigHelper(CommonConfigHelper commonConfigHelper) {
		this.commonConfigHelper = commonConfigHelper;
	}


	/**
	 * @return the localHeader
	 */
	public LocalHeader getLocalHeader() {
		return localHeader;
	}


	/**
	 * @param localHeader the localHeader to set
	 */
	public void setLocalHeader(LocalHeader localHeader) {
		this.localHeader = localHeader;
	}


	/**
	 * @return the batchFault
	 */
	public StatementProcessorBatchFault getBatchFault() {
		return batchFault;
	}


	/**
	 * @param batchFault the batchFault to set
	 */
	public void setBatchFault(StatementProcessorBatchFault batchFault) {
		this.batchFault = batchFault;
	}



	
}
