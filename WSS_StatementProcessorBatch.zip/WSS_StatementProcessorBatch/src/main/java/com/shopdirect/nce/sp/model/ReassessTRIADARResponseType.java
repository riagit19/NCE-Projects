package com.shopdirect.nce.sp.model;

public class ReassessTRIADARResponseType {
	
	private ReassessTriadRespType reassessTriadRespType;

	public ReassessTriadRespType getReassessTriadRespType() {
		return reassessTriadRespType;
	}

	public void setReassessTriadRespType(ReassessTriadRespType reassessTriadRespType) {
		this.reassessTriadRespType = reassessTriadRespType;
	}
}
