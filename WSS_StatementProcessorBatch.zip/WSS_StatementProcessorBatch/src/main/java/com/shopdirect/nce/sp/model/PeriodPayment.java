package com.shopdirect.nce.sp.model;

import java.util.Date;

import com.shopdirect.nce.sp.util.StatementProcessorBatchUtil;

public class PeriodPayment {
	
	private String periodPaymentId;
	
	private String agreementId;
    
    private Long agreementSeq;
	
	private Date datePaid;
	
	private String paymentType;
	
	private Double paymentAmount;
	
	private String paymentSourceType;
	
	private String mivCode;
	
	private String mivSubCode;
	
	private Long batchId;
	
	private String errorFlag;
	
	private String errorMessage;
	
	private Date creationDate;
	
	private Long createdByUser;
	
	private Date lastUpdateDate;
	
	private Long lastUpdateByUser;

	public String getPeriodPaymentId() {
		return periodPaymentId;
	}

	public void setPeriodPaymentId(String periodPaymentId) {
		this.periodPaymentId = periodPaymentId;
	}

	public String getAgreementId() {
		return agreementId;
	}

	public void setAgreementId(String agreementId) {
		this.agreementId = agreementId;
	}

	public Long getAgreementSeq() {
		return agreementSeq;
	}

	public void setAgreementSeq(Long agreementSeq) {
		this.agreementSeq = agreementSeq;
	}

	public Date getDatePaid() {
		return datePaid;
	}

	public void setDatePaid(Date datePaid) {
		this.datePaid = datePaid;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public Double getPaymentAmount() {
		return paymentAmount;
	}

	public void setPaymentAmount(Double paymentAmount) {
		this.paymentAmount = paymentAmount;
	}

	public String getPaymentSourceType() {
		return paymentSourceType;
	}

	public void setPaymentSourceType(String paymentSourceType) {
		this.paymentSourceType = paymentSourceType;
	}

	public String getMivCode() {
		return mivCode;
	}

	public void setMivCode(String mivCode) {
		this.mivCode = mivCode;
	}

	public String getMivSubCode() {
		return mivSubCode;
	}

	public void setMivSubCode(String mivSubCode) {
		this.mivSubCode = mivSubCode;
	}

	public Long getBatchId() {
		return batchId;
	}

	public void setBatchId(Long batchId) {
		this.batchId = batchId;
	}

	public String getErrorFlag() {
		return errorFlag;
	}

	public void setErrorFlag(String errorFlag) {
		this.errorFlag = errorFlag;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public Long getCreatedByUser() {
		return createdByUser;
	}

	public void setCreatedByUser(Long createdByUser) {
		this.createdByUser = createdByUser;
	}

	public Date getLastUpdateDate() {
		return lastUpdateDate;
	}

	public void setLastUpdateDate(Date lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}

	public Long getLastUpdateByUser() {
		return lastUpdateByUser;
	}

	public void setLastUpdateByUser(Long lastUpdateByUser) {
		this.lastUpdateByUser = lastUpdateByUser;
	}	

}
