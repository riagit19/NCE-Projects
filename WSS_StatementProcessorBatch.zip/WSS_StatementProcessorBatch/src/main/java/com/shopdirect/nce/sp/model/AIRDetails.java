/**
 * 
 */
package com.shopdirect.nce.sp.model;

import java.math.BigDecimal;

import javax.xml.bind.annotation.XmlElement;

/**
 * @author AyantikaBiswas
 *
 */
public class AIRDetails {

    private String airAction;

    private BigDecimal airNumber;

    private String airImplementAfter;

    private String airGuardrailsHit;

	/**
	 * @return the airAction
	 */
	public String getAirAction() {
		return airAction;
	}

	/**
	 * @param airAction the airAction to set
	 */
	public void setAirAction(String airAction) {
		this.airAction = airAction;
	}

	/**
	 * @return the airNumber
	 */
	public BigDecimal getAirNumber() {
		return airNumber;
	}

	/**
	 * @param airNumber the airNumber to set
	 */
	public void setAirNumber(BigDecimal airNumber) {
		this.airNumber = airNumber;
	}

	/**
	 * @return the airImplementAfter
	 */
	public String getAirImplementAfter() {
		return airImplementAfter;
	}

	/**
	 * @param airImplementAfter the airImplementAfter to set
	 */
	public void setAirImplementAfter(String airImplementAfter) {
		this.airImplementAfter = airImplementAfter;
	}

	/**
	 * @return the airGuardrailsHit
	 */
	public String getAirGuardrailsHit() {
		return airGuardrailsHit;
	}

	/**
	 * @param airGuardrailsHit the airGuardrailsHit to set
	 */
	public void setAirGuardrailsHit(String airGuardrailsHit) {
		this.airGuardrailsHit = airGuardrailsHit;
	}

}
