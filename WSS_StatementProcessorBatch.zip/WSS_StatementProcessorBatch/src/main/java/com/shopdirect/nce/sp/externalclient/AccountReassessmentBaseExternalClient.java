/**
 * 
 */
package com.shopdirect.nce.sp.externalclient;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.xml.ws.Binding;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.handler.Handler;

import com.shopdirect.nce.common.extcnfg.ExternalFileDataConfiguration;
import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.externalclient.handler.ExternalServiceAuditLoggingHandler;
import com.shopdirect.nce.sp.externalclient.handler.ExternalServicePerformanceLoggingHandler;
import com.shopdirect.nce.sp.model.LocalHeader;
import com.shopdirect.nce.sp.model.StatementProcessorBatchFault;
import com.shopdirect.nce.sp.util.CommonConfigHelper;

/**
 * @author amitkumar4
 *
 */
public class AccountReassessmentBaseExternalClient {
	
	private static SDLoggerImpl logger = new SDLoggerImpl();
	private CommonConfigHelper commonConfigHelper;
	private ExternalServiceAuditLoggingHandler auditLoggingHandler;
	private LocalHeader localHeader;
	private StatementProcessorBatchFault stmtProcesFault = null;

	/**
	 * 
	 */
	public AccountReassessmentBaseExternalClient() {
		setCommonConfigHelper(CommonConfigHelper.getInstance());
		auditLoggingHandler = new ExternalServiceAuditLoggingHandler();
	}
	
	
	/**
	 * This method will add the end point and operation name to the Binding provider of the web service
	 * 
	 * @param bindingProvider
	 * 		  BindingProvider interface provides access to the protocol binding and 
	 * 		  associated context objects for request and response message processing 	
	 * @param endpoint
	 * 		  Endpoint url of the external web service	
	 * @param operationName
	 * 		  Operation Name to be called in the external web service	
	 */
	@SuppressWarnings("rawtypes")
	protected void addEndpointAddressAndHandlers(BindingProvider bindingProvider ,String endpoint, String operationName) {
		Map<String, Object> requestContextMap = bindingProvider.getRequestContext();
		requestContextMap.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, endpoint);
		List<Handler> handlerList = new ArrayList<>();
		ExternalServicePerformanceLoggingHandler performanceLoggingHandler = new ExternalServicePerformanceLoggingHandler();
		performanceLoggingHandler.setOperationName(operationName);
		
		auditLoggingHandler.setLocalHeader(getLocalHeader());
		StatementProcessorBatchFault batchFault = new StatementProcessorBatchFault(operationName);
		setStmtProcesFault(batchFault);
		auditLoggingHandler.setBatchFault(batchFault);
		
		handlerList.add(auditLoggingHandler);

		handlerList.add(performanceLoggingHandler);
		Binding binding = bindingProvider.getBinding();
		binding.setHandlerChain(handlerList);
		getLogger().debug("Suessfully added endpoint address and handlers.");
	}
	
	

	/**
	 * @return the stmtProcesFault
	 */
	public StatementProcessorBatchFault getStmtProcesFault() {
		return stmtProcesFault;
	}


	/**
	 * @param stmtProcesFault the stmtProcesFault to set
	 */
	public void setStmtProcesFault(StatementProcessorBatchFault stmtProcesFault) {
		this.stmtProcesFault = stmtProcesFault;
	}


	/**
	 * @return the commonConfigHelper
	 */
	public CommonConfigHelper getCommonConfigHelper() {
		return commonConfigHelper;
	}

	/**
	 * @param commonConfigHelper the commonConfigHelper to set
	 */
	public void setCommonConfigHelper(CommonConfigHelper commonConfigHelper) {
		this.commonConfigHelper = commonConfigHelper;
	}

	/**
	 * @return the logger
	 */
	public static SDLoggerImpl getLogger() {
		return logger;
	}


	/**
	 * @return the localHeader
	 */
	public LocalHeader getLocalHeader() {
		return localHeader;
	}


	/**
	 * @param localHeader the localHeader to set
	 */
	public void setLocalHeader(LocalHeader localHeader) {
		this.localHeader = localHeader;
	}

	public void populateLocalHeader() {
		LocalHeader localHeaderVal = new LocalHeader();
		try {
			ExternalFileDataConfiguration externalFileDataConfiguration = 
					getCommonConfigHelper().loadPropertyConfig(StatementProcessorBatchConstants.EXTERNAL_CONFIGURATION_FILE_KEY);
			localHeaderVal.setCallingApp(getCommonConfigHelper().readConfigData(externalFileDataConfiguration, "UC_LOCAL_HEADER_CALLING_APP"));
			localHeaderVal.setAuditLevel(getCommonConfigHelper().readConfigData(externalFileDataConfiguration, "UC_LOCAL_HEADER_AUDIT_LEVEL"));
			localHeaderVal.setTransactionId(UUID.randomUUID().toString());
			localHeaderVal.setVersion(getCommonConfigHelper().readConfigData(externalFileDataConfiguration, "UC_LOCAL_HEADER_VERSION"));
			setLocalHeader(localHeaderVal);
		} catch (Exception e){
			logger.error("Set Local Header Failed: " + e);
			localHeaderVal.setCallingApp("statementProcessor");
			localHeaderVal.setAuditLevel("Debug");
			localHeaderVal.setTransactionId(UUID.randomUUID().toString());
			localHeaderVal.setVersion("1.0");
			
			setLocalHeader(localHeaderVal);
		}
		
	}
}
