package com.shopdirect.nce.sp.model;

import java.math.BigInteger;
import java.util.Calendar;



public class StartAccountReassessmentRequestType {
	
    private String txUser;
    
    private BigInteger txBatchId;
    
    private Calendar txBatchRunDt;

	public String getTxUser() {
		return txUser;
	}

	public void setTxUser(String txUser) {
		this.txUser = txUser;
	}

	public BigInteger getTxBatchId() {
		return txBatchId;
	}

	public void setTxBatchId(BigInteger txBatchId) {
		this.txBatchId = txBatchId;
	}

	public Calendar getTxBatchRunDt() {
		return txBatchRunDt;
	}

	public void setTxBatchRunDt(Calendar txBatchRunDt) {
		this.txBatchRunDt = txBatchRunDt;
	}
    

}
