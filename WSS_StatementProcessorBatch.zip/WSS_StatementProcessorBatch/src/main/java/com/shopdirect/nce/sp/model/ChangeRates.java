package com.shopdirect.nce.sp.model;

import java.math.BigInteger;
import java.util.Date;

public class ChangeRates {
	private Integer cimAccountInfoID;
	private Long air;
	private String creditAccountNumber;
	private Date implementAfter;
	private Integer assessmentNumber;
	private Double outstandingBnplBalAmt;
	private Integer riskNavScore;
	private Double scheduledPaymntPastDue;
	private String aprAction;
	private Double apr;
	private String brandCode;

	public ChangeRates(){
		super();
	}
	public ChangeRates(Integer cimAccountInfoID, Long air, String creditAccountNumber,Date  implementAfter,
					Integer assessmentNumber, Double outstandingBnplBalAmt, Integer riskNavScore,Double  scheduledPaymntPastDue,
					String aprAction,Double  apr, String brandCode) {

		this.cimAccountInfoID = cimAccountInfoID;
		this.air = air;
		this.creditAccountNumber = creditAccountNumber;
		this.implementAfter = implementAfter;
		this.assessmentNumber = assessmentNumber;
		this.outstandingBnplBalAmt = outstandingBnplBalAmt;
		this.riskNavScore = riskNavScore;
		this.scheduledPaymntPastDue = scheduledPaymntPastDue;
		this.aprAction = aprAction;
		this.apr = apr;
		this.brandCode = brandCode;

	}

	public String getBrandCode() {
		return brandCode;
	}

	public void setBrandCode(String brandCode) {
		this.brandCode = brandCode;
	}

	public Integer getCimAccountInfoID() {
		return cimAccountInfoID;
	}

	public void setCimAccountInfoID(Integer cimAccountInfoID) {
		this.cimAccountInfoID = cimAccountInfoID;
	}

	public String getCreditAccountNumber() {
		return creditAccountNumber;
	}

	public void setCreditAccountNumber(String creditAccountNumber) {
		this.creditAccountNumber = creditAccountNumber;
	}

	public Date getImplementAfter() {
		return implementAfter;
	}

	public void setImplementAfter(Date implementAfter) {
		this.implementAfter = implementAfter;
	}

	public Integer getAssessmentNumber() {
		return assessmentNumber;
	}

	public void setAssessmentNumber(Integer assessmentNumber) {
		this.assessmentNumber = assessmentNumber;
	}

	public Integer getRiskNavScore() {
		return riskNavScore;
	}

	public void setRiskNavScore(Integer riskNavScore) {
		this.riskNavScore = riskNavScore;
	}

	public Long getAir() {
		return air;
	}

	public void setAir(Long air) {
		this.air = air;
	}

	public Double getOutstandingBnplBalAmt() {
		return outstandingBnplBalAmt;
	}

	public void setOutstandingBnplBalAmt(Double outstandingBnplBalAmt) {
		this.outstandingBnplBalAmt = outstandingBnplBalAmt;
	}

	public Double getScheduledPaymntPastDue() {
		return scheduledPaymntPastDue;
	}

	public void setScheduledPaymntPastDue(Double scheduledPaymntPastDue) {
		this.scheduledPaymntPastDue = scheduledPaymntPastDue;
	}

	public Double getApr() {
		return apr;
	}

	public void setApr(Double apr) {
		this.apr = apr;
	}

	public String getAprAction() {
		return aprAction;
	}

	public void setAprAction(String aprAction) {
		this.aprAction = aprAction;
	}

}
