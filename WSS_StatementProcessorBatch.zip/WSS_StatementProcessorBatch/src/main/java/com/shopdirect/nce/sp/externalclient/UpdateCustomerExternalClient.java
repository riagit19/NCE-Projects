/**
 * 
 */
package com.shopdirect.nce.sp.externalclient;

import java.net.URL;
import java.util.Map;

import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.WebServiceException;

import com.shopdirect.nce.common.extcnfg.ExternalFileDataConfiguration;
import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.util.CommonConfigHelper;
import com.shopdirect.osb.updatecustomeraccount.UpdateCustomerAccount;
import com.shopdirect.osb.updatecustomeraccount.UpdateCustomerAccountPT;
import com.shopdirect.osb.xsd.header.RequestHeaderType;
import com.shopdirect.osb.xsd.updatecustomeraccount.UpdateCustomerAccountRequestType;
import com.shopdirect.osb.xsd.updatecustomeraccount.UpdateCustomerAccountResponseType;
/**
 * @author ibm
 * This is externalClient for calling INT695-CustomerAccount (OSB service)
 *
 */
public class UpdateCustomerExternalClient extends AccountReassessmentBaseExternalClient {
	private static SDLoggerImpl logger = new SDLoggerImpl();
	private ExternalFileDataConfiguration extFileDataCfg = null;
	private String namespacheUri=null;
	private String serviceName=null;
	private String resourcePath=null;
	private BindingProvider bindingProvider;
	private UpdateCustomerAccountPT updateCustomerAccountPortType;
	private UpdateCustomerAccount updateCustomerAccount;
	

	/**
	 * Default constructor Set the CommonConfigHelper class Set the
	 * ExternalFileDataConfiguration object
	 * 
	 * @throws StatementProcessorBatchException
	 */
	public UpdateCustomerExternalClient() throws StatementProcessorBatchException {
		setCommonConfigHelper(CommonConfigHelper.getInstance());
		initExternalConfig();

	}
	
	/*
	 * this is primary method for calling CustomerAccount from UpdateCustomerInfoBusinessImpl class
	 * @param RequestHeaderType,UpdateCustomerAccountRequestType
	 */
	public UpdateCustomerAccountResponseType updateCustomerAccountContent(UpdateCustomerAccountRequestType request) throws StatementProcessorBatchException {
		getLogger().debug("[UpdateCustomerExternalClient- updateCustomerAccountContent] - Start");
		UpdateCustomerAccountResponseType response = null;
		try {
			updateCustomerAccountPortType = getCustomerAccountPortType();
			
			String endpoint =
					getCommonConfigHelper().readConfigData(getExtFileDataCfg(), StatementProcessorBatchConstants.UPDATECUSTOMERACCOUNT_ENDPOINT_URL);

			if (this.getBindingProvider() == null) {
				this.setBindingProvider((BindingProvider) this.getCustomerAccountPortType());
			}
			
			Map<String, Object> requestContextMap = this.getBindingProvider().getRequestContext();
			requestContextMap.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, endpoint);
			populateLocalHeader();
			addEndpointAddressAndHandlers(this.getBindingProvider(), endpoint, "process");
			RequestHeaderType headerType = new RequestHeaderType();
			response = updateCustomerAccountPortType.process(headerType,request);
		} 
		catch(WebServiceException se){
			getLogger().error("[[UpdateCustomerExternalClient- updateCustomerAccountContent] - WebServiceException"+se.getMessage());
			
			String faultDesc = "";
			String faultCode = "";
			if (isErrorCodePresent()) {
				faultDesc = getStmtProcesFault().getFaultErrorDesc();
				faultCode = getStmtProcesFault().getFaultErroCode();
			}

			throw new StatementProcessorBatchException(
					StatementProcessorBatchConstants.UPDATECUSTOMER_BUSINESS_ERROR_CODE,
					"[UpdateCustomerExternalClient -- updateCustomerAccountContent] Exception Block",
					"Webservice exception generated at time to process updateCustomerMaintenance " + se.getMessage()
							+ faultDesc,
					faultCode, null, se);
		}
		catch(Exception exception){
			
			getLogger().error("[updateCustomermaintenanceContent] - General exception"+exception.getMessage());
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.UPDATECUSTOMER_BUSINESS_ERROR_CODE,
					"[UpdateCustomerExternalClient -- updateCustomermaintenance] Exception Block",
					"Webservice exception generated at time to process updateCustomermaintenance "+ exception.getMessage(),
					null, null,exception);
			
		}
		getLogger().debug("[updateCustomerAccountContent] - The exit.");
		return response;
				
	}

	private boolean isErrorCodePresent() {
		return getStmtProcesFault() != null && getStmtProcesFault().getFaultErroCode() != null
				|| getStmtProcesFault().getFaultErrorDesc() != null;
	}
	
	
	public UpdateCustomerAccountPT getUpdateCustomerAccountPortType() {
		return updateCustomerAccountPortType;
	}

	public void setUpdateCustomerAccountPortType(UpdateCustomerAccountPT updateCustomerAccountPortType) {
		this.updateCustomerAccountPortType = updateCustomerAccountPortType;
	}

	public UpdateCustomerAccount getUpdateCustomerAccount() {
		return updateCustomerAccount;
	}

	public void setUpdateCustomerAccount(UpdateCustomerAccount updateCustomerAccount) {
		this.updateCustomerAccount = updateCustomerAccount;
	}

	/*
	 * this method sets queue name and end point url to portType object
	 */
	private UpdateCustomerAccountPT getCustomerAccountPortType() {
		getLogger().debug("[UpdateCustomerExternalClient -- getCustomerAccountPortType] -- Start");
		try {
			QName qName = new QName(getNamespacheUri(), getServiceName());
			URL url = UpdateCustomerAccountPT.class.getResource(getResourcePath());
			
			if(this.updateCustomerAccount == null){
				
				this.updateCustomerAccount = new UpdateCustomerAccount(url,qName);
			}
			
			setUpdateCustomerAccountPortType(updateCustomerAccount.getUpdateCustomerAccountPortHttp());
			
		} catch (Exception e) {
			getLogger().error("[UpdateCustomerExternalClient -- getCustomerAccountPortType] Exception" + e);
		}
		getLogger().debug("[UpdateCustomerExternalClient -- getCustomerAccountPortType] -- End");
		return this.updateCustomerAccountPortType;
	}


	public String getResourcePath() {
		return resourcePath;
	}


	public void setResourcePath(String resourcePath) {
		
		this.resourcePath = resourcePath;
	}


	public ExternalFileDataConfiguration getExtFileDataCfg() {
		return extFileDataCfg;
	}


	public void setExtFileDataCfg(ExternalFileDataConfiguration extFileDataCfg) {
		this.extFileDataCfg = extFileDataCfg;
	}


	public String getServiceName() {
		
		return serviceName;
	}


	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}


	public BindingProvider getBindingProvider() {
		
		return bindingProvider;
	}

	public void setBindingProvider(BindingProvider bindingProvider) {
		
		this.bindingProvider = bindingProvider;
	}

	

	public String getNamespacheUri() {
		
		return namespacheUri;
	}

	public void setNamespacheUri(String namespacheUri) {
		this.namespacheUri = namespacheUri;
	}

	/**
	 * @return the logger
	 */
	public static SDLoggerImpl getLogger() {
		return logger;
	}

	/**
	 * Configuration Object creation
	 * This method sets namespacheUri,servicename and WSDL path to private variable retrieving from externalConfig.properties
	 * @throws StatementProcessorBatchException
	 */
	private void initExternalConfig() throws StatementProcessorBatchException {
		logger.debug("[UpdateCustomerExternalClient -- initExternalConfig] -- Start");

		this.extFileDataCfg = getCommonConfigHelper().loadPropertyConfig("externalClientConfig");
		
		this.setNamespacheUri(getCommonConfigHelper().readConfigData(getExtFileDataCfg(),  StatementProcessorBatchConstants.UPDATECUSTOMERACCOUNT_SERVICE_NAMESPACE_URI));
		this.setServiceName(getCommonConfigHelper().readConfigData(getExtFileDataCfg(), StatementProcessorBatchConstants.UPDATECUSTOMERACCOUNT_EXTERNAL_SERVICE_NAME));
		this.setResourcePath(getCommonConfigHelper().readConfigData(getExtFileDataCfg(), StatementProcessorBatchConstants.UPDATECUSTOMERACCOUNT_SERVICE_WSDL_PATH));
		
		logger.debug("[UpdateCustomerExternalClient -- initExternalConfig] -- End");
	}    
}
