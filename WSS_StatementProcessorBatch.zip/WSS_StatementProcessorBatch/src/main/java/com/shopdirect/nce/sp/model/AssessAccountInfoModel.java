package com.shopdirect.nce.sp.model;

import java.math.BigDecimal;

import javax.xml.bind.annotation.XmlElement;

public class AssessAccountInfoModel {

    private String publicAccountNumber;

    private BigDecimal creditRiskFactor;
    
    private BigDecimal creditLimit;
    
    private BigDecimal pastDueAmount;
    
    private BigDecimal currentArrearsPosition;
    
    private String tradingStatus;
    
    private BigDecimal scheduledPaymentPastDue;
    
    private BigDecimal collection;
    
    private BigDecimal leftCollections;
    
    private BigDecimal openToBuy;
    
    private String currentAccountStatus;

	/**
	 * @return the publicAccountNumber
	 */
	public String getPublicAccountNumber() {
		return publicAccountNumber;
	}

	/**
	 * @param publicAccountNumber the publicAccountNumber to set
	 */
	public void setPublicAccountNumber(String publicAccountNumber) {
		this.publicAccountNumber = publicAccountNumber;
	}

	/**
	 * @return the creditRiskFactor
	 */
	public BigDecimal getCreditRiskFactor() {
		return creditRiskFactor;
	}

	/**
	 * @param creditRiskFactor the creditRiskFactor to set
	 */
	public void setCreditRiskFactor(BigDecimal creditRiskFactor) {
		this.creditRiskFactor = creditRiskFactor;
	}

	/**
	 * @return the creditLimit
	 */
	public BigDecimal getCreditLimit() {
		return creditLimit;
	}

	/**
	 * @param creditLimit the creditLimit to set
	 */
	public void setCreditLimit(BigDecimal creditLimit) {
		this.creditLimit = creditLimit;
	}

	/**
	 * @return the pastDueAmount
	 */
	public BigDecimal getPastDueAmount() {
		return pastDueAmount;
	}

	/**
	 * @param pastDueAmount the pastDueAmount to set
	 */
	public void setPastDueAmount(BigDecimal pastDueAmount) {
		this.pastDueAmount = pastDueAmount;
	}

	/**
	 * @return the currentArrearsPosition
	 */
	public BigDecimal getCurrentArrearsPosition() {
		return currentArrearsPosition;
	}

	/**
	 * @param currentArrearsPosition the currentArrearsPosition to set
	 */
	public void setCurrentArrearsPosition(BigDecimal currentArrearsPosition) {
		this.currentArrearsPosition = currentArrearsPosition;
	}

	/**
	 * @return the tradingStatus
	 */
	public String getTradingStatus() {
		return tradingStatus;
	}

	/**
	 * @param tradingStatus the tradingStatus to set
	 */
	public void setTradingStatus(String tradingStatus) {
		this.tradingStatus = tradingStatus;
	}

	/**
	 * @return the scheduledPaymentPastDue
	 */
	public BigDecimal getScheduledPaymentPastDue() {
		return scheduledPaymentPastDue;
	}

	/**
	 * @param scheduledPaymentPastDue the scheduledPaymentPastDue to set
	 */
	public void setScheduledPaymentPastDue(BigDecimal scheduledPaymentPastDue) {
		this.scheduledPaymentPastDue = scheduledPaymentPastDue;
	}

	/**
	 * @return the collection
	 */
	public BigDecimal getCollection() {
		return collection;
	}

	/**
	 * @param collection the collection to set
	 */
	public void setCollection(BigDecimal collection) {
		this.collection = collection;
	}

	/**
	 * @return the leftCollections
	 */
	public BigDecimal getLeftCollections() {
		return leftCollections;
	}

	/**
	 * @param leftCollections the leftCollections to set
	 */
	public void setLeftCollections(BigDecimal leftCollections) {
		this.leftCollections = leftCollections;
	}

	/**
	 * @return the openToBuy
	 */
	public BigDecimal getOpenToBuy() {
		return openToBuy;
	}

	/**
	 * @param openToBuy the openToBuy to set
	 */
	public void setOpenToBuy(BigDecimal openToBuy) {
		this.openToBuy = openToBuy;
	}

	/**
	 * @return the currentAccountStatus
	 */
	public String getCurrentAccountStatus() {
		return currentAccountStatus;
	}

	/**
	 * @param currentAccountStatus the currentAccountStatus to set
	 */
	public void setCurrentAccountStatus(String currentAccountStatus) {
		this.currentAccountStatus = currentAccountStatus;
	}
}
