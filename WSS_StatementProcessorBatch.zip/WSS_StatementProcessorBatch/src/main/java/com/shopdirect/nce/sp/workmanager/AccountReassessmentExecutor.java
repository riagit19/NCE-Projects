package com.shopdirect.nce.sp.workmanager;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.concurrent.Callable;

import com.shopdirect.nce.common.extcnfg.ExternalFileDataConfiguration;
import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.business.ArrearsStatusBusinessImpl;
import com.shopdirect.nce.sp.business.AssessTriadBusinessImpl;
import com.shopdirect.nce.sp.business.SPDormancyCheckBusinessImpl;
import com.shopdirect.nce.sp.business.UpdateCustomerAccountBusinessImpl;
import com.shopdirect.nce.sp.business.UpdateCustomerInfoBusinessImpl;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.dao.AccountInfoStatusDaoImpl;
import com.shopdirect.nce.sp.dao.SPErrorLogDaoImpl;
import com.shopdirect.nce.sp.dao.StatementProcessorARDao;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.CustomerAccountInfo;
import com.shopdirect.nce.sp.model.PseudoChargeResponseType;
import com.shopdirect.nce.sp.model.SpErrorLog;
import com.shopdirect.nce.sp.util.CommonConfigHelper;

/**
 * 
 * @author SudiptaRoy
 *
 */
public class AccountReassessmentExecutor implements Callable<AccountReassessmentExecutor> {

	private static final SDLoggerImpl LOGGER = new SDLoggerImpl();
	private CustomerAccountInfo customerAccountInfo;
	private CommonConfigHelper commonConfigHelper;
	private ExternalFileDataConfiguration externalClientConfig;
	private StatementProcessorBatchException processorBatchException;
	private Map <String, PseudoChargeResponseType> linkedAccountPseudoRspMap;

	public AccountReassessmentExecutor() {
		//Default Constructor
	}

	public AccountReassessmentExecutor(CustomerAccountInfo customerAccountInfo, Map <String, PseudoChargeResponseType> linkedAccountMap) throws StatementProcessorBatchException {
		initExternalConfig();
		this.customerAccountInfo = customerAccountInfo;
		this.linkedAccountPseudoRspMap = linkedAccountMap;
	}

	public CustomerAccountInfo getCustomerAccountInfo() {
		return customerAccountInfo;
	}

	public void setCustomerAccountInfo(CustomerAccountInfo customerAccountInfo) {
		this.customerAccountInfo = customerAccountInfo;
	}

	public StatementProcessorBatchException getProcessorBatchException() {
		return processorBatchException;
	}

	public void setProcessorBatchException(StatementProcessorBatchException processorBatchException) {
		this.processorBatchException = processorBatchException;
	}

	@Override
	public AccountReassessmentExecutor call() throws Exception {
		LOGGER.debug("[AccountReassessmentExecutor -- Call] -- Start"); 
		try {
			SPDormancyCheckBusinessImpl spDormancyCheckImpl = new SPDormancyCheckBusinessImpl();
			
			String accountStatus = getCustomerAccountInfo().getAccountStatus();
			/**
			 * Call Dormancy Check process
			 */
			long start = System.currentTimeMillis();
			String dormancyRsp = spDormancyCheckImpl.process(getCustomerAccountInfo());
			long time = System.currentTimeMillis() - start;
			LOGGER.debug("||| Dormancy Check took " + logTime(time)); 
			
			callExternalServices(accountStatus, dormancyRsp);
			
		} catch (StatementProcessorBatchException spbe) {
			LOGGER.error("[AccountReassessmentExecutor -- Call] -- Account: " + 
					getCustomerAccountInfo().getPublicAccountId() + " Exception: " + spbe);
			String errorKey = spbe.getErrorKey();
			this.setProcessorBatchException(spbe);
			SPErrorLogDaoImpl errorLogDao = new SPErrorLogDaoImpl();
			SpErrorLog spErrorLog = new SpErrorLog();
			spErrorLog.setErrCode(spbe.getErrorCode());
			spErrorLog.setErrDesc(spbe.getMessage());
			spErrorLog.setProgramName(StatementProcessorBatchConstants.PROGRAMNAME);
			spErrorLog.setStepStatus(StatementProcessorBatchConstants.ERROR);
			spErrorLog.setStepDesc(errorKey);
			spErrorLog.setStartDate(new Timestamp(System.currentTimeMillis()));
			spErrorLog.setEndDate(new Timestamp(System.currentTimeMillis()));
			errorLogDao.insertErrorLogData(spErrorLog);
			if (errorKey != null  && !errorKey.isEmpty()) {
				StatementProcessorARDao arDao = new StatementProcessorARDao();

				try {
					arDao.updateStatusMessage(customerAccountInfo.getPublicAccountId(),
							commonConfigHelper.readConfigData(externalClientConfig, errorKey),
							customerAccountInfo.getAccountInfoId());
					
				} catch (Exception e) {
					LOGGER.error("[AccountReassessmentExecutor -- Call] -- Exception while updating status: " + e);
				}
			}
		}
		LOGGER.debug("[AccountReassessmentExecutor -- Call] -- End");
		return this;
	}

	private String logTime(long time) {
		return time + "ms for Public Account No. " + getCustomerAccountInfo().getPublicAccountId() + " and Customer Id "
				+ getCustomerAccountInfo().getCustomerId();
	}

	private void callExternalServices(String accountStatus, String dormancyRsp)
			throws StatementProcessorBatchException {

		UpdateCustomerInfoBusinessImpl customerInfoBusinessImpl = new UpdateCustomerInfoBusinessImpl();
		ArrearsStatusBusinessImpl arrearsStatusBusinessImpl = new ArrearsStatusBusinessImpl();
		UpdateCustomerAccountBusinessImpl updateCustomerAccBusinessImpl = new UpdateCustomerAccountBusinessImpl();
		AssessTriadBusinessImpl triadBusinessImpl = new AssessTriadBusinessImpl();

		AccountInfoStatusDaoImpl accountInfoStatusDaoImpl = new AccountInfoStatusDaoImpl();
		String publicAccNum = getCustomerAccountInfo().getPublicAccountId();
		Date statementDate = getCustomerAccountInfo().getStatementDate();
		Format formatter = new SimpleDateFormat("dd-MMM-yy");
		String statementDt = formatter.format(statementDate);
		
		try {
			
			/**
			 * Call Arrears Status determination
			 */
			long start = System.currentTimeMillis();
			Map<String, String> arrearsStatusMap = arrearsStatusBusinessImpl.process(getCustomerAccountInfo());
			long time = System.currentTimeMillis() - start;
			LOGGER.debug("||| Arrears Status took " + logTime(time)); 
		

			/**
			 * Call update customer account INT 1171
			 */
			start = System.currentTimeMillis();
			String arrearsStatus = null;
			if (!arrearsStatusMap.isEmpty()) {
				arrearsStatus = arrearsStatusMap.get(StatementProcessorBatchConstants.ARREARS_STATUS_CODE);
			}
			updateCustomerAccBusinessImpl.process(getCustomerAccountInfo(), dormancyRsp, arrearsStatus);
			time = System.currentTimeMillis() - start;
			LOGGER.debug("||| Update Customer Account 1171 took " + logTime(time)); 
			
			
			/**
			 * Call Reassess TRIAD, INT 1146
			 */
			start = System.currentTimeMillis();
			triadBusinessImpl.processTriad(getCustomerAccountInfo(), getLinkedAccountPseudoRspMap(), arrearsStatusMap);
			time = System.currentTimeMillis() - start;
			LOGGER.debug("||| Reassess Triad Account 1146 took " + logTime(time)); 
			
		} catch (StatementProcessorBatchException spbe) {
			LOGGER.error("[AccountReassessmentExecutor -- Call] -- SPBException -- Rollback Account Status " + spbe);
			customerInfoBusinessImpl.process(getCustomerAccountInfo(), accountStatus);
			try {
				accountInfoStatusDaoImpl.updateCimAccountInfoStatus(publicAccNum,statementDt,StatementProcessorBatchConstants.AR_STATUS_ERROR);
			} catch (SQLException sqe) {
				LOGGER.error("[AccountReassessmentExecutor -- Call] -- SPBException -- error while updating status " + sqe);
			}
			throw spbe;
		} catch (Exception e) {
			LOGGER.error("[AccountReassessmentExecutor -- Call] -- Exception -- Rollback Account Status " + e);
			customerInfoBusinessImpl.process(getCustomerAccountInfo(), accountStatus);
			try {
				accountInfoStatusDaoImpl.updateCimAccountInfoStatus(publicAccNum,statementDt,StatementProcessorBatchConstants.AR_STATUS_ERROR);
			} catch (SQLException sqe) {
				LOGGER.error("[AccountReassessmentExecutor -- Call] -- SPBException -- error while updating status " + sqe);
			}
		}
	}

	public void initExternalConfig() throws StatementProcessorBatchException {
		commonConfigHelper = CommonConfigHelper.getInstance();
		externalClientConfig = commonConfigHelper
				.loadPropertyConfig(StatementProcessorBatchConstants.AUDITLOG_CONFIGURATION_FILE_KEY);
	}

	/**
	 * @return the linkedAccountPseudoRspMap
	 */
	public Map<String, PseudoChargeResponseType> getLinkedAccountPseudoRspMap() {
		return linkedAccountPseudoRspMap;
	}

	/**
	 * @param linkedAccountPseudoRspMap the linkedAccountPseudoRspMap to set
	 */
	public void setLinkedAccountPseudoRspMap(Map<String, PseudoChargeResponseType> linkedAccountPseudoRspMap) {
		this.linkedAccountPseudoRspMap = linkedAccountPseudoRspMap;
	}
	
	
}
