package com.shopdirect.nce.sp.model;

import java.math.BigDecimal;
import java.sql.Array;
import java.sql.SQLData;
import java.sql.SQLException;
import java.sql.SQLInput;
import java.sql.SQLOutput;
import java.sql.Struct;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class AccountConfirmationModel implements SQLData {

	private Date stmtDate;
	private BigDecimal currTakeAmt;
	private BigDecimal currMinPayAmt;
	private String sqlType;
	private String agreementId;
	private Date payDueDate;
	private Double offsetDaysPdd;
	private String brandType;
	private Date nxtStmtDate;
	private List<DrawdownObj> drawDownObjList;

	@Override
	public void readSQL(SQLInput stream, String typeName) throws SQLException {
		sqlType = typeName;
		setAgreementId(stream.readString());
		setPayDueDate(stream.readDate());
		setOffsetDaysPdd(stream.readDouble());
		setBrandType(stream.readString());
		setStmtDate(stream.readDate());
		setCurrTakeAmt(stream.readBigDecimal());
		setCurrMinPayAmt(stream.readBigDecimal());
		setNxtStmtDate(stream.readDate());
		
		Array drawDownList = stream.readArray();
		Object[] values = (Object[]) drawDownList.getArray();
		if (values.length > 0) {
			for (int index = 0; index < values.length; index++) {
				Struct val = (Struct) values[index];
				Object[] attributes = val.getAttributes();
				DrawdownObj ddObj = new DrawdownObj();
				ddObj.setOutStandingBalance((BigDecimal) attributes[0]);
				ddObj.setStartDate((Date) attributes[1]);
				ddObj.setItemType((String) attributes[2]);
				ddObj.setDailyIntRate((BigDecimal) attributes[3]);
				ddObj.setDrawdownCode((BigDecimal) attributes[4]);
				ddObj.setProdCategory((String) attributes[5]);
				ddObj.setDrawdownTerm((BigDecimal) attributes[6]);
				ddObj.setOsCap((BigDecimal) attributes[7]);
				ddObj.setInstAmtInit((BigDecimal) attributes[8]);
				ddObj.setChargeDate((Timestamp) attributes[9]);
				ddObj.setProdCode((String) attributes[10]);
				ddObj.setBnplEndDate((Date) attributes[11]);
				ddObj.setPlnCurTerm((BigDecimal) attributes[12]);
				ddObj.setIsOptOut((BigDecimal) attributes[13]);
				ddObj.setTermInMonths((BigDecimal) attributes[14]);
				ddObj.setDeffTermInMonths((BigDecimal) attributes[15]);

				Array airDirArray = (Array) attributes[16];
				Object[] airDirs = (Object[]) airDirArray.getArray();
				if (airDirs.length > 0) {
					for (int j = 0; j < airDirs.length; j++) {
						Struct ad = (Struct) airDirs[j];
						Object[] airdirAtt = ad.getAttributes();
						AirDir airDir = new AirDir();
						airDir.setAir((BigDecimal) airdirAtt[0]);
						airDir.setNonBnplDir((BigDecimal) airdirAtt[1]);
						airDir.setBnplDir((BigDecimal) airdirAtt[2]);
						airDir.setDir((BigDecimal) airdirAtt[3]);
						airDir.setEffectiveDate((Date) airdirAtt[4]);

						ddObj.getAirDirList().add(airDir);
					}
				}
				
				Array DDIncomeArray = (Array) attributes[17];
				Object[] incomes = (Object[]) DDIncomeArray.getArray();
				if (incomes.length > 0) {
					for (int j = 0; j < incomes.length; j++) {
						Struct ad = (Struct) incomes[j];
						Object[] incomeAttrib = ad.getAttributes();
						DrawdownIncome ddIncome = new DrawdownIncome();
						ddIncome.setDrawdownId(((BigDecimal)incomeAttrib[0]).toString());
						ddIncome.setIncomeType((String)incomeAttrib[1]);
						ddIncome.setOutstandingCapital(((BigDecimal)incomeAttrib[2]).doubleValue());
						ddObj.getDdIncomeList().add(ddIncome);
					}
				}
				
				Array DDTransArray = (Array) attributes[18];
				Object[] transactions = (Object[]) DDTransArray.getArray();
				if (transactions.length > 0) {
					for (int j = 0; j < transactions.length; j++) {
						Struct ad = (Struct) transactions[j];
						Object[] transAttrib = ad.getAttributes();
						DrawdownTransaction ddTransaction = new DrawdownTransaction();
						ddTransaction.setDrawdownId(((BigDecimal)transAttrib[0]).toString());
						ddTransaction.setDdtType((String)transAttrib[1]);
						ddTransaction.setDdtIncomeType((String)transAttrib[2]);
						ddTransaction.setTransactionAmount(((BigDecimal)transAttrib[3]).doubleValue());
						ddTransaction.setTransactionEffectiveDate((Date)transAttrib[4]);
						ddObj.getDdTranList().add(ddTransaction);
					}
				}
				
				getDrawDownObjList().add(ddObj);
			}
		}
	}

	@Override
	public String getSQLTypeName() throws SQLException {
		return sqlType;
	}

	@Override
	public void writeSQL(SQLOutput stream) throws SQLException {
		stream.writeString(getAgreementId());
		stream.writeDate(new java.sql.Date(getPayDueDate().getTime()));
		stream.writeDouble(getOffsetDaysPdd());
		stream.writeString(getBrandType());
	}

	public String getAgreementId() {
		return agreementId;
	}

	public void setAgreementId(String agreementId) {
		this.agreementId = agreementId;
	}

	public Date getPayDueDate() {
		return payDueDate;
	}

	public void setPayDueDate(Date payDueDate) {
		this.payDueDate = payDueDate;
	}

	public Double getOffsetDaysPdd() {
		return offsetDaysPdd;
	}

	public void setOffsetDaysPdd(Double offsetDaysPdd) {
		this.offsetDaysPdd = offsetDaysPdd;
	}

	public String getBrandType() {
		return brandType;
	}

	public void setBrandType(String brandType) {
		this.brandType = brandType;
	}

	public List<DrawdownObj> getDrawDownObjList() {
		if (drawDownObjList == null) {
			drawDownObjList = new ArrayList<>();
		}
		return drawDownObjList;
	}

	public void setDrawDownObjList(List<DrawdownObj> drawDownObjList) {
		this.drawDownObjList = drawDownObjList;
	}
	
	public Date getStmtDate() {
		return stmtDate;
	}

	public void setStmtDate(Date stmtDate) {
		this.stmtDate = stmtDate;
	}

	public BigDecimal getCurrTakeAmt() {
		return currTakeAmt;
	}

	public void setCurrTakeAmt(BigDecimal currTakeAmt) {
		this.currTakeAmt = currTakeAmt;
	}

	public BigDecimal getCurrMinPayAmt() {
		return currMinPayAmt;
	}

	public void setCurrMinPayAmt(BigDecimal currMinPayAmt) {
		this.currMinPayAmt = currMinPayAmt;
	}

	public Date getNxtStmtDate() {
		return nxtStmtDate;
	}

	public void setNxtStmtDate(Date nxtStmtDate) {
		this.nxtStmtDate = nxtStmtDate;
	}
}
