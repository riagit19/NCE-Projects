package com.shopdirect.nce.sp.model;

import java.math.BigDecimal;
import java.math.BigInteger;

public class CreditLimitType {

	private BigInteger actualCreditLimit;
	
	private BigInteger proposedCreditLimit;
	
	private String statementMessage;
	
	private String creditLineReasonCode;
	
	private String daysProposedLimitExpires;
	
	private BigInteger creditRiskFactor;
	
	private BigInteger custBehaviourScore;
	
	private BigInteger annotationsTriadDecisionKeyBatch;

	private BigInteger authStrategyId;

	private BigInteger authDigitsLowerLimit;

	private BigInteger authDigitsUpperLimit;

	private BigDecimal barFactor;
	
	private BigInteger scorecardId;

	private BigInteger rawBehaviourScore;

	private BigInteger triadBehaviourScorecardTypeCode;
	
	private String collTimedAction;

	private BigInteger aCDScorecardId;

	private BigInteger aCDRawBehaviourScore;

	private BigInteger aCDAlignedBehaviourScore;

	private BigInteger nDRScorecardId;
	
	private BigInteger nDRRawBehaviourScore;
	
	private BigInteger nDRAlignedBehaviourScore;

	private BigInteger custScorecardId;
	
	private BigInteger custRawBehaviourScore;

	private BigInteger custAlignedBehaviourScore;
	
	private BigInteger limitCapValue;

	private BigInteger affordabilityUpdateRequiredCode;
	
	private BigInteger derivedIncome;
	
	private BigInteger creditLimitOutcomeCode;
	
	private BigInteger derivedIncomeFlag;
	
	private BigInteger bNPLScore;

	public BigInteger getActualCreditLimit() {
		return actualCreditLimit;
	}

	public void setActualCreditLimit(BigInteger actualCreditLimit) {
		this.actualCreditLimit = actualCreditLimit;
	}

	public BigInteger getProposedCreditLimit() {
		return proposedCreditLimit;
	}

	public void setProposedCreditLimit(BigInteger proposedCreditLimit) {
		this.proposedCreditLimit = proposedCreditLimit;
	}

	public String getStatementMessage() {
		return statementMessage;
	}

	public void setStatementMessage(String statementMessage) {
		this.statementMessage = statementMessage;
	}

	public String getCreditLineReasonCode() {
		return creditLineReasonCode;
	}

	public void setCreditLineReasonCode(String creditLineReasonCode) {
		this.creditLineReasonCode = creditLineReasonCode;
	}

	public String getDaysProposedLimitExpires() {
		return daysProposedLimitExpires;
	}

	public void setDaysProposedLimitExpires(String daysProposedLimitExpires) {
		this.daysProposedLimitExpires = daysProposedLimitExpires;
	}

	public BigInteger getCreditRiskFactor() {
		return creditRiskFactor;
	}

	public void setCreditRiskFactor(BigInteger creditRiskFactor) {
		this.creditRiskFactor = creditRiskFactor;
	}

	public BigInteger getCustBehaviourScore() {
		return custBehaviourScore;
	}

	public void setCustBehaviourScore(BigInteger custBehaviourScore) {
		this.custBehaviourScore = custBehaviourScore;
	}

	public BigInteger getAnnotationsTriadDecisionKeyBatch() {
		return annotationsTriadDecisionKeyBatch;
	}

	public void setAnnotationsTriadDecisionKeyBatch(BigInteger annotationsTriadDecisionKeyBatch) {
		this.annotationsTriadDecisionKeyBatch = annotationsTriadDecisionKeyBatch;
	}

	public BigInteger getAuthStrategyId() {
		return authStrategyId;
	}

	public void setAuthStrategyId(BigInteger authStrategyId) {
		this.authStrategyId = authStrategyId;
	}

	public BigInteger getAuthDigitsLowerLimit() {
		return authDigitsLowerLimit;
	}

	public void setAuthDigitsLowerLimit(BigInteger authDigitsLowerLimit) {
		this.authDigitsLowerLimit = authDigitsLowerLimit;
	}

	public BigInteger getAuthDigitsUpperLimit() {
		return authDigitsUpperLimit;
	}

	public void setAuthDigitsUpperLimit(BigInteger authDigitsUpperLimit) {
		this.authDigitsUpperLimit = authDigitsUpperLimit;
	}

	public BigDecimal getBarFactor() {
		return barFactor;
	}

	public void setBarFactor(BigDecimal barFactor) {
		this.barFactor = barFactor;
	}

	public BigInteger getScorecardId() {
		return scorecardId;
	}

	public void setScorecardId(BigInteger scorecardId) {
		this.scorecardId = scorecardId;
	}

	public BigInteger getRawBehaviourScore() {
		return rawBehaviourScore;
	}

	public void setRawBehaviourScore(BigInteger rawBehaviourScore) {
		this.rawBehaviourScore = rawBehaviourScore;
	}

	public BigInteger getTriadBehaviourScorecardTypeCode() {
		return triadBehaviourScorecardTypeCode;
	}

	public void setTriadBehaviourScorecardTypeCode(BigInteger triadBehaviourScorecardTypeCode) {
		this.triadBehaviourScorecardTypeCode = triadBehaviourScorecardTypeCode;
	}

	public String getCollTimedAction() {
		return collTimedAction;
	}

	public void setCollTimedAction(String collTimedAction) {
		this.collTimedAction = collTimedAction;
	}

	public BigInteger getaCDScorecardId() {
		return aCDScorecardId;
	}

	public void setaCDScorecardId(BigInteger aCDScorecardId) {
		this.aCDScorecardId = aCDScorecardId;
	}

	public BigInteger getaCDRawBehaviourScore() {
		return aCDRawBehaviourScore;
	}

	public void setaCDRawBehaviourScore(BigInteger aCDRawBehaviourScore) {
		this.aCDRawBehaviourScore = aCDRawBehaviourScore;
	}

	public BigInteger getaCDAlignedBehaviourScore() {
		return aCDAlignedBehaviourScore;
	}

	public void setaCDAlignedBehaviourScore(BigInteger aCDAlignedBehaviourScore) {
		this.aCDAlignedBehaviourScore = aCDAlignedBehaviourScore;
	}

	public BigInteger getnDRScorecardId() {
		return nDRScorecardId;
	}

	public void setnDRScorecardId(BigInteger nDRScorecardId) {
		this.nDRScorecardId = nDRScorecardId;
	}

	public BigInteger getnDRRawBehaviourScore() {
		return nDRRawBehaviourScore;
	}

	public void setnDRRawBehaviourScore(BigInteger nDRRawBehaviourScore) {
		this.nDRRawBehaviourScore = nDRRawBehaviourScore;
	}

	public BigInteger getnDRAlignedBehaviourScore() {
		return nDRAlignedBehaviourScore;
	}

	public void setnDRAlignedBehaviourScore(BigInteger nDRAlignedBehaviourScore) {
		this.nDRAlignedBehaviourScore = nDRAlignedBehaviourScore;
	}

	public BigInteger getCustScorecardId() {
		return custScorecardId;
	}

	public void setCustScorecardId(BigInteger custScorecardId) {
		this.custScorecardId = custScorecardId;
	}

	public BigInteger getCustRawBehaviourScore() {
		return custRawBehaviourScore;
	}

	public void setCustRawBehaviourScore(BigInteger custRawBehaviourScore) {
		this.custRawBehaviourScore = custRawBehaviourScore;
	}

	public BigInteger getCustAlignedBehaviourScore() {
		return custAlignedBehaviourScore;
	}

	public void setCustAlignedBehaviourScore(BigInteger custAlignedBehaviourScore) {
		this.custAlignedBehaviourScore = custAlignedBehaviourScore;
	}

	public BigInteger getLimitCapValue() {
		return limitCapValue;
	}

	public void setLimitCapValue(BigInteger limitCapValue) {
		this.limitCapValue = limitCapValue;
	}

	public BigInteger getAffordabilityUpdateRequiredCode() {
		return affordabilityUpdateRequiredCode;
	}

	public void setAffordabilityUpdateRequiredCode(BigInteger affordabilityUpdateRequiredCode) {
		this.affordabilityUpdateRequiredCode = affordabilityUpdateRequiredCode;
	}

	public BigInteger getDerivedIncome() {
		return derivedIncome;
	}

	public void setDerivedIncome(BigInteger derivedIncome) {
		this.derivedIncome = derivedIncome;
	}

	public BigInteger getCreditLimitOutcomeCode() {
		return creditLimitOutcomeCode;
	}

	public void setCreditLimitOutcomeCode(BigInteger creditLimitOutcomeCode) {
		this.creditLimitOutcomeCode = creditLimitOutcomeCode;
	}

	public BigInteger getDerivedIncomeFlag() {
		return derivedIncomeFlag;
	}

	public void setDerivedIncomeFlag(BigInteger derivedIncomeFlag) {
		this.derivedIncomeFlag = derivedIncomeFlag;
	}

	public BigInteger getbNPLScore() {
		return bNPLScore;
	}

	public void setbNPLScore(BigInteger bNPLScore) {
		this.bNPLScore = bNPLScore;
	}
}
