package com.shopdirect.nce.sp.transform;

import java.math.BigInteger;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.StartAccountReassessmentRequestType;
import com.shopdirect.nce.sp.model.StartAccountReassessmentResponseType;
import com.shopdirect.nce.sp.util.CalendarFormatUtil;
import com.shopdirect.nce.sp.util.StatementProcessorBatchUtil;
import com.shopdirect.schemas.statementprocessorbatch.v1.ARStatisticDetailsType;
import com.shopdirect.schemas.statementprocessorbatch.v1.StartCustomerARProcessRequestType;
import com.shopdirect.schemas.statementprocessorbatch.v1.StartCustomerARProcessResponseType;
import com.shopdirect.schemas.statementprocessorbatch.v1.StatusType;
import com.shopdirect.schemas.statementprocessorbatch.v1.ProcessCreditDataResponseType;
import com.shopdirect.schemas.statementprocessorbatch.v1.ProcessCreditDataResponseType;

public class AccountReassessmentTransformer {
	
	private static SDLoggerImpl logger = new SDLoggerImpl();
	
  
    public AccountReassessmentTransformer(){
    	
    }
    /**
     * Capture the JAXB object MOdel Object.
     * @param arProcessRequestType
     * @return StartAccountReassessmentRequestType
     * @throws StatementProcessorBatchException
     */
    public StartAccountReassessmentRequestType convertJaxbToServiceObj(StartCustomerARProcessRequestType arProcessRequestType) throws StatementProcessorBatchException {
    	logger.debug("[AccountReassessmentTransformer -- convertJaxbToServiceObj]  -- START");
    	StartAccountReassessmentRequestType requesType = null;
    	try {
    		requesType = new StartAccountReassessmentRequestType();
    		requesType.setTxUser(arProcessRequestType.getUser());
    		requesType.setTxBatchId(arProcessRequestType.getBatchId());
    		String runDate = arProcessRequestType.getBatchRunDt();
    		
    		requesType.setTxBatchRunDt(CalendarFormatUtil.convertCalendar(runDate));
    		
		} catch (Exception e) {
			getLogger().error("[AccountReassessmentTransformer -- convertJaxbToServiceObj] Exception Block "+ e.getMessage());
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_WEBSERVICE_TRANSFPORMATION_ERROR_CODE,
					"[AccountReassessmentTransformer--convertJaxbToServiceObj] Exception Block",
					"Exception  generated at time to copy JAXB to Model object of StartAR operation"+ e.getMessage(),
					null, null,e);
		}
    	
    	getLogger().debug("[AccountReassessmentTransformer -- convertJaxbToServiceObj]  -- END");
    	return requesType;
    }
    
    

	public static SDLoggerImpl getLogger() {
		return logger;
	}

	/**
	 * This method transform the Model object to JAXB object. That JAXB object will forward to consumer. 
	 * ANy failure will build default JAXB object.
	 * @param responseType
	 * @return
	 */
	public StartCustomerARProcessResponseType convertVoToJaxb(StartAccountReassessmentResponseType responseType) {
		getLogger().debug("[StartAccountReassessmentBusinessImpl -- convertJaxbToServiceObj]  -- START");
		StartCustomerARProcessResponseType response = new StartCustomerARProcessResponseType();
		try{
			if(responseType != null && 
					responseType.getTotalCustomersARApply() != null && 
					responseType.getTotalCustomersARApply() > 0 ){
				
				StatusType status = new StatusType();
				status.setStatusCode("0");
				status.setStatusReason("Success");
				response.setStatus(status);
				
				ARStatisticDetailsType arStatisticDetailsType = new ARStatisticDetailsType();
				arStatisticDetailsType.setTotalCustomersARApply(new BigInteger(responseType.getTotalCustomersARApply().toString()));
				response.setARStatisticDetails(arStatisticDetailsType);
				
			}
		}catch(Exception ex){
			getLogger().error("[AccountReassessmentTransformer - convertVoToJaxb] Exception Block  "+ex.getMessage());
			StatementProcessorBatchException statementProcessorBatchException = new StatementProcessorBatchException(
					StatementProcessorBatchConstants.GENERIC_WEBSERVICE_TRANSFPORMATION_ERROR_CODE,
					"[AccountReassessmentTransformer-convertVoToJaxb] Exception Block",
					"Failure to convert from Model object o JAXB. "+ ex.getMessage(),
					null, null,ex);
			StatementProcessorBatchUtil.printExceptionInformation(statementProcessorBatchException);
			/**
			 * In case methods throws exception , Default exception will generate.
			 */
			response = defaultResponseForStartAR(statementProcessorBatchException, StatementProcessorBatchConstants.FAILURE_STATUS_CODE);
		}
		getLogger().debug("[StartAccountReassessmentBusinessImpl -- convertJaxbToServiceObj]  -- END");
		return response;
	}

    
	
	public ProcessCreditDataResponseType convertVoToCreditJaxb(boolean isSuccess, StatementProcessorBatchException se) {
		getLogger().debug("[StartAccountReassessmentBusinessImpl -- convertJaxbToServiceObj]  -- START");
		ProcessCreditDataResponseType response = new ProcessCreditDataResponseType();
		try{
			
				StatusType status = new StatusType();
				if(isSuccess){
				status.setStatusCode("0");
				status.setStatusReason("Success");
				response.setStatus(status);
				}
				else{
					if (se != null) {
						status.setStatusCode(se.getErrorCode());
						status.setStatusReason(se.getErrorDesc());
					} else {
						status.setStatusCode("1");
						status.setStatusReason("Failure");
					}
					response.setStatus(status);	
				}
		}catch(Exception ex){
			getLogger().error("[AccountReassessmentTransformer - convertVoToJaxb] Exception Block  "+ex.getMessage());
			StatementProcessorBatchException statementProcessorBatchException = new StatementProcessorBatchException(
					StatementProcessorBatchConstants.GENERIC_WEBSERVICE_TRANSFPORMATION_ERROR_CODE,
					"[AccountReassessmentTransformer-convertVoToJaxb] Exception Block",
					"Failure to convert from Model object o JAXB. "+ ex.getMessage(),
					null, null,ex);
			StatementProcessorBatchUtil.printExceptionInformation(statementProcessorBatchException);
			/**
			 * In case methods throws exception , Default exception will generate.
			 */
			
		}
		getLogger().debug("[StartAccountReassessmentBusinessImpl -- convertJaxbToServiceObj]  -- END");
		return response;
	}
	/**
	 * BUild Default Response.
	 * @param stEx
	 * @param statusCode TODO
	 * @return StartCustomerARProcessResponseType
	 */
	public StartCustomerARProcessResponseType defaultResponseForStartAR(StatementProcessorBatchException stEx, String statusCode) {
		StartCustomerARProcessResponseType response = new StartCustomerARProcessResponseType();
		try {
			
			StatusType status = new StatusType();
			status.setStatusCode(statusCode);
			status.setStatusReason(StatementProcessorBatchConstants.FAILURE_MESSAGE);
			status.setStatusDetailDescription(StatementProcessorBatchUtil.getExceptionDetails(stEx));
			response.setStatus(status);
		} catch (Exception e) {			
			getLogger().error("[AccountReassessmentTransformer -- defaultResponseForStartAR] Exception Block- failed to build default resposne ");
			StatementProcessorBatchUtil.printExceptionInformation(e);
		}
		return response;
	}
    

}
