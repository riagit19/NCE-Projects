/**
 * 
 */
package com.shopdirect.nce.sp.business.creditdataload;

import java.io.File;
import java.io.FileReader;
import java.io.LineNumberReader;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.shopdirect.nce.sp.constants.CreditLoadDataConstants;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.dao.creditdataload.NosiaDaoImpl;
import com.shopdirect.nce.sp.dao.creditdataload.SpCreditFilLoadControlDaoImpl;
import com.shopdirect.nce.sp.exception.BuisnessException;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.Nosia;
import com.shopdirect.nce.sp.util.FinFileBaseProcessor;
import com.shopdirect.nce.sp.util.StatementProcessorBatchUtil;

/**
 * @author AyantikaBiswas
 *
 */
public class NosiaFileProcessorImpl extends FinFileBaseProcessor implements DataFileProcessor {

	private NosiaDaoImpl nosiaDaoImpl;
	
	public NosiaFileProcessorImpl() throws StatementProcessorBatchException {
		super();
	}

	/**
	 * @param folder
	 * @throws StatementProcessorBatchException
	 */
	public boolean processFile(File folder, long batchID, int user, String batchRunDate) throws StatementProcessorBatchException {
		
		getLogger().debug("[NosiaFileProcessorImpl -- processFile]  -- START");
		String fileName = StatementProcessorBatchUtil.generateFileName(CreditLoadDataConstants.NOSIA,
				CreditLoadDataConstants.NEW_STATUS, batchRunDate);
		File file = getFile(folder, fileName);
		String line = "";
		String comma = ",";
		List<Map<String, Object>> columns = getColumns(StatementProcessorBatchConstants.NOSIA_DATA_MAPPING,
				StatementProcessorBatchConstants.NOSIA_MAP);
		String fileIdentifier = getCommonConfigHelper().readConfigData(getDataconfig(), "NOSIA");
		String insertedMessage = null;
		String errorMessage = StatementProcessorBatchConstants.EMPTY_STRING;
		int insertCount;
		List<Nosia> nosiaRecords = null;
		boolean insertedNosia = false;
		SpCreditFilLoadControlDaoImpl spCreditFilLoadControlDaoImpl = new SpCreditFilLoadControlDaoImpl();	
		
		Object[] procReturnVal = new Object[2];
		int retCode = 0;
		String retMsg = null;
		

		try (LineNumberReader reader = new LineNumberReader(new FileReader(file))) {
			int records = getRecordsCount(this.getFinancierFilePath() + file.getName());
			/**
			 * Insert data in Control Table and pass the Batch Id
			 */
			insertSpLoadControlData(batchID, file.getName(), fileIdentifier, user);
			String header = reader.readLine();
			if(records == StatementProcessorBatchConstants.HEADER_RECORD){
				insertedNosia = true ;
			}
			else {			
				while ((reader.getLineNumber()) < records) {
					nosiaRecords = new ArrayList<>();
					for (insertCount = 0; insertCount<getBatchInsertcount() ;insertCount++ ){					
						if ((line = reader.readLine())!= null){	
							String[] contents = line.split(comma, -1);
							//Check number of data in xml and .dat file is same or not
							if (columns.size() != contents.length) {
								throw new Exception(CreditLoadDataConstants.MISMATCH_ON_COLUMN_COUNT);
							}
							Nosia nosia = new Nosia();
							// Set batchId in Nosia
							nosia.setBatchId(batchID);
							nosia.setCreatedByUser(Long.valueOf(user));
							nosia.setLastUpdateByUser(Long.valueOf(user));
							nosiaRecords.add(nosia);
							constructObjects(contents, columns, nosia);
						} else{
							break;
						}
					}
					procReturnVal = getNosiaDaoImpl().insertNosiaData(nosiaRecords);
					retCode = (int) procReturnVal[0];
					retMsg = (String) procReturnVal[1];
					
	
					// update the CONTROL table and DELETE if INSERTION fails
					if (retCode == 0) {
						insertedNosia = true;
					} else {
						insertedNosia = false;
						errorMessage = retMsg;
					}				
				}
			}

			/**
			 * Update the CONTROL table with batch id and error messege
			 */
			spCreditFilLoadControlDaoImpl.updateControlData(batchID, insertedNosia, errorMessage, fileIdentifier);

		} catch (Exception exception) {
			insertedMessage = exception.getMessage();
			errorMessage = insertedMessage;
			insertedNosia = false;
			/**
			 * Update the CONTROL table with batch id and error messege
			 */
			try {
				spCreditFilLoadControlDaoImpl.updateControlData(batchID, insertedNosia, errorMessage, fileIdentifier);
			} catch (BuisnessException buisnessException) {
				getLogger()
						.debug("[NosiaFileProcessorImpl -- processFile] -- Control Table Update Exception: "
								+ buisnessException);
			} catch (SQLException sqlException) {
				getLogger()
						.debug("[NosiaFileProcessorImpl -- processFile] -- Control Table Update Exception: "
								+ sqlException);
			} catch (Exception exception2) {
				getLogger()
						.debug("[NosiaFileProcessorImpl -- processFile] -- Control Table Update Exception: "
								+ exception2);
			}

			getLogger()
					.error("[NosiaFileProcessorImpl -- processFile] -- Nosia Insert Error occured");
			getLogger().debug("[NosiaFileProcessorImpl -- processFile] -- Nosia Exception: " + exception);
			
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_BUSINESS_ERROR_CODE,
					"[FinancierDataLoadBusinessImpl-processFile] StatementProcessorBatchException Block",
					"Nosia Exception " + errorMessage, null, null,
					new StatementProcessorBatchException());
		}
		getLogger().debug("[NosiaFileProcessorImpl -- processFile]  -- END");
		return insertedNosia;
	}




	/**
	 * @return the nosiaDaoImpl
	 * @throws StatementProcessorBatchException 
	 */
	public NosiaDaoImpl getNosiaDaoImpl() throws StatementProcessorBatchException {
		if(nosiaDaoImpl == null) {
			nosiaDaoImpl = new NosiaDaoImpl();
		}
		return nosiaDaoImpl;
	}

	/**
	 * @param nosiaDaoImpl the nosiaDaoImpl to set
	 */
	public void setNosiaDaoImpl(NosiaDaoImpl nosiaDaoImpl) {
		this.nosiaDaoImpl = nosiaDaoImpl;
	}

}
