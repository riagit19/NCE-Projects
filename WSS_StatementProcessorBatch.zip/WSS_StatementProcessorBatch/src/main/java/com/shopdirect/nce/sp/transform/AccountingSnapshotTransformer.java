package com.shopdirect.nce.sp.transform;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.model.AccountingSnapshot;
import com.shopdirect.nce.sp.model.AccountingSnapshotTriad;
import com.shopdirect.nce.sp.model.AgreementTriad;
import com.shopdirect.nce.sp.model.CurrentAccoutingSnapshotTriad;
import com.shopdirect.nce.sp.model.CustomerAccountInfo;
import com.shopdirect.nce.sp.model.CustomerContractTriad;
import com.shopdirect.nce.sp.model.RetailContractTriad;

public class AccountingSnapshotTransformer {

	private static SDLoggerImpl logger = new SDLoggerImpl();
	
	public List<AccountingSnapshot> getAccountingSnapshot(List<RetailContractTriad> retailContractTriadList,
			List<AccountingSnapshotTriad> accountingSnapshotTriadList, CurrentAccoutingSnapshotTriad currentAccSnapshotTriad, 
			List<CustomerContractTriad> customerContractTriadList,
			List<AgreementTriad> agreementTriadList, CustomerAccountInfo accountInfo) {
		
		logger.debug("[AccountingSnapshotTransformer - getAccountingSnapshot] - Start");

		List<AccountingSnapshot> accountingSnapshotList = new ArrayList<AccountingSnapshot>();
		AccountingSnapshot accountingSnapshot;
		
		for (int i = 0; i< customerContractTriadList.size(); i++) {
			accountingSnapshot = new AccountingSnapshot();
			CustomerContractTriad custContTraid = customerContractTriadList.get(i);
			accountingSnapshot.setCustomerAccountNumber(accountInfo.getPublicAccountId());
			accountingSnapshot.setOccurence(new BigDecimal(i+1));
			accountingSnapshot.setAssessmentDate(custContTraid.getAccountingDate());
			accountingSnapshot.setTimestampCreated(new java.sql.Date(new Date().getTime()));
			accountingSnapshot.setAccountStatusCode(custContTraid.getAccountStatusCode());
			accountingSnapshot.setNetSalesValueTSPAmt(currentAccSnapshotTriad.getNetSalesValueTSPAmt());
			accountingSnapshot.setWorstFollowUP(custContTraid.getWorstFollowUpCode());
			accountingSnapshot.setAlignedBehaviourScore(custContTraid.getAlignedBehaviourScore());
			accountingSnapshot.setBehaviourRawScore(custContTraid.getRawBehaviourScore());
			accountingSnapshot.setScorecardId(custContTraid.getScorecardRefno());
			accountingSnapshot.setAcdScorecardId(custContTraid.getAcdScorecardRefno());
			accountingSnapshot.setAcdRawScore(custContTraid.getAcdRawScore());
			accountingSnapshot.setAcdAlignedScore(custContTraid.getAcdAlignedScore());
			accountingSnapshot.setNdrScorecardId(custContTraid.getNdrScorecardRefno());
			accountingSnapshot.setNdrRawScore(custContTraid.getNdrRawScore());
			accountingSnapshot.setNdrAlignedScore(custContTraid.getNdrAlignedScore());
			accountingSnapshot.setCustScorecardId(custContTraid.getCustScorecardRefno());
			accountingSnapshot.setCustRawScore(custContTraid.getCustRawScore());
			accountingSnapshot.setCustAlignedScore(custContTraid.getCustAlignedScore());
			accountingSnapshot.setcRF(custContTraid.getCreditRiskFactor());
			accountingSnapshot.setTodaysAccountingDate(custContTraid.getAccountingDate());
		
			if (retailContractTriadList.size() > i) {
				RetailContractTriad reailContTriad = retailContractTriadList.get(i);
				accountingSnapshot.setFidScoreWorst(reailContTriad.getFidScoreWorst());
				accountingSnapshot.setRiskNavScore(reailContTriad.getRiskNavScore());
				accountingSnapshot.setOverIndebtScore(reailContTriad.getOverIndebtScore());
			}
			
			if (agreementTriadList.size() > i) {
				AgreementTriad agrmntTraid = agreementTriadList.get(i);
				if (agrmntTraid.getBalance() != null &&
						agrmntTraid.getBnplBalance() != null) {
					accountingSnapshot.setClosingBalance(agrmntTraid.getBalance()
						.subtract(agrmntTraid.getBnplBalance()));
				}
				accountingSnapshot.setTakeAll(agrmntTraid.getTakeAll());
				accountingSnapshot.setBnplBalance(agrmntTraid.getBnplBalance());
				accountingSnapshot.setScheduledPaymentAmt(agrmntTraid.getScheduledPaymentAmt());
				accountingSnapshot.setPastDue(agrmntTraid.getPastDueAmt());
				accountingSnapshot.setPaymentAmountTSP(agrmntTraid.getPayAmtTSP());
				accountingSnapshot.setScheduledPaymentsPastDue(agrmntTraid.getScheduledPaymentPastDue());
				accountingSnapshot.setStatementNumber(agrmntTraid.getFnStatNo());
				accountingSnapshot.setStatPromtMessageCodeRec(currentAccSnapshotTriad.getStatPromtMessageCodeRec());
				accountingSnapshot.setInterestChargedAmtTSP(agrmntTraid.getIntChargedTSP());
				if (agrmntTraid.getPurchaseAmtTSP() != null && agrmntTraid.getReturnsAmtTSP() != null) {
					accountingSnapshot.setNetSalesValueTSPAmt(agrmntTraid.getPurchaseAmtTSP().add(agrmntTraid.getReturnsAmtTSP()));
				}
				accountingSnapshot.setPurchaseAmountTSP(agrmntTraid.getPurchaseAmtTSP());
				accountingSnapshot.setReturnsAmountTSP(agrmntTraid.getReturnsAmtTSP());
				accountingSnapshot.setaPR(agrmntTraid.getApr());
				accountingSnapshot.setNumPurchasesTSP(agrmntTraid.getNumPurchasesTSP());
				accountingSnapshot.setTotalFeesTSP(agrmntTraid.getTotFeesTSP());
				accountingSnapshot.setNumPaymentsTSP(agrmntTraid.getNumPayTSP());
				accountingSnapshot.setCustomerCreditTSP(agrmntTraid.getCustCreditsTSP());
				accountingSnapshot.setNumReturnedPaymentTSP(agrmntTraid.getNumRetPayTSP());
				accountingSnapshot.setValueFailedPayments(agrmntTraid.getReturnsAmtTSP());
				accountingSnapshot.setRebatesAmountTSP(agrmntTraid.getRebatesAmtTSP());
				accountingSnapshot.setReturnsAmountTSP(agrmntTraid.getReturnsAmtTSP());
				accountingSnapshot.setoTB(agrmntTraid.getAvailableToSpend());
				accountingSnapshot.setNumNSF(agrmntTraid.getNumRetPayTSP());
			}
			
			if (accountingSnapshotTriadList.size() > i) {
				AccountingSnapshotTriad accSnptTriad = accountingSnapshotTriadList.get(i);
				accountingSnapshot.setOpeningBalance(accSnptTriad.getOpeningBalanceAmtSign());
				accountingSnapshot.setSalesFor6Months(accSnptTriad.getNettSales6M());
				accountingSnapshot.setSalesFor12Months(accSnptTriad.getNettSales12M());
				accountingSnapshot.setSalesLifetime(accSnptTriad.getNettSalesLifeTime());
				accountingSnapshot.setHighBalance(accSnptTriad.getHighBalanceAmt());
				accountingSnapshot.setHighDelq(accSnptTriad.getHighDelq());
				accountingSnapshot.setNumCycle1(accSnptTriad.getNumCycle1());
				accountingSnapshot.setNumCycle2(accSnptTriad.getNumCycle2());
				accountingSnapshot.setNumCycle3(accSnptTriad.getNumCycle3());
				accountingSnapshot.setNumCycle4(accSnptTriad.getNumCycle4());
				accountingSnapshot.setBalanceBeforePPI(accSnptTriad.getTcbipChargableBalAmtSigned());
				accountingSnapshot.setOpeningBNPLBalance(accSnptTriad.getOpeningBNPLBalAmt());
				accountingSnapshot.setDebtType(accSnptTriad.getDebtType() != null ? accSnptTriad.getDebtType().toString() : null);
				accountingSnapshot.setOtherDebits(accSnptTriad.getOtherDebitsAmtSigned());
				accountingSnapshot.setOtherCredits(accSnptTriad.getOtherCreditsAmtSigned());
				accountingSnapshot.setNextAssessmentAPR(accSnptTriad.getNextAssessmentApr());
				accountingSnapshot.setNextAccountAPR(accSnptTriad.getNextAccountApr());
			}
			
			accountingSnapshotList.add(accountingSnapshot);
		}
		
		logger.debug("[AccountingSnapshotTransformer - getAccountingSnapshot] - End");
		
		return accountingSnapshotList;
	
	}
}
