package com.shopdirect.nce.sp.model;

import java.sql.Timestamp;
import java.util.Date;

public class DrawdownTransaction {
	
	private String drawdownTransactionId;
	
	private String drawdownId;
	
	private Timestamp transactionCreateDate; 
	
	private Date interestLiableDate;
	
	private Date transactionEffectiveDate;
	
	private Double transactionAmount;
	
	private String transactionType;
	
	private String reasonCode;
	
	private String ddtType;

	private Long mivCode;
	
	private String mivSubCode;
	
	private Long batchId;
	
	private String errorFlag;
	
	private String errorMessage;
	
	private Date creationDate;
	
	private Long createdByUser;
	
	private Date lastUpdateDate;
	
	private Long lastUpdateByUser;
	
	private String tfrLink;

	private String ddtIncomeType;
	
	private String internalTrxInd;

	public String getDdtIncomeType() {
		return ddtIncomeType;
	}

	public void setDdtIncomeType(String ddtIncomeType) {
		this.ddtIncomeType = ddtIncomeType;
	}

	public String getDrawdownTransactionId() {
		return drawdownTransactionId;
	}

	public void setDrawdownTransactionId(String drawdownTransactionId) {
		this.drawdownTransactionId = drawdownTransactionId;
	}

	public String getDrawdownId() {
		return drawdownId;
	}

	public void setDrawdownId(String drawdownId) {
		this.drawdownId = drawdownId;
	}

	public Timestamp getTransactionCreateDate() {
		return transactionCreateDate;
	}

	public void setTransactionCreateDate(Timestamp transactionCreateDate) {
		this.transactionCreateDate = transactionCreateDate;
	}

	public Date getInterestLiableDate() {
		return interestLiableDate;
	}

	public void setInterestLiableDate(Date interestLiableDate) {
		this.interestLiableDate = interestLiableDate;
	}

	public Date getTransactionEffectiveDate() {
		return transactionEffectiveDate;
	}

	public void setTransactionEffectiveDate(Date transactionEffectiveDate) {
		this.transactionEffectiveDate = transactionEffectiveDate;
	}

	public Double getTransactionAmount() {
		return transactionAmount;
	}

	public void setTransactionAmount(Double transactionAmount) {
		this.transactionAmount = transactionAmount;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getReasonCode() {
		return reasonCode;
	}

	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}

	public Long getMivCode() {
		return mivCode;
	}

	public void setMivCode(Long mivCode) {
		this.mivCode = mivCode;
	}

	public String getMivSubCode() {
		return mivSubCode;
	}

	public void setMivSubCode(String mivSubCode) {
		this.mivSubCode = mivSubCode;
	}

	public Long getBatchId() {
		return batchId;
	}

	public void setBatchId(Long batchId) {
		this.batchId = batchId;
	}

	public String getErrorFlag() {
		return errorFlag;
	}

	public void setErrorFlag(String errorFlag) {
		this.errorFlag = errorFlag;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public Long getCreatedByUser() {
		return createdByUser;
	}

	public void setCreatedByUser(Long createdByUser) {
		this.createdByUser = createdByUser;
	}

	public Date getLastUpdateDate() {
		return lastUpdateDate;
	}

	public void setLastUpdateDate(Date lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}

	public Long getLastUpdateByUser() {
		return lastUpdateByUser;
	}

	public void setLastUpdateByUser(Long lastUpdateByUser) {
		this.lastUpdateByUser = lastUpdateByUser;
	}
	
	public String getDdtType() {
		return ddtType;
	}

	public void setDdtType(String ddtType) {
		this.ddtType = ddtType;
	}

	public String getTfrLink() {
		return tfrLink;
	}

	public void setTfrLink(String tfrLink) {
		this.tfrLink = tfrLink;
	}

	public String getInternalTrxInd() {
		return internalTrxInd;
	}

	public void setInternalTrxInd(String internalTrxInd) {
		this.internalTrxInd = internalTrxInd;
	}

}
