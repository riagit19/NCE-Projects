package com.shopdirect.nce.sp.business;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import com.shopdirect.fcm.xsd.forecastmodeller.BRAND_CODE;
import com.shopdirect.fcm.xsd.forecastmodeller.BRAND_CREDIT_PRODUCT_CODE;
import com.shopdirect.fcm.xsd.forecastmodeller.BrandCreditProductType;
import com.shopdirect.fcm.xsd.forecastmodeller.CurrentDDTWithTransactionsAndIncomesType;
import com.shopdirect.fcm.xsd.forecastmodeller.CustomerAccountInterestReqType;
import com.shopdirect.fcm.xsd.forecastmodeller.CustomerAccountInterestRespType;
import com.shopdirect.fcm.xsd.forecastmodeller.CustomerAccountType;
import com.shopdirect.fcm.xsd.forecastmodeller.DDTIncomeType;
import com.shopdirect.fcm.xsd.forecastmodeller.DDTTransactionType;
import com.shopdirect.fcm.xsd.forecastmodeller.DailyRateType;
import com.shopdirect.nce.cc.fcm.core.adapter.CustomerAccountInterestAdapter;
import com.shopdirect.nce.common.extcnfg.ExternalFileDataConfiguration;
import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.dao.AccountForcastInterestPersistDaoImpl;
import com.shopdirect.nce.sp.dao.AccountForecastInterestRetreivalDao;
import com.shopdirect.nce.sp.dao.StatementProcessorARDao;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.AccountConfirmationModel;
import com.shopdirect.nce.sp.model.AirDir;
import com.shopdirect.nce.sp.model.DrawdownIncome;
import com.shopdirect.nce.sp.model.DrawdownObj;
import com.shopdirect.nce.sp.model.DrawdownTransaction;
import com.shopdirect.nce.sp.util.CommonConfigHelper;
import com.shopdirect.nce.sp.util.ConvertToJsonUtil;

/**
 * 
 * @author ibm
 *
 */
public class AccountForcastProcessBusinessImpl {

	private static final String EXCEPTION_TEXT = "Business exception generated at time to process the data collection ";
	private static SDLoggerImpl logger = new SDLoggerImpl();
	private AccountForecastInterestRetreivalDao accountReassessmentConfirmationDao = null;
	private StatementProcessorARDao statementProcessorARDao = null;
	private CustomerAccountInterestAdapter customerAccountInterestAdapter = null;
	
	final String DATE_FORMAT = "dd-MMM-yy";

	BigDecimal estimatedInterest = null;
	String publicAcctNum = null;
	String assmntDate = null;
	String accountId = null;

	/**
	 * Default Constructor
	 * 
	 * @throws StatementProcessorBatchException
	 */
	public AccountForcastProcessBusinessImpl() throws StatementProcessorBatchException {
		accountReassessmentConfirmationDao = getAccountReassessmentConfirmationDao();
		statementProcessorARDao = getStatementProcessorARDao();
	}

	/**
	 * @return the logger
	 */
	public static SDLoggerImpl getLogger() {
		return logger;
	}

	/**
	 * 
	 * @param aqMessage
	 * @return void
	 * @throws StatementProcessorBatchException
	 */
	public void processForcastInterest(String aqMessage) throws StatementProcessorBatchException {
		logger.debug("[AccountForcastProcessBusinessImpl -- processForcastInterest] -- Start");
		
		CommonConfigHelper commonConfigHelper = CommonConfigHelper.getInstance();
		ExternalFileDataConfiguration externalClientConfig = commonConfigHelper.loadPropertyConfig(StatementProcessorBatchConstants.AUDITLOG_CONFIGURATION_FILE_KEY);
		
		try {
			accountReassessmentConfirmationDao = new AccountForecastInterestRetreivalDao();
			statementProcessorARDao = new StatementProcessorARDao();
			customerAccountInterestAdapter = new CustomerAccountInterestAdapter();

			String[] paramsArr = aqMessage.split(",");
			publicAcctNum = paramsArr[0];
			assmntDate = paramsArr[1];
			String cimAccInfoId = paramsArr[4];
			if (assmntDate.length() >= 10) {
				assmntDate = assmntDate.substring(0, 10);
			}

			List<AccountConfirmationModel> modelList = accountReassessmentConfirmationDao
					.getForcastRequestData(publicAcctNum, assmntDate, cimAccInfoId, DATE_FORMAT);

			if (modelList != null && !modelList.isEmpty()) {
				CustomerAccountInterestReqType request = getCustomerAccountInterestReqType(modelList, paramsArr[5], paramsArr[2], paramsArr[3]);
				logger.debug("Request JSON: "+ConvertToJsonUtil.convertToJson(request));
				
				CustomerAccountInterestRespType response = callInvoke(publicAcctNum, request, cimAccInfoId);
				
				if (response != null) {
					AccountForcastInterestPersistDaoImpl dao = new AccountForcastInterestPersistDaoImpl();
					dao.persistForcastInterest(response, modelList.get(0).getAgreementId(), modelList.get(0).getStmtDate());
				} else {
					statementProcessorARDao.updateStatusMessage(publicAcctNum, commonConfigHelper.readConfigData(externalClientConfig, "invokeCallFailure"), cimAccInfoId);
				}
			}else {
				logger.debug("[AccountForcastProcessBusinessImpl -- processForcastInterest] -- Else Block : No Data Found");
				throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_BUSINESS_ERROR_CODE,
						"[AccountForcastProcessBusinessImpl-processForcastInterest] Else Block", EXCEPTION_TEXT + "No Data Found", null, null, null);
			}
			mergePreFormatCall(assmntDate, publicAcctNum, cimAccInfoId);
		} catch (Exception e) {
			logger.error("[AccountForcastProcessBusinessImpl -- processForcastInterest] -- Exception: " + e);
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_BUSINESS_ERROR_CODE,
					"[AccountForcastProcessBusinessImpl-processForcastInterest] Exception Block", EXCEPTION_TEXT + e.getMessage(), null, null, e);
		}
		logger.debug("[AccountForcastProcessBusinessImpl -- processForcastInterest] -- End");
	}

	/**
	 * Purpose is to call MergePreFormat SP and update status of
	 * CIM_ACCOUNT_INFO_ID on success and failure
	 * 
	 * @param statementDate,custID,accountId
	 * @return void
	 * @throws StatementProcessorBatchException,
	 *             SQLException
	 * @throws SQLException
	 */
	public void mergePreFormatCall(String statementDate, String custID, String accountId) throws Exception {
		logger.debug("[AccountForcastProcessBusinessImpl -- mergePreFormatCall] -- Start");
		CommonConfigHelper commonConfigHelper = CommonConfigHelper.getInstance();
		ExternalFileDataConfiguration externalClientConfig = commonConfigHelper.loadPropertyConfig(StatementProcessorBatchConstants.AUDITLOG_CONFIGURATION_FILE_KEY);
		try {
			statementProcessorARDao.updateStatusMessage(custID, commonConfigHelper.readConfigData(externalClientConfig, "mergerPreformatSuccess"), accountId);
			accountReassessmentConfirmationDao.callMargePreformatSP(statementDate, custID, DATE_FORMAT);
		} catch (Exception e) {

			statementProcessorARDao.updateStatusMessage(custID, commonConfigHelper.readConfigData(externalClientConfig, "mergerPreformatFailure"), accountId);

			logger.debug("[AccountForcastProcessBusinessImpl -- mergePreFormatCall] -- Exception: " + e.getMessage());
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_BUSINESS_ERROR_CODE,
					"[AccountForcastProcessBusinessImpl-mergePreFormatCall] Exception Block", EXCEPTION_TEXT + e.getMessage(), null, null, e);
		}
		logger.debug("[AccountForcastProcessBusinessImpl -- mergePreFormatCall] -- End");
	}

	/**
	 * Purpose is to call CustomerAccountInterestAdapter.invoke() and set update
	 * estimatedInterest from invoke()
	 * @param retailId TODO
	 * 
	 * @param custID,AccountReassementModel,accountId
	 * @return CustomerAccountInterestRespType
	 * @throws StatementProcessorBatchException,
	 *             SQLException, JsonGenerationException, JsonMappingException,
	 *             IOException, ParseException
	 */
	public CustomerAccountInterestRespType callInvoke(String custID, CustomerAccountInterestReqType request, String accountId) throws Exception {
		logger.debug("[AccountForcastProcessBusinessImpl -- callInvoke] -- Start");
		CommonConfigHelper commonConfigHelper = CommonConfigHelper.getInstance();
		ExternalFileDataConfiguration externalClientConfig = commonConfigHelper.loadPropertyConfig(StatementProcessorBatchConstants.AUDITLOG_CONFIGURATION_FILE_KEY);

		CustomerAccountInterestRespType response = null;
		try {
			response = getCustomerAccountInterestAdapter().invoke(request);
			logger.debug("Response JSON: "+ConvertToJsonUtil.convertToJson(response));
			
		} catch (Exception e) {
			statementProcessorARDao.updateStatusMessage(custID, commonConfigHelper.readConfigData(externalClientConfig, "invokeCallFailure"), accountId);

			logger.error("[AccountForcastProcessBusinessImpl -- callInvoke] -- Exception: " + e);
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_BUSINESS_ERROR_CODE,
					"[AccountForcastProcessBusinessImpl-callInvoke] Exception Block", EXCEPTION_TEXT + e.getMessage(), null, null, e);
		}
		logger.debug("[AccountForcastProcessBusinessImpl -- callInvoke] -- End");
		return response;
	}

	/**
	 * Purpose is create request object for
	 * CustomerAccountInterestAdapter.invoke()
	 * 
	 * @param AccountReassessmentInfoModelList
	 * @return CustomerAccountInterestReqType
	 * @throws StatementProcessorBatchException
	 */
	public CustomerAccountInterestReqType getCustomerAccountInterestReqType(List<AccountConfirmationModel> modelList, String action, String rate, String date) throws StatementProcessorBatchException {
		logger.debug("[AccountForcastProcessBusinessImpl -- getCustomerAccountInterestReqType] -- Start");
		CustomerAccountInterestReqType customerAccIntReq = new CustomerAccountInterestReqType();
		
		try {
			for (AccountConfirmationModel model : modelList) {
				if(model!=null){
					if(model.getStmtDate()!=null){
						Calendar stmtDt = Calendar.getInstance();
						stmtDt.setTime(model.getStmtDate());
						customerAccIntReq.setCurrentDate(stmtDt);
					}
					if(model.getCurrTakeAmt()!=null)
						customerAccIntReq.setCurrentTakeAmount(model.getCurrTakeAmt());
					if(model.getCurrMinPayAmt()!=null)
						customerAccIntReq.setCurrentMinPayAmount(model.getCurrMinPayAmt());
					customerAccIntReq.setCustomer(setCustomerAccountType(model, action, rate, date));
				}else {
					logger.debug("[AccountForcastProcessBusinessImpl -- getCustomerAccountInterestReqType] -- Else Block : No Data Found");
					throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_BUSINESS_ERROR_CODE,
							"[AccountForcastProcessBusinessImpl-getCustomerAccountInterestReqType] Else Block", EXCEPTION_TEXT + "No Data Found", null, null, null);
				}
			}
		} catch (Exception e) {
			logger.error("[AccountForcastProcessBusinessImpl -- getCustomerAccountInterestReqType] -- Exception: " + e);
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_BUSINESS_ERROR_CODE,
					"[AccountForcastProcessBusinessImpl-getCustomerAccountInterestReqType] Exception Block", EXCEPTION_TEXT + e.getMessage(), null, null, e);
		}
		logger.debug("[AccountForcastProcessBusinessImpl -- getCustomerAccountInterestReqType] -- End");
		return customerAccIntReq;
	}

	/**
	 * Purpose is to set CustomerAccountType
	 * 
	 * @param model
	 * @return CustomerAccountType
	 * @throws StatementProcessorBatchException
	 * @throws ParseException 
	 */
	public CustomerAccountType setCustomerAccountType(AccountConfirmationModel model, String action, String rate, String date) throws StatementProcessorBatchException, ParseException {
		logger.debug("[AccountForcastProcessBusinessImpl -- setCustomerAccountType] -- Start");
		CustomerAccountType customerAccountType = new CustomerAccountType();

		if (model.getPayDueDate() != null) {
			Calendar dueDate = Calendar.getInstance();
			dueDate.setTime(model.getPayDueDate());
			customerAccountType.setPaymentDayOfMonth(dueDate.get(Calendar.DAY_OF_MONTH));
		}

		if (model.getOffsetDaysPdd() != null) {
			customerAccountType.setPaymentPeriod(model.getOffsetDaysPdd().intValue());
		}

		String brandType = model.getBrandType();
		if (brandType != null && !brandType.isEmpty()) {
			switch (brandType) {
			case "LEX":
				customerAccountType.setCode(BRAND_CODE.LEX);
				break;
			case "LAI":
				customerAccountType.setCode(BRAND_CODE.LAI);
				break;
			case "LWI":
				customerAccountType.setCode(BRAND_CODE.LWI);
				break;
			case "N47":
				customerAccountType.setCode(BRAND_CODE.N_47);
				break;
			default:
				throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_BUSINESS_ERROR_CODE,
						"[AccountForcastProcessBusinessImpl -- setCustomerAccountType]", "Invalid Brand Code", null, null, null);
			}
		}
		if(model.getNxtStmtDate()!=null){
			Calendar nxtStmtDt = Calendar.getInstance();
			nxtStmtDt.setTime(model.getNxtStmtDate());
			customerAccountType.setNextStatementDate(nxtStmtDt);
		}
		/*if(model.getDrawDownObjList().size()>0){
			if(model.getDrawDownObjList().get(0)!=null)
					customerAccountType.setCurrentOutstandingBalance(model.getDrawDownObjList().get(0).getOutStandingBalance());
			if(model.getDrawDownObjList().get(0)!=null){
				if(model.getDrawDownObjList().get(0).getPlnCurTerm()!=null)
					customerAccountType.setCurrentPeriod(model.getDrawDownObjList().get(0).getPlnCurTerm().intValue());
			}
		}*/
		
		customerAccountType.getDrawdowns().addAll(setDrawdowns(model, action, rate, date));
		logger.debug("[AccountForcastProcessBusinessImpl -- setCustomerAccountType] -- End");
		return customerAccountType;
	}

	/**
	 * Purpose is to set DrawdownTermsDirect
	 * 
	 * @param AccountConfirmationModel
	 * @return List<CurrentDDTWithTransactionsAndIncomesType>
	 * @throws ParseException 
	 */
	public List<CurrentDDTWithTransactionsAndIncomesType> setDrawdowns(AccountConfirmationModel model, String action, String rate, String date) throws StatementProcessorBatchException, ParseException {
		logger.debug("[AccountForcastProcessBusinessImpl -- setDrawdowns] -- Start");
		List<CurrentDDTWithTransactionsAndIncomesType> drawdowns = new ArrayList<>();

		List<DrawdownObj> modelDrawdownList = model.getDrawDownObjList();
		if (modelDrawdownList != null && !modelDrawdownList.isEmpty()) {
			for (DrawdownObj modelDD : modelDrawdownList) {
				CurrentDDTWithTransactionsAndIncomesType drawdown = new CurrentDDTWithTransactionsAndIncomesType();
				if(modelDD.getOsCap() !=null)
					drawdown.setCashPrice(modelDD.getOsCap());
				if (modelDD.getDrawdownCode() != null) {
					drawdown.setID(modelDD.getDrawdownCode().toString());
				}
				
				if (modelDD.getOutStandingBalance() != null) {
					drawdown.setCurrentOutStandingBalance(modelDD.getOutStandingBalance());
				}
				if (modelDD.getInstAmtInit() != null) {
					drawdown.setCurrentMonthPayment(modelDD.getInstAmtInit());
				}
				if (modelDD.getStartDate() != null) {
					Calendar chargeDate = Calendar.getInstance();
					chargeDate.setTime(modelDD.getStartDate());
					drawdown.setChargeDate(chargeDate);
				}
					
				drawdown.setCreditProduct(setDTBrandCreditProductDirect(modelDD, action, rate, date));
				
				drawdown.getTransactions().addAll(constructDDTransactions(modelDD));
				
				drawdown.getIncomes().addAll(constructDDIncome(modelDD));
				
				drawdowns.add(drawdown);
			}
		}

		logger.debug("[AccountForcastProcessBusinessImpl -- setDrawdowns] -- End");
		return drawdowns;

	}

	/**
	 * 
	 * @param drawdown
	 * @return the brandCreditProductType
	 * @throws StatementProcessorBatchException
	 * @throws ParseException 
	 */
	public BrandCreditProductType setDTBrandCreditProductDirect(DrawdownObj drawdown, String action, String rate, String date) throws StatementProcessorBatchException, ParseException {
		logger.debug("[AccountForcastProcessBusinessImpl -- setDTBrandCreditProductDirect] -- Start");
		BrandCreditProductType brandCreditProductType = new BrandCreditProductType();
		try{
			if (drawdown.getProdCode() != null && !drawdown.getProdCode().isEmpty()) 
				brandCreditProductType.setCode(BRAND_CREDIT_PRODUCT_CODE.fromValue(drawdown.getProdCode()));
			}
		catch(Exception e){
			logger.error("[AccountForcastProcessBusinessImpl -- setDTBrandCreditProductDirect]"+e);
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_BUSINESS_ERROR_CODE,
					"[AccountForcastProcessBusinessImpl -- setDTBrandCreditProductDirect]", "Invalid Brand Credit Product Code:"+drawdown.getProdCode(), null, null, null);
		}

		if (drawdown.getTermInMonths() != null) {
			brandCreditProductType.setTermInMonths(drawdown.getTermInMonths().intValue());
		}

		if (drawdown.getDeffTermInMonths() != null) {
			brandCreditProductType.setDeferredTermInMonths(drawdown.getDeffTermInMonths().intValue());
		}

		brandCreditProductType.getDailyRates().addAll(constructDailyRate(drawdown, action, rate, date));

		logger.debug("[AccountForcastProcessBusinessImpl -- setDTBrandCreditProductDirect] -- End");
		return brandCreditProductType;

	}
	

	/**
	 * Purpose is to set DailyRate data
	 * 
	 * @param DrawdownObj
	 * @return DailyRateType
	 * @throws ParseException 
	 */
	public List<DailyRateType> constructDailyRate(DrawdownObj drawdown, String action, String rate, String date) throws ParseException {
		logger.debug("[AccountForcastProcessBusinessImpl -- constructDailyRate] -- Start");
		List<DailyRateType> dailyRateList = new ArrayList<>();
		List<AirDir> airDirList = drawdown.getAirDirList();
		if (airDirList != null && !airDirList.isEmpty()) {
			for (AirDir airDir : airDirList) {
				DailyRateType dailyRateType = new DailyRateType();
				if (airDir.getBnplDir() != null && BigDecimal.ZERO.compareTo(airDir.getBnplDir()) != 0) {
					dailyRateType.setRate(airDir.getBnplDir());
				} else if (airDir.getNonBnplDir() != null && BigDecimal.ZERO.compareTo(airDir.getNonBnplDir()) != 0) {
					dailyRateType.setRate(airDir.getNonBnplDir());
				} else {
					dailyRateType.setRate(airDir.getDir());
				}

				if (airDir.getEffectiveDate() != null) {
					Calendar startDate = Calendar.getInstance();
					startDate.setTime(airDir.getEffectiveDate());
					dailyRateType.setStartDate(startDate);
				}
				dailyRateList.add(dailyRateType);
			}
		}
		if(action !=null){
			if(action.equalsIgnoreCase("CHANGE")){
				DailyRateType dailyRateTypeFuture = new DailyRateType();
				if (rate != null) {
					dailyRateTypeFuture.setRate(new BigDecimal(rate));
				} else {
					dailyRateTypeFuture.setRate(new BigDecimal(rate));
				}

				if (date != null) {
					SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);
					Date stmtDate = sdf.parse(date);
					Calendar startDate = Calendar.getInstance();
					startDate.setTime(stmtDate);
					dailyRateTypeFuture.setStartDate(startDate);
				}
				dailyRateList.add(dailyRateTypeFuture);
			}
		}
		
		logger.debug("[AccountForcastProcessBusinessImpl -- constructDailyRate] -- End");
		return dailyRateList;
	}

	/**
	 * Sets Drawdown-Transactions
	 * 
	 * @param DrawdownObj
	 * @return DDTTransactionType
	 */
	public List<DDTTransactionType> constructDDTransactions(DrawdownObj drawdown) {
		logger.debug("[AccountForcastProcessBusinessImpl -- constructDDTransactions] -- Start");
		List<DDTTransactionType> ddTransaction = new ArrayList<>();
		List<DrawdownTransaction> ddtranList = drawdown.getDdTranList();
		if (ddtranList != null && !ddtranList.isEmpty()) {
			int idCounter=0;
			for (DrawdownTransaction oneDDTranctn : ddtranList) {
				DDTTransactionType ddTransctnType = new DDTTransactionType();
				
				ddTransctnType.setID((new Integer(++idCounter)).toString());
				
				if(oneDDTranctn.getDdtType()!=null && !oneDDTranctn.getDdtType().isEmpty()){
					ddTransctnType.setType(oneDDTranctn.getDdtType());
				}
				if(oneDDTranctn.getDdtIncomeType()!=null && !oneDDTranctn.getDdtIncomeType().isEmpty()){
					ddTransctnType.setIncomeType(oneDDTranctn.getDdtIncomeType());
				}
				if(oneDDTranctn.getTransactionAmount()!=null && 
						BigDecimal.ZERO.compareTo(new BigDecimal(oneDDTranctn.getTransactionAmount())) != 0){
					ddTransctnType.setAmount(new BigDecimal(oneDDTranctn.getTransactionAmount()));
				}
				if(oneDDTranctn.getTransactionEffectiveDate()!=null){
					Calendar startDate = Calendar.getInstance();
					startDate.setTime(oneDDTranctn.getTransactionEffectiveDate());
					ddTransctnType.setDate(startDate);
				}
				
				ddTransaction.add(ddTransctnType);
			}
		}

		logger.debug("[AccountForcastProcessBusinessImpl -- constructDDTransactions] -- End");
		return ddTransaction;
	}
	
	/**
	 * Sets Drawdown-Income
	 * 
	 * @param DrawdownObj
	 * @return DDTIncomeType
	 */
	public List<DDTIncomeType> constructDDIncome(DrawdownObj drawdown) {
		logger.debug("[AccountForcastProcessBusinessImpl -- constructDDIncome] -- Start");
		List<DDTIncomeType> ddIncome = new ArrayList<>();
		List<DrawdownIncome> ddIncomeList = drawdown.getDdIncomeList();
		if (ddIncomeList != null && !ddIncomeList.isEmpty()) {
			int incmIdCounter = 0;
			for (DrawdownIncome oneDDIncome : ddIncomeList) {
				DDTIncomeType ddIncomeType = new DDTIncomeType();
				
				ddIncomeType.setID((new Integer(++incmIdCounter)).toString());
				
				if(oneDDIncome.getIncomeType()!=null && !oneDDIncome.getIncomeType().isEmpty());
					ddIncomeType.setType(oneDDIncome.getIncomeType());
				if(oneDDIncome.getOutstandingCapital()!=null && 
						BigDecimal.ZERO.compareTo(new BigDecimal(oneDDIncome.getOutstandingCapital())) != 0)
					ddIncomeType.setOutstandingCapital(new BigDecimal(oneDDIncome.getOutstandingCapital()));
				
				ddIncome.add(ddIncomeType);
			}
		}

		logger.debug("[AccountForcastProcessBusinessImpl -- constructDDIncome] -- End");
		return ddIncome;
	}
	
	public CustomerAccountInterestAdapter getCustomerAccountInterestAdapter() {
		if (this.customerAccountInterestAdapter != null) {
			return this.customerAccountInterestAdapter;
		}
		return new CustomerAccountInterestAdapter();
	}

	public void setCustomerAccountInterestAdapter(CustomerAccountInterestAdapter customerAccountInterestAdapter) {
		this.customerAccountInterestAdapter = customerAccountInterestAdapter;
	}

	public AccountForecastInterestRetreivalDao getAccountReassessmentConfirmationDao() throws StatementProcessorBatchException {
		if (this.accountReassessmentConfirmationDao != null) {
			return this.accountReassessmentConfirmationDao;
		}
		return new AccountForecastInterestRetreivalDao();
	}

	public void setAccountReassessmentConfirmationDao(AccountForecastInterestRetreivalDao accountReassessmentConfirmationDao) {
		this.accountReassessmentConfirmationDao = accountReassessmentConfirmationDao;
	}

	public StatementProcessorARDao getStatementProcessorARDao() throws StatementProcessorBatchException {
		if (this.statementProcessorARDao != null) {
			return this.statementProcessorARDao;
		}
		return new StatementProcessorARDao();
	}

	public void setStatementProcessorARDao(StatementProcessorARDao statementProcessorARDao) {
		this.statementProcessorARDao = statementProcessorARDao;
	}

}
