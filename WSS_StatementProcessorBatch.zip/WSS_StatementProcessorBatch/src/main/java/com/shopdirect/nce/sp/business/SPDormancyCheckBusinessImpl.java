package com.shopdirect.nce.sp.business;

import java.sql.SQLException;
import java.util.Date;

import com.shopdirect.nce.common.extcnfg.ExternalFileDataConfiguration;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.CustomerAccountInfo;
import com.shopdirect.nce.sp.util.SPDormancyCheckHelper;

/**
 * @author AyantikaBiswas
 *
 */
public class SPDormancyCheckBusinessImpl extends AccountReassessmentBaseBusinessImpl {
	
	private static final String STATUS_CODE_SIXTY = "STATUS_CODE_SIXTY";

	private static final String CREDIT_STATUS_D = "CREDIT_STATUS_D";

	private static final String STATUS_CODE_ZERO = "STATUS_CODE_ZERO";

	private static final String NON_LW_TIME_LIMIT_2 = "NON_LW_TIME_LIMIT_2";

	private static final String LW_TIME_LIMIT_2 = "LW_TIME_LIMIT_2";

	private static final String BRAND_CODE_LW = "BRAND_CODE_LW";

	private SPDormancyCheckHelper dormancyCheckHelper = null;
	
	private ExternalFileDataConfiguration dataConfig = null;
	String updateFlag;
	int daysBetween = 0;
	
	public SPDormancyCheckBusinessImpl() throws StatementProcessorBatchException, SQLException {
		super();
		 dormancyCheckHelper = new SPDormancyCheckHelper();
		 dataConfig = getCommonConfigHelper().loadPropertyConfig(StatementProcessorBatchConstants.DATA_CONFIGURATION_FILE_KEY);
	}
	
	public int getConfigIntData(String strProp) throws StatementProcessorBatchException {
		return Integer.parseInt(getCommonConfigHelper().readConfigData(getDataConfig(), strProp));
	}
	
	public String getConfigStrData(String strProp) throws StatementProcessorBatchException {

		 return getCommonConfigHelper().readConfigData(getDataConfig(),strProp );

	}
	/**
	 * @param custAccountInfoId
	 * @param creditAccountNo
	 * @param statementDate
	 * @param accountStatus
	 * @param brandCode
	 * @return
	 * @throws Exception
	 */
	public String process(CustomerAccountInfo customerAccountInfo) throws StatementProcessorBatchException {
		getLogger().debug("[SPDormancyCheckBusinessImpl -- process]  -- START");
		updateFlag = customerAccountInfo.getAccountStatus();
		
		try{
		String custAccountInfoId = customerAccountInfo.getAccountInfoId();
		String creditAccountNo = customerAccountInfo.getCreditAccountId(); 
		Date statementDate = customerAccountInfo.getStatementDate();
		String accountStatus = customerAccountInfo.getAccountStatus(); 
		String brandCode = customerAccountInfo.getBrandCode();
		String publicAccountNo = customerAccountInfo.getPublicAccountId(); 
		Date accountCreationDate = customerAccountInfo.getCreditStartDate();
		
		Date lastTransDate = dormancyCheckHelper.checkLastTransactionDt(publicAccountNo, statementDate);
		double custAccntBalance = dormancyCheckHelper.checkAccountBalance(creditAccountNo);
		String creditStatus = dormancyCheckHelper.checkCreditStatus(creditAccountNo);
		
		
		if(lastTransDate!= null){
			daysBetween = dormancyCheckHelper.calculateTime(statementDate, lastTransDate);
		}		
		

		if ((getConfigStrData(STATUS_CODE_ZERO).equals(accountStatus)) && (custAccntBalance == 0)) {
			updateStatForBalanceZero(brandCode, custAccountInfoId, creditAccountNo);
			
		}else if( (custAccntBalance == 0) && ((getConfigStrData(STATUS_CODE_SIXTY).equals(accountStatus) || getConfigStrData("STATUS_CODE_SEVENTY").equals(accountStatus)
				|| getConfigStrData("STATUS_CODE_SEVENTY_TWO").equals(accountStatus)))) {

				if (creditStatus.equals(getConfigStrData(CREDIT_STATUS_D))) {
					updateStatForNonZerostatusD(creditStatus, brandCode, daysBetween, custAccountInfoId, creditAccountNo, publicAccountNo, accountCreationDate, statementDate);
				
				} else if (!creditStatus.equals(getConfigStrData(CREDIT_STATUS_D))) {
					updateStatForNonZerostatusD(creditStatus, brandCode, daysBetween, custAccountInfoId, creditAccountNo, publicAccountNo, accountCreationDate, statementDate);
				}
			
		} else if(Double.compare(custAccntBalance, 0d) != 0 && getConfigStrData(STATUS_CODE_SIXTY).equals(accountStatus) || getConfigStrData("STATUS_CODE_SEVENTY").equals(accountStatus) 
				|| getConfigStrData("STATUS_CODE_SEVENTY_TWO").equals(accountStatus)) {
			updateFlag = getConfigStrData(STATUS_CODE_ZERO);
		}
		}

		catch (Exception exception) {    	
		    getLogger().error("[SPDormancyCheckBusinessImpl --process] Exception Block "+exception);
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.DORMANCYCHECK_BUSINESS_ERROR_CODE,
					"[SPDormancyCheckBusinessImpl] Exception Block",
					"Business exception generated at time to process the Dormancy check " + exception.getMessage(), StatementProcessorBatchConstants.ERROR_DORM_CHECK, null,
					exception);
		       
		 }
		 
		getLogger().debug("[SPDormancyCheckBusinessImpl -- process]  -- END");
		return updateFlag;
	}
	
	/**
	 * @param custAccntBalance
	 * @param creditStatus
	 * @param brandCode
	 * @param daysBetween
	 * @param custAccountInfoId
	 * @param creditAccountNo
	 * @throws Exception
	 */
	public String updateStatForNonZerostatusD(String creditStatus, String brandCode, int daysBetween,String custAccountInfoId, String creditAccountNo, String publicAccountNo, Date accountCreationDate, Date statementDate) throws StatementProcessorBatchException {
		
		
		if(getConfigStrData(CREDIT_STATUS_D).equals(creditStatus)){
		if (brandCode.equals(getConfigStrData(BRAND_CODE_LW))) {
				if (daysBetween >= getConfigIntData(LW_TIME_LIMIT_2)) {
					// termination , set new status 71
					updateFlag = getConfigStrData("STATUS_CODE_SEVENTY_ONE");
				} else {
					// set new status 0
					updateFlag = getConfigStrData(STATUS_CODE_ZERO);
				}
		} else if(!brandCode.equals(getConfigStrData(BRAND_CODE_LW))) {
				if (daysBetween >= getConfigIntData(NON_LW_TIME_LIMIT_2)) {
					// termination , set new status 71
					updateFlag = getConfigStrData("STATUS_CODE_SEVENTY_ONE");
				} else {
					// set new status 0
					updateFlag = getConfigStrData(STATUS_CODE_ZERO);
				}
		}
		} else {
			if (brandCode.equals(getConfigStrData(BRAND_CODE_LW))) {
				if (daysBetween >= getConfigIntData(LW_TIME_LIMIT_2)) {
					updateStatForNonZerostatusOther(creditStatus, brandCode, daysBetween, custAccountInfoId, creditAccountNo, publicAccountNo, accountCreationDate, statementDate);
				} else {
					// set new status 0
					updateFlag = getConfigStrData(STATUS_CODE_ZERO);
				}
		} else if(!brandCode.equals(getConfigStrData(BRAND_CODE_LW))) {
				if (daysBetween >= getConfigIntData(NON_LW_TIME_LIMIT_2)) {
					updateStatForNonZerostatusOther(creditStatus, brandCode, daysBetween, custAccountInfoId, creditAccountNo, publicAccountNo, accountCreationDate, statementDate);
				} else {
					// set new status 0
					updateFlag = getConfigStrData(STATUS_CODE_ZERO);
				}
		}
		}
		return updateFlag;

	}
	
	/**
	 * @param custAccntBalance
	 * @param creditStatus
	 * @param brandCode
	 * @param daysBetween
	 * @param custAccountInfoId
	 * @param creditAccountNo
	 * @throws Exception
	 */
	public String updateStatForNonZerostatusOther(String creditStatus, String brandCode, int daysBetween, String custAccountInfoId, String creditAccountNo, String publicAccountNo, Date accountCreationDate, Date statementDate) throws StatementProcessorBatchException {
		Date accntOpened = dormancyCheckHelper.checkAccntOpened(custAccountInfoId);
		Date lastOrderDate = dormancyCheckHelper.getLastOrderDate(publicAccountNo,accountCreationDate);
		int days = 0;
		if (lastOrderDate != null) {
			days = dormancyCheckHelper.calculateTime(lastOrderDate, accntOpened);
		}
		
		//int days = getConfigIntData("STUB_ORDER_DAYS");
		
		if ((brandCode.equals(getConfigStrData(BRAND_CODE_LW)))&&(daysBetween >= getConfigIntData(LW_TIME_LIMIT_2))){
			updateFlag = updateFinal(days,custAccountInfoId,creditAccountNo);
		} else if ((!brandCode.equals(getConfigStrData(BRAND_CODE_LW)))&&(daysBetween >= getConfigIntData(NON_LW_TIME_LIMIT_2))){
			updateFlag = updateFinal(days,custAccountInfoId,creditAccountNo);
		}
		return updateFlag;
	}

	/**
	 * @param custAccntBalance
	 * @param brandCode
	 * @param custAccountInfoId
	 * @param creditAccountNo
	 * @throws Exception
	 */
	public String updateStatForBalanceZero(String brandCode,String custAccountInfoId, String creditAccountNo) throws StatementProcessorBatchException {		
		if ((brandCode.equals(getConfigStrData(BRAND_CODE_LW)))&&(daysBetween >= getConfigIntData("LW_TIME_LIMIT_1")) ) {
				updateFlag = getConfigStrData(STATUS_CODE_SIXTY);
			
		} else if((!brandCode.equals(getConfigStrData(BRAND_CODE_LW)))&&(daysBetween >= getConfigIntData("NON_LW_TIME_LIMIT_1")) ) {
				// termination , set new status 60
				updateFlag =  getConfigStrData(STATUS_CODE_SIXTY);
			
		}		
		return updateFlag;		
	}	
	

	/**
	 * @param days
	 * @param custAccountInfoId
	 * @param creditAccountNo
	 * @return 
	 * @throws Exception
	 */
	public String updateFinal(int days, String custAccountInfoId, String creditAccountNo ) throws StatementProcessorBatchException {
		if (days < getConfigIntData("ORDERED_DAYS_LIMIT1")) {
			// set new status 72
			updateFlag = getConfigStrData("STATUS_CODE_SEVENTY_TWO");
		}
		else if(days > getConfigIntData("ORDERED_DAYS_LIMIT2")) {
			// new status 70
			updateFlag = getConfigStrData("STATUS_CODE_SEVENTY");
		}
		return updateFlag;
	}	
	/**
	 * @return the dormancyCheckHelper
	 */
	public SPDormancyCheckHelper getDormancyCheckHelper() {
		return dormancyCheckHelper;
	}
	/**
	 * @param dormancyCheckHelper the dormancyCheckHelper to set
	 */
	public void setDormancyCheckHelper(SPDormancyCheckHelper dormancyCheckHelper) {
		this.dormancyCheckHelper = dormancyCheckHelper;
	}
	/**
	 * @return the dataConfig
	 */
	public ExternalFileDataConfiguration getDataConfig() {
		return dataConfig;
	}
	/**
	 * @param dataConfig the dataConfig to set
	 */
	public void setDataConfig(ExternalFileDataConfiguration dataConfig) {
		this.dataConfig = dataConfig;
	}
	
	

}
