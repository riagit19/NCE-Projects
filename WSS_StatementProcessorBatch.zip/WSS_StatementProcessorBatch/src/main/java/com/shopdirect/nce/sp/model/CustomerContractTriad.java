package com.shopdirect.nce.sp.model;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.SQLData;
import java.sql.SQLException;
import java.sql.SQLInput;
import java.sql.SQLOutput;

public class CustomerContractTriad implements SQLData {

	private String sqlType;
	private BigDecimal triadCimDetailSID;         
	private Date createdTimestamp;           
	private BigDecimal recordID;         
	private Date creationDate;           
	private BigDecimal createdBy;         
	private BigDecimal lastUpdatedBy;         
	private Date lastUpdatedDate;           
	private String errorMessage; 
	private BigDecimal batchID;         
	private String interfaceStatus;
	private Date accountingDate;
	private Date creditLimitIncrDate;
	private Date lastAssessmentDate;
	private Date lastNumCode60Date;
	private BigDecimal consolidationLoanInd;
	private BigDecimal lastAssessmentFUPCode;
	private BigDecimal remit2Sales;
	private String accountStatusCode;    
	private Date accountStatusChangedDate;           
	private Date startDate;           
	private String brandCode;    
	private String creditStatusCode;    
	private String creditStatusSubCode;    
	private BigDecimal deceasedInd;      
	private String lastSpecialCommentCode;    
	private BigDecimal spID;      
	private BigDecimal staffType;      
	private BigDecimal accountTypeSID;     
	private Date dateOfBirth;           
	private BigDecimal doNotCreditCheckInd;         
	private BigDecimal mailOptOutPreferenceInd;      
	private BigDecimal phoneAddressInd;         
	private String emailAddress;   
	private BigDecimal creditLimitDecisionTypeSID;     
	private String brandTypeCode;    
	private BigDecimal dellCollQueue;         
	private BigDecimal authDigitsRangeLowerLimit;     
	private BigDecimal authDigitsRangeUpperLimit;     
	private Date accountClosedDate;           
	private Date credLimitIncDate;           
	private Date credLimitDecDate;           
	private Date accountRestartDate;           
	private Date startDellDate;           
	private Date endDellDate;           
	private Date actualDrdDate;           
	private Date credLineIncDate;           
	private Date credLineDecDate;           
	private Date migrationDate;           
	private Date creditLimitReviewedDate;           
	private BigDecimal shadowCreditMonetaryLimit;      
	private BigDecimal creditRiskFactor;    
	private BigDecimal highestCrf;    
	private BigDecimal creditLimitFrozenCode;      
	private BigDecimal alignedBehaviourScore;      
	private BigDecimal recruitCrf;    
	private BigDecimal lastFollowUpCode;   
	private BigDecimal numCredAccts;         
	private BigDecimal numAllAccts;         
	private BigDecimal bnplEligibility;      
	private BigDecimal creditBandInd1;         
	private BigDecimal collection_Method_Code;      
	private String accBlockCode;   
	private BigDecimal payRescInd;         
	private BigDecimal rawBehaviourScore;      
	private BigDecimal scorecardRefno;      
	private BigDecimal promiseToPayInd;      
	private BigDecimal creditLimitLastRev;      
	private BigDecimal collectionMethodCode;      
	private BigDecimal mobileNumInd;         
	private BigDecimal creditBandInd2;         
	private BigDecimal collAgencyReturnCode;      
	private BigDecimal creditBandInd3;         
	private BigDecimal clFrozenInd;         
	private BigDecimal tcuMonitorStatusCode;      
	private BigDecimal debitSaleFlag;      
	private Date lastPhoneCheckDate;           
	private BigDecimal telephoneNumber;     
	private BigDecimal acdScorecardRefno;      
	private BigDecimal acdRawScore;      
	private BigDecimal acdAlignedScore;      
	private BigDecimal ndrScorecardRefno;      
	private BigDecimal ndrRawScore;      
	private BigDecimal ndrAlignedScore;      
	private BigDecimal custScorecardRefno;      
	private BigDecimal custRawScore;      
	private BigDecimal custAlignedScore;      
	private Date firstCollStmtDate;           
	private BigDecimal collInd;      
	private BigDecimal dmInd;      
	private Date credLimitChgDate;           
	private String creditBand;    
	private BigDecimal collAuthInd;      
	private String creditBandScore;         
	private BigDecimal wksLastFollowUp;         
	private BigDecimal tcWks;         
	private BigDecimal numCode2;         
	private BigDecimal numCode4;         
	private BigDecimal numcode5;         
	private BigDecimal highFup6M;         
	private BigDecimal highFup12M;         
	private BigDecimal code5Last12;         
	private String creditStatusScore;         
	private BigDecimal worstFollowUpCode;      
	private BigDecimal lastFollowUpDays;      
	private BigDecimal tcDays;         
	private BigDecimal worstCrf3Score;         
	private BigDecimal worstCrf5Score;         
	private String retailAccountNumber;   
	private String publicAccountNumber;   
	private Date statementProducedDate;
	private String accountTypeCode;
	private BigDecimal applicationCreditScore;
	private BigDecimal procCode;
	private BigDecimal delqCollQueue;
	private String debtType;
	private String specialAttentionCode;
	
	public CustomerContractTriad() {
		//Default Constructor
	}
	
	
	public CustomerContractTriad(BigDecimal triadCimDetailSID, Date createdTimestamp, BigDecimal recordID,
			Date creationDate, BigDecimal createdBy, BigDecimal lastUpdatedBy, Date lastUpdatedDate,
			String errorMessage, BigDecimal batchID, String interfaceStatus, Date accountingDate,
			Date creditLimitIncrDate, Date lastAssessmentDate, Date lastNumCode60Date, BigDecimal consolidationLoanInd,
			BigDecimal lastAssessmentFUPCode, BigDecimal remit2Sales, String accountStatusCode,
			Date accountStatusChangedDate, Date startDate, String brandCode, String creditStatusCode,
			String creditStatusSubCode, BigDecimal deceasedInd, String lastSpecialCommentCode, BigDecimal spID,
			BigDecimal staffType, BigDecimal accountTypeSID, Date dateOfBirth, BigDecimal doNotCreditCheckInd,
			BigDecimal mailOptOutPreferenceInd, BigDecimal phoneAddressInd, String emailAddress,
			BigDecimal creditLimitDecisionTypeSID, String brandTypeCode, BigDecimal dellCollQueue,
			BigDecimal authDigitsRangeLowerLimit, BigDecimal authDigitsRangeUpperLimit, Date accountClosedDate,
			Date credLimitIncDate, Date credLimitDecDate, Date accountRestartDate, Date startDellDate, Date endDellDate,
			Date actualDrdDate, Date credLineIncDate, Date credLineDecDate, Date migrationDate,
			Date creditLimitReviewedDate, BigDecimal shadowCreditMonetaryLimit, BigDecimal creditRiskFactor,
			BigDecimal highestCrf, BigDecimal creditLimitFrozenCode, BigDecimal alignedBehaviourScore,
			BigDecimal recruitCrf, BigDecimal lastFollowUpCode, BigDecimal numCredAccts, BigDecimal numAllAccts,
			BigDecimal bnplEligibility, BigDecimal creditBandInd1, BigDecimal collection_Method_Code,
			String accBlockCode, BigDecimal payRescInd, BigDecimal rawBehaviourScore, BigDecimal scorecardRefno,
			BigDecimal promiseToPayInd, BigDecimal creditLimitLastRev, BigDecimal collectionMethodCode,
			BigDecimal mobileNumInd, BigDecimal creditBandInd2, BigDecimal collAgencyReturnCode,
			BigDecimal creditBandInd3, BigDecimal clFrozenInd, BigDecimal tcuMonitorStatusCode,
			BigDecimal debitSaleFlag, Date lastPhoneCheckDate, BigDecimal telephoneNumber, BigDecimal acdScorecardRefno,
			BigDecimal acdRawScore, BigDecimal acdAlignedScore, BigDecimal ndrScorecardRefno, BigDecimal ndrRawScore,
			BigDecimal ndrAlignedScore, BigDecimal custScorecardRefno, BigDecimal custRawScore,
			BigDecimal custAlignedScore, Date firstCollStmtDate, BigDecimal collInd, BigDecimal dmInd,
			Date credLimitChgDate, String creditBand, BigDecimal collAuthInd, String creditBandScore,
			BigDecimal wksLastFollowUp, BigDecimal tcWks, BigDecimal numCode2, BigDecimal numCode4, BigDecimal numcode5,
			BigDecimal highFup6M, BigDecimal highFup12M, BigDecimal code5Last12, String creditStatusScore,
			BigDecimal worstFollowUpCode, BigDecimal lastFollowUpDays, BigDecimal tcDays, BigDecimal worstCrf3Score,
			BigDecimal worstCrf5Score, String retailAccountNumber, String publicAccountNumber,
			Date statementProducedDate, String accountTypeCode, BigDecimal applicationCreditScore) {
		super();
		this.triadCimDetailSID = triadCimDetailSID;
		this.createdTimestamp = createdTimestamp;
		this.recordID = recordID;
		this.creationDate = creationDate;
		this.createdBy = createdBy;
		this.lastUpdatedBy = lastUpdatedBy;
		this.lastUpdatedDate = lastUpdatedDate;
		this.errorMessage = errorMessage;
		this.batchID = batchID;
		this.interfaceStatus = interfaceStatus;
		this.accountingDate = accountingDate;
		this.creditLimitIncrDate = creditLimitIncrDate;
		this.lastAssessmentDate = lastAssessmentDate;
		this.lastNumCode60Date = lastNumCode60Date;
		this.consolidationLoanInd = consolidationLoanInd;
		this.lastAssessmentFUPCode = lastAssessmentFUPCode;
		this.remit2Sales = remit2Sales;
		this.accountStatusCode = accountStatusCode;
		this.accountStatusChangedDate = accountStatusChangedDate;
		this.startDate = startDate;
		this.brandCode = brandCode;
		this.creditStatusCode = creditStatusCode;
		this.creditStatusSubCode = creditStatusSubCode;
		this.deceasedInd = deceasedInd;
		this.lastSpecialCommentCode = lastSpecialCommentCode;
		this.spID = spID;
		this.staffType = staffType;
		this.accountTypeSID = accountTypeSID;
		this.dateOfBirth = dateOfBirth;
		this.doNotCreditCheckInd = doNotCreditCheckInd;
		this.mailOptOutPreferenceInd = mailOptOutPreferenceInd;
		this.phoneAddressInd = phoneAddressInd;
		this.emailAddress = emailAddress;
		this.creditLimitDecisionTypeSID = creditLimitDecisionTypeSID;
		this.brandTypeCode = brandTypeCode;
		this.dellCollQueue = dellCollQueue;
		this.authDigitsRangeLowerLimit = authDigitsRangeLowerLimit;
		this.authDigitsRangeUpperLimit = authDigitsRangeUpperLimit;
		this.accountClosedDate = accountClosedDate;
		this.credLimitIncDate = credLimitIncDate;
		this.credLimitDecDate = credLimitDecDate;
		this.accountRestartDate = accountRestartDate;
		this.startDellDate = startDellDate;
		this.endDellDate = endDellDate;
		this.actualDrdDate = actualDrdDate;
		this.credLineIncDate = credLineIncDate;
		this.credLineDecDate = credLineDecDate;
		this.migrationDate = migrationDate;
		this.creditLimitReviewedDate = creditLimitReviewedDate;
		this.shadowCreditMonetaryLimit = shadowCreditMonetaryLimit;
		this.creditRiskFactor = creditRiskFactor;
		this.highestCrf = highestCrf;
		this.creditLimitFrozenCode = creditLimitFrozenCode;
		this.alignedBehaviourScore = alignedBehaviourScore;
		this.recruitCrf = recruitCrf;
		this.lastFollowUpCode = lastFollowUpCode;
		this.numCredAccts = numCredAccts;
		this.numAllAccts = numAllAccts;
		this.bnplEligibility = bnplEligibility;
		this.creditBandInd1 = creditBandInd1;
		this.collection_Method_Code = collection_Method_Code;
		this.accBlockCode = accBlockCode;
		this.payRescInd = payRescInd;
		this.rawBehaviourScore = rawBehaviourScore;
		this.scorecardRefno = scorecardRefno;
		this.promiseToPayInd = promiseToPayInd;
		this.creditLimitLastRev = creditLimitLastRev;
		this.collectionMethodCode = collectionMethodCode;
		this.mobileNumInd = mobileNumInd;
		this.creditBandInd2 = creditBandInd2;
		this.collAgencyReturnCode = collAgencyReturnCode;
		this.creditBandInd3 = creditBandInd3;
		this.clFrozenInd = clFrozenInd;
		this.tcuMonitorStatusCode = tcuMonitorStatusCode;
		this.debitSaleFlag = debitSaleFlag;
		this.lastPhoneCheckDate = lastPhoneCheckDate;
		this.telephoneNumber = telephoneNumber;
		this.acdScorecardRefno = acdScorecardRefno;
		this.acdRawScore = acdRawScore;
		this.acdAlignedScore = acdAlignedScore;
		this.ndrScorecardRefno = ndrScorecardRefno;
		this.ndrRawScore = ndrRawScore;
		this.ndrAlignedScore = ndrAlignedScore;
		this.custScorecardRefno = custScorecardRefno;
		this.custRawScore = custRawScore;
		this.custAlignedScore = custAlignedScore;
		this.firstCollStmtDate = firstCollStmtDate;
		this.collInd = collInd;
		this.dmInd = dmInd;
		this.credLimitChgDate = credLimitChgDate;
		this.creditBand = creditBand;
		this.collAuthInd = collAuthInd;
		this.creditBandScore = creditBandScore;
		this.wksLastFollowUp = wksLastFollowUp;
		this.tcWks = tcWks;
		this.numCode2 = numCode2;
		this.numCode4 = numCode4;
		this.numcode5 = numcode5;
		this.highFup6M = highFup6M;
		this.highFup12M = highFup12M;
		this.code5Last12 = code5Last12;
		this.creditStatusScore = creditStatusScore;
		this.worstFollowUpCode = worstFollowUpCode;
		this.lastFollowUpDays = lastFollowUpDays;
		this.tcDays = tcDays;
		this.worstCrf3Score = worstCrf3Score;
		this.worstCrf5Score = worstCrf5Score;
		this.retailAccountNumber = retailAccountNumber;
		this.publicAccountNumber = publicAccountNumber;
		this.statementProducedDate = statementProducedDate;
		this.accountTypeCode = accountTypeCode;
		this.applicationCreditScore = applicationCreditScore;
	}





	@Override
	public void readSQL(SQLInput stream, String typeName) throws SQLException {
		
		sqlType = typeName;
		setTriadCimDetailSID(stream.readBigDecimal());
		setAccountingDate(stream.readDate());
		setCreditLimitIncrDate(stream.readDate());
		setLastAssessmentDate(stream.readDate());
		setLastNumCode60Date(stream.readDate());
		setConsolidationLoanInd(stream.readBigDecimal());
		setLastAssessmentFUPCode(stream.readBigDecimal());
		setRemit2Sales(stream.readBigDecimal());
		setAccountStatusCode(stream.readString());
		setAccountStatusChangedDate(stream.readDate());
		setStartDate(stream.readDate());
		setBrandCode(stream.readString());
		setCreditStatusCode(stream.readString());
		setCreditStatusSubCode(stream.readString());
		setDeceasedInd(stream.readBigDecimal());
		setLastSpecialCommentCode(stream.readString());
		setSpID(stream.readBigDecimal());
		setStaffType(stream.readBigDecimal());
		setAccountTypeSID(stream.readBigDecimal());
		setDateOfBirth(stream.readDate());
		setDoNotCreditCheckInd(stream.readBigDecimal());
		setMailOptOutPreferenceInd(stream.readBigDecimal());
		setPhoneAddressInd(stream.readBigDecimal());
		setEmailAddress(stream.readString());
		setCreditLimitDecisionTypeSID(stream.readBigDecimal());
		setBrandTypeCode(stream.readString());
		setDellCollQueue(stream.readBigDecimal());
		setAuthDigitsRangeLowerLimit(stream.readBigDecimal());
		setAuthDigitsRangeUpperLimit(stream.readBigDecimal());
		setAccountClosedDate(stream.readDate());
		setCredLimitIncDate(stream.readDate());
		setCredLimitDecDate(stream.readDate());
		setAccountRestartDate(stream.readDate());
		setStartDellDate(stream.readDate());
		setEndDellDate(stream.readDate());
		setActualDrdDate(stream.readDate());
		setCredLineIncDate(stream.readDate());
		setCredLineDecDate(stream.readDate());
		setMigrationDate(stream.readDate());
		setCreditLimitReviewedDate(stream.readDate());
		setShadowCreditMonetaryLimit(stream.readBigDecimal());
		setCreditRiskFactor(stream.readBigDecimal());
		setHighestCrf(stream.readBigDecimal());
		setCreditLimitFrozenCode(stream.readBigDecimal());
		setAlignedBehaviourScore(stream.readBigDecimal());
		setRecruitCrf(stream.readBigDecimal());
		setLastFollowUpCode(stream.readBigDecimal());
		setNumCredAccts(stream.readBigDecimal());
		setNumAllAccts(stream.readBigDecimal());
		setBnplEligibility(stream.readBigDecimal());
		setCreditBandInd1(stream.readBigDecimal());
		setCollection_Method_Code(stream.readBigDecimal());
		setAccBlockCode(stream.readString());
		setPayRescInd(stream.readBigDecimal());
		setRawBehaviourScore(stream.readBigDecimal());
		setScorecardRefno(stream.readBigDecimal());
		setPromiseToPayInd(stream.readBigDecimal());
		setCreditLimitLastRev(stream.readBigDecimal());
		setCollectionMethodCode(stream.readBigDecimal());
		setMobileNumInd(stream.readBigDecimal());
		setCreditBandInd2(stream.readBigDecimal());
		setCollAgencyReturnCode(stream.readBigDecimal());
		setCreditBandInd3(stream.readBigDecimal());
		setClFrozenInd(stream.readBigDecimal());
		setTcuMonitorStatusCode(stream.readBigDecimal());
		setDebitSaleFlag(stream.readBigDecimal());
		setLastPhoneCheckDate(stream.readDate());
		setTelephoneNumber(stream.readBigDecimal());
		setAcdScorecardRefno(stream.readBigDecimal());
		setAcdRawScore(stream.readBigDecimal());
		setAcdAlignedScore(stream.readBigDecimal());
		setNdrScorecardRefno(stream.readBigDecimal());
		setNdrRawScore(stream.readBigDecimal());
		setNdrAlignedScore(stream.readBigDecimal());
		setCustScorecardRefno(stream.readBigDecimal());
		setCustRawScore(stream.readBigDecimal());
		setCustAlignedScore(stream.readBigDecimal());
		setFirstCollStmtDate(stream.readDate());
		setCollInd(stream.readBigDecimal());
		setDmInd(stream.readBigDecimal());
		setCredLimitChgDate(stream.readDate());
		setCreditBand(stream.readString());
		setCollAuthInd(stream.readBigDecimal());
		setCreditBandScore(stream.readString());
		setWksLastFollowUp(stream.readBigDecimal());
		setTcWks(stream.readBigDecimal());
		setNumCode2(stream.readBigDecimal());
		setNumCode4(stream.readBigDecimal());
		setNumcode5(stream.readBigDecimal());
		setHighFup6M(stream.readBigDecimal());
		setHighFup12M(stream.readBigDecimal());
		setCode5Last12(stream.readBigDecimal());
		setCreditStatusScore(stream.readString());
		setWorstFollowUpCode(stream.readBigDecimal());
		setLastFollowUpDays(stream.readBigDecimal());
		setTcDays(stream.readBigDecimal());
		setWorstCrf3Score(stream.readBigDecimal());
		setWorstCrf5Score(stream.readBigDecimal());
		setRetailAccountNumber(stream.readString());
		setPublicAccountNumber(stream.readString());
		setStatementProducedDate(stream.readDate());
		
	}
	
	@Override
	public void writeSQL(SQLOutput stream) throws SQLException {
		
	}

	@Override
	public String getSQLTypeName() throws SQLException {
		return sqlType;
	}

	public String getSqlType() {
		return sqlType;
	}

	public void setSqlType(String sqlType) {
		this.sqlType = sqlType;
	}
	
	public BigDecimal getTriadCimDetailSID() {
		return triadCimDetailSID;
	}
	public void setTriadCimDetailSID(BigDecimal triadCimDetailSID) {
		this.triadCimDetailSID = triadCimDetailSID;
	}
	public Date getCreatedTimestamp() {
		return createdTimestamp;
	}
	public void setCreatedTimestamp(Date createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}
	public BigDecimal getRecordID() {
		return recordID;
	}
	public void setRecordID(BigDecimal recordID) {
		this.recordID = recordID;
	}
	public Date getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}
	public BigDecimal getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(BigDecimal createdBy) {
		this.createdBy = createdBy;
	}
	public BigDecimal getLastUpdatedBy() {
		return lastUpdatedBy;
	}
	public void setLastUpdatedBy(BigDecimal lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}
	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}
	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public BigDecimal getBatchID() {
		return batchID;
	}
	public void setBatchID(BigDecimal batchID) {
		this.batchID = batchID;
	}
	public String getInterfaceStatus() {
		return interfaceStatus;
	}
	public void setInterfaceStatus(String interfaceStatus) {
		this.interfaceStatus = interfaceStatus;
	}
	public Date getAccountingDate() {
		return accountingDate;
	}


	public void setAccountingDate(Date accountingDate) {
		this.accountingDate = accountingDate;
	}


	public Date getCreditLimitIncrDate() {
		return creditLimitIncrDate;
	}


	public void setCreditLimitIncrDate(Date creditLimitIncrDate) {
		this.creditLimitIncrDate = creditLimitIncrDate;
	}


	public Date getLastAssessmentDate() {
		return lastAssessmentDate;
	}


	public void setLastAssessmentDate(Date lastAssessmentDate) {
		this.lastAssessmentDate = lastAssessmentDate;
	}


	public Date getLastNumCode60Date() {
		return lastNumCode60Date;
	}


	public void setLastNumCode60Date(Date lastNumCode60Date) {
		this.lastNumCode60Date = lastNumCode60Date;
	}


	public BigDecimal getConsolidationLoanInd() {
		return consolidationLoanInd;
	}


	public void setConsolidationLoanInd(BigDecimal consolidationLoanInd) {
		this.consolidationLoanInd = consolidationLoanInd;
	}


	public BigDecimal getLastAssessmentFUPCode() {
		return lastAssessmentFUPCode;
	}


	public void setLastAssessmentFUPCode(BigDecimal lastAssessmentFUPCode) {
		this.lastAssessmentFUPCode = lastAssessmentFUPCode;
	}


	public BigDecimal getRemit2Sales() {
		return remit2Sales;
	}


	public void setRemit2Sales(BigDecimal remit2Sales) {
		this.remit2Sales = remit2Sales;
	}


	public String getAccountStatusCode() {
		return accountStatusCode;
	}
	public void setAccountStatusCode(String accountStatusCode) {
		this.accountStatusCode = accountStatusCode;
	}
	public Date getAccountStatusChangedDate() {
		return accountStatusChangedDate;
	}
	public void setAccountStatusChangedDate(Date accountStatusChangedDate) {
		this.accountStatusChangedDate = accountStatusChangedDate;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public String getBrandCode() {
		return brandCode;
	}
	public void setBrandCode(String brandCode) {
		this.brandCode = brandCode;
	}
	public String getCreditStatusCode() {
		return creditStatusCode;
	}
	public void setCreditStatusCode(String creditStatusCode) {
		this.creditStatusCode = creditStatusCode;
	}
	public String getCreditStatusSubCode() {
		return creditStatusSubCode;
	}
	public void setCreditStatusSubCode(String creditStatusSubCode) {
		this.creditStatusSubCode = creditStatusSubCode;
	}
	public BigDecimal getDeceasedInd() {
		return deceasedInd;
	}
	public void setDeceasedInd(BigDecimal deceasedInd) {
		this.deceasedInd = deceasedInd;
	}
	public String getLastSpecialCommentCode() {
		return lastSpecialCommentCode;
	}
	public void setLastSpecialCommentCode(String lastSpecialCommentCode) {
		this.lastSpecialCommentCode = lastSpecialCommentCode;
	}
	public BigDecimal getSpID() {
		return spID;
	}
	public void setSpID(BigDecimal spID) {
		this.spID = spID;
	}
	public BigDecimal getStaffType() {
		return staffType;
	}
	public void setStaffType(BigDecimal staffType) {
		this.staffType = staffType;
	}
	public BigDecimal getAccountTypeSID() {
		return accountTypeSID;
	}
	public void setAccountTypeSID(BigDecimal accountTypeSID) {
		this.accountTypeSID = accountTypeSID;
	}
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public BigDecimal getDoNotCreditCheckInd() {
		return doNotCreditCheckInd;
	}
	public void setDoNotCreditCheckInd(BigDecimal doNotCreditCheckInd) {
		this.doNotCreditCheckInd = doNotCreditCheckInd;
	}
	public BigDecimal getMailOptOutPreferenceInd() {
		return mailOptOutPreferenceInd;
	}
	public void setMailOptOutPreferenceInd(BigDecimal mailOptOutPreferenceInd) {
		this.mailOptOutPreferenceInd = mailOptOutPreferenceInd;
	}
	public BigDecimal getPhoneAddressInd() {
		return phoneAddressInd;
	}
	public void setPhoneAddressInd(BigDecimal phoneAddressInd) {
		this.phoneAddressInd = phoneAddressInd;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public BigDecimal getCreditLimitDecisionTypeSID() {
		return creditLimitDecisionTypeSID;
	}
	public void setCreditLimitDecisionTypeSID(BigDecimal creditLimitDecisionTypeSID) {
		this.creditLimitDecisionTypeSID = creditLimitDecisionTypeSID;
	}
	public String getBrandTypeCode() {
		return brandTypeCode;
	}
	public void setBrandTypeCode(String brandTypeCode) {
		this.brandTypeCode = brandTypeCode;
	}
	public BigDecimal getDellCollQueue() {
		return dellCollQueue;
	}
	public void setDellCollQueue(BigDecimal dellCollQueue) {
		this.dellCollQueue = dellCollQueue;
	}
	public BigDecimal getAuthDigitsRangeLowerLimit() {
		return authDigitsRangeLowerLimit;
	}
	public void setAuthDigitsRangeLowerLimit(BigDecimal authDigitsRangeLowerLimit) {
		this.authDigitsRangeLowerLimit = authDigitsRangeLowerLimit;
	}
	public BigDecimal getAuthDigitsRangeUpperLimit() {
		return authDigitsRangeUpperLimit;
	}
	public void setAuthDigitsRangeUpperLimit(BigDecimal authDigitsRangeUpperLimit) {
		this.authDigitsRangeUpperLimit = authDigitsRangeUpperLimit;
	}
	public Date getAccountClosedDate() {
		return accountClosedDate;
	}
	public void setAccountClosedDate(Date accountClosedDate) {
		this.accountClosedDate = accountClosedDate;
	}
	public Date getCredLimitIncDate() {
		return credLimitIncDate;
	}
	public void setCredLimitIncDate(Date credLimitIncDate) {
		this.credLimitIncDate = credLimitIncDate;
	}
	public Date getCredLimitDecDate() {
		return credLimitDecDate;
	}
	public void setCredLimitDecDate(Date credLimitDecDate) {
		this.credLimitDecDate = credLimitDecDate;
	}
	public Date getAccountRestartDate() {
		return accountRestartDate;
	}
	public void setAccountRestartDate(Date accountRestartDate) {
		this.accountRestartDate = accountRestartDate;
	}
	public Date getStartDellDate() {
		return startDellDate;
	}
	public void setStartDellDate(Date startDellDate) {
		this.startDellDate = startDellDate;
	}
	public Date getEndDellDate() {
		return endDellDate;
	}
	public void setEndDellDate(Date endDellDate) {
		this.endDellDate = endDellDate;
	}
	public Date getActualDrdDate() {
		return actualDrdDate;
	}
	public void setActualDrdDate(Date actualDrdDate) {
		this.actualDrdDate = actualDrdDate;
	}
	public Date getCredLineIncDate() {
		return credLineIncDate;
	}
	public void setCredLineIncDate(Date credLineIncDate) {
		this.credLineIncDate = credLineIncDate;
	}
	public Date getCredLineDecDate() {
		return credLineDecDate;
	}
	public void setCredLineDecDate(Date credLineDecDate) {
		this.credLineDecDate = credLineDecDate;
	}
	public Date getMigrationDate() {
		return migrationDate;
	}
	public void setMigrationDate(Date migrationDate) {
		this.migrationDate = migrationDate;
	}
	public Date getCreditLimitReviewedDate() {
		return creditLimitReviewedDate;
	}
	public void setCreditLimitReviewedDate(Date creditLimitReviewedDate) {
		this.creditLimitReviewedDate = creditLimitReviewedDate;
	}
	public BigDecimal getShadowCreditMonetaryLimit() {
		return shadowCreditMonetaryLimit;
	}
	public void setShadowCreditMonetaryLimit(BigDecimal shadowCreditMonetaryLimit) {
		this.shadowCreditMonetaryLimit = shadowCreditMonetaryLimit;
	}
	public BigDecimal getCreditRiskFactor() {
		return creditRiskFactor;
	}
	public void setCreditRiskFactor(BigDecimal creditRiskFactor) {
		this.creditRiskFactor = creditRiskFactor;
	}
	public BigDecimal getHighestCrf() {
		return highestCrf;
	}
	public void setHighestCrf(BigDecimal highestCrf) {
		this.highestCrf = highestCrf;
	}
	public BigDecimal getCreditLimitFrozenCode() {
		return creditLimitFrozenCode;
	}
	public void setCreditLimitFrozenCode(BigDecimal creditLimitFrozenCode) {
		this.creditLimitFrozenCode = creditLimitFrozenCode;
	}
	public BigDecimal getAlignedBehaviourScore() {
		return alignedBehaviourScore;
	}
	public void setAlignedBehaviourScore(BigDecimal alignedBehaviourScore) {
		this.alignedBehaviourScore = alignedBehaviourScore;
	}
	public BigDecimal getRecruitCrf() {
		return recruitCrf;
	}
	public void setRecruitCrf(BigDecimal recruitCrf) {
		this.recruitCrf = recruitCrf;
	}
	public BigDecimal getLastFollowUpCode() {
		return lastFollowUpCode;
	}
	public void setLastFollowUpCode(BigDecimal lastFollowUpCode) {
		this.lastFollowUpCode = lastFollowUpCode;
	}
	public BigDecimal getNumCredAccts() {
		return numCredAccts;
	}
	public void setNumCredAccts(BigDecimal numCredAccts) {
		this.numCredAccts = numCredAccts;
	}
	public BigDecimal getNumAllAccts() {
		return numAllAccts;
	}
	public void setNumAllAccts(BigDecimal numAllAccts) {
		this.numAllAccts = numAllAccts;
	}
	public BigDecimal getBnplEligibility() {
		return bnplEligibility;
	}
	public void setBnplEligibility(BigDecimal bnplEligibility) {
		this.bnplEligibility = bnplEligibility;
	}
	public BigDecimal getCreditBandInd1() {
		return creditBandInd1;
	}
	public void setCreditBandInd1(BigDecimal creditBandInd1) {
		this.creditBandInd1 = creditBandInd1;
	}
	public BigDecimal getCollection_Method_Code() {
		return collection_Method_Code;
	}
	public void setCollection_Method_Code(BigDecimal collection_Method_Code) {
		this.collection_Method_Code = collection_Method_Code;
	}
	public String getAccBlockCode() {
		return accBlockCode;
	}
	public void setAccBlockCode(String accBlockCode) {
		this.accBlockCode = accBlockCode;
	}
	public BigDecimal getPayRescInd() {
		return payRescInd;
	}
	public void setPayRescInd(BigDecimal payRescInd) {
		this.payRescInd = payRescInd;
	}
	public BigDecimal getRawBehaviourScore() {
		return rawBehaviourScore;
	}
	public void setRawBehaviourScore(BigDecimal rawBehaviourScore) {
		this.rawBehaviourScore = rawBehaviourScore;
	}
	public BigDecimal getScorecardRefno() {
		return scorecardRefno;
	}
	public void setScorecardRefno(BigDecimal scorecardRefno) {
		this.scorecardRefno = scorecardRefno;
	}
	public BigDecimal getPromiseToPayInd() {
		return promiseToPayInd;
	}
	public void setPromiseToPayInd(BigDecimal promiseToPayInd) {
		this.promiseToPayInd = promiseToPayInd;
	}
	public BigDecimal getCreditLimitLastRev() {
		return creditLimitLastRev;
	}
	public void setCreditLimitLastRev(BigDecimal creditLimitLastRev) {
		this.creditLimitLastRev = creditLimitLastRev;
	}
	public BigDecimal getCollectionMethodCode() {
		return collectionMethodCode;
	}
	public void setCollectionMethodCode(BigDecimal collectionMethodCode) {
		this.collectionMethodCode = collectionMethodCode;
	}
	public BigDecimal getMobileNumInd() {
		return mobileNumInd;
	}
	public void setMobileNumInd(BigDecimal mobileNumInd) {
		this.mobileNumInd = mobileNumInd;
	}
	public BigDecimal getCreditBandInd2() {
		return creditBandInd2;
	}
	public void setCreditBandInd2(BigDecimal creditBandInd2) {
		this.creditBandInd2 = creditBandInd2;
	}
	public BigDecimal getCollAgencyReturnCode() {
		return collAgencyReturnCode;
	}
	public void setCollAgencyReturnCode(BigDecimal collAgencyReturnCode) {
		this.collAgencyReturnCode = collAgencyReturnCode;
	}
	public BigDecimal getCreditBandInd3() {
		return creditBandInd3;
	}
	public void setCreditBandInd3(BigDecimal creditBandInd3) {
		this.creditBandInd3 = creditBandInd3;
	}
	public BigDecimal getClFrozenInd() {
		return clFrozenInd;
	}
	public void setClFrozenInd(BigDecimal clFrozenInd) {
		this.clFrozenInd = clFrozenInd;
	}
	public BigDecimal getTcuMonitorStatusCode() {
		return tcuMonitorStatusCode;
	}
	public void setTcuMonitorStatusCode(BigDecimal tcuMonitorStatusCode) {
		this.tcuMonitorStatusCode = tcuMonitorStatusCode;
	}
	public BigDecimal getDebitSaleFlag() {
		return debitSaleFlag;
	}
	public void setDebitSaleFlag(BigDecimal debitSaleFlag) {
		this.debitSaleFlag = debitSaleFlag;
	}
	public Date getLastPhoneCheckDate() {
		return lastPhoneCheckDate;
	}
	public void setLastPhoneCheckDate(Date lastPhoneCheckDate) {
		this.lastPhoneCheckDate = lastPhoneCheckDate;
	}
	public BigDecimal getTelephoneNumber() {
		return telephoneNumber;
	}
	public void setTelephoneNumber(BigDecimal telephoneNumber) {
		this.telephoneNumber = telephoneNumber;
	}
	public BigDecimal getAcdScorecardRefno() {
		return acdScorecardRefno;
	}
	public void setAcdScorecardRefno(BigDecimal acdScorecardRefno) {
		this.acdScorecardRefno = acdScorecardRefno;
	}
	public BigDecimal getAcdRawScore() {
		return acdRawScore;
	}
	public void setAcdRawScore(BigDecimal acdRawScore) {
		this.acdRawScore = acdRawScore;
	}
	public BigDecimal getAcdAlignedScore() {
		return acdAlignedScore;
	}
	public void setAcdAlignedScore(BigDecimal acdAlignedScore) {
		this.acdAlignedScore = acdAlignedScore;
	}
	public BigDecimal getNdrScorecardRefno() {
		return ndrScorecardRefno;
	}
	public void setNdrScorecardRefno(BigDecimal ndrScorecardRefno) {
		this.ndrScorecardRefno = ndrScorecardRefno;
	}
	public BigDecimal getNdrRawScore() {
		return ndrRawScore;
	}
	public void setNdrRawScore(BigDecimal ndrRawScore) {
		this.ndrRawScore = ndrRawScore;
	}
	public BigDecimal getNdrAlignedScore() {
		return ndrAlignedScore;
	}
	public void setNdrAlignedScore(BigDecimal ndrAlignedScore) {
		this.ndrAlignedScore = ndrAlignedScore;
	}
	public BigDecimal getCustScorecardRefno() {
		return custScorecardRefno;
	}
	public void setCustScorecardRefno(BigDecimal custScorecardRefno) {
		this.custScorecardRefno = custScorecardRefno;
	}
	public BigDecimal getCustRawScore() {
		return custRawScore;
	}
	public void setCustRawScore(BigDecimal custRawScore) {
		this.custRawScore = custRawScore;
	}
	public BigDecimal getCustAlignedScore() {
		return custAlignedScore;
	}
	public void setCustAlignedScore(BigDecimal custAlignedScore) {
		this.custAlignedScore = custAlignedScore;
	}
	public Date getFirstCollStmtDate() {
		return firstCollStmtDate;
	}
	public void setFirstCollStmtDate(Date firstCollStmtDate) {
		this.firstCollStmtDate = firstCollStmtDate;
	}
	public BigDecimal getCollInd() {
		return collInd;
	}
	public void setCollInd(BigDecimal collInd) {
		this.collInd = collInd;
	}
	public BigDecimal getDmInd() {
		return dmInd;
	}
	public void setDmInd(BigDecimal dmInd) {
		this.dmInd = dmInd;
	}
	public Date getCredLimitChgDate() {
		return credLimitChgDate;
	}
	public void setCredLimitChgDate(Date credLimitChgDate) {
		this.credLimitChgDate = credLimitChgDate;
	}
	public String getCreditBand() {
		return creditBand;
	}
	public void setCreditBand(String creditBand) {
		this.creditBand = creditBand;
	}
	public BigDecimal getCollAuthInd() {
		return collAuthInd;
	}
	public void setCollAuthInd(BigDecimal collAuthInd) {
		this.collAuthInd = collAuthInd;
	}
	public String getCreditBandScore() {
		return creditBandScore;
	}
	public void setCreditBandScore(String creditBandScore) {
		this.creditBandScore = creditBandScore;
	}
	public BigDecimal getWksLastFollowUp() {
		return wksLastFollowUp;
	}
	public void setWksLastFollowUp(BigDecimal wksLastFollowUp) {
		this.wksLastFollowUp = wksLastFollowUp;
	}
	public BigDecimal getTcWks() {
		return tcWks;
	}
	public void setTcWks(BigDecimal tcWks) {
		this.tcWks = tcWks;
	}
	public BigDecimal getNumCode2() {
		return numCode2;
	}
	public void setNumCode2(BigDecimal numCode2) {
		this.numCode2 = numCode2;
	}
	public BigDecimal getNumCode4() {
		return numCode4;
	}
	public void setNumCode4(BigDecimal numCode4) {
		this.numCode4 = numCode4;
	}
	public BigDecimal getNumcode5() {
		return numcode5;
	}
	public void setNumcode5(BigDecimal numcode5) {
		this.numcode5 = numcode5;
	}
	public BigDecimal getHighFup6M() {
		return highFup6M;
	}
	public void setHighFup6M(BigDecimal highFup6M) {
		this.highFup6M = highFup6M;
	}
	public BigDecimal getHighFup12M() {
		return highFup12M;
	}
	public void setHighFup12M(BigDecimal highFup12M) {
		this.highFup12M = highFup12M;
	}
	public BigDecimal getCode5Last12() {
		return code5Last12;
	}
	public void setCode5Last12(BigDecimal code5Last12) {
		this.code5Last12 = code5Last12;
	}
	public String getCreditStatusScore() {
		return creditStatusScore;
	}
	public void setCreditStatusScore(String creditStatusScore) {
		this.creditStatusScore = creditStatusScore;
	}
	public BigDecimal getWorstFollowUpCode() {
		return worstFollowUpCode;
	}
	public void setWorstFollowUpCode(BigDecimal worstFollowUpCode) {
		this.worstFollowUpCode = worstFollowUpCode;
	}
	public BigDecimal getLastFollowUpDays() {
		return lastFollowUpDays;
	}
	public void setLastFollowUpDays(BigDecimal lastFollowUpDays) {
		this.lastFollowUpDays = lastFollowUpDays;
	}
	public BigDecimal getTcDays() {
		return tcDays;
	}
	public void setTcDays(BigDecimal tcDays) {
		this.tcDays = tcDays;
	}
	public BigDecimal getWorstCrf3Score() {
		return worstCrf3Score;
	}
	public void setWorstCrf3Score(BigDecimal worstCrf3Score) {
		this.worstCrf3Score = worstCrf3Score;
	}
	public BigDecimal getWorstCrf5Score() {
		return worstCrf5Score;
	}
	public void setWorstCrf5Score(BigDecimal worstCrf5Score) {
		this.worstCrf5Score = worstCrf5Score;
	}
	public String getRetailAccountNumber() {
		return retailAccountNumber;
	}
	public void setRetailAccountNumber(String retailAccountNumber) {
		this.retailAccountNumber = retailAccountNumber;
	}
	public String getPublicAccountNumber() {
		return publicAccountNumber;
	}
	public void setPublicAccountNumber(String publicAccountNumber) {
		this.publicAccountNumber = publicAccountNumber;
	}
	public Date getStatementProducedDate() {
		return statementProducedDate;
	}
	public void setStatementProducedDate(Date statementProducedDate) {
		this.statementProducedDate = statementProducedDate;
	}


	public String getAccountTypeCode() {
		return accountTypeCode;
	}


	public void setAccountTypeCode(String accountTypeCode) {
		this.accountTypeCode = accountTypeCode;
	}


	public BigDecimal getApplicationCreditScore() {
		return applicationCreditScore;
	}


	public void setApplicationCreditScore(BigDecimal applicationCreditScore) {
		this.applicationCreditScore = applicationCreditScore;
	}


	public BigDecimal getProcCode() {
		return procCode;
	}


	public void setProcCode(BigDecimal procCode) {
		this.procCode = procCode;
	}


	public BigDecimal getDelqCollQueue() {
		return delqCollQueue;
	}


	public void setDelqCollQueue(BigDecimal delqCollQueue) {
		this.delqCollQueue = delqCollQueue;
	}


	public String getDebtType() {
		return debtType;
	}


	public void setDebtType(String debtType) {
		this.debtType = debtType;
	}


	public String getSpecialAttentionCode() {
		return specialAttentionCode;
	}


	public void setSpecialAttentionCode(String specialAttentionCode) {
		this.specialAttentionCode = specialAttentionCode;
	}
}
