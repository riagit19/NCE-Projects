package com.shopdirect.nce.sp.transform;

import java.math.BigInteger;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.model.BatchDetails;
import com.shopdirect.nce.sp.model.CustomerAccountInfo;
import com.shopdirect.osb.reassesstriadar.AccountDetailType;
import com.shopdirect.osb.reassesstriadar.GetCRDRDataType;
import com.shopdirect.osb.reassesstriadar.ReassessTRIADARType;

public class CRDRDataTransformer {

	private static SDLoggerImpl logger = new SDLoggerImpl();
	
	public void transformCRDRDataType(ReassessTRIADARType reassessTriadType, CustomerAccountInfo accountInfo, 
			BatchDetails batchDetails, String callType) {
		logger.debug("[CRDRDataTransformer -- transformCRDRDataType] -- Start");
		
		GetCRDRDataType crdrData = new GetCRDRDataType();
		AccountDetailType accountDetails = new AccountDetailType();
		crdrData.setAccountDetail(accountDetails);
		reassessTriadType.setGetCRDRData(crdrData);
		
		BigInteger callTypeIntValue = null;
		if (callType != null) {
			try {
				callTypeIntValue = new BigInteger(callType);
			} catch (NumberFormatException nfe){
				logger.error("[CRDRDataTransformer -- transformCRDRDataType] - callType should be int " + nfe);
			}
		}
		
		accountDetails.setAccountNumber(accountInfo.getPublicAccountId());
		accountDetails.setCallType(callTypeIntValue);
		accountDetails.setSPID(batchDetails.getSpid() != null ? batchDetails.getSpid().toBigInteger() : null);
		logger.debug("[CRDRDataTransformer -- transformCRDRDataType] -- End");
	}
}
