package com.shopdirect.nce.sp.model;

public class TriadResponseType {

	private AccountResponseType accountResponseType;

	public AccountResponseType getAccountResponseType() {
		return accountResponseType;
	}

	public void setAccountResponseType(AccountResponseType accountResponseType) {
		this.accountResponseType = accountResponseType;
	}
}
