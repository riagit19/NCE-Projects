
package com.shopdirect.nce.sp.business;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import com.shopdirect.nce.common.extcnfg.ExternalFileDataConfiguration;
import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.dao.AccountReassementProcessDao;
import com.shopdirect.nce.sp.dao.StatementProcessorARDao;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.jms.QueueSend;
import com.shopdirect.nce.sp.model.CustomerAccountInfo;
import com.shopdirect.nce.sp.model.CustomerReassesmentInfo;
import com.shopdirect.nce.sp.model.PseudoChargeResponseType;
import com.shopdirect.nce.sp.parser.StatementProcessorParser;
import com.shopdirect.nce.sp.util.CommonConfigHelper;
import com.shopdirect.nce.sp.workmanager.AccountReassessmentExecutor;
import com.shopdirect.nce.sp.workmanager.FutureJobExecutor;
import com.shopdirect.nce.sp.workmanager.PseudoChargeExecutor;

/**
 * 
 * @author SudiptaRoy
 *
 */
public class AccountReassementProcessBusinessImpl extends AccountReassessmentBaseBusinessImpl {

	private static final SDLoggerImpl LOGGER = new SDLoggerImpl();
	
	private static final String CUSTOMER_ID_TAG = "customerId";
	private static final String STATEMENT_DATE_TAG = "statementDate";
	
	private QueueSend queueSend;
	private AccountReassementProcessDao accReassessProcDao;
	StatementProcessorARDao arDao;
	
	/**
	 * Default Constructor
	 * @throws StatementProcessorBatchException
	 */
	public AccountReassementProcessBusinessImpl () throws StatementProcessorBatchException {
		super();
		accReassessProcDao = getAccountReassementProcessDao();
		arDao = getArDao();
	}
	
	
	/**
	 * @param jmsMessage
	 * @throws Exception
	 */
	public void getCustIdDetailsFromJMSMessage(String jmsMessage) throws StatementProcessorBatchException {
		LOGGER.debug("[AccountReassementProcessBusinessImpl -- getCustIdDetailsFromJMSMessage] -- Start"); 
		try{
			String customerID = extractValue(jmsMessage, CUSTOMER_ID_TAG);
			String inputStmtDate = extractValue(jmsMessage, STATEMENT_DATE_TAG); 
			if (inputStmtDate.length() >= 10) {
				inputStmtDate = inputStmtDate.substring(0, 10);
			}
			
			List<CustomerAccountInfo> customerAccountInfoList = accReassessProcDao.getCustomerDetails(customerID, inputStmtDate);
			
			if(customerAccountInfoList != null && !customerAccountInfoList.isEmpty())
			{
				Map <String, PseudoChargeResponseType> linkedAccountMap = new HashMap<>();
				FutureJobExecutor executor = new FutureJobExecutor();
				List<Future<AccountReassessmentExecutor>> resultList = new ArrayList<>();
				List<Future<PseudoChargeExecutor>> pseudoResultList = new ArrayList<>();
				calculatePseudoCharge(customerAccountInfoList, linkedAccountMap, executor, pseudoResultList);
				for(CustomerAccountInfo customerAccountInfo : customerAccountInfoList)
				{
					if (!isLinkedAccount(customerAccountInfo)) {
						Future<AccountReassessmentExecutor> result = executor.submitJob(new AccountReassessmentExecutor(customerAccountInfo, linkedAccountMap));
						resultList.add(result);
					}
				}
				for(Future<AccountReassessmentExecutor> futureResult : resultList){
					handleResponse(futureResult.get());
				}
				executor.closeExecutorService();
			}
		}catch(Exception e){
			LOGGER.error("[AccountReassementProcessBusinessImpl -- getCustIdDetailsFromJMSMessage] -- Exception: " + e.getMessage());  
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_BUSINESS_ERROR_CODE,
					"[StartAccountReassessmentBusinessImpl-startAR] Exception Block",
					"Business exception generated at time of AR process "+ e.getMessage(),
					null, null,e);
		}
		LOGGER.debug("[AccountReassementProcessBusinessImpl -- getCustIdDetailsFromJMSMessage] -- End"); 
	}


	private boolean isLinkedAccount(CustomerAccountInfo customerAccountInfo) {
		return customerAccountInfo != null && customerAccountInfo.getLinkedAccntIndex() != null
				&& isLinkAccount(customerAccountInfo.getLinkedAccntIndex());
	}

	/**
	 * @param customerAccountInfoList
	 * @param linkedAccountMap
	 * @param executor
	 * @param pseudoResultList
	 * @throws StatementProcessorBatchException
	 * @throws InterruptedException
	 * @throws ExecutionException
	 */
	private void calculatePseudoCharge(List<CustomerAccountInfo> customerAccountInfoList,
			Map<String, PseudoChargeResponseType> linkedAccountMap, FutureJobExecutor executor,
			List<Future<PseudoChargeExecutor>> pseudoResultList)
			throws StatementProcessorBatchException, InterruptedException, ExecutionException {
		LOGGER.debug("[AccountReassementProcessBusinessImpl -- calculatePseudoCharge] -- Start"); 
		for(CustomerAccountInfo accountInfo : customerAccountInfoList) {
			Future<PseudoChargeExecutor> pseudoResult = executor.submitPseudoJobs(new PseudoChargeExecutor(accountInfo));
			pseudoResultList.add(pseudoResult);
			
			
			// Remove Below Code
			Integer linkedAccountIndex = accountInfo.getLinkedAccntIndex();
			boolean isLinkedAccount = isLinkAccount(linkedAccountIndex);
			if (isLinkedAccount) {
				linkedAccountMap.put(accountInfo.getPublicAccountId(), null);
			}
			// Remove Above code
			
		}
		
		boolean stopExecution = true;
		
		if(!stopExecution) {
			for (Future<PseudoChargeExecutor> futurePseudoResult : pseudoResultList) {
				PseudoChargeExecutor pseudoResult = futurePseudoResult.get();
				if (pseudoResult.getPseudoChargeResponse() != null) {
					String publicAccountId = pseudoResult.getCustomerAccountInfo().getPublicAccountId();
					linkedAccountMap.put(publicAccountId, pseudoResult.getPseudoChargeResponse());
				}
			}
		}
		
		LOGGER.debug("[AccountReassementProcessBusinessImpl -- calculatePseudoCharge] -- End"); 
	}

	/**
	 * @param reassessExecRsps
	 * @throws Exception 
	 */
	public void handleResponse(AccountReassessmentExecutor reassessExecRsp)
			throws Exception {
		LOGGER.debug("[AccountReassementProcessBusinessImpl -- handleResponse] -- Start"); 
		
		if (reassessExecRsp != null && reassessExecRsp.getProcessorBatchException() == null) {
			CommonConfigHelper commonConfigHelper = CommonConfigHelper.getInstance();
			ExternalFileDataConfiguration externalClientConfig = commonConfigHelper
					.loadPropertyConfig(StatementProcessorBatchConstants.AUDITLOG_CONFIGURATION_FILE_KEY);
			performDbUpdate(reassessExecRsp, commonConfigHelper.readConfigData(externalClientConfig, "successAR"));
		}
		
		LOGGER.debug("[AccountReassementProcessBusinessImpl -- handleResponse] -- End");
	}

	/**
	 * 
	 * @param reassessExecRsp Executor
	 * @param status Status
	 * @throws Exception Exception Thrown
	 */
	public void putToResponseQueue(AccountReassessmentExecutor reassessExecRsp, String status)
			throws Exception {
		LOGGER.debug("[AccountReassementProcessBusinessImpl -- putToResponseQueue] -- Start");
		List<String> messageList = new ArrayList<>();
		List<CustomerReassesmentInfo> customerReassesmentInfoList = new ArrayList<>();
		constructReAssessAccount(reassessExecRsp.getCustomerAccountInfo(), customerReassesmentInfoList, false);
		try {
			messageList = StatementProcessorParser.getCustomerReassesInfoAsXml(customerReassesmentInfoList);
			getQueueSend().sendAsyncMessage(messageList, "RSP_QUEUE");
		} catch (Exception e) {
			performDbUpdate(reassessExecRsp, status);
			LOGGER.error(e.getMessage());
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_BUSINESS_ERROR_CODE,
					"[AccountReassementProcessBusinessImpl-putToResponseQueue]", "Problem in sending message in queue", null, null, e);

		}
		LOGGER.debug("[AccountReassementProcessBusinessImpl -- putToResponseQueue] -- End");
	}

	/**
	 * @throws Exception 
	 * @param reassessExecRsp
	 * @param status
	 * @throws StatementProcessorBatchException
	 * @throws  
	 */
	private void performDbUpdate(AccountReassessmentExecutor reassessExecRsp, String status)
			throws Exception {
		LOGGER.debug("[AccountReassementProcessBusinessImpl -- performDbUpdate] Start");
		try {
		CustomerAccountInfo customerAccountInfo = reassessExecRsp.getCustomerAccountInfo();
		int rowsAffected = getArDao().updateStatusMessage(customerAccountInfo.getPublicAccountId(),
				status, customerAccountInfo.getAccountInfoId());
		if (rowsAffected > 0) {
			LOGGER.info("[AccountReassementProcessBusinessImpl -- performDbUpdate] Database update successful");
		}
		}catch(SQLException sqle){
			LOGGER.error("[AccountReassementProcessBusinessImpl -- performDbUpdate] Database update failed: " + sqle);
		}
		LOGGER.debug("[AccountReassementProcessBusinessImpl -- performDbUpdate] End");
	}

	/**
	 * extractCustomerID
	 * 
	 * @param message
	 * @return
	 */
	protected String extractValue(String message, String tag) {
		String value = "";
		if (message != null && message.length() > tag.length()) {
			int start = message.indexOf(tag) + tag.length() + 1;
			int end = message.lastIndexOf(tag) - 2;
			if (end > start) {
				value = message.substring(start, end);
			}
		}
		if(value.length() > 0){
			value = value.trim();
		}
		LOGGER.debug("[AccountReassementProcessBusinessImpl -- extractValue] tag=" + tag + " value=" + value);
		return value;
	}

	private void filterDormantAccounts(List<CustomerAccountInfo> custAccInfoList) throws StatementProcessorBatchException {
		LOGGER.debug("[AccountReassementProcessBusinessImpl -- filterDormantAccounts] -- Start");
		if(custAccInfoList != null && !custAccInfoList.isEmpty()) {
			List <CustomerAccountInfo> dormantList = new ArrayList<>();
			for (CustomerAccountInfo custAccInfo : custAccInfoList) {
				if(custAccInfo != null && custAccInfo.getAccountStatus() != null) {
					try {
						ExternalFileDataConfiguration dataConfig = getCommonConfigHelper().loadPropertyConfig(StatementProcessorBatchConstants.DATA_CONFIGURATION_FILE_KEY);
						String value = getCommonConfigHelper().readConfigData(dataConfig, "STATUS_CODE_SEVENTY_TWO");
						int val = Integer.parseInt(value);
						int accountStatus = Integer.parseInt(custAccInfo.getAccountStatus()); 
						if(accountStatus > val) {
							dormantList.add(custAccInfo);
						}
					} catch (NumberFormatException nfe) {
						LOGGER.error("[AccountReassementProcessBusinessImpl -- filterDormantAccounts] Number Format Exception: " + nfe);
					} catch (StatementProcessorBatchException e) {
						LOGGER.error("[AccountReassementProcessBusinessImpl -- filterDormantAccounts] Exception: " + e);
						throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_BUSINESS_ERROR_CODE,
								"[StartAccountReassessmentBusinessImpl-startAR] Exception Block",
								"Exception generated at time to filter dormat account "+ e.getMessage(),
								null, null,e);
					}
				}
			}

			List<CustomerReassesmentInfo> custReassInfoList = new ArrayList<>();
			for(CustomerAccountInfo dormantAcc : dormantList) {
				custAccInfoList.remove(dormantAcc);
				constructReAssessAccount(dormantAcc, custReassInfoList, true);
			}
			
			try {
				List <String> messageList = StatementProcessorParser.getCustomerReassesInfoAsXml(custReassInfoList);
				getQueueSend().sendAsyncMessage(messageList, "RSP_QUEUE");
			} catch (Exception e) {
				LOGGER.error("[AccountReassementProcessBusinessImpl -- filterDormantAccounts] Exception in Queue: " + e);
				throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_BUSINESS_ERROR_CODE,
						"[StartAccountReassessmentBusinessImpl-startAR] Exception Block",
						"Exception generated at time to put dormat account in queue "+ e.getMessage(),
						null, null,e);
			}
		}
		LOGGER.debug("[AccountReassementProcessBusinessImpl -- filterDormantAccounts] -- End");
	}


	private void constructReAssessAccount(CustomerAccountInfo acc, List<CustomerReassesmentInfo> custReassInfoList, boolean isDormant) {
		LOGGER.debug("[AccountReassementProcessBusinessImpl -- constructReAssessAccount] -- Start");
		String publicAccountId = acc.getPublicAccountId();
		Date statementDate = acc.getStatementDate();
		String accountInfoId = acc.getAccountInfoId();
		String retailAccNum = acc.getRetailAccountId();
		custReassInfoList.add(new CustomerReassesmentInfo(publicAccountId, statementDate, accountInfoId, isDormant, retailAccNum));
		LOGGER.debug("[AccountReassementProcessBusinessImpl -- constructReAssessAccount] -- End");
	}

	public AccountReassementProcessDao getAccountReassementProcessDao() throws StatementProcessorBatchException {
		if (this.accReassessProcDao != null) {
			return this.accReassessProcDao;
		}
		return new AccountReassementProcessDao();
	}

	public void setAccountReassementProcessDao(AccountReassementProcessDao arpd) {
		this.accReassessProcDao = arpd;
	}


	public StatementProcessorARDao getArDao() throws StatementProcessorBatchException {
		if (this.arDao != null) {
			return this.arDao;
		}
		return new StatementProcessorARDao();
	}

	public void setArDao(StatementProcessorARDao arDao) {
		this.arDao = arDao;
	}


	public QueueSend getQueueSend() throws StatementProcessorBatchException {
		if (this.queueSend != null) {
			return this.queueSend;
		}
		return new QueueSend();
	}


	public void setQueueSend(QueueSend queueSend) {
		this.queueSend = queueSend;
	}
	
}
