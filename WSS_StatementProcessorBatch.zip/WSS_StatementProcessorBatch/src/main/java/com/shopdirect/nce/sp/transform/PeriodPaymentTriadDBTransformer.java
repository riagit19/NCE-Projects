package com.shopdirect.nce.sp.transform;

import java.math.BigDecimal;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.model.PeriodPaymentTriad;

public class PeriodPaymentTriadDBTransformer {
	
	private static SDLoggerImpl logger = new SDLoggerImpl();

	public void setPeriodPaymentTriadObject(PeriodPaymentTriad periodPaymentTriad, Object[] attributes) {

		logger.debug("[PeriodPaymentTriadDBTransformer - setPeriodPaymentTriadObject] - Start");
		
		int index = 0;
		periodPaymentTriad.setAgreementID(attributes[index] != null ? attributes[index].toString() : null);
		++index;
		periodPaymentTriad.setPaymentAmountCredit(attributes[index] != null ? new BigDecimal(attributes[index].toString()) : null);
		++index;
		periodPaymentTriad.setPaymentAmountDebit(attributes[index] != null ? new BigDecimal(attributes[index].toString()) : null);

		logger.debug("[PeriodPaymentTriadDBTransformer - setPeriodPaymentTriadObject] - End");
		
	}
	
}
