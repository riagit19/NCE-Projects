package com.shopdirect.nce.sp.dao;

import java.sql.Connection;
import java.sql.SQLException;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.AuthType;
import com.shopdirect.nce.sp.model.CreditLimitType;
import com.shopdirect.nce.sp.util.UCPConnection;

public class MasterAcCreditAndReassessmentDaoImpl extends AccountReassessmentBaseDao  {

private SDLoggerImpl logger = new SDLoggerImpl();
	
	
	public MasterAcCreditAndReassessmentDaoImpl() throws StatementProcessorBatchException{
		super();
		setSpMainSchema(getSchema(StatementProcessorBatchConstants.DB_SCHEMA_MAIN_SP_KEY));
	}
	
	public int processUpdateCreditAndReassessment(CreditLimitType creditLimitType, AuthType authType, String publicAccNum, String creditLimitAction,
			String clStatus, String statementDate, String arrearsStatus, String tradingCode) throws StatementProcessorBatchException {
		
		logger.info("[MasterAcCreditAndReassessmentDaoImpl -- processUpdateCreditAndReassessment]  -- START");
		Connection con = null;
		int updateStatus = 0;
		int insertStatus = 0;
		int acCreditLimitUpdateStatus = 0;
		String proposedCreditLimit = creditLimitType.getProposedCreditLimit() != null ? creditLimitType.getProposedCreditLimit().toString() : "";
		String actualCreditLimit = creditLimitType.getActualCreditLimit() != null ? creditLimitType.getActualCreditLimit().toString() : "";
		String creditLimitReasonCode = creditLimitType.getCreditLineReasonCode();
		String creditRiskFactor = creditLimitType.getCreditRiskFactor() != null ? creditLimitType.getCreditRiskFactor().toString() : "";
		String authStrategyID = creditLimitType.getAuthStrategyId() != null ? creditLimitType.getAuthStrategyId().toString() : "";
		String custBehaviourScore = creditLimitType.getCustBehaviourScore() != null ? creditLimitType.getCustBehaviourScore().toString() : "";
		String daysProposedLimitExpires = creditLimitType.getDaysProposedLimitExpires();
		String limitCapValue = creditLimitType.getLimitCapValue() != null ? creditLimitType.getLimitCapValue().toString() : "";
		String shadowCreditMonetoryLimit = authType.getShadowCreditMonetaryLimit() != null ? authType.getShadowCreditMonetaryLimit().toString() : "";
		String actualCreditMonetroyLimit = authType.getActualCreditMonetaryLimit() != null ? authType.getActualCreditMonetaryLimit().toString() : "";
		
	    try {
			con = UCPConnection.getConnection();
	    	con.setAutoCommit(false); 
	    	AccountReassessmentDaoImpl accountReassessmentDaoImpl = new AccountReassessmentDaoImpl();
	    	AccountCreditLimitInfoDaoImpl accountCreditLimitInfoDaoImpl = new AccountCreditLimitInfoDaoImpl();
	    	updateStatus = accountReassessmentDaoImpl.updateAccReassessment(con, publicAccNum, creditLimitAction, proposedCreditLimit, clStatus);
	    	if (updateStatus != 0) {
	    		acCreditLimitUpdateStatus = accountCreditLimitInfoDaoImpl.updateAccCreditLimitInfo(con, publicAccNum, creditLimitAction, proposedCreditLimit, 
						clStatus, actualCreditLimit, statementDate, arrearsStatus, creditLimitReasonCode, creditRiskFactor,
						authStrategyID, custBehaviourScore, daysProposedLimitExpires, limitCapValue, shadowCreditMonetoryLimit,
						actualCreditMonetroyLimit);
	    		if (acCreditLimitUpdateStatus == 0) {
	    			insertStatus = accountCreditLimitInfoDaoImpl.insertAccCreditLimitInfo(con, publicAccNum, creditLimitAction, proposedCreditLimit, 
	    					clStatus, actualCreditLimit, statementDate, arrearsStatus, creditLimitReasonCode, creditRiskFactor,
	    					authStrategyID, custBehaviourScore, daysProposedLimitExpires, limitCapValue, shadowCreditMonetoryLimit,
	    					actualCreditMonetroyLimit, tradingCode);
	    		}
	    	}
	    	con.commit();

	    } catch(StatementProcessorBatchException batchEx){
	    	getLogger().error("[MasterAcCreditAndReassessmentDaoImpl -- processUpdateCreditAndReassessment] catch Block: " + batchEx);
	    	throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_DB_ERROR_CODE,
					"[MasterAcCreditAndReassessmentDaoImpl -- processUpdateCreditAndReassessment] SQLException Block",
					"Database execution exception [SQLCode: "+ batchEx.getErrorCode() + "] , SQL Detail "+batchEx,
					null, null,batchEx);
	    } catch (SQLException sqlException) {
	    	if(con != null){
	    		try {
					con.rollback();
				} catch (SQLException e) {
					getLogger().error("[MasterAcCreditAndReassessmentDaoImpl -- processUpdateCreditAndReassessment] finally Block: failed to Rollback DB objects. " + e);
				}
	    	}
	    	
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_DB_ERROR_CODE,
					"[MasterAcCreditAndReassessmentDaoImpl -- processUpdateCreditAndReassessment] SQLException Block",
					"Database execution exception [SQLCode: "+ sqlException.getSQLState() + "] , SQL Detail "+sqlException,
					null, null,sqlException);
		      
		       
		 } catch(Exception exception){
				throw new StatementProcessorBatchException(StatementProcessorBatchConstants.CONNECTTION_DB_ERROR_CODE,
						"[MasterAcCreditAndReassessmentDaoImpl -- processUpdateCreditAndReassessment] Exception Block",
						"Database execution exception "+ exception,
						null, null,exception);
		 } finally {
			   try {				 
				   if (con != null) {
						con.close();
					}
				} catch (Exception e) {
					getLogger().error("[MasterAcCreditAndReassessmentDaoImpl -- processUpdateCreditAndReassessment] finally Block: failed to close DB objects. " + e);
				}
		   }
		   logger.debug("[MasterAcCreditAndReassessmentDaoImpl -- processUpdateCreditAndReassessment]  -- END");
		   if (acCreditLimitUpdateStatus != 0) {
			   return acCreditLimitUpdateStatus;
		   }
		return insertStatus;
	}
	
	public int processInsertCreditAndReassessment(CreditLimitType creditLimitType, AuthType authType, String publicAccNum, String creditLimitAction,
			String clStatus, String statementDate, String arrearsStatus, String tradingCode) throws StatementProcessorBatchException {

		logger.info("[MasterAcCreditAndReassessmentDaoImpl -- processInsertCreditAndReassessment]  -- START");
		Connection con = null;
		int inserCreditLimitStatus = 0;
		int acCreditLimitUpdateStatus = 0;
		String proposedCreditLimit = creditLimitType.getProposedCreditLimit() != null ? creditLimitType.getProposedCreditLimit().toString() : "";
		String actualCreditLimit = creditLimitType.getActualCreditLimit() != null ? creditLimitType.getActualCreditLimit().toString() : "";
		String creditLimitReasonCode = creditLimitType.getCreditLineReasonCode();
		String creditRiskFactor = creditLimitType.getCreditRiskFactor() != null ? creditLimitType.getCreditRiskFactor().toString() : "";
		String authStrategyID = creditLimitType.getAuthStrategyId() != null ? creditLimitType.getAuthStrategyId().toString() : "";
		String custBehaviourScore = creditLimitType.getCustBehaviourScore() != null ? creditLimitType.getCustBehaviourScore().toString() : "";
		String daysProposedLimitExpires = creditLimitType.getDaysProposedLimitExpires();
		String limitCapValue = creditLimitType.getLimitCapValue() != null ? creditLimitType.getLimitCapValue().toString() : "";
		String shadowCreditMonetoryLimit = authType.getShadowCreditMonetaryLimit() != null ? authType.getShadowCreditMonetaryLimit().toString() : "";
		String actualCreditMonetroyLimit = authType.getActualCreditMonetaryLimit() != null ? authType.getActualCreditMonetaryLimit().toString() : "";
		try {
			con = UCPConnection.getConnection();
			con.setAutoCommit(false); 
			AccountReassessmentDaoImpl accountReassessmentDaoImpl = new AccountReassessmentDaoImpl();
			AccountCreditLimitInfoDaoImpl accountCreditLimitInfoDaoImpl = new AccountCreditLimitInfoDaoImpl();
			accountReassessmentDaoImpl.insertAccReassessment(con, publicAccNum, creditLimitAction, proposedCreditLimit, clStatus);
			acCreditLimitUpdateStatus = accountCreditLimitInfoDaoImpl.updateAccCreditLimitInfo(con, publicAccNum, creditLimitAction, proposedCreditLimit, 
					clStatus, actualCreditLimit, statementDate, arrearsStatus, creditLimitReasonCode, creditRiskFactor,
					authStrategyID, custBehaviourScore, daysProposedLimitExpires, limitCapValue, shadowCreditMonetoryLimit,
					actualCreditMonetroyLimit);
			if (acCreditLimitUpdateStatus == 0) {
				inserCreditLimitStatus = accountCreditLimitInfoDaoImpl.insertAccCreditLimitInfo(con, publicAccNum, creditLimitAction, proposedCreditLimit, 
						clStatus, actualCreditLimit, statementDate, arrearsStatus, creditLimitReasonCode, creditRiskFactor,
						authStrategyID, custBehaviourScore, daysProposedLimitExpires, limitCapValue, shadowCreditMonetoryLimit,
						actualCreditMonetroyLimit, tradingCode);
			}

			con.commit();

		} catch(StatementProcessorBatchException batchEx){
			getLogger().error("[MasterAcCreditAndReassessmentDaoImpl -- processInsertCreditAndReassessment] catch Block: " + batchEx);
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_DB_ERROR_CODE,
					"[MasterAcCreditAndReassessmentDaoImpl -- processInsertCreditAndReassessment] SQLException Block",
					"Database execution exception [SQLCode: "+ batchEx.getErrorCode() + "] , SQL Detail "+batchEx,
					null, null,batchEx);
		} catch (SQLException sqlException) {
			if(con != null){
				try {
					con.rollback();
				} catch (SQLException e) {
					getLogger().error("[MasterAcCreditAndReassessmentDaoImpl -- processInsertCreditAndReassessment] finally Block: failed to Rollback DB objects. " + e);
				}
			}

			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_DB_ERROR_CODE,
					"[MasterAcCreditAndReassessmentDaoImpl -- processInsertCreditAndReassessment] SQLException Block",
					"Database execution exception [SQLCode: "+ sqlException.getSQLState() + "] , SQL Detail "+sqlException,
					null, null,sqlException);


		} catch(Exception exception){
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.CONNECTTION_DB_ERROR_CODE,
					"[MasterAcCreditAndReassessmentDaoImpl -- processInsertCreditAndReassessment] Exception Block",
					"Database execution exception "+ exception,
					null, null,exception);
		} finally {

			try {				 
				if (con != null) {
					con.close();
				}

			} catch (Exception e) {
				getLogger().error("[MasterAcCreditAndReassessmentDaoImpl -- processInsertCreditAndReassessment] finally Block: failed to close DB objects. " + e);
			}
		}

		logger.debug("[MasterAcCreditAndReassessmentDaoImpl -- processInsertCreditAndReassessment]  -- END");
		if (acCreditLimitUpdateStatus != 0) {
			return acCreditLimitUpdateStatus;
		} 
		return inserCreditLimitStatus;
	}	
	    	
			
	
	/**
	 * @return the logger
	 */
	@Override
	public SDLoggerImpl getLogger() {
		return logger;
	}
	
}
