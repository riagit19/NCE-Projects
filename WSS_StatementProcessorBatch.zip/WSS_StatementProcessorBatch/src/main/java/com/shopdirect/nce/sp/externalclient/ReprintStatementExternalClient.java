package com.shopdirect.nce.sp.externalclient;
import java.net.URL;
import java.util.List;
import java.util.Map;

import javax.xml.namespace.QName;
import javax.xml.soap.SOAPException;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.WebServiceException;

import com.shopdirect.nce.common.extcnfg.ExternalFileDataConfiguration;
import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.dao.ReprintStatementDao;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.CustomerAccountInfo;
import com.shopdirect.nce.sp.util.CommonConfigHelper;
import com.shopdirect.osb.customeraccount.CustomerAccount;
import com.shopdirect.osb.customeraccount.CustomerAccountPT;
import com.shopdirect.osb.xsd.customeraccount.AccountDetailsRes;
import com.shopdirect.osb.xsd.customeraccount.AccountNumbers;
import com.shopdirect.osb.xsd.customeraccount.Address;
import com.shopdirect.osb.xsd.customeraccount.CreditAccount;
import com.shopdirect.osb.xsd.customeraccount.GetAccountDetailsRequestType;
import com.shopdirect.osb.xsd.customeraccount.GetAccountDetailsResponseType;
import com.shopdirect.osb.xsd.customeraccount.RetailAccount;
import com.shopdirect.osb.xsd.header.RequestHeaderType;

public class ReprintStatementExternalClient extends AccountReassessmentBaseExternalClient {

	private static final String DONE_STATUS = "DONE";
	private static final String REPRINT_STATEMENT_EXCEPTION = "[ReprintStatementExternalClient -- getCustomerAccountContent] Exception Block";
	private static final String WEBSERVICE_EXCEPTION = "Webservice exception generated at time to process getCustomerAccountContent ";
	private static SDLoggerImpl logger = new SDLoggerImpl();
	private ExternalFileDataConfiguration extFileDataCfg = null;
	private String namespaceUri = null;
	private String serviceName = null;
	private String resourcePath = null;
	private BindingProvider bindingProvider;
	private CustomerAccountPT customerAccountPortType;
	private CustomerAccount customerAcc;
	
	public ReprintStatementExternalClient() throws StatementProcessorBatchException {
		setCommonConfigHelper(CommonConfigHelper.getInstance());
		initExternalConfig();

	}

	public BindingProvider getBindingProvider() {
		return bindingProvider;
	}

	public void setBindingProvider(BindingProvider bindingProvider) {
		this.bindingProvider = bindingProvider;
	}

	public CustomerAccount getCustomerAcc() {
		return customerAcc;
	}

	public void setCustomerAcc(CustomerAccount customerAcc) {
		this.customerAcc = customerAcc;
	}

	public void setCustomerAccountPortType(CustomerAccountPT customerAccountPortType) {
		this.customerAccountPortType = customerAccountPortType;
	}

	public static SDLoggerImpl getLogger() {
		return logger;
	}

	public static void setLogger(SDLoggerImpl logger) {
		ReprintStatementExternalClient.logger = logger;
	}

	public ExternalFileDataConfiguration getExtFileDataCfg() {
		return extFileDataCfg;
	}

	public void setExtFileDataCfg(ExternalFileDataConfiguration extFileDataCfg) {
		this.extFileDataCfg = extFileDataCfg;
	}

	public String getNamespaceUri() {
		return namespaceUri;
	}

	public void setNamespaceUri(String namespaceUri) {
		this.namespaceUri = namespaceUri;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getResourcePath() {
		return resourcePath;
	}

	public void setResourcePath(String resourcePath) {
		this.resourcePath = resourcePath;
	}

	public GetAccountDetailsResponseType getCustomerAccountContent(GetAccountDetailsRequestType request)
			throws StatementProcessorBatchException {
		getLogger().debug("[ReprintStatementExternalClient -- getCustomerAccountContent] -- Start");
		GetAccountDetailsResponseType response = null;
		try {
			CustomerAccountPT customerAccountPT = getCustomerAccountPortType();

			String endpoint = getCommonConfigHelper().readConfigData(getExtFileDataCfg(),
					StatementProcessorBatchConstants.CUSTOMERACCOUNT_ENDPOINT_URL);

			if (this.getBindingProvider() == null) {
				this.setBindingProvider((BindingProvider) this.getCustomerAccountPT());
			}

			Map<String, Object> requestContextMap = this.getBindingProvider().getRequestContext();
			requestContextMap.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, endpoint);
			populateLocalHeader();
			addEndpointAddressAndHandlers(this.getBindingProvider(), endpoint, "GetCustomer");
			RequestHeaderType headerType = new RequestHeaderType();
			response = customerAccountPT.getAccountDetails(headerType, request);

			populateCusstomerInfo(response);

		} catch (WebServiceException se) {
			getLogger().error("[[ReprintStatementExternalClient -- getCustomerAccountContent] -- WebServiceException"
					+ se.getMessage());
			throw new StatementProcessorBatchException(
					StatementProcessorBatchConstants.UPDATECUSTOMER_BUSINESS_ERROR_CODE,
					REPRINT_STATEMENT_EXCEPTION,
					WEBSERVICE_EXCEPTION + se.getMessage(),
					null, null, se);
		} catch (SOAPException se) {
			getLogger().error(
					"[ReprintStatementExternalClient -- getCustomerAccountContent] -- SOAPException" + se.getMessage());
			throw new StatementProcessorBatchException(
					StatementProcessorBatchConstants.UPDATECUSTOMER_BUSINESS_ERROR_CODE,
					REPRINT_STATEMENT_EXCEPTION,
					WEBSERVICE_EXCEPTION + se.getMessage(),
					null, null, se);
		} catch (Exception exception) {
			
			getLogger().error("[ReprintStatementExternalClient -- getCustomerAccountContent] -- General exception=" + exception.getMessage());
			throw new StatementProcessorBatchException(
					StatementProcessorBatchConstants.UPDATECUSTOMER_BUSINESS_ERROR_CODE,
					REPRINT_STATEMENT_EXCEPTION,
					WEBSERVICE_EXCEPTION
							+ exception.getMessage(),
					null, null, exception);

		} finally {
			this.setBindingProvider(null);
		}
		getLogger().debug("[getCustomerAccountContent] - The exit.");
		return response;

	}

	public void populateCusstomerInfo(GetAccountDetailsResponseType response) throws Exception {
		getLogger().debug("[ReprintStatementExternalClient -- populateCustomerInfo] -- Start");

		List<AccountDetailsRes> accDtl = response.getAccountDetailsRes();
		for (AccountDetailsRes accountDetailsRes : accDtl) {
			CustomerAccountInfo custAccInfo = new CustomerAccountInfo();
			custAccInfo.setStatus(DONE_STATUS);
			AccountNumbers accnumber = accountDetailsRes.getAccountNumbers();
			if(accnumber != null){
			custAccInfo.setPublicAccountId(accnumber.getCustomerAccountNumber());
			}
			CreditAccount creditAcount = accountDetailsRes.getCreditAccount();
			RetailAccount retailAccount = accountDetailsRes.getRetailAccount();
			if(retailAccount!=null)
				custAccInfo.setRetailAccountId(retailAccount.getRetailAccountNumber());
			com.shopdirect.osb.xsd.customeraccount.CustomerAccount customerAccount = accountDetailsRes.getCustomerAccount();
			List<Address> address = accountDetailsRes.getAddress();
			for (Address addr : address) {

				if (customerAccount.getAccountBrand() != null)
					custAccInfo.setBrandType(customerAccount.getAccountBrand().toString());
				setAddress(custAccInfo, addr);

				setCreditDetails(custAccInfo, creditAcount);

				ReprintStatementDao reprintDao = new ReprintStatementDao();
				reprintDao.populateCimAccInfo(custAccInfo);
			}
		}
		getLogger().debug("[ReprintStatementExternalClient -- populateCustomerInfo] -- End");
	}

	private void setAddress(CustomerAccountInfo custAccInfo, Address addr) {
		if (addr != null) {
			if (addr.getAddressLine1() != null)
				custAccInfo.setAddressLine1(addr.getAddressLine1().getValue());
			if (addr.getAddressLine2() != null)
				custAccInfo.setAddressLine2(addr.getAddressLine2().getValue());
			if (addr.getPostCodeArea() != null)
				custAccInfo.setPostCode(addr.getPostCodeArea().getValue());
		}
	}

	private void setCreditDetails(CustomerAccountInfo custAccInfo, CreditAccount creditAcount) {
		if (creditAcount != null && creditAcount.getCreditStatusCode() != null) {
				getLogger().debug("[ReprintStatementExternalClient -- setCreditDetails] -- credistatus code="
						+ creditAcount.getCreditStatusCode());
				custAccInfo.setCreditStatus(creditAcount.getCreditStatusCode().getValue());
				if(creditAcount.getCreditAccountNumber()!=null)
					custAccInfo.setCreditAccountId(creditAcount.getCreditAccountNumber().getValue());
		}
	}

	/**
	 * Configuration Object creation This method sets namespacheUri,servicename
	 * and WSDL path to private variable retrieving from
	 * externalConfig.properties
	 * 
	 * @throws StatementProcessorBatchException
	 */
	private void initExternalConfig() throws StatementProcessorBatchException {
		logger.debug("[ReprintStatementExternalClient -- initExternalConfig]  -- START");

		this.extFileDataCfg = getCommonConfigHelper().loadPropertyConfig("externalClientConfig");

		this.setNamespaceUri(getCommonConfigHelper().readConfigData(getExtFileDataCfg(),
				StatementProcessorBatchConstants.CUSTOMERACCOUNT_SERVICE_NAMESPACE_URI));
		this.setServiceName(getCommonConfigHelper().readConfigData(getExtFileDataCfg(),
				StatementProcessorBatchConstants.CUSTOMERACCOUNT_EXTERNAL_SERVICE_NAME));
		this.setResourcePath(getCommonConfigHelper().readConfigData(getExtFileDataCfg(),
				StatementProcessorBatchConstants.CUSTOMERACCOUNT_SERVICE_WSDL_PATH));
		logger.debug("[ReprintStatementExternalClient -- initExternalConfig]  -- END");
	}

	/*
	 * this mehod sets queue name and end point url to portType object
	 */
	private CustomerAccountPT getCustomerAccountPortType() {
		getLogger().debug("[ReprintStatementExternalClient -- getCustomerAccountPortType] -- Start");
		try {
			QName qName = new QName(getNamespaceUri(), getServiceName());
			URL url = CustomerAccountPT.class.getResource(getResourcePath());

			if (this.customerAccountPortType == null) {

				this.customerAcc = new CustomerAccount(url, qName);
			}

			setCustomerAccountPT(customerAcc.getCustomerAccountPortHttp());

		} catch (Exception e) {

			getLogger().error("[ReprintStatementExternalClient -- getCustomerAccountPortType]  -- Exception: " + e);
		}
		getLogger().debug("[ReprintStatementExternalClient -- getCustomerAccountPortType] -- End");
		return this.customerAccountPortType;
	}

	public CustomerAccountPT getCustomerAccountPT() {

		return this.customerAccountPortType;
	}

	public void setCustomerAccountPT(CustomerAccountPT customerAccountPortType) {

		this.customerAccountPortType = customerAccountPortType;
	}
}
