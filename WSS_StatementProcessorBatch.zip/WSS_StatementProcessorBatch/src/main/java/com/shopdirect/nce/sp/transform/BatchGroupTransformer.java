package com.shopdirect.nce.sp.transform;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.model.AccountingSnapshot;
import com.shopdirect.nce.sp.model.BatchGroup;

public class BatchGroupTransformer {

	private static SDLoggerImpl logger = new SDLoggerImpl();
	
	public List<BatchGroup> getBatchGroup(List<AccountingSnapshot> accountingSnapshotList) {

		logger.debug("[BatchGroupTransformer - getBatchGroup] - Start");
		
		List<BatchGroup> batchGroupList = new ArrayList<BatchGroup>();
		BatchGroup batchGroupObj;
		
		for (int i = 0; i < accountingSnapshotList.size(); i++) {
			batchGroupObj = new BatchGroup();
			
			batchGroupObj.setCustomerAccountNumber(accountingSnapshotList.get(i).getCustomerAccountNumber());
			batchGroupObj.setBatchGroupOccurence(new BigDecimal(i+1));
			if (i == 1 || i > 4) {
				batchGroupObj.setValFees(new BigDecimal(0));
			} else {
				if (accountingSnapshotList.get(i).getScheduledPaymentsPastDue() != null) {
					batchGroupObj.setValFees(new BigDecimal(Math.max(Math.min(accountingSnapshotList.get(i).getScheduledPaymentsPastDue().intValue(), 9), 0)));
				}
			}
			batchGroupObj.setDelqNumCycles(new BigDecimal(i+1));
			
			batchGroupList.add(batchGroupObj);
		}
		
		logger.debug("[BatchGroupTransformer - getBatchGroup] - End");
		return batchGroupList;
	}
}
