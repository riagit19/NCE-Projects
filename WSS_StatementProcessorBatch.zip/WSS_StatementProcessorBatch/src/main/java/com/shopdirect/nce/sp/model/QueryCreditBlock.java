package com.shopdirect.nce.sp.model;

import java.sql.SQLData;
import java.sql.SQLException;
import java.sql.SQLInput;
import java.sql.SQLOutput;
import java.util.Date;

public class QueryCreditBlock implements SQLData {

	private String sqlType;
	private String retailAccountNumber;
	private String qcbBSC410;
	private String qcbBSC413;
	private String qcbBSC435;
	private String qcbBSC437;
	private String qcbBSC438;
	private String qcbDSC435;
	private String qcbDSC437;
	private String qcbDSC438;
	private String qcbLSC250;
	private String qcbLSC556;
	private String qcbLSC557;
	private String qcbLSC887;
	private String qcbLSC888;
	private String qcbLSC547;
	private String qcbFSC402;
	private String qcbLSC320;
	private String qcbCSC4;
	private String qcbLSC251;
	private String qcbLSC173;
	private String qcbFSC308;
	private String qcbLSC157;
	private String qcbSSC4;
	private String qcbSSC2;
	private String qcbXPCF09;
	private String qcbFSC104;
	private Date timestampCreated;
	private Date timestampUpdated;
	private Double recordId;
	private Double createdBy;
	private Date creationDate;
	private Double lastUpdatedBy;
	private Date lastUpdatedDate;
	private Double batchId;
	private String interfaceStatus;
	private String errorMessage;

	@Override
	public String getSQLTypeName() throws SQLException {
		return sqlType;
	}

	@Override
	public void readSQL(SQLInput stream, String typeName) throws SQLException {
		setRetailAccountNumber(stream.readString());
		setQcbBSC410(stream.readString());
		setQcbBSC413(stream.readString());
		setQcbBSC435(stream.readString());
		setQcbBSC437(stream.readString());
		setQcbBSC438(stream.readString());
		setQcbDSC435(stream.readString());
		setQcbDSC437(stream.readString());
		setQcbDSC438(stream.readString());
		setQcbLSC250(stream.readString());
		setQcbLSC556(stream.readString());
		setQcbLSC557(stream.readString());
		setQcbLSC887(stream.readString());
		setQcbLSC888(stream.readString());
		setQcbLSC547(stream.readString());
		setQcbFSC402(stream.readString());
		setQcbLSC320(stream.readString());
		setQcbCSC4(stream.readString());
		setQcbLSC251(stream.readString());
		setQcbLSC173(stream.readString());
		setQcbFSC308(stream.readString());
		setQcbLSC157(stream.readString());
		setQcbSSC4(stream.readString());
		setQcbSSC2(stream.readString());
		setQcbXPCF09(stream.readString());
		setQcbFSC104(stream.readString());
		setTimestampCreated(stream.readDate());
		setTimestampUpdated(stream.readDate());
		setRecordId(stream.readDouble());
		setCreatedBy(stream.readDouble());
		setCreationDate(stream.readDate());
		setLastUpdatedBy(stream.readDouble());
		setLastUpdatedDate(stream.readDate());
		setBatchId(stream.readDouble());
		setInterfaceStatus(stream.readString());
		setErrorMessage(stream.readString());
	}

	@Override
	public void writeSQL(SQLOutput stream) throws SQLException {
		stream.writeString(getRetailAccountNumber());
		stream.writeString(getQcbBSC410());
		stream.writeString(getQcbBSC413());
		stream.writeString(getQcbBSC435());
		stream.writeString(getQcbBSC437());
		stream.writeString(getQcbBSC438());
		stream.writeString(getQcbLSC250());
		stream.writeString(getQcbLSC556());
		stream.writeString(getQcbLSC557());
		stream.writeString(getQcbLSC887());
		stream.writeString(getQcbLSC888());
		stream.writeString(getQcbLSC547());
		stream.writeString(getQcbFSC402());
		stream.writeString(getQcbLSC320());
		stream.writeString(getQcbCSC4());
		stream.writeString(getQcbLSC251());
		stream.writeString(getQcbLSC173());
		stream.writeString(getQcbFSC308());
		stream.writeString(getQcbLSC157());
		stream.writeString(getQcbSSC4());
		stream.writeString(getQcbSSC2());
		stream.writeString(getQcbXPCF09());
		stream.writeString(getQcbFSC104());
		stream.writeDate(new java.sql.Date(getTimestampCreated().getTime()));
		stream.writeDate(new java.sql.Date(getTimestampUpdated().getTime()));
		stream.writeDouble(getRecordId());
		stream.writeDouble(getCreatedBy());
		stream.writeDate(new java.sql.Date(getCreationDate().getTime()));
		stream.writeDouble(getLastUpdatedBy());
		stream.writeDate(new java.sql.Date(getLastUpdatedDate().getTime()));
		stream.writeDouble(getBatchId());
		stream.writeString(getInterfaceStatus());
		stream.writeString(getErrorMessage());
	}

	public String getSqlType() {
		return sqlType;
	}

	public void setSqlType(String sqlType) {
		this.sqlType = sqlType;
	}

	public String getRetailAccountNumber() {
		return retailAccountNumber;
	}

	public void setRetailAccountNumber(String retailAccountNumber) {
		this.retailAccountNumber = retailAccountNumber;
	}

	public String getQcbBSC410() {
		return qcbBSC410;
	}

	public void setQcbBSC410(String qcbBSC410) {
		this.qcbBSC410 = qcbBSC410;
	}

	public String getQcbBSC413() {
		return qcbBSC413;
	}

	public void setQcbBSC413(String qcbBSC413) {
		this.qcbBSC413 = qcbBSC413;
	}

	public String getQcbBSC435() {
		return qcbBSC435;
	}

	public void setQcbBSC435(String qcbBSC435) {
		this.qcbBSC435 = qcbBSC435;
	}

	public String getQcbBSC437() {
		return qcbBSC437;
	}

	public void setQcbBSC437(String qcbBSC437) {
		this.qcbBSC437 = qcbBSC437;
	}

	public String getQcbBSC438() {
		return qcbBSC438;
	}

	public void setQcbBSC438(String qcbBSC438) {
		this.qcbBSC438 = qcbBSC438;
	}

	public String getQcbDSC435() {
		return qcbDSC435;
	}

	public void setQcbDSC435(String qcbDSC435) {
		this.qcbDSC435 = qcbDSC435;
	}

	public String getQcbDSC437() {
		return qcbDSC437;
	}

	public void setQcbDSC437(String qcbDSC437) {
		this.qcbDSC437 = qcbDSC437;
	}

	public String getQcbDSC438() {
		return qcbDSC438;
	}

	public void setQcbDSC438(String qcbDSC438) {
		this.qcbDSC438 = qcbDSC438;
	}

	public String getQcbLSC250() {
		return qcbLSC250;
	}

	public void setQcbLSC250(String qcbLSC250) {
		this.qcbLSC250 = qcbLSC250;
	}

	public String getQcbLSC556() {
		return qcbLSC556;
	}

	public void setQcbLSC556(String qcbLSC556) {
		this.qcbLSC556 = qcbLSC556;
	}

	public String getQcbLSC557() {
		return qcbLSC557;
	}

	public void setQcbLSC557(String qcbLSC557) {
		this.qcbLSC557 = qcbLSC557;
	}

	public String getQcbLSC887() {
		return qcbLSC887;
	}

	public void setQcbLSC887(String qcbLSC887) {
		this.qcbLSC887 = qcbLSC887;
	}

	public String getQcbLSC888() {
		return qcbLSC888;
	}

	public void setQcbLSC888(String qcbLSC888) {
		this.qcbLSC888 = qcbLSC888;
	}

	public String getQcbLSC547() {
		return qcbLSC547;
	}

	public void setQcbLSC547(String qcbLSC547) {
		this.qcbLSC547 = qcbLSC547;
	}

	public String getQcbFSC402() {
		return qcbFSC402;
	}

	public void setQcbFSC402(String qcbFSC402) {
		this.qcbFSC402 = qcbFSC402;
	}

	public String getQcbLSC320() {
		return qcbLSC320;
	}

	public void setQcbLSC320(String qcbLSC320) {
		this.qcbLSC320 = qcbLSC320;
	}

	public String getQcbCSC4() {
		return qcbCSC4;
	}

	public void setQcbCSC4(String qcbCSC4) {
		this.qcbCSC4 = qcbCSC4;
	}

	public String getQcbLSC251() {
		return qcbLSC251;
	}

	public void setQcbLSC251(String qcbLSC251) {
		this.qcbLSC251 = qcbLSC251;
	}

	public String getQcbLSC173() {
		return qcbLSC173;
	}

	public void setQcbLSC173(String qcbLSC173) {
		this.qcbLSC173 = qcbLSC173;
	}

	public String getQcbFSC308() {
		return qcbFSC308;
	}

	public void setQcbFSC308(String qcbFSC308) {
		this.qcbFSC308 = qcbFSC308;
	}

	public String getQcbLSC157() {
		return qcbLSC157;
	}

	public void setQcbLSC157(String qcbLSC157) {
		this.qcbLSC157 = qcbLSC157;
	}

	public String getQcbSSC4() {
		return qcbSSC4;
	}

	public void setQcbSSC4(String qcbSSC4) {
		this.qcbSSC4 = qcbSSC4;
	}

	public String getQcbSSC2() {
		return qcbSSC2;
	}

	public void setQcbSSC2(String qcbSSC2) {
		this.qcbSSC2 = qcbSSC2;
	}

	public String getQcbXPCF09() {
		return qcbXPCF09;
	}

	public void setQcbXPCF09(String qcbXPCF09) {
		this.qcbXPCF09 = qcbXPCF09;
	}

	public String getQcbFSC104() {
		return qcbFSC104;
	}

	public void setQcbFSC104(String qcbFSC104) {
		this.qcbFSC104 = qcbFSC104;
	}

	public Date getTimestampCreated() {
		return timestampCreated;
	}

	public void setTimestampCreated(Date timestampCreated) {
		this.timestampCreated = timestampCreated;
	}

	public Date getTimestampUpdated() {
		return timestampUpdated;
	}

	public void setTimestampUpdated(Date timestampUpdated) {
		this.timestampUpdated = timestampUpdated;
	}

	public Double getRecordId() {
		return recordId;
	}

	public void setRecordId(Double recordId) {
		this.recordId = recordId;
	}

	public Double getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Double createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public Double getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(Double lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public Double getBatchId() {
		return batchId;
	}

	public void setBatchId(Double batchId) {
		this.batchId = batchId;
	}

	public String getInterfaceStatus() {
		return interfaceStatus;
	}

	public void setInterfaceStatus(String interfaceStatus) {
		this.interfaceStatus = interfaceStatus;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

}
