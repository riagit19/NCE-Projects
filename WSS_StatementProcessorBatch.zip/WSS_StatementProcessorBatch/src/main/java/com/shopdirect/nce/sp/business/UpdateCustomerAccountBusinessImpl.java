package com.shopdirect.nce.sp.business;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.externalclient.UpdateCustomerExternalClient;
import com.shopdirect.nce.sp.model.CustomerAccountInfo;
import com.shopdirect.nce.sp.transform.UpdateCustomerAccountTransformer;
import com.shopdirect.osb.xsd.updatecustomeraccount.UpdateCustomerAccountRequestType;

public class UpdateCustomerAccountBusinessImpl extends AccountReassessmentBaseBusinessImpl {

	private SDLoggerImpl logger = new SDLoggerImpl();
	private UpdateCustomerAccountTransformer transformer = null;
	private UpdateCustomerExternalClient updateCustomerExternalClient = null;

	public UpdateCustomerAccountBusinessImpl() throws StatementProcessorBatchException {
		super();
		setUpdateCustomerExternalClient(new UpdateCustomerExternalClient());
		setTransformer(new UpdateCustomerAccountTransformer());
	}
	
	public void process(CustomerAccountInfo customerAccountInfo, String updateStatus, String arrearsStatus) throws StatementProcessorBatchException {
		logger.debug("[UpdateCustomerInfoBusinessImpl -- customerAccountInfo]  -- START");
		
		UpdateCustomerAccountRequestType updateCustomerAccountRequestType = getTransformer().transformRequest(customerAccountInfo, updateStatus, arrearsStatus);
		
		getUpdateCustomerExternalClient().updateCustomerAccountContent(updateCustomerAccountRequestType);
		logger.debug("[UpdateCustomerInfoBusinessImpl -- customerAccountInfo]  -- END");
			    
	}
	
	public UpdateCustomerAccountTransformer getTransformer() {
		return transformer;
	}

	public void setTransformer(UpdateCustomerAccountTransformer transformer) {
		this.transformer = transformer;
	}

	public UpdateCustomerExternalClient getUpdateCustomerExternalClient() {
		return updateCustomerExternalClient;
	}

	public void setUpdateCustomerExternalClient(UpdateCustomerExternalClient updateCustomerExternalClient) {
		this.updateCustomerExternalClient = updateCustomerExternalClient;
	}
}
