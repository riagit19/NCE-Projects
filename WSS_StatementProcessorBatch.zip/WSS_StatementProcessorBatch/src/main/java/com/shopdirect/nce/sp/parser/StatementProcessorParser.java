package com.shopdirect.nce.sp.parser;

import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.CustomerAccountInfo;
import com.shopdirect.nce.sp.model.CustomerReassesmentInfo;

/**
 * @author GouravChakraborty
 * Parse CustomerAccountInfo object to XML
 */
public class StatementProcessorParser {
	private static final String STATEMENT_PROCESSOR_PARSER_DAO_TO_XML = "[StatementProcessorParser-daoToXml]";
	private static final String PROBLEM_MARSHALLING = "Problem in marshalling";
	private static SDLoggerImpl logger = new SDLoggerImpl();
	
	private StatementProcessorParser() {

	}
	
	/**
	 * Parse DAO object into XML
	 * @param customerAccountInfoList
	 * @throws StatementProcessorBatchException 
	 */
	public static List<String> daoToXml(List<CustomerAccountInfo> customerAccountInfoList) throws StatementProcessorBatchException {
		ArrayList<String> messageList=new ArrayList<>();
		String message = "";
		try {
			for(CustomerAccountInfo customerAccountInfo:customerAccountInfoList){
				JAXBContext jaxbContext = JAXBContext.newInstance(CustomerAccountInfo.class);
				Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
				StringWriter sw = new StringWriter();
				jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
				jaxbMarshaller.marshal(customerAccountInfo, sw);
				message = sw.toString();
				messageList.add(message);
			}
			
		} catch (JAXBException e) {
			logger.error(e.getMessage());
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_BUSINESS_ERROR_CODE,STATEMENT_PROCESSOR_PARSER_DAO_TO_XML,PROBLEM_MARSHALLING,null, null, e);
		}
		return messageList;
	}
	
	/**
	 * Parse DAO object into XML
	 * @param customerAccountInfo
	 * @throws StatementProcessorBatchException 
	 */
	public static String daoToXml(CustomerAccountInfo customerAccountInfo) throws StatementProcessorBatchException {
		String message = "";
		try {
				JAXBContext jaxbContext = JAXBContext.newInstance(CustomerAccountInfo.class);
				Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
				StringWriter sw = new StringWriter();
				jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
				jaxbMarshaller.marshal(customerAccountInfo, sw);
				message = sw.toString();
			
		} catch (JAXBException e) {
			logger.error(e.getMessage());
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_BUSINESS_ERROR_CODE,STATEMENT_PROCESSOR_PARSER_DAO_TO_XML,PROBLEM_MARSHALLING,null, null, e);
		}
		return message;
	}
	
	/**
	 * 
	 * @param customerReassesmentInfoList
	 * @return
	 * @throws StatementProcessorBatchException
	 */
	public static List<String> getCustomerReassesInfoAsXml(List<CustomerReassesmentInfo> customerReassesmentInfoList)
			throws StatementProcessorBatchException {
		List<String> messageList = new ArrayList<>();
		try {
			for (CustomerReassesmentInfo customerReassesmentInfo : customerReassesmentInfoList) {
				JAXBContext jaxbContext = JAXBContext.newInstance(CustomerReassesmentInfo.class);
				Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
				StringWriter xmlContent = new StringWriter();
				jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
				jaxbMarshaller.marshal(customerReassesmentInfo, xmlContent);
				messageList.add(xmlContent.toString());
			}

		} catch (JAXBException e) {
			logger.error(e.getMessage());
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_BUSINESS_ERROR_CODE,
					STATEMENT_PROCESSOR_PARSER_DAO_TO_XML, PROBLEM_MARSHALLING, null, null, e);
		}
		return messageList;
	}
}
