package com.shopdirect.nce.sp.util;

import com.shopdirect.nce.common.extcnfg.ExternalConfigurationException;
import com.shopdirect.nce.common.extcnfg.ExternalFileDataConfiguration;
import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;


/**
 * The purpose of this class is provide the helper methods related to common
 * configuration component.
 * 
 */
public class CommonConfigHelper {

	
	private static SDLoggerImpl logger = new SDLoggerImpl();
	private static CommonConfigHelper commonConfig;
	
	private CommonConfigHelper(){
	}

	/**
	 * 
	 * @return
	 */
	public static CommonConfigHelper getInstance(){
		if(commonConfig == null){
			commonConfig = new CommonConfigHelper();
		}
		return commonConfig;
	}
	
	/**
	 * 
	 * @return
	 */
	public static void cleatrInstance(){
		commonConfig = null;
	}
	
	public ExternalFileDataConfiguration loadPropertyConfig(String fileName) throws StatementProcessorBatchException{
		try {
			return  new ExternalFileDataConfiguration(
					StatementProcessorBatchConstants.SERVICE_NAME,
					StatementProcessorBatchConstants.VALIDATOR_CONFIGURATION_TYPE,
					fileName);
		} catch (ExternalConfigurationException e) {
			logger.error("[CommonConfigHelper - loadPropertyConfig] - The exception: " + e.getMessage());
				throw new StatementProcessorBatchException(StatementProcessorBatchConstants.FILE_CONFIG_ERROR_CODE,
						"[CommonConfigHelper-loadPropertyConfig]",
						"Failed to load the Config file ["+fileName+"]"+ e.getMessage(),
						null, null,e);
		}
	}
	
	/**
	 * @param config
	 * @param key
	 * @return
	 * @throws ExternalConfigFailedException
	 */
	public String readConfigData(ExternalFileDataConfiguration config, String key) throws StatementProcessorBatchException {
		String value = config.getConfigData(key);
		if (value == null || "".equals(value)) {
			logger.error("readConfigData method :: Problem occurred in reading the value from the configuration file with key : " + key);
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.FILE_CONFIG_ERROR_CODE,
					"[CommonConfigHelper-loadPropertyConfig]",
					"Key-Value pair not found ["+key+"]",
					null, null,null);
		}
		return value;
	}
	
	public ExternalFileDataConfiguration loadXmlConfig(String fileName) throws StatementProcessorBatchException{
		try {
			return  new ExternalFileDataConfiguration(
					StatementProcessorBatchConstants.SERVICE_NAME,
					StatementProcessorBatchConstants.BUSINESS_CONFIGURATION_TYPE,
					fileName);
		} catch (ExternalConfigurationException e) {
			logger.error(("[getPrepaidCardConfigData] - The exception :: " + e.getMessage()));
				throw new StatementProcessorBatchException(StatementProcessorBatchConstants.FILE_CONFIG_ERROR_CODE,
						"[CommonConfigHelper-loadPropertyConfig]",
						"Failed to load the Config file ["+fileName+"]"+ e.getMessage(),
						null, null,e);
		}
	}	

}
