package com.shopdirect.nce.sp.model;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.SQLData;
import java.sql.SQLException;
import java.sql.SQLInput;
import java.sql.SQLOutput;


public class AccountingSnapshotTriad implements SQLData {

	private String sqlType;
	private BigDecimal triadCrdrDetailSID;         
	private Date createdTimestamp;           
	private BigDecimal recordID;         
	private Date creationDate;           
	private BigDecimal createdBy;         
	private BigDecimal lastUpdatedBy;         
	private Date lastUpdatedDate;           
	private String errorMessage; 
	private BigDecimal batchID;         
	private String interfaceStatus;   
	private BigDecimal highBalanceAmt;   
	private BigDecimal highDelq;
	private BigDecimal openingBalanceAmtSign;
	private BigDecimal nettSales6M;
	private BigDecimal nettSales12M;
	private BigDecimal nettSalesLifeTime;
	private BigDecimal numCycle1;      
	private BigDecimal numCycle2;      
	private BigDecimal numCycle3;      
	private BigDecimal numCycle4; 
	private BigDecimal openingBNPLBalAmt;
	private BigDecimal numberCustomerDebits;
	private BigDecimal tcbipChargableBalAmtSigned;
	private String retailAccountNumber;   
	private Date statementProducedDate;
	private String publicAccountNumber;
	private BigDecimal custScoreCardRefNo;
	private BigDecimal customerDebitsAmtSigned;
	private String contractNumber;
	private BigDecimal closingBalanceAmtSigned;
	private Date assessmentDate;
	private BigDecimal bnplBalanceAmtSigned;
	private BigDecimal scheduledPaymentAmt;
	private BigDecimal pastDueAmtSigned;
	private BigDecimal acdAlignedScore;
	private BigDecimal acdRawScore;
	private BigDecimal acdScorecardRefno;
	private BigDecimal assessmentApr;
	private BigDecimal alignedBehaviourScore;
	private BigDecimal creditRiskFactor;
	private BigDecimal custRawScore;
	private BigDecimal rawBehaviourScore;
	private BigDecimal custAlignedScore;
	private BigDecimal pctinterestRate;
	private BigDecimal fixedclosingBalAmtSigned;
	private BigDecimal ndrAlignedScore;
	private BigDecimal ndrRawScore;
	private BigDecimal ndrScorecardRefno;
	private BigDecimal debtType;
	private BigDecimal ddiSuspendedInd;
	private BigDecimal nextAccountApr;
	private BigDecimal nextAssessmentApr;
	private String fidScoreWorse;
	private BigDecimal netSalesValueTSPAmtSigned;
	private BigDecimal nettSales;
	private BigDecimal interestChargedAmt;
	private BigDecimal numberCustomerCredits;
	private BigDecimal numRetPayments;
	private BigDecimal oTB;
	private BigDecimal customerCreditsAmtSigned;
	private BigDecimal otherCreditsAmtSigned;
	private BigDecimal otherDebitsAmtSigned;
	private BigDecimal overIndebtScore;
	private BigDecimal rebatesAmtSigned;
	private BigDecimal returnsTSPAmtSigned;
	private BigDecimal t8ReturnsAmtSigned;
	private BigDecimal ordersValueTSPAmtSigned;
	private BigDecimal riskNavScore;
	private BigDecimal scorecardRefno;
	private BigDecimal assessmentNumber;
	private String statPromMessageCodeRec;
	private BigDecimal MinIntFreePaymentAmt;
	private Date timestampCreatedSnapshot;
	private BigDecimal totalBalanceAmtSigned;
	private BigDecimal totalFeesAmtSigned;
	private BigDecimal totalUnchMvmtAmtSigned;
	private BigDecimal worseFollowupCode;
	private BigDecimal retPaymentsAmtSigned;
	private BigDecimal grossRevenueAmtSigned;
	private BigDecimal tradingStatus;
	private BigDecimal sppd;
	private BigDecimal payTypeTSTAmtSigned;
	
	public AccountingSnapshotTriad() {
		//Default Constructor
	}
	
	

	public AccountingSnapshotTriad(BigDecimal triadCrdrDetailSID, Date createdTimestamp, BigDecimal recordID,
			Date creationDate, BigDecimal createdBy, BigDecimal lastUpdatedBy, Date lastUpdatedDate,
			String errorMessage, BigDecimal batchID, String interfaceStatus, BigDecimal highBalanceAmt,
			BigDecimal highDelq, BigDecimal openingBalanceAmtSign, BigDecimal nettSales6M, BigDecimal nettSales12M,
			BigDecimal nettSalesLifeTime, BigDecimal numCycle1, BigDecimal numCycle2, BigDecimal numCycle3,
			BigDecimal numCycle4, BigDecimal openingBNPLBalAmt, BigDecimal numberCustomerDebits,
			BigDecimal tcbipChargableBalAmtSigned, String retailAccountNumber, Date statementProducedDate) {
		super();
		this.triadCrdrDetailSID = triadCrdrDetailSID;
		this.createdTimestamp = createdTimestamp;
		this.recordID = recordID;
		this.creationDate = creationDate;
		this.createdBy = createdBy;
		this.lastUpdatedBy = lastUpdatedBy;
		this.lastUpdatedDate = lastUpdatedDate;
		this.errorMessage = errorMessage;
		this.batchID = batchID;
		this.interfaceStatus = interfaceStatus;
		this.highBalanceAmt = highBalanceAmt;
		this.highDelq = highDelq;
		this.openingBalanceAmtSign = openingBalanceAmtSign;
		this.nettSales6M = nettSales6M;
		this.nettSales12M = nettSales12M;
		this.nettSalesLifeTime = nettSalesLifeTime;
		this.numCycle1 = numCycle1;
		this.numCycle2 = numCycle2;
		this.numCycle3 = numCycle3;
		this.numCycle4 = numCycle4;
		this.openingBNPLBalAmt = openingBNPLBalAmt;
		this.numberCustomerDebits = numberCustomerDebits;
		this.tcbipChargableBalAmtSigned = tcbipChargableBalAmtSigned;
		this.retailAccountNumber = retailAccountNumber;
		this.statementProducedDate = statementProducedDate;
	}



	@Override
	public void readSQL(SQLInput stream, String typeName) throws SQLException {
		
		sqlType = typeName;
		setTriadCrdrDetailSID(stream.readBigDecimal());
		setHighBalanceAmt(stream.readBigDecimal());
		setHighDelq(stream.readBigDecimal());
		setOpeningBalanceAmtSign(stream.readBigDecimal());
		setNettSales6M(stream.readBigDecimal());
		setNettSales12M(stream.readBigDecimal());
		setNettSalesLifeTime(stream.readBigDecimal());
		setNumCycle1(stream.readBigDecimal());
		setNumCycle2(stream.readBigDecimal());
		setNumCycle3(stream.readBigDecimal());
		setNumCycle4(stream.readBigDecimal());
		setOpeningBNPLBalAmt(stream.readBigDecimal());
		setNumberCustomerDebits(stream.readBigDecimal());
		setTcbipChargableBalAmtSigned(stream.readBigDecimal());
		setRetailAccountNumber(stream.readString());
		setStatementProducedDate(stream.readDate());
		
	}
	
	@Override
	public void writeSQL(SQLOutput stream) throws SQLException {
		
	}

	@Override
	public String getSQLTypeName() throws SQLException {
		return sqlType;
	}

	public String getSqlType() {
		return sqlType;
	}

	public void setSqlType(String sqlType) {
		this.sqlType = sqlType;
	}

	public BigDecimal getTriadCrdrDetailSID() {
		return triadCrdrDetailSID;
	}
	public void setTriadCrdrDetailSID(BigDecimal triadCrdrDetailSID) {
		this.triadCrdrDetailSID = triadCrdrDetailSID;
	}
	public Date getCreatedTimestamp() {
		return createdTimestamp;
	}
	public void setCreatedTimestamp(Date createdTimestamp) {
		this.createdTimestamp = createdTimestamp;
	}
	public BigDecimal getRecordID() {
		return recordID;
	}
	public void setRecordID(BigDecimal recordID) {
		this.recordID = recordID;
	}
	public Date getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}
	public BigDecimal getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(BigDecimal createdBy) {
		this.createdBy = createdBy;
	}
	public BigDecimal getLastUpdatedBy() {
		return lastUpdatedBy;
	}
	public void setLastUpdatedBy(BigDecimal lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}
	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}
	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public BigDecimal getBatchID() {
		return batchID;
	}
	public void setBatchID(BigDecimal batchID) {
		this.batchID = batchID;
	}
	public String getInterfaceStatus() {
		return interfaceStatus;
	}
	public void setInterfaceStatus(String interfaceStatus) {
		this.interfaceStatus = interfaceStatus;
	}
	public BigDecimal getHighBalanceAmt() {
		return highBalanceAmt;
	}
	public void setHighBalanceAmt(BigDecimal highBalanceAmt) {
		this.highBalanceAmt = highBalanceAmt;
	}
	public BigDecimal getHighDelq() {
		return highDelq;
	}
	public void setHighDelq(BigDecimal highDelq) {
		this.highDelq = highDelq;
	}
	public BigDecimal getNumCycle1() {
		return numCycle1;
	}
	public void setNumCycle1(BigDecimal numCycle1) {
		this.numCycle1 = numCycle1;
	}
	public BigDecimal getNumCycle2() {
		return numCycle2;
	}
	public void setNumCycle2(BigDecimal numCycle2) {
		this.numCycle2 = numCycle2;
	}
	public BigDecimal getNumCycle3() {
		return numCycle3;
	}
	public void setNumCycle3(BigDecimal numCycle3) {
		this.numCycle3 = numCycle3;
	}
	public BigDecimal getNumCycle4() {
		return numCycle4;
	}
	public BigDecimal getOpeningBalanceAmtSign() {
		return openingBalanceAmtSign;
	}



	public void setOpeningBalanceAmtSign(BigDecimal openingBalanceAmtSign) {
		this.openingBalanceAmtSign = openingBalanceAmtSign;
	}



	public BigDecimal getNettSales6M() {
		return nettSales6M;
	}



	public void setNettSales6M(BigDecimal nettSales6M) {
		this.nettSales6M = nettSales6M;
	}



	public BigDecimal getNettSales12M() {
		return nettSales12M;
	}



	public void setNettSales12M(BigDecimal nettSales12M) {
		this.nettSales12M = nettSales12M;
	}



	public BigDecimal getNettSalesLifeTime() {
		return nettSalesLifeTime;
	}



	public void setNettSalesLifeTime(BigDecimal nettSalesLifeTime) {
		this.nettSalesLifeTime = nettSalesLifeTime;
	}



	public BigDecimal getOpeningBNPLBalAmt() {
		return openingBNPLBalAmt;
	}



	public void setOpeningBNPLBalAmt(BigDecimal openingBNPLBalAmt) {
		this.openingBNPLBalAmt = openingBNPLBalAmt;
	}



	public BigDecimal getNumberCustomerDebits() {
		return numberCustomerDebits;
	}



	public void setNumberCustomerDebits(BigDecimal numberCustomerDebits) {
		this.numberCustomerDebits = numberCustomerDebits;
	}



	public BigDecimal getTcbipChargableBalAmtSigned() {
		return tcbipChargableBalAmtSigned;
	}



	public void setTcbipChargableBalAmtSigned(BigDecimal tcbipChargableBalAmtSigned) {
		this.tcbipChargableBalAmtSigned = tcbipChargableBalAmtSigned;
	}



	public void setNumCycle4(BigDecimal numCycle4) {
		this.numCycle4 = numCycle4;
	}
	public String getRetailAccountNumber() {
		return retailAccountNumber;
	}
	public void setRetailAccountNumber(String retailAccountNumber) {
		this.retailAccountNumber = retailAccountNumber;
	}
	public Date getStatementProducedDate() {
		return statementProducedDate;
	}
	public void setStatementProducedDate(Date statementProducedDate) {
		this.statementProducedDate = statementProducedDate;
	}



	public String getPublicAccountNumber() {
		return publicAccountNumber;
	}



	public void setPublicAccountNumber(String publicAccountNumber) {
		this.publicAccountNumber = publicAccountNumber;
	}



	public BigDecimal getCustScoreCardRefNo() {
		return custScoreCardRefNo;
	}



	public void setCustScoreCardRefNo(BigDecimal custScoreCardRefNo) {
		this.custScoreCardRefNo = custScoreCardRefNo;
	}



	public BigDecimal getCustomerDebitsAmtSigned() {
		return customerDebitsAmtSigned;
	}



	public void setCustomerDebitsAmtSigned(BigDecimal customerDebitsAmtSigned) {
		this.customerDebitsAmtSigned = customerDebitsAmtSigned;
	}



	public String getContractNumber() {
		return contractNumber;
	}



	public void setContractNumber(String contractNumber) {
		this.contractNumber = contractNumber;
	}



	public BigDecimal getClosingBalanceAmtSigned() {
		return closingBalanceAmtSigned;
	}



	public void setClosingBalanceAmtSigned(BigDecimal closingBalanceAmtSigned) {
		this.closingBalanceAmtSigned = closingBalanceAmtSigned;
	}



	public Date getAssessmentDate() {
		return assessmentDate;
	}



	public void setAssessmentDate(Date assessmentDate) {
		this.assessmentDate = assessmentDate;
	}



	public BigDecimal getBnplBalanceAmtSigned() {
		return bnplBalanceAmtSigned;
	}



	public void setBnplBalanceAmtSigned(BigDecimal bnplBalanceAmtSigned) {
		this.bnplBalanceAmtSigned = bnplBalanceAmtSigned;
	}



	public BigDecimal getScheduledPaymentAmt() {
		return scheduledPaymentAmt;
	}



	public void setScheduledPaymentAmt(BigDecimal scheduledPaymentAmt) {
		this.scheduledPaymentAmt = scheduledPaymentAmt;
	}



	public BigDecimal getPastDueAmtSigned() {
		return pastDueAmtSigned;
	}



	public void setPastDueAmtSigned(BigDecimal pastDueAmtSigned) {
		this.pastDueAmtSigned = pastDueAmtSigned;
	}



	public BigDecimal getAcdAlignedScore() {
		return acdAlignedScore;
	}



	public void setAcdAlignedScore(BigDecimal acdAlignedScore) {
		this.acdAlignedScore = acdAlignedScore;
	}



	public BigDecimal getAcdRawScore() {
		return acdRawScore;
	}



	public void setAcdRawScore(BigDecimal acdRawScore) {
		this.acdRawScore = acdRawScore;
	}



	public BigDecimal getAcdScorecardRefno() {
		return acdScorecardRefno;
	}



	public void setAcdScorecardRefno(BigDecimal acdScorecardRefno) {
		this.acdScorecardRefno = acdScorecardRefno;
	}



	public BigDecimal getAssessmentApr() {
		return assessmentApr;
	}



	public void setAssessmentApr(BigDecimal assessmentApr) {
		this.assessmentApr = assessmentApr;
	}



	public BigDecimal getAlignedBehaviourScore() {
		return alignedBehaviourScore;
	}



	public void setAlignedBehaviourScore(BigDecimal alignedBehaviourScore) {
		this.alignedBehaviourScore = alignedBehaviourScore;
	}



	public BigDecimal getCreditRiskFactor() {
		return creditRiskFactor;
	}



	public void setCreditRiskFactor(BigDecimal creditRiskFactor) {
		this.creditRiskFactor = creditRiskFactor;
	}



	public BigDecimal getCustRawScore() {
		return custRawScore;
	}



	public void setCustRawScore(BigDecimal custRawScore) {
		this.custRawScore = custRawScore;
	}



	public BigDecimal getRawBehaviourScore() {
		return rawBehaviourScore;
	}



	public void setRawBehaviourScore(BigDecimal rawBehaviourScore) {
		this.rawBehaviourScore = rawBehaviourScore;
	}



	public BigDecimal getCustAlignedScore() {
		return custAlignedScore;
	}



	public void setCustAlignedScore(BigDecimal custAlignedScore) {
		this.custAlignedScore = custAlignedScore;
	}



	public BigDecimal getPctinterestRate() {
		return pctinterestRate;
	}



	public void setPctinterestRate(BigDecimal pctinterestRate) {
		this.pctinterestRate = pctinterestRate;
	}



	public BigDecimal getFixedclosingBalAmtSigned() {
		return fixedclosingBalAmtSigned;
	}



	public void setFixedclosingBalAmtSigned(BigDecimal fixedclosingBalAmtSigned) {
		this.fixedclosingBalAmtSigned = fixedclosingBalAmtSigned;
	}



	public BigDecimal getNdrAlignedScore() {
		return ndrAlignedScore;
	}



	public void setNdrAlignedScore(BigDecimal ndrAlignedScore) {
		this.ndrAlignedScore = ndrAlignedScore;
	}



	public BigDecimal getNdrRawScore() {
		return ndrRawScore;
	}



	public void setNdrRawScore(BigDecimal ndrRawScore) {
		this.ndrRawScore = ndrRawScore;
	}



	public BigDecimal getNdrScorecardRefno() {
		return ndrScorecardRefno;
	}



	public void setNdrScorecardRefno(BigDecimal ndrScorecardRefno) {
		this.ndrScorecardRefno = ndrScorecardRefno;
	}



	public BigDecimal getDebtType() {
		return debtType;
	}



	public void setDebtType(BigDecimal debtType) {
		this.debtType = debtType;
	}



	public BigDecimal getDdiSuspendedInd() {
		return ddiSuspendedInd;
	}



	public void setDdiSuspendedInd(BigDecimal ddiSuspendedInd) {
		this.ddiSuspendedInd = ddiSuspendedInd;
	}



	public BigDecimal getNextAccountApr() {
		return nextAccountApr;
	}



	public void setNextAccountApr(BigDecimal nextAccountApr) {
		this.nextAccountApr = nextAccountApr;
	}



	public BigDecimal getNextAssessmentApr() {
		return nextAssessmentApr;
	}



	public void setNextAssessmentApr(BigDecimal nextAssessmentApr) {
		this.nextAssessmentApr = nextAssessmentApr;
	}



	public String getFidScoreWorse() {
		return fidScoreWorse;
	}



	public void setFidScoreWorse(String fidScoreWorse) {
		this.fidScoreWorse = fidScoreWorse;
	}



	public BigDecimal getNetSalesValueTSPAmtSigned() {
		return netSalesValueTSPAmtSigned;
	}



	public void setNetSalesValueTSPAmtSigned(BigDecimal netSalesValueTSPAmtSigned) {
		this.netSalesValueTSPAmtSigned = netSalesValueTSPAmtSigned;
	}



	public BigDecimal getNettSales() {
		return nettSales;
	}



	public void setNettSales(BigDecimal nettSales) {
		this.nettSales = nettSales;
	}



	public BigDecimal getInterestChargedAmt() {
		return interestChargedAmt;
	}



	public void setInterestChargedAmt(BigDecimal interestChargedAmt) {
		this.interestChargedAmt = interestChargedAmt;
	}



	public BigDecimal getNumberCustomerCredits() {
		return numberCustomerCredits;
	}



	public void setNumberCustomerCredits(BigDecimal numberCustomerCredits) {
		this.numberCustomerCredits = numberCustomerCredits;
	}



	public BigDecimal getNumRetPayments() {
		return numRetPayments;
	}



	public void setNumRetPayments(BigDecimal numRetPayments) {
		this.numRetPayments = numRetPayments;
	}



	public BigDecimal getoTB() {
		return oTB;
	}



	public void setoTB(BigDecimal oTB) {
		this.oTB = oTB;
	}



	public BigDecimal getCustomerCreditsAmtSigned() {
		return customerCreditsAmtSigned;
	}



	public void setCustomerCreditsAmtSigned(BigDecimal customerCreditsAmtSigned) {
		this.customerCreditsAmtSigned = customerCreditsAmtSigned;
	}



	public BigDecimal getOtherCreditsAmtSigned() {
		return otherCreditsAmtSigned;
	}



	public void setOtherCreditsAmtSigned(BigDecimal otherCreditsAmtSigned) {
		this.otherCreditsAmtSigned = otherCreditsAmtSigned;
	}



	public BigDecimal getOtherDebitsAmtSigned() {
		return otherDebitsAmtSigned;
	}



	public void setOtherDebitsAmtSigned(BigDecimal otherDebitsAmtSigned) {
		this.otherDebitsAmtSigned = otherDebitsAmtSigned;
	}



	public BigDecimal getOverIndebtScore() {
		return overIndebtScore;
	}



	public void setOverIndebtScore(BigDecimal overIndebtScore) {
		this.overIndebtScore = overIndebtScore;
	}



	public BigDecimal getRebatesAmtSigned() {
		return rebatesAmtSigned;
	}



	public void setRebatesAmtSigned(BigDecimal rebatesAmtSigned) {
		this.rebatesAmtSigned = rebatesAmtSigned;
	}



	public BigDecimal getReturnsTSPAmtSigned() {
		return returnsTSPAmtSigned;
	}



	public void setReturnsTSPAmtSigned(BigDecimal returnsTSPAmtSigned) {
		this.returnsTSPAmtSigned = returnsTSPAmtSigned;
	}



	public BigDecimal getT8ReturnsAmtSigned() {
		return t8ReturnsAmtSigned;
	}



	public void setT8ReturnsAmtSigned(BigDecimal t8ReturnsAmtSigned) {
		this.t8ReturnsAmtSigned = t8ReturnsAmtSigned;
	}



	public BigDecimal getOrdersValueTSPAmtSigned() {
		return ordersValueTSPAmtSigned;
	}



	public void setOrdersValueTSPAmtSigned(BigDecimal ordersValueTSPAmtSigned) {
		this.ordersValueTSPAmtSigned = ordersValueTSPAmtSigned;
	}



	public BigDecimal getRiskNavScore() {
		return riskNavScore;
	}



	public void setRiskNavScore(BigDecimal riskNavScore) {
		this.riskNavScore = riskNavScore;
	}



	public BigDecimal getScorecardRefno() {
		return scorecardRefno;
	}



	public void setScorecardRefno(BigDecimal scorecardRefno) {
		this.scorecardRefno = scorecardRefno;
	}



	public BigDecimal getAssessmentNumber() {
		return assessmentNumber;
	}



	public void setAssessmentNumber(BigDecimal assessmentNumber) {
		this.assessmentNumber = assessmentNumber;
	}



	public String getStatPromMessageCodeRec() {
		return statPromMessageCodeRec;
	}



	public void setStatPromMessageCodeRec(String statPromMessageCodeRec) {
		this.statPromMessageCodeRec = statPromMessageCodeRec;
	}



	public BigDecimal getMinIntFreePaymentAmt() {
		return MinIntFreePaymentAmt;
	}



	public void setMinIntFreePaymentAmt(BigDecimal minIntFreePaymentAmt) {
		MinIntFreePaymentAmt = minIntFreePaymentAmt;
	}



	public Date getTimestampCreatedSnapshot() {
		return timestampCreatedSnapshot;
	}



	public void setTimestampCreatedSnapshot(Date timestampCreatedSnapshot) {
		this.timestampCreatedSnapshot = timestampCreatedSnapshot;
	}



	public BigDecimal getTotalBalanceAmtSigned() {
		return totalBalanceAmtSigned;
	}



	public void setTotalBalanceAmtSigned(BigDecimal totalBalanceAmtSigned) {
		this.totalBalanceAmtSigned = totalBalanceAmtSigned;
	}



	public BigDecimal getTotalFeesAmtSigned() {
		return totalFeesAmtSigned;
	}



	public void setTotalFeesAmtSigned(BigDecimal totalFeesAmtSigned) {
		this.totalFeesAmtSigned = totalFeesAmtSigned;
	}



	public BigDecimal getTotalUnchMvmtAmtSigned() {
		return totalUnchMvmtAmtSigned;
	}



	public void setTotalUnchMvmtAmtSigned(BigDecimal totalUnchMvmtAmtSigned) {
		this.totalUnchMvmtAmtSigned = totalUnchMvmtAmtSigned;
	}



	public BigDecimal getWorseFollowupCode() {
		return worseFollowupCode;
	}



	public void setWorseFollowupCode(BigDecimal worseFollowupCode) {
		this.worseFollowupCode = worseFollowupCode;
	}



	public BigDecimal getRetPaymentsAmtSigned() {
		return retPaymentsAmtSigned;
	}



	public void setRetPaymentsAmtSigned(BigDecimal retPaymentsAmtSigned) {
		this.retPaymentsAmtSigned = retPaymentsAmtSigned;
	}



	public BigDecimal getGrossRevenueAmtSigned() {
		return grossRevenueAmtSigned;
	}



	public void setGrossRevenueAmtSigned(BigDecimal grossRevenueAmtSigned) {
		this.grossRevenueAmtSigned = grossRevenueAmtSigned;
	}



	public BigDecimal getTradingStatus() {
		return tradingStatus;
	}



	public void setTradingStatus(BigDecimal tradingStatus) {
		this.tradingStatus = tradingStatus;
	}



	public BigDecimal getSppd() {
		return sppd;
	}



	public void setSppd(BigDecimal sppd) {
		this.sppd = sppd;
	}



	public BigDecimal getPayTypeTSTAmtSigned() {
		return payTypeTSTAmtSigned;
	}



	public void setPayTypeTSTAmtSigned(BigDecimal payTypeTSTAmtSigned) {
		this.payTypeTSTAmtSigned = payTypeTSTAmtSigned;
	}
}
