package com.shopdirect.nce.sp.business;

import java.util.ArrayList;
import java.util.List;

import com.shopdirect.fcm.data_pseudochargeforecastservice.FcmPseudoChargeException;
import com.shopdirect.fcm.xsd.forecastmodeller.PseudoChargeReqType;
import com.shopdirect.fcm.xsd.forecastmodeller.PseudoChargeRespType;
import com.shopdirect.nce.cc.fcm.core.adapter.pseudocharge.PseudoChargeAdapter;
import com.shopdirect.nce.cc.fcm.core.factory.AdapterFactory;
import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.dao.AccountReassessmentPsuedoChargesDao;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.ARPseudoChargeReqType;
import com.shopdirect.nce.sp.model.CustomerAccountInfo;
import com.shopdirect.nce.sp.model.PseudoChargeResponseType;
import com.shopdirect.osb.xsd.header.RequestHeaderType;

/**
 * @author amitkumar4
 *
 */

public class PseudoChargeCalculationBusinessImpl extends AccountReassessmentBaseBusinessImpl {

	private static SDLoggerImpl logger = new SDLoggerImpl();
	
	public PseudoChargeCalculationBusinessImpl() throws StatementProcessorBatchException {
		super();
	}
	
	/**
	 * This Method calculate the Pseudo Charge calculation  .  
	 * @param customerAccountInfo
	 * @return isLinkedAccout
	 * @throws StatementProcessorBatchException
	 */
	public PseudoChargeResponseType process(CustomerAccountInfo customerAccountInfo) throws StatementProcessorBatchException {
		logger.debug("[PseudoChargeCalculationBusinessImpl -- process] -- Start"); 
		PseudoChargeResponseType arPseudoChargeRespType = new PseudoChargeResponseType();
		
		arPseudoChargeRespType.setPseudoChargeRespType(calculatePseudoCharges(customerAccountInfo));
		logger.debug("[PseudoChargeCalculationBusinessImpl -- process] -- End"); 
		return arPseudoChargeRespType;
	}
	
	
	/**
	 * @param 
	 * @return logger 
	 */
	public SDLoggerImpl getLogger() {
		return logger;
	}
	

	/**
	 * @param customerAccountInfo
	 * @return accountReassessmentPseudoChargeRespType
	 * @throws StatementProcessorBatchException
	 */
	public PseudoChargeRespType calculatePseudoCharges(CustomerAccountInfo customerAccountInfo) throws StatementProcessorBatchException {
		getLogger().info("[PseudoChargeCalculationBusinessImpl -- calculatePseudoCharges] -- Start");
		PseudoChargeRespType  pseudoChargeRespType = new PseudoChargeRespType();
		try {
			AccountReassessmentPsuedoChargesDao accountReassessmentPsuedoChargesDao = new AccountReassessmentPsuedoChargesDao();
			//List<AccountReassessmentPseudoChargeReqType> requestTypeList = new ArrayList();
			List<ARPseudoChargeReqType> requestTypeList = new ArrayList<>();
			RequestHeaderType requestHeaderType = new RequestHeaderType();
			PseudoChargeReqType pseudoChargeReqType = new PseudoChargeReqType();
			requestTypeList = accountReassessmentPsuedoChargesDao.getCalculatePseudoCharges(customerAccountInfo.getCreditAccountId(),customerAccountInfo.getStatementDate());
				
			for(ARPseudoChargeReqType requestType : requestTypeList){
				logger.debug("requestType: " +requestType);
				if(requestType != null){
					
					pseudoChargeRespType = getPseudoCharge(requestHeaderType, pseudoChargeReqType);
				}
			  }
			
			}catch (StatementProcessorBatchException statementProcessorBatchException) {
				statementProcessorBatchException.setErrorKey(StatementProcessorBatchConstants.ERROR_PSEUDOCHARGE);
				throw statementProcessorBatchException; 
			   		
			}catch(Exception exception){
				getLogger().error("[PseudoChargeCalculationBusinessImpl -- calculatePseudoCharges] --FcmPseudoChargeException Block  "+exception.getMessage());
				throw new StatementProcessorBatchException(StatementProcessorBatchConstants.PSEUDOCHARGE_BUSINESS_ERROR_CODE,
						"[StartAccountReassessmentBusinessImpl-getPseudoCharge] Exception Block",
						"Business exception generated at time to process the data collection "+ exception.getMessage(),
						StatementProcessorBatchConstants.ERROR_PSEUDOCHARGE, null,exception);
			}
		getLogger().info("[PseudoChargeCalculationBusinessImpl -- calculatePseudoCharges] -- End");
		return pseudoChargeRespType;
	}
	
	/**
	 * @param requestHeaderType
	 * @param pseudoChargeReqType
	 * @return
	 * @throws GetPseudoChargeFault
	 */
	public PseudoChargeRespType getPseudoCharge(RequestHeaderType requestHeaderType, PseudoChargeReqType pseudoChargeReqType) throws StatementProcessorBatchException {
		PseudoChargeAdapter pseudoChargeadapter = AdapterFactory.getAdapter(pseudoChargeReqType);
		try{
			return pseudoChargeadapter.invoke(pseudoChargeReqType);
		}catch(FcmPseudoChargeException fcme){
			getLogger().error("[PseudoChargeCalculationBusinessImpl--getPseudoCharge] --FcmPseudoChargeException Block  "+fcme.getMessage());
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.PSEUDOCHARGE_BUSINESS_ERROR_CODE,
					"[PseudoChargeCalculationBusinessImpl-getPseudoCharge] Exception Block",
					"Failed to invoke Forecast Modeller method "+ fcme.getMessage(),
					null, null,fcme);
		}catch(Exception e){
			getLogger().error("[PseudoChargeCalculationBusinessImpl--getPseudoCharge] --FcmPseudoChargeException Block  "+e.getMessage());
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.PSEUDOCHARGE_BUSINESS_ERROR_CODE,
					"[PseudoChargeCalculationBusinessImpl-getPseudoCharge] Exception Block",
					"Failed to invoke Forecast Modeller method "+ e.getMessage(),
					null, null,e);
		}
	}

}
