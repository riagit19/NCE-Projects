package com.shopdirect.nce.sp.transform;

import java.math.BigDecimal;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.model.AgreementTriad;
import com.shopdirect.nce.sp.util.StatementProcessorBatchUtil;

public class AgreementTriadDBTransformer {

	private static SDLoggerImpl logger = new SDLoggerImpl();
	
	public void setAgreementTriadObject(AgreementTriad agreementTriad, Object[] attributes) {

		logger.debug("[AgreementTriadDBTransformer - setAgreementTriadObject] - Start");
		int index = 0;
		agreementTriad.setAgreementID(attributes[index] != null ? attributes[index].toString() : null);
		++index;
		agreementTriad.setFnStatNo(attributes[index] != null ? new BigDecimal(attributes[index].toString()) : null);
		++index;
		agreementTriad.setStatementDate(StatementProcessorBatchUtil.convertSqlDate(attributes[index]));
		++index;
		agreementTriad.setCreditLimit(attributes[index] != null ? new BigDecimal(attributes[index].toString()) : null);
		++index;
		agreementTriad.setLastPayMethod(attributes[index] != null ? new BigDecimal(attributes[index].toString()) : null);
		++index;
		agreementTriad.setBalance(attributes[index] != null ? new BigDecimal(attributes[index].toString()) : null);
		++index;
		agreementTriad.setLastMIVDate(StatementProcessorBatchUtil.convertSqlDate(attributes[index]));
		++index;
		agreementTriad.setLastOrderDate(StatementProcessorBatchUtil.convertSqlDate(attributes[index]));
		++index;
		agreementTriad.setLastPayDate(StatementProcessorBatchUtil.convertSqlDate(attributes[index]));
		++index;
		agreementTriad.setNextPaymentDueDate(StatementProcessorBatchUtil.convertSqlDate(attributes[index]));
		++index;
		agreementTriad.setLastStatementDate(StatementProcessorBatchUtil.convertSqlDate(attributes[index]));
		++index;
		agreementTriad.setNextStatementDate(StatementProcessorBatchUtil.convertSqlDate(attributes[index]));
		++index;
		agreementTriad.setDateSection87(StatementProcessorBatchUtil.convertSqlDate(attributes[index]));
		++index;
		agreementTriad.setNsfDate(StatementProcessorBatchUtil.convertSqlDate(attributes[index]));
		++index;
		agreementTriad.setPayDateAmtList(attributes[index] != null ? attributes[index].toString() : null);
		++index;
		agreementTriad.setScheduledPaymentAmt(attributes[index] != null ? new BigDecimal(attributes[index].toString()) : null);
		++index;
		agreementTriad.setScheduledPaymentPastDue(attributes[index] != null ? new BigDecimal(attributes[index].toString()) : null);
		++index;
		agreementTriad.setPastDueAmt(attributes[index] != null ? new BigDecimal(attributes[index].toString()) : null);
		++index;
		agreementTriad.setAvailableToSpend(attributes[index] != null ? new BigDecimal(attributes[index].toString()) : null);
		++index;
		agreementTriad.setBnplBalance(attributes[index] != null ? new BigDecimal(attributes[index].toString()) : null);
		++index;
		agreementTriad.setApr(attributes[index] != null ? new BigDecimal(attributes[index].toString()) : null);
		++index;
		agreementTriad.setTotPay30Days(attributes[index] != null ? new BigDecimal(attributes[index].toString()) : null);
		++index;
		agreementTriad.setInstArrears(attributes[index] != null ? new BigDecimal(attributes[index].toString()) : null);
		++index;
		agreementTriad.setLastArrangementDate(StatementProcessorBatchUtil.convertSqlDate(attributes[index]));
		++index;
		agreementTriad.setPayAmtTSP(attributes[index] != null ? new BigDecimal(attributes[index].toString()) : null);
		++index;
		agreementTriad.setLastZeroBal(StatementProcessorBatchUtil.convertSqlDate(attributes[index]));
		++index;
		agreementTriad.setReturnsAmtTSP(attributes[index] != null ? new BigDecimal(attributes[index].toString()) : null);
		++index;
		agreementTriad.setOtherAdjAmtTSP(attributes[index] != null ? new BigDecimal(attributes[index].toString()) : null);
		++index;
		agreementTriad.setLastPayAmt(attributes[index] != null ? new BigDecimal(attributes[index].toString()) : null);
		++index;
		agreementTriad.setPaymentPreviousIND(attributes[index] != null ? new BigDecimal(attributes[index].toString()) : null);
		++index;
		agreementTriad.setPaymentCurrentIND(attributes[index] != null ? new BigDecimal(attributes[index].toString()) : null);
		++index;
		agreementTriad.setNumPurchasesTSP(attributes[index] != null ? new BigDecimal(attributes[index].toString()) : null);
		++index;
		agreementTriad.setTotFeesTSP(attributes[index] != null ? new BigDecimal(attributes[index].toString()) : null);
		++index;
		agreementTriad.setCustCreditsTSP(attributes[index] != null ? new BigDecimal(attributes[index].toString()) : null);
		++index;
		agreementTriad.setTotPayYear(attributes[index] != null ? new BigDecimal(attributes[index].toString()) : null);
		++index;
		agreementTriad.setNumPayTSP(attributes[index] != null ? new BigDecimal(attributes[index].toString()) : null);
		++index;
		agreementTriad.setIntChargedTSP(attributes[index] != null ? new BigDecimal(attributes[index].toString()) : null);
		++index;
		agreementTriad.setPurchaseAmtTSP(attributes[index] != null ? new BigDecimal(attributes[index].toString()) : null);
		++index;
		agreementTriad.setRebatesAmtTSP(attributes[index] != null ? new BigDecimal(attributes[index].toString()) : null);
		++index;
		agreementTriad.setBnplIntAmtTSP(attributes[index] != null ? new BigDecimal(attributes[index].toString()) : null);
		++index;
		agreementTriad.setNumRetPayTSP(attributes[index] != null ? new BigDecimal(attributes[index].toString()) : null);
		++index;
		agreementTriad.setLastArrearsWks(attributes[index] != null ? new BigDecimal(attributes[index].toString()) : null);
		++index;
		agreementTriad.setCreditLimitUtil(attributes[index] != null ? new BigDecimal(attributes[index].toString()) : null);
		++index;
		agreementTriad.setLastPaymentDays(attributes[index] != null ? new BigDecimal(attributes[index].toString()) : null);
		++index;
		agreementTriad.setNillBalanceDays(attributes[index] != null ? new BigDecimal(attributes[index].toString()) : null);
		++index;
		agreementTriad.setTakeAll(attributes[index] != null ? new BigDecimal(attributes[index].toString()) : null);
		
		logger.debug("[AgreementTriadDBTransformer - setAgreementTriadObject] - End");
	}
}
