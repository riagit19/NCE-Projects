package com.shopdirect.nce.sp.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import com.shopdirect.fcm.xsd.forecastmodeller.CustomerAccountInterestReqType;

public class AccountReassessmentInfoModel implements Serializable {

	/* the constant serialVersionUID */
	private static final long serialVersionUID = 1L;

	private String agreementCode;
	private String agreementBrandType;
	private String cimPaymentDayOfMonth;
	private String cimPaymentPeriod;
	private String agreementMinPayThreshold;
	private String agreementMinPayPercentageThreshold;
	private String agreementOtbAmount;
	private String noisaArrearsAmount;
	private String drawdownTermCashPrice;
	private String drawdownTermCurrentBalance;
	private String uniqueRequestId;
	private String drawdownItemType;
	private String drawdownTermChargeDate;
	private String drawdownTermDeferredTerminDays;
	private String drawdownTermRate;
	private String drawdownTermStartDate;
	private String drawdownTermEndDate;
	private String drawdownItemscashPrice;
	private String drawdownProductCategory;
	private String drawdownEstimatedInterest;
	private String drawdownCode;
	private String drawdownTerm;
	private String drawdownTermUnit;
	private Set<String> drawdownCodeList;

	public AccountReassessmentInfoModel() {
	}

	public AccountReassessmentInfoModel(String agreementCode, String agreementOtbAmount, String drawdownTermEndDate,
			String drawdownTermDeferredTerminDays, String drawdownTermStartDate,String drawdownTermRate, String cimPaymentPeriod,
			String cimPaymentDayOfMonth, String drawdownProductCategory,
			String drawdownCode, String drawdownTerm, String drawdownTermUnit) {
		this.agreementCode = agreementCode;
		this.agreementOtbAmount = agreementOtbAmount;
		this.drawdownTermStartDate=drawdownTermStartDate;
		this.drawdownTermEndDate = drawdownTermEndDate;
		this.drawdownTermDeferredTerminDays = drawdownTermDeferredTerminDays;
		this.drawdownTermRate = drawdownTermRate;
		this.cimPaymentPeriod = cimPaymentPeriod;
		this.cimPaymentDayOfMonth = cimPaymentDayOfMonth;
		this.drawdownProductCategory = drawdownProductCategory;
		this.drawdownCode = drawdownCode;
		this.drawdownTerm = drawdownTerm;
		this.drawdownTermUnit = drawdownTermUnit;
	}

	public String getAgreementCode() {
		return agreementCode;
	}

	public void setAgreementCode(String agreementCode) {
		this.agreementCode = agreementCode;
	}

	public String getAgreementBrandType() {
		return agreementBrandType;
	}

	public void setAgreementBrandType(String agreementBrandType) {
		this.agreementBrandType = agreementBrandType;
	}

	public String getCimPaymentDayOfMonth() {
		return cimPaymentDayOfMonth;
	}

	public void setCimPaymentDayOfMonth(String cimPaymentDayOfMonth) {
		this.cimPaymentDayOfMonth = cimPaymentDayOfMonth;
	}

	public String getCimPaymentPeriod() {
		return cimPaymentPeriod;
	}

	public void setCimPaymentPeriod(String cimPaymentPeriod) {
		this.cimPaymentPeriod = cimPaymentPeriod;
	}

	public String getAgreementMinPayThreshold() {
		return agreementMinPayThreshold;
	}

	public void setAgreementMinPayThreshold(String agreementMinPayThreshold) {
		this.agreementMinPayThreshold = agreementMinPayThreshold;
	}

	public String getAgreementMinPayPercentageThreshold() {
		return agreementMinPayPercentageThreshold;
	}

	public void setAgreementMinPayPercentageThreshold(String agreementMinPayPercentageThreshold) {
		this.agreementMinPayPercentageThreshold = agreementMinPayPercentageThreshold;
	}

	public String getAgreementOtbAmount() {
		return agreementOtbAmount;
	}

	public void setAgreementOtbAmount(String agreementOtbAmount) {
		this.agreementOtbAmount = agreementOtbAmount;
	}

	public String getNoisaArrearsAmount() {
		return noisaArrearsAmount;
	}

	public void setNoisaArrearsAmount(String noisaArrearsAmount) {
		this.noisaArrearsAmount = noisaArrearsAmount;
	}

	public String getDrawdownTermCashPrice() {
		return drawdownTermCashPrice;
	}

	public void setDrawdownTermCashPrice(String drawdownTermCashPrice) {
		this.drawdownTermCashPrice = drawdownTermCashPrice;
	}

	public String getDrawdownTermCurrentBalance() {
		return drawdownTermCurrentBalance;
	}

	public void setDrawdownTermCurrentBalance(String drawdownTermCurrentBalance) {
		this.drawdownTermCurrentBalance = drawdownTermCurrentBalance;
	}

	public String getUniqueRequestId() {
		return uniqueRequestId;
	}

	public void setUniqueRequestId(String uniqueRequestId) {
		this.uniqueRequestId = uniqueRequestId;
	}

	public String getDrawdownItemType() {
		return drawdownItemType;
	}

	public void setDrawdownItemType(String drawdownItemType) {
		this.drawdownItemType = drawdownItemType;
	}

	public String getDrawdownTermChargeDate() {
		return drawdownTermChargeDate;
	}

	public void setDrawdownTermChargeDate(String drawdownTermChargeDate) {
		this.drawdownTermChargeDate = drawdownTermChargeDate;
	}

	public String getDrawdownTermDeferredTerminDays() {
		return drawdownTermDeferredTerminDays;
	}

	public void setDrawdownTermDeferredTerminDays(String drawdownTermDeferredTerminDays) {
		this.drawdownTermDeferredTerminDays = drawdownTermDeferredTerminDays;
	}

	public String getDrawdownTermRate() {
		return drawdownTermRate;
	}

	public void setDrawdownTermRate(String drawdownTermRate) {
		this.drawdownTermRate = drawdownTermRate;
	}

	public String getDrawdownTermStartDate() {
		return drawdownTermStartDate;
	}

	public void setDrawdownTermStartDate(String drawdownTermStartDate) {
		this.drawdownTermStartDate = drawdownTermStartDate;
	}

	public String getDrawdownTermEndDate() {
		return drawdownTermEndDate;
	}

	public void setDrawdownTermEndDate(String drawdownTermEndDate) {
		this.drawdownTermEndDate = drawdownTermEndDate;
	}

	public String getDrawdownItemscashPrice() {
		return drawdownItemscashPrice;
	}

	public void setDrawdownItemscashPrice(String drawdownItemscashPrice) {
		this.drawdownItemscashPrice = drawdownItemscashPrice;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getDrawdownProductCategory() {
		return drawdownProductCategory;
	}

	public void setDrawdownProductCategory(String drawdownProductCategory) {
		this.drawdownProductCategory = drawdownProductCategory;
	}

	public String getDrawdownEstimatedInterest() {
		return drawdownEstimatedInterest;
	}

	public void setDrawdownEstimatedInterest(String drawdownEstimatedInterest) {
		this.drawdownEstimatedInterest = drawdownEstimatedInterest;
	}

	public String getDrawdownCode() {
		return drawdownCode;
	}

	public void setDrawdownCode(String drawdownCode) {
		this.drawdownCode = drawdownCode;
	}

	public Set<String> getDrawdownCodeList() {
		return drawdownCodeList;
	}

	public void setDrawdownCodeList(Set<String> drawdownCodeList) {
		this.drawdownCodeList = drawdownCodeList;
	}

	public String getDrawdownTerm() {
		return drawdownTerm;
	}

	public void setDrawdownTerm(String drawdownTerm) {
		this.drawdownTerm = drawdownTerm;
	}

	public String getDrawdownTermUnit() {
		return drawdownTermUnit;
	}

	public void setDrawdownTermUnit(String drawdownTermUnit) {
		this.drawdownTermUnit = drawdownTermUnit;
	}

}
