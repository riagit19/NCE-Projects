package com.shopdirect.nce.sp.model;

import java.math.BigDecimal;
import java.sql.Date;

public class BatchMonth extends BatchDetails{

	private BigDecimal batchMonthOccurence;
	private Date dateStatement;
	
	public BatchMonth() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BatchMonth(BigDecimal batchMonthOccurence, Date dateStatement) {
		super();
		this.batchMonthOccurence = batchMonthOccurence;
		this.dateStatement = dateStatement;
	}

	public BigDecimal getBatchMonthOccurence() {
		return batchMonthOccurence;
	}

	public void setBatchMonthOccurence(BigDecimal batchMonthOccurence) {
		this.batchMonthOccurence = batchMonthOccurence;
	}

	public Date getDateStatement() {
		return dateStatement;
	}

	public void setDateStatement(Date dateStatement) {
		this.dateStatement = dateStatement;
	}
	
	
}
