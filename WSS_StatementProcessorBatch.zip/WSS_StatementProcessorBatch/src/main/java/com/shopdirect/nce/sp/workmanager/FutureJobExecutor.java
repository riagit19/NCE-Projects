package com.shopdirect.nce.sp.workmanager;

import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;

/**
 * 
 * @author SudiptaRoy
 *
 */
public class FutureJobExecutor {

	private ThreadPoolExecutor executorService;
	private static final SDLoggerImpl LOGGER = new SDLoggerImpl();

	public FutureJobExecutor() {
		executorService = (ThreadPoolExecutor) Executors.newCachedThreadPool();
	}

	/**
	 * Execute the jobs added to Future Job
	 * 
	 * @param futureJobs
	 */
	public Future<AccountReassessmentExecutor> submitJob(AccountReassessmentExecutor job) {
		return executorService.submit(job);
	}
	
	/**
	 * 
	 * @param pseudoJob
	 * @return
	 */
	public Future<PseudoChargeExecutor> submitPseudoJobs(PseudoChargeExecutor pseudoJob) {
		return executorService.submit(pseudoJob);
	}

	/**
	 * 
	 */
	public void closeExecutorService() {
		if (executorService != null && !executorService.isShutdown() && !executorService.isTerminated()) {
			executorService.shutdown();
			try {
				executorService.awaitTermination(20, TimeUnit.SECONDS);
			} catch (Exception e) {
				LOGGER.error("Exception while shutting down executor: " + e);
			}
		}
	}
}
