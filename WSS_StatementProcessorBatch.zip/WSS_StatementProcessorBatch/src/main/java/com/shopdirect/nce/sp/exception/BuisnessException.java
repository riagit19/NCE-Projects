package com.shopdirect.nce.sp.exception;

public class BuisnessException extends Exception {
	
	String errorCode;
	String message;

    public BuisnessException() {
        super();
    }

    public BuisnessException(String msg) {
    	this.message = msg;

    }
    
    public BuisnessException(String msg, String errorCode) {
        this.message = msg;
        this.errorCode = errorCode;

    }
    
    // Overrides Exception's getMessage()
    @Override
    public String getMessage(){
        return message;
    }

    public String getErrorCode(){
    	return errorCode;
    }

}
