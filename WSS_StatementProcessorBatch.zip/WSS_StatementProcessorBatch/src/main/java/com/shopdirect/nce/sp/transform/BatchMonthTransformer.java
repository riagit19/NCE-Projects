package com.shopdirect.nce.sp.transform;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.model.AccountingSnapshot;
import com.shopdirect.nce.sp.model.BatchDetails;
import com.shopdirect.nce.sp.model.BatchMonth;
import com.shopdirect.nce.sp.model.CustomerAccountInfo;

public class BatchMonthTransformer {

	private static SDLoggerImpl logger = new SDLoggerImpl();
	
	public List<BatchMonth> getBatchMonth(BatchDetails batchDetails,
			List<AccountingSnapshot> accountingSnapshotList, CustomerAccountInfo accountInfo) {
		
		logger.debug("[BatchMonthTransformer - getBatchMonth] - Start");

		List<BatchMonth> batchMonthList = new ArrayList<BatchMonth>();
		BatchMonth batchMonthObj;
		
		for (int i = 0; i < accountingSnapshotList.size(); i++) {
			batchMonthObj = new BatchMonth();
			
			if (i == 0) {
				batchMonthObj.setCustomerAccountNumber(accountInfo.getPublicAccountId());
				batchMonthObj.setBatchMonthOccurence(new BigDecimal(i+1));
				batchMonthObj.setScheduledPaymentsPastDue(batchDetails.getScheduledPaymentsPastDue());
				batchMonthObj.setInterestChargedAmtTSP(batchDetails.getInterestChargedAmtTSP());
				batchMonthObj.setNumPurchasesTSP(batchDetails.getNumPurchasesTSP());
				batchMonthObj.setRiskNavScore(batchDetails.getRiskNavScore());
				batchMonthObj.setOverIndebtScore(batchDetails.getOverIndebtScore());
				batchMonthObj.setBehaviourScore(batchDetails.getBehaviourScore());
				batchMonthObj.setcRF(batchDetails.getcRF());
				batchMonthObj.setBehaviourRawScore(batchDetails.getBehaviourRawScore());
				batchMonthObj.setScorecardId(batchDetails.getScorecardId());
				batchMonthObj.setAcdScorecardId(batchDetails.getAcdScorecardId());
				batchMonthObj.setAcdRawScore(batchDetails.getAcdRawScore());
				batchMonthObj.setAcdAlignedScore(batchDetails.getAcdAlignedScore());
				batchMonthObj.setNdrScorecardId(batchDetails.getNdrScorecardId());
				batchMonthObj.setNdrRawScore(batchDetails.getNdrRawScore());
				batchMonthObj.setNdrAlignedScore(batchDetails.getNdrAlignedScore());
				batchMonthObj.setCustScorecardId(batchDetails.getCustScorecardId());
				batchMonthObj.setCustRawScore(batchDetails.getCustRawScore());
				batchMonthObj.setCustAlignedScore(batchDetails.getCustAlignedScore());
				batchMonthObj.setRebatesAmountTSP(batchDetails.getRebatesAmountTSP());
				batchMonthObj.setoTB(batchDetails.getoTB());
				batchMonthObj.setNumPaymentsTSP(batchDetails.getNumPaymentsTSP());
				batchMonthObj.setNumNSF(batchDetails.getNumNSF());
				batchMonthObj.setDateStatement(accountingSnapshotList.get(i).getAssessmentDate());
				batchMonthObj.setBlockCode(null);
				batchMonthObj.setCurrentBalance(batchDetails.getCurrentBalance());
				batchMonthObj.setPurchaseAmountTSP(batchDetails.getPurchaseAmountTSP());
				batchMonthObj.setTotalFeesTSP(batchDetails.getTotalFeesTSP());
				batchMonthObj.setOtherDebits(batchDetails.getOtherDebits());
				batchMonthObj.setPaymentAmountTSP(batchDetails.getPaymentAmountTSP());
				batchMonthObj.setOtherCredits(batchDetails.getOtherCredits());
				batchMonthObj.setNumFailedPayments(batchDetails.getNumFailedPayments());
				batchMonthObj.setValueFailedPayments(batchDetails.getValueFailedPayments());
				batchMonthObj.setMinPayment(batchDetails.getMinPayment());
				batchMonthObj.setPastDue(batchDetails.getPastDue());
				batchMonthObj.setFidScoreWorst(batchDetails.getFidScoreWorst());
				batchMonthObj.setBnplBalance(batchDetails.getBnplBalance());
				batchMonthObj.setReturnsAmountTSP(batchDetails.getReturnsAmountTSP());
				batchMonthObj.setNetSalesValueTSPAmt(batchDetails.getNetSalesValueTSPAmt());
				batchMonthObj.setReturnsAmountTSP(batchDetails.getReturnsAmountTSP());
			} else {
				
				AccountingSnapshot accSnapshot = accountingSnapshotList.get(i);
				batchMonthObj.setCustomerAccountNumber(accountInfo.getPublicAccountId());
				batchMonthObj.setBatchMonthOccurence(new BigDecimal(i));
				batchMonthObj.setScheduledPaymentsPastDue(accSnapshot.getScheduledPaymentsPastDue());
				batchMonthObj.setInterestChargedAmtTSP(accSnapshot.getInterestChargedAmtTSP());
				batchMonthObj.setNumPurchasesTSP(accSnapshot.getNumPurchasesTSP());
				batchMonthObj.setRiskNavScore(accSnapshot.getRiskNavScore());
				batchMonthObj.setOverIndebtScore(accSnapshot.getOverIndebtScore());
				batchMonthObj.setBehaviourScore(accSnapshot.getBehaviourScore());
				batchMonthObj.setcRF(accSnapshot.getcRF());
				batchMonthObj.setBehaviourRawScore(accSnapshot.getBehaviourRawScore());
				batchMonthObj.setScorecardId(accSnapshot.getScorecardId());
				batchMonthObj.setAcdScorecardId(accSnapshot.getAcdScorecardId());
				batchMonthObj.setAcdRawScore(accSnapshot.getAcdRawScore());
				batchMonthObj.setAcdAlignedScore(accSnapshot.getAcdAlignedScore());
				batchMonthObj.setNdrScorecardId(accSnapshot.getNdrScorecardId());
				batchMonthObj.setNdrRawScore(accSnapshot.getNdrRawScore());
				batchMonthObj.setNdrAlignedScore(accSnapshot.getNdrAlignedScore());
				batchMonthObj.setCustScorecardId(accSnapshot.getCustScorecardId());
				batchMonthObj.setCustRawScore(accSnapshot.getCustRawScore());
				batchMonthObj.setCustAlignedScore(accSnapshot.getCustAlignedScore());
				batchMonthObj.setRebatesAmountTSP(accSnapshot.getRebatesAmountTSP());
				batchMonthObj.setoTB(accSnapshot.getoTB());
				batchMonthObj.setNumPaymentsTSP(accSnapshot.getNumPaymentsTSP());
				batchMonthObj.setNumNSF(accSnapshot.getNumNSF());
				batchMonthObj.setDateStatement(accSnapshot.getAssessmentDate());
				batchMonthObj.setBlockCode(accSnapshot.getBlockCode());
				batchMonthObj.setCurrentBalance(accSnapshot.getCurrentBalance());
				batchMonthObj.setPurchaseAmountTSP(accSnapshot.getPurchaseAmountTSP());
				batchMonthObj.setTotalFeesTSP(accSnapshot.getTotalFeesTSP());
				batchMonthObj.setOtherDebits(accSnapshot.getOtherDebits());
				batchMonthObj.setPaymentAmountTSP(accSnapshot.getPaymentAmountTSP());
				batchMonthObj.setOtherCredits(accSnapshot.getOtherCredits());
				batchMonthObj.setNumFailedPayments(accSnapshot.getNumFailedPayments());
				batchMonthObj.setValueFailedPayments(accSnapshot.getValueFailedPayments());
				batchMonthObj.setMinPayment(accSnapshot.getMinPayment());
				batchMonthObj.setPastDue(accSnapshot.getPastDue());
				batchMonthObj.setFidScoreWorst(accSnapshot.getFidScoreWorst());
				batchMonthObj.setBnplBalance(accSnapshot.getBnplBalance());
				batchMonthObj.setReturnsAmountTSP(accSnapshot.getReturnsAmountTSP());
				batchMonthObj.setNetSalesValueTSPAmt(accSnapshot.getNetSalesValueTSPAmt());
				batchMonthObj.setReturnsAmountTSP(accSnapshot.getReturnsAmountTSP());

			}
			batchMonthList.add(batchMonthObj);	
		}
		
		logger.debug("[BatchMonthTransformer - getBatchMonth] - End");
		return batchMonthList;
	}
}
