package com.shopdirect.nce.sp.transform;

import java.math.BigDecimal;
import java.math.BigInteger;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.model.AccountingSnapshotTriad;
import com.shopdirect.nce.sp.model.AgreementTriad;
import com.shopdirect.nce.sp.model.CustomerAccountInfo;
import com.shopdirect.nce.sp.model.CustomerContractTriad;
import com.shopdirect.nce.sp.util.StatementProcessorBatchUtil;
import com.shopdirect.osb.reassesstriadar.IssueAccountSnapshotDataRequestType;
import com.shopdirect.osb.reassesstriadar.ReassessTRIADARType;

public class IssueAccountSnapshotDataTransformer {
	
	private static SDLoggerImpl logger = new SDLoggerImpl();
	
	public void issueAccountSnapshotDataRequest(ReassessTRIADARType reassessTRIADARType,
			CustomerAccountInfo accountInfo, AgreementTriad agreementTriad, CustomerContractTriad customerContractTriad,
			AccountingSnapshotTriad accountingSnapshotTriad, String tradingCode) throws Exception {
		
		logger.debug("[IssueAccountSnapshotDataTransformer -- issueAccountSnapshotDataRequest] -- Start");
		
		IssueAccountSnapshotDataRequestType issueAccountSnapshotDataRequestType = new IssueAccountSnapshotDataRequestType();
		issueAccountSnapshotDataRequestType.setRetailAccountNumber(accountInfo.getRetailAccountId());
		issueAccountSnapshotDataRequestType.setAssessmentDate(StatementProcessorBatchUtil.getDate(accountingSnapshotTriad.getAssessmentDate()));
		issueAccountSnapshotDataRequestType.setAssessmentNumber(accountingSnapshotTriad.getAssessmentNumber() != null ? accountingSnapshotTriad.getAssessmentNumber().toString() : null);
		issueAccountSnapshotDataRequestType.setClosingBalanceAmountSigned(accountingSnapshotTriad.getClosingBalanceAmtSigned());
		issueAccountSnapshotDataRequestType.setOpeningBalanceAmountSigned(accountingSnapshotTriad.getOpeningBalanceAmtSign());
		issueAccountSnapshotDataRequestType.setBNPLBalanceAmountSigned(accountingSnapshotTriad.getBnplBalanceAmtSigned());
		issueAccountSnapshotDataRequestType.setScheduledPaymenAmount(accountingSnapshotTriad.getScheduledPaymentAmt());
		issueAccountSnapshotDataRequestType.setPastDueAmountSigned(accountingSnapshotTriad.getPastDueAmtSigned());
		issueAccountSnapshotDataRequestType.setPayTypeTSPAmountSigned(accountingSnapshotTriad.getPayTypeTSTAmtSigned());
		issueAccountSnapshotDataRequestType.setTotalUNCHMvmtAmountSigned(BigDecimal.ZERO);
		issueAccountSnapshotDataRequestType.setTotalUNCHCreditCardAmountSigned(BigDecimal.ZERO);
		issueAccountSnapshotDataRequestType.setScheduledPaymentsPastDue(accountingSnapshotTriad.getScheduledPaymentAmt());
		issueAccountSnapshotDataRequestType.setTimestampCreated(StatementProcessorBatchUtil.getDate(accountInfo.getStatementDate()));
		try {
			issueAccountSnapshotDataRequestType.setTradingStatusCode(new BigInteger(tradingCode));
		} catch (Exception e) {
			logger.error("[IssueAccountSnapshotDataTransformer -- issueAccountSnapshotDataRequest] tradingCode should be int" + e);
		}
		issueAccountSnapshotDataRequestType.setMinIntFreePaymentAmount(agreementTriad.getTakeAll());
		try {
			issueAccountSnapshotDataRequestType.setDebtType(customerContractTriad.getDebtType() != null ? new BigInteger(customerContractTriad.getDebtType()) : null);
		} catch (Exception e) {
			logger.error("[IssueAccountSnapshotDataTransformer -- issueAccountSnapshotDataRequest] debt type should be integer " + e);
		}
		issueAccountSnapshotDataRequestType.setStatPromMessageCodeRec(accountingSnapshotTriad.getStatPromMessageCodeRec());
		issueAccountSnapshotDataRequestType.setPctInterestRate(accountingSnapshotTriad.getPctinterestRate());
		issueAccountSnapshotDataRequestType.setDDISuspendedInd(null);
		issueAccountSnapshotDataRequestType.setTotalBalanceAmountSigned(accountingSnapshotTriad.getTotalBalanceAmtSigned());
		issueAccountSnapshotDataRequestType.setFixedClosingBalAmountSigned(accountingSnapshotTriad.getFixedclosingBalAmtSigned());
		issueAccountSnapshotDataRequestType.setInterestChargedAmount(agreementTriad.getIntChargedTSP());
		issueAccountSnapshotDataRequestType.setNetSalesValueTSPAmountSigned(accountingSnapshotTriad.getNetSalesValueTSPAmtSigned());
		issueAccountSnapshotDataRequestType.setOrdersValueTSPAmountSigned(accountingSnapshotTriad.getOrdersValueTSPAmtSigned());
		issueAccountSnapshotDataRequestType.setReturnsTSPAMountSigned(agreementTriad.getReturnsAmtTSP());
		issueAccountSnapshotDataRequestType.setGrossRevenueAmountSigned(BigDecimal.ZERO);
		issueAccountSnapshotDataRequestType.setVarAPRByTCOfferCode(null);
		issueAccountSnapshotDataRequestType.setVarAPRByTCOfferNo(null);
		issueAccountSnapshotDataRequestType.setVTOTAPR(agreementTriad.getApr());
		issueAccountSnapshotDataRequestType.setOutstandingIBBNPLBalAmount(null);
		issueAccountSnapshotDataRequestType.setIBBNPLInterestChargedAmount(null);
		issueAccountSnapshotDataRequestType.setFullChargeNowAmountSigned(null);
		issueAccountSnapshotDataRequestType.setFlexIASchedPayAmountSigned(null);
		issueAccountSnapshotDataRequestType.setAssessmentAPR(accountingSnapshotTriad.getNextAssessmentApr());
		issueAccountSnapshotDataRequestType.setNumberCustomerDebits(accountingSnapshotTriad.getNumberCustomerDebits() != null ? accountingSnapshotTriad.getNumberCustomerDebits().toBigInteger() : null);
		issueAccountSnapshotDataRequestType.setCustomerDebitsAmountSigned(accountingSnapshotTriad.getCustomerDebitsAmtSigned());
		issueAccountSnapshotDataRequestType.setTotalFeesAmountSigned(accountingSnapshotTriad.getTotalFeesAmtSigned());
		issueAccountSnapshotDataRequestType.setOtherDebitsAmountSigned(accountingSnapshotTriad.getOtherDebitsAmtSigned());
		issueAccountSnapshotDataRequestType.setNumberCustomerCredits(accountingSnapshotTriad.getNumberCustomerCredits() != null ? accountingSnapshotTriad.getNumberCustomerCredits().toBigInteger() : null);
		issueAccountSnapshotDataRequestType.setCustomerCreditsAmountSigned(accountingSnapshotTriad.getCustomerCreditsAmtSigned());
		issueAccountSnapshotDataRequestType.setOtherCreditsAmountSigned(accountingSnapshotTriad.getOtherCreditsAmtSigned());
		issueAccountSnapshotDataRequestType.setNumRetPayments(agreementTriad.getNumRetPayTSP() != null ? agreementTriad.getNumRetPayTSP().toBigInteger() : null);
		issueAccountSnapshotDataRequestType.setRetPaymentsAmountSigned(accountingSnapshotTriad.getRetPaymentsAmtSigned());
		issueAccountSnapshotDataRequestType.setNETTSales(accountingSnapshotTriad.getNettSales());
		issueAccountSnapshotDataRequestType.setNETTSales6M(accountingSnapshotTriad.getNettSales6M());
		issueAccountSnapshotDataRequestType.setNETTSales12M(accountingSnapshotTriad.getNettSales12M());
		issueAccountSnapshotDataRequestType.setNETTSalesLifeTime(accountingSnapshotTriad.getNettSalesLifeTime());
		issueAccountSnapshotDataRequestType.setLatest6MNETTSales(null);
		issueAccountSnapshotDataRequestType.setLatest12MNETTSales(null);
		issueAccountSnapshotDataRequestType.setWorstFollowupCode(accountingSnapshotTriad.getWorseFollowupCode() != null ? accountingSnapshotTriad.getWorseFollowupCode().toBigInteger() : null);
		issueAccountSnapshotDataRequestType.setHighBalanceAmount(accountingSnapshotTriad.getHighBalanceAmt());
		issueAccountSnapshotDataRequestType.setHighDelq(accountingSnapshotTriad.getHighDelq() != null ? accountingSnapshotTriad.getHighDelq().toBigInteger() : null);
		issueAccountSnapshotDataRequestType.setNumCycle1(accountingSnapshotTriad.getNumCycle1() != null ? accountingSnapshotTriad.getNumCycle1().toBigInteger() : null);
		issueAccountSnapshotDataRequestType.setNumCycle2(accountingSnapshotTriad.getNumCycle2() != null ? accountingSnapshotTriad.getNumCycle2().toBigInteger() : null);
		issueAccountSnapshotDataRequestType.setNumCycle3(accountingSnapshotTriad.getNumCycle3() != null ? accountingSnapshotTriad.getNumCycle3().toBigInteger() : null);
		issueAccountSnapshotDataRequestType.setNumCycle4(accountingSnapshotTriad.getNumCycle4() != null ? accountingSnapshotTriad.getNumCycle4().toBigInteger() : null);
		issueAccountSnapshotDataRequestType.setFIDScoreWorse(accountingSnapshotTriad.getFidScoreWorse());
		issueAccountSnapshotDataRequestType.setTCBIPChargableAmountSigned(accountingSnapshotTriad.getTcbipChargableBalAmtSigned());
		issueAccountSnapshotDataRequestType.setRebatesAmountSigned(accountingSnapshotTriad.getRebatesAmtSigned());
		issueAccountSnapshotDataRequestType.setT8ReturnsAmountSigned(accountingSnapshotTriad.getT8ReturnsAmtSigned());
		issueAccountSnapshotDataRequestType.setSnapshotVTOTOfferCode(null);
		issueAccountSnapshotDataRequestType.setSnapshotVTOTOfferNo(null);
		issueAccountSnapshotDataRequestType.setSnapshotVTOTAPR(null);
		issueAccountSnapshotDataRequestType.setSnapshotAssessmentAPR(accountingSnapshotTriad.getAssessmentApr());
		issueAccountSnapshotDataRequestType.setSnapshotPCTInterestRate(accountingSnapshotTriad.getPctinterestRate());
		issueAccountSnapshotDataRequestType.setSnapshotAccountAPR(accountingSnapshotTriad.getNextAccountApr());
		issueAccountSnapshotDataRequestType.setNextVTOTOfferCode(null);
		issueAccountSnapshotDataRequestType.setNextVTOTOfferNo(null);
		issueAccountSnapshotDataRequestType.setNextVTOTAPR(null);
		issueAccountSnapshotDataRequestType.setNextAssessmentAPR(accountingSnapshotTriad.getNextAssessmentApr());
		issueAccountSnapshotDataRequestType.setNextAccountAPR(accountingSnapshotTriad.getNextAccountApr());
		issueAccountSnapshotDataRequestType.setNextAccountVddAPR(null);
		issueAccountSnapshotDataRequestType.setNextAccountVddInd(null);
		issueAccountSnapshotDataRequestType.setOpeningBNPLBalAmount(accountingSnapshotTriad.getOpeningBNPLBalAmt());
		issueAccountSnapshotDataRequestType.setOTB(accountingSnapshotTriad.getoTB());
		issueAccountSnapshotDataRequestType.setRiskNavScore(accountingSnapshotTriad.getRiskNavScore());
		issueAccountSnapshotDataRequestType.setOverInDebtScore(accountingSnapshotTriad.getOverIndebtScore());
		issueAccountSnapshotDataRequestType.setAlignedBehaviourScore(accountingSnapshotTriad.getAlignedBehaviourScore());
		issueAccountSnapshotDataRequestType.setRowBehaviourScore(accountingSnapshotTriad.getRawBehaviourScore());
		issueAccountSnapshotDataRequestType.setScorecardRefNo(accountingSnapshotTriad.getScorecardRefno());
		issueAccountSnapshotDataRequestType.setACDScorecardRefNo(accountingSnapshotTriad.getAcdScorecardRefno());
		issueAccountSnapshotDataRequestType.setACDRowScore(accountingSnapshotTriad.getAcdRawScore());
		issueAccountSnapshotDataRequestType.setACDAlignedScore(accountingSnapshotTriad.getAcdAlignedScore());
		issueAccountSnapshotDataRequestType.setNDRScorecardRefNo(accountingSnapshotTriad.getNdrScorecardRefno());
		issueAccountSnapshotDataRequestType.setNDRRowScore(accountingSnapshotTriad.getNdrRawScore());
		issueAccountSnapshotDataRequestType.setNDRAlignedScore(accountingSnapshotTriad.getNdrAlignedScore());
		issueAccountSnapshotDataRequestType.setCUSTScorecardRefNo(accountingSnapshotTriad.getCustScoreCardRefNo());
		issueAccountSnapshotDataRequestType.setCUSTRowScore(accountingSnapshotTriad.getCustRawScore());
		issueAccountSnapshotDataRequestType.setCUSTAlignedScore(accountingSnapshotTriad.getCustAlignedScore());
		issueAccountSnapshotDataRequestType.setCreditRiskFactor(customerContractTriad.getCreditRiskFactor());
		
		reassessTRIADARType.setIssueAccountSnapshotDataRequest(issueAccountSnapshotDataRequestType);
		logger.debug("[IssueAccountSnapshotDataTransformer -- issueAccountSnapshotDataRequest] -- End");
	}

}
