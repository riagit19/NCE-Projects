package com.shopdirect.nce.sp.transform;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;
import java.util.List;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.rule.model.Account;
import com.shopdirect.nce.rule.model.DateLastOrder;
import com.shopdirect.nce.rule.model.DateLastPayment;
import com.shopdirect.nce.rule.model.FPWODateAmt;
import com.shopdirect.nce.rule.model.LastPaymentAmt;
import com.shopdirect.nce.rule.model.PaymentsTotal;
import com.shopdirect.nce.sp.model.AccountingSnapshot;
import com.shopdirect.nce.sp.model.AgreementTriad;
import com.shopdirect.nce.sp.model.BatchDetails;
import com.shopdirect.nce.sp.model.BatchLinked;
import com.shopdirect.nce.sp.model.CurrentAccoutingSnapshotTriad;
import com.shopdirect.nce.sp.model.CustomerAccountInfo;
import com.shopdirect.nce.sp.model.CustomerContractTriad;
import com.shopdirect.nce.sp.model.RetailContractTriad;
import com.shopdirect.nce.sp.util.StatementProcessorBatchUtil;
import com.shopdirect.osb.reassesstriadar.AccountCommonDataType;
import com.shopdirect.osb.reassesstriadar.AccountType;
import com.shopdirect.osb.reassesstriadar.AccountingSnapshotType;
import com.shopdirect.osb.reassesstriadar.AuthorisationDetailsType;
import com.shopdirect.osb.reassesstriadar.BNPLCustomerType;
import com.shopdirect.osb.reassesstriadar.BNPLTermMaxWklyType;
import com.shopdirect.osb.reassesstriadar.CheckBNPLEligibilityRequestType;
import com.shopdirect.osb.reassesstriadar.CustomerOrderDataType;
import com.shopdirect.osb.reassesstriadar.DateChargeOffType;
import com.shopdirect.osb.reassesstriadar.DateLastMivType;
import com.shopdirect.osb.reassesstriadar.DateLastOrderType;
import com.shopdirect.osb.reassesstriadar.DateLastPaymentType;
import com.shopdirect.osb.reassesstriadar.DateNSFType;
import com.shopdirect.osb.reassesstriadar.FPWODateAmtListType;
import com.shopdirect.osb.reassesstriadar.GetAccountSnapshotType;
import com.shopdirect.osb.reassesstriadar.GetTriadDataRequestType;
import com.shopdirect.osb.reassesstriadar.LastPaymentAmtType;
import com.shopdirect.osb.reassesstriadar.LinkedAccountsType;
import com.shopdirect.osb.reassesstriadar.NSFIndType;
import com.shopdirect.osb.reassesstriadar.OmsSumType;
import com.shopdirect.osb.reassesstriadar.PastDueType;
import com.shopdirect.osb.reassesstriadar.PaymentsTotalType;
import com.shopdirect.osb.reassesstriadar.ReassessTRIADARType;
import com.shopdirect.osb.reassesstriadar.SAMS300CReqType;
import com.shopdirect.osb.reassesstriadar.ScheduledPaymentAmtType;
import com.shopdirect.osb.reassesstriadar.ScheduledPaymentsPastDueType;
import com.shopdirect.osb.reassesstriadar.TriadAccountingSnapshotType;
import com.shopdirect.osb.reassesstriadar.TriadAuthorisationDataResponseType;
import com.shopdirect.osb.reassesstriadar.UpdateEligibilityRequestType;
import com.shopdirect.osb.reassesstriadar.UpdateEligibilityType;

public class CheckBNPLEligibilityRequestTransformer {

	private static SDLoggerImpl logger = new SDLoggerImpl();
	
	public void checkBNPLEligibilityRequest(ReassessTRIADARType reassessTRIADARType, CustomerAccountInfo accountInfo,
			BatchDetails batchDetails, CustomerContractTriad customerContractTriad,
			RetailContractTriad retailContractTriad, AgreementTriad agreementTriad, List<AccountingSnapshot> accountingSnapshotList,
			List<BatchLinked> batchLinkedList, CurrentAccoutingSnapshotTriad currentAccSnapshotTriad, 
			Account accountRule, String callType) throws Exception {
		
		logger.debug("[CheckBNPLEligibilityRequestTransformer -- checkBNPLEligibilityRequest] -- Start");
		
		CheckBNPLEligibilityRequestType bnplEligibilityRequestType = new CheckBNPLEligibilityRequestType();
		reassessTRIADARType.setCheckBNPLEligibilityRequest(bnplEligibilityRequestType);
		
		GetAccountSnapshotType getAccountSnapshotType = new GetAccountSnapshotType();
		bnplEligibilityRequestType.setGetAccountSnapshot(getAccountSnapshotType);

		getAccountSnapshotType.setRetailAccountNumber(accountInfo.getRetailAccountId());
		BigInteger callTypeIntValue = null;
		if (callType != null) {
			try {
				callTypeIntValue = new BigInteger(callType);
			} catch (NumberFormatException nfe){
				logger.error("[CRDRDataTransformer -- transformCRDRDataType] - callType should be int " + nfe);
			}
		}
		getAccountSnapshotType.setCallType(callTypeIntValue);
		
		SAMS300CReqType sams300cReqType = new SAMS300CReqType();
		bnplEligibilityRequestType.setSAMS300CReq(sams300cReqType);
		
		BNPLCustomerType bnplCustomerType = new BNPLCustomerType();
		sams300cReqType.setBNPLCustomer(bnplCustomerType);
		
		bnplCustomerType.setAccountNumber(accountInfo.getPublicAccountId());
		bnplCustomerType.setCreditBand(batchDetails.getCreditBand());
		bnplCustomerType.setEtradInd("1");
		try {
			bnplCustomerType.setTCStatus(batchDetails.getAccountStatusCode() != null ? new BigInteger(batchDetails.getAccountStatusCode()) : null);
		} catch (Exception e) {
			logger.error("Account status code should be Integer" + e);
		}
		bnplCustomerType.setStartDate(StatementProcessorBatchUtil.getDate(batchDetails.getDateStart()));
		bnplCustomerType.setCurrentBURef(batchDetails.getCurrentBURef());
		bnplCustomerType.setPrincipalBrand(batchDetails.getPrincipalBrand());
		bnplCustomerType.setCreditStatusCode(batchDetails.getCreditStatusCode());
		bnplCustomerType.setCreditStatusSubCode(batchDetails.getCreditStatusSubCode());
		bnplCustomerType.setDeceasedInd(batchDetails.getDeceasedInd() != null ? batchDetails.getDeceasedInd().toBigInteger() : null);
		bnplCustomerType.setSPID(batchDetails.getSpid() != null ? batchDetails.getSpid().toBigInteger() : null);
		bnplCustomerType.setSchedPaymentsPastDuePCAdjusted(accountRule.getScheduledPaymentsPastDue());
		bnplCustomerType.setFIDRuleInd(BigInteger.ZERO);
		bnplCustomerType.setAuthInd(batchDetails.getCollAuthInd() != null ? batchDetails.getCollAuthInd().toBigInteger() : null);
		bnplCustomerType.setNotFullPayInd(BigInteger.ZERO);
		//bnplCustomerType.setAltDelAddrInd(value); //aa
		bnplCustomerType.setBNPLTermMaxMthly(BigInteger.ZERO);
		//bnplCustomerType.setChannelInd(value); //aa
		//bnplCustomerType.setBNPLScore(value); //aa
		
		CustomerOrderDataType customerOrderDataType = new CustomerOrderDataType();
		bnplCustomerType.getCustomerOrderData().add(customerOrderDataType);
		
		//customerOrderDataType.setMinValue(value); //aa
		customerOrderDataType.setDeptCode(batchDetails.getCollDeptCode() != null ? batchDetails.getCollDeptCode().toBigInteger() : null);
		
		TriadAuthorisationDataResponseType triadAuthorisationDataResponseType = new TriadAuthorisationDataResponseType();
		sams300cReqType.setTriadAuthorisationDataResponse(triadAuthorisationDataResponseType);
		
		AuthorisationDetailsType authorisationDetailsType = new AuthorisationDetailsType();
		triadAuthorisationDataResponseType.setAuthorisationDetails(authorisationDetailsType);
		
		authorisationDetailsType.setAccountNumber(accountInfo.getRetailAccountId());
		authorisationDetailsType.setAccountTypeCode(batchDetails.getAccountTypeCode());
		authorisationDetailsType.setDateOfBirth(StatementProcessorBatchUtil.getDate(batchDetails.getDateOfBirth()));
		authorisationDetailsType.setCurrency(retailContractTriad.getCurrency());
		authorisationDetailsType.setDoNotCreditCheckInd(customerContractTriad.getDoNotCreditCheckInd() != null ? customerContractTriad.getDoNotCreditCheckInd().toBigInteger() : null);
		authorisationDetailsType.setDateLastDelinquent(StatementProcessorBatchUtil.getDate(batchDetails.getDateLastDelinquent()));
		authorisationDetailsType.setPaymentMethod(batchDetails.getLastPaymentMethod() != null ? batchDetails.getLastPaymentMethod().toString() : null);
		authorisationDetailsType.setBillingFrequency("2");
		authorisationDetailsType.setCustomerContactInd(batchDetails.getCustNoMailInd() != null ? batchDetails.getCustNoMailInd().toBigInteger() : null);
		authorisationDetailsType.setPhoneAddressInd(customerContractTriad.getPhoneAddressInd() != null ? customerContractTriad.getPhoneAddressInd().toBigInteger() : null);
		authorisationDetailsType.setCustomerType(batchDetails.getCustomerType() != null ? batchDetails.getCustomerType().toString() : null);
		authorisationDetailsType.setTransactionType("0");
		authorisationDetailsType.setTransactionAmount(batchDetails.getCollTransactionAmount());
		authorisationDetailsType.setProcCode(batchDetails.getAccountTypeCode());
		authorisationDetailsType.setDelqCollQueue(customerContractTriad.getDellCollQueue() != null ? customerContractTriad.getDellCollQueue().toString() : null);
		authorisationDetailsType.setAuthDigitsRangeLowerLimit(customerContractTriad.getAuthDigitsRangeLowerLimit() != null ? customerContractTriad.getAuthDigitsRangeLowerLimit().toBigInteger() : null);
		authorisationDetailsType.setAuthDigitsRangeUpperLimit(customerContractTriad.getAuthDigitsRangeUpperLimit() != null ? customerContractTriad.getAuthDigitsRangeUpperLimit().toBigInteger() : null);
		authorisationDetailsType.setClosingBalance(batchDetails.getCurrentBalance());
		authorisationDetailsType.setDateCompleted(StatementProcessorBatchUtil.getDate(batchDetails.getDateClosed()));
		authorisationDetailsType.setDateCreditLimitDecrease(StatementProcessorBatchUtil.getDate(batchDetails.getDateLastCreditLimitDecrease()));
		authorisationDetailsType.setDateCreditLimitIncrease(StatementProcessorBatchUtil.getDate(batchDetails.getDateLastCreditLimitIncrease()));
		//authorisationDetailsType.setDateLastIncentiveSchmClaim(value); //Obsolete
		authorisationDetailsType.setDateCreditLimitReviewed(StatementProcessorBatchUtil.getDate(customerContractTriad.getCreditLimitReviewedDate()));
		authorisationDetailsType.setPendingReferralsAmt(retailContractTriad.getPendingRefAmt());
		authorisationDetailsType.setRiskNavScore(batchDetails.getRiskNavScore() != null ? batchDetails.getRiskNavScore().toBigInteger() : null);
		authorisationDetailsType.setTotalUnchargedMvmts(BigDecimal.ZERO);
		authorisationDetailsType.setVtotApr(batchDetails.getaPR());
		authorisationDetailsType.setPPIInd(batchDetails.getPpiInd() != null ? batchDetails.getPpiInd().toBigInteger() : null);
		authorisationDetailsType.setCreditLimit(batchDetails.getCreditLimit());
		authorisationDetailsType.setShadowCreditLimit(customerContractTriad.getShadowCreditMonetaryLimit());
		authorisationDetailsType.setHostOTB(batchDetails.getoTB());
		authorisationDetailsType.setBNPLBalance(agreementTriad.getBnplBalance());
		authorisationDetailsType.setCreditRiskFactor(batchDetails.getcRF());
		authorisationDetailsType.setHighestCRF(customerContractTriad.getHighestCrf());
		authorisationDetailsType.setCreditLimitFrozenCode(batchDetails.getCreditLimitFrozenInd() != null ? batchDetails.getCreditLimitFrozenInd().toBigInteger() : null);
		authorisationDetailsType.setAlignedBehaviourScore(batchDetails.getAlignedBehaviourScore() != null ? batchDetails.getAlignedBehaviourScore().toBigInteger() : null);
		authorisationDetailsType.setRecruitmentCRF(batchDetails.getRecruitmentCRF());
		authorisationDetailsType.setLastFollowUpCode(batchDetails.getLastFollowUpCode() != null ? batchDetails.getLastFollowUpCode().toBigInteger() : null);
		authorisationDetailsType.setAnnotationInd(batchDetails.getAnnotationPeriodInd() != null ? batchDetails.getAnnotationPeriodInd().toBigInteger() : null);
		authorisationDetailsType.setNumCreditAccts(batchDetails.getNumCreditAccts() != null ? batchDetails.getNumCreditAccts().toBigInteger() : null);
		authorisationDetailsType.setNumAccts(batchDetails.getNumAccts() != null ? batchDetails.getNumAccts().toBigInteger() : null);
		authorisationDetailsType.setOverIndebtScore(batchDetails.getOverIndebtScore() != null ? batchDetails.getOverIndebtScore().toBigInteger() : null);
		authorisationDetailsType.setCollectionStage(BigInteger.ZERO);
		authorisationDetailsType.setBNPLEligibility(customerContractTriad.getBnplEligibility() != null ? customerContractTriad.getBnplEligibility().toBigInteger() : null);
		authorisationDetailsType.setCreditBand(batchDetails.getCreditBand());
		authorisationDetailsType.setScreenBalance(batchDetails.getScreenBalance());
		authorisationDetailsType.setCAAReceived(batchDetails.getCreditBandCodeInd() != null ? batchDetails.getCreditBandCodeInd().toBigInteger() : null);
		authorisationDetailsType.setFIDScore(batchDetails.getFidScore() != null ? new BigInteger(batchDetails.getFidScore()) : null);
		authorisationDetailsType.setCollectionMethodCode(batchDetails.getCollectionMethodCode() != null ? batchDetails.getCollectionMethodCode().toBigInteger() : null);
		authorisationDetailsType.setBlockCode(batchDetails.getBlockCode());
		authorisationDetailsType.setDateRiskNavScoreUpdated(StatementProcessorBatchUtil.getDate(batchDetails.getDateRiskNavScoreUpdated()));
		try {
			authorisationDetailsType.setAnnualSalary(batchDetails.getAnnualSalary() != null ? new BigInteger(batchDetails.getAnnualSalary()) : null);
			authorisationDetailsType.setEmploymentStatus(batchDetails.getEmploymentStatus() != null ? new BigInteger(batchDetails.getEmploymentStatus()) : null);
			authorisationDetailsType.setHouseholdIncome(batchDetails.getHouseholdIncome() != null ? new BigInteger(batchDetails.getHouseholdIncome()) : null);
		} catch (NumberFormatException e) {
			logger.error("[CheckBNPLEligibilityRequestTransformer -- checkBNPLEligibilityRequest] - annual salary / employment status / household income should be int " + e);
		}
		authorisationDetailsType.setGaugeScore(retailContractTriad.getGaugeScore() != null ? retailContractTriad.getGaugeScore().toBigInteger() : null);
		authorisationDetailsType.setNoOfDependents(batchDetails.getNoOfDependants() != null ? batchDetails.getNoOfDependants().toBigInteger() : null);
		authorisationDetailsType.setOptOutCreditLimitIncreaseInd(batchDetails.getOptOutCreditLimitIncInd() != null ? batchDetails.getOptOutCreditLimitIncInd().toBigInteger() :  null);
		try {
			authorisationDetailsType.setResidentStatus(batchDetails.getResidentStatus() != null ? new BigInteger(batchDetails.getResidentStatus()) : null);
		} catch (NumberFormatException e) {
			logger.error("[CheckBNPLEligibilityRequestTransformer -- checkBNPLEligibilityRequest] -residentStatus should be int " + e);
		}
		authorisationDetailsType.setSixMonthIncomeVerificationCode(batchDetails.getSixMonthIncomeVerificationCode());
		authorisationDetailsType.setTwelveMonthIncomeVerificationCode(batchDetails.getTwelveMonthIncomeVerificationCode());
		authorisationDetailsType.setDateofChangeRequest(StatementProcessorBatchUtil.getDate(batchDetails.getDateOfChangeRequest()));
		
		for (AccountingSnapshot accountingSnapshot : accountingSnapshotList) { 
			
			AccountingSnapshotType accountingSnapshotType = new AccountingSnapshotType();
			accountingSnapshotType.setClosingBalance(accountingSnapshot.getClosingBalance());
			accountingSnapshotType.setInterestChargedAmt(accountingSnapshot.getInterestChargedAmtTSP());
			accountingSnapshotType.setNetSalesValueTSPAmt(accountingSnapshot.getNetSalesValueTSPAmt());
			accountingSnapshotType.setPayTypeTspAmt(accountingSnapshot.getPaymentAmountTSP());
			accountingSnapshotType.setGrossRevenueAmt(BigDecimal.ZERO);
			accountingSnapshotType.setTum(BigDecimal.ZERO);
			accountingSnapshotType.setRiskNavScore(accountingSnapshot.getRiskNavScore() != null ? accountingSnapshot.getRiskNavScore().toBigInteger() : null);
			authorisationDetailsType.getAccountingSnapshot().add(accountingSnapshotType);
		}
		
		int occurence = 1;
		for (BatchLinked batchLinked : batchLinkedList) {
			LinkedAccountsType linkedAccountsType = new LinkedAccountsType();
			linkedAccountsType.setLinkedOccurence(BigInteger.valueOf(occurence));
			linkedAccountsType.setAccountNumber(accountInfo.getPublicAccountId());
			linkedAccountsType.setAlignedBehaviourScore(batchLinked.getAlignedBehaviourScore() != null ? batchLinked.getAlignedBehaviourScore().toBigInteger() : null);
			linkedAccountsType.setRecruitmentCRF(batchLinked.getRecruitmentCRF());
			linkedAccountsType.setClosingBalance(batchLinked.getCurrentBalance());
			linkedAccountsType.setBNPLBalance(batchLinked.getBnplBalance());
			linkedAccountsType.setCurrentLimit(batchLinked.getCreditLimit());
			linkedAccountsType.setPPIInd(batchLinked.getPpiInd() != null ? batchLinked.getPpiInd().toBigInteger() : null);
			linkedAccountsType.setDateCreditLimitDecrease(StatementProcessorBatchUtil.getDate(batchLinked.getDateLastCreditLimitDecrease()));
			linkedAccountsType.setDateCreditLimitIncrease(StatementProcessorBatchUtil.getDate(batchLinked.getDateLastCreditLimitIncrease()));
			linkedAccountsType.setCreditLimitFrozenInd(batchLinked.getCreditLimitFrozenInd() != null ? batchLinked.getCreditLimitFrozenInd().toBigInteger() : null);
			linkedAccountsType.setCreditStatusCode(batchLinked.getCreditStatusCode());
			linkedAccountsType.setCreditStatusSubCode(batchLinked.getCreditStatusSubCode());
			linkedAccountsType.setDateStart(StatementProcessorBatchUtil.getDate(batchLinked.getDateStart()));
			linkedAccountsType.setDateCompleted(StatementProcessorBatchUtil.getDate(batchLinked.getDateClosed()));
			linkedAccountsType.setDateLastOrder(StatementProcessorBatchUtil.getDate(batchLinked.getDateLastCreditOrder()));
			linkedAccountsType.setScheduledPaymentAmt(batchLinked.getScheduledPaymentAmt());
			linkedAccountsType.setOTB(batchLinked.getoTB());
			linkedAccountsType.setPaymentsTotal(batchLinked.getCreditPaymentsTotal());
			linkedAccountsType.setCreditRiskFactor(batchLinked.getCreditRiskFactor());
			occurence++;
			authorisationDetailsType.getLinkedAccounts().add(linkedAccountsType);
		}
		
		GetTriadDataRequestType triadDataRequestType = new GetTriadDataRequestType();
		bnplEligibilityRequestType.setGetTriadDataRequest(triadDataRequestType);
		
		BigDecimal callTypeValue = null;
		if (callType != null) {
			try {
				callTypeValue = new BigDecimal(callType);
			} catch (NumberFormatException nfe){
				logger.error("[CheckBNPLEligibilityRequestTransformer -- checkBNPLEligibilityRequest] - callType should be int " + nfe);
			}
		}
		
		triadDataRequestType.setCallType(callTypeValue);
		
		for (AccountingSnapshot accountingSnapshot : accountingSnapshotList) {
			AccountType accountType = new AccountType();
			accountType.setAccountType(batchDetails.getAccountTypeCode());
			
			AccountCommonDataType accountCommonDataType = new AccountCommonDataType();
			accountType.setAccountCommonData(accountCommonDataType);
			accountCommonDataType.setScheduledPaymentsPastDue(accountingSnapshot.getScheduledPaymentsPastDue());
			accountCommonDataType.setDateStart(StatementProcessorBatchUtil.getDate(batchDetails.getDateStart()));
			accountCommonDataType.setCurrentBalance(batchDetails.getCurrentBalance());
			
			DateLastMivType dateLastMivType = new DateLastMivType();
			accountType.setDateLastMiv(dateLastMivType);
			dateLastMivType.setDateLastMivCredit(StatementProcessorBatchUtil.getDate(retailContractTriad.getDateLastMIV()));
			dateLastMivType.setDateLastMivRetail(StatementProcessorBatchUtil.getDate(retailContractTriad.getDateLastMIV()));
			
			DateLastOrderType dateLastOrderType = new DateLastOrderType();
			dateLastOrderType.setDateLastOrderRetail(StatementProcessorBatchUtil.getDate(accountingSnapshot.getDateLastRetailOrder()));
			dateLastOrderType.setDateLastOrderCredit(StatementProcessorBatchUtil.getDate(accountingSnapshot.getDateLastCreditOrder()));
			dateLastOrderType.setDateLastOrderCredit(StatementProcessorBatchUtil.getDate(new Date())); // change with correct above value
			accountType.setDateLastOrder(dateLastOrderType);
			DateLastOrder dateLastOrder = accountRule.getDateLastOrder();
			if (dateLastOrder != null) {
				dateLastOrderType.setDateLastOrderRetail(StatementProcessorBatchUtil.getDate(dateLastOrder.getDateLastOrderRetail().getTime()));
				dateLastOrderType.setDateLastOrderCredit(StatementProcessorBatchUtil.getDate(dateLastOrder.getDateLastOrderCredit().getTime()));
			}
			
			DateLastPaymentType dateLastPaymentType = new DateLastPaymentType();
			dateLastPaymentType.setDateLastPaymentRetail(StatementProcessorBatchUtil.getDate(accountingSnapshot.getDateLastPayment()));
			dateLastPaymentType.setDateLastPaymentCredit(StatementProcessorBatchUtil.getDate(accountingSnapshot.getDateLastPayment()));
			dateLastPaymentType.setDateLastPaymentCredit(StatementProcessorBatchUtil.getDate(new Date())); //change with correct above value
			accountType.setDateLastPayment(dateLastPaymentType);
			DateLastPayment dateLastPayment = accountRule.getDateLastPayment();
			if (dateLastPayment != null) {
				dateLastPaymentType.setDateLastPaymentRetail(StatementProcessorBatchUtil.getDate(dateLastPayment.getDateLastPaymentRetail().getTime()));
				dateLastPaymentType.setDateLastPaymentCredit(StatementProcessorBatchUtil.getDate(dateLastPayment.getDateLastPaymentCredit().getTime()));
			}
			
			LastPaymentAmtType lastPaymentAmtType = new LastPaymentAmtType();
			accountType.setLastPaymentAmt(lastPaymentAmtType);
			lastPaymentAmtType.setLastPaymentAmtCredit(agreementTriad.getLastPayAmt());
			lastPaymentAmtType.setLastPaymentAmtRetail(agreementTriad.getLastPayAmt());
			LastPaymentAmt lastPaymentAmt = accountRule.getLastPaymentAmt();
			if(lastPaymentAmt != null) {
				lastPaymentAmtType.setLastPaymentAmtRetail(lastPaymentAmt.getLastPaymentAmtRetail());
				lastPaymentAmtType.setLastPaymentAmtCredit(lastPaymentAmt.getLastPaymentAmtCredit());
			}
			
			DateChargeOffType dateChargeOffType = new DateChargeOffType();
			accountType.setDateChargeOff(dateChargeOffType);
			
			TriadAccountingSnapshotType triadAccountSnapshotType = new TriadAccountingSnapshotType();
			triadAccountSnapshotType.setScheduledPaymentsPastDue(accountingSnapshot.getScheduledPaymentsPastDue());
			triadAccountSnapshotType.setAssessmentDate(StatementProcessorBatchUtil.getDate(accountingSnapshot.getAssessmentDate()));
			triadAccountSnapshotType.setScheduledPaymentAmount(accountingSnapshot.getScheduledPaymentAmt());
			triadAccountSnapshotType.setPastDue(accountingSnapshot.getPastDue());
			triadAccountSnapshotType.setPaymentAmountTSP(accountingSnapshot.getPaymentAmountTSP());
			//triadAccountSnapshotType.setDateEnteredCollections(value); //not found
			triadAccountSnapshotType.setDateTCAccounting(StatementProcessorBatchUtil.getDate(accountingSnapshot.getTodaysAccountingDate()));
			triadAccountSnapshotType.setCustomerCreditTSP(accountingSnapshot.getCustomerCreditTSP());
			triadAccountSnapshotType.setClosingBalance(accountingSnapshot.getCurrentBalance());
			triadAccountSnapshotType.setInterestChargedAmtTSP(accountingSnapshot.getInterestChargedAmtTSP());
			triadAccountSnapshotType.setPurchaseAmountTSP(accountingSnapshot.getPurchaseAmountTSP());
			triadAccountSnapshotType.setSalesFor12Months(accountingSnapshot.getSalesFor12Months());
			triadAccountSnapshotType.setNumPaymentsTSP(accountingSnapshot.getNumPaymentsTSP());
			triadAccountSnapshotType.setNetSalesValueTSPAMT(accountingSnapshot.getNetSalesValueTSPAmt());
			dateChargeOffType.getTriadAccountingSnapshot().add(triadAccountSnapshotType);
			
			dateChargeOffType.setTodaysAccountingDate(StatementProcessorBatchUtil.getDate(accountingSnapshot.getTodaysAccountingDate()));
			
			OmsSumType omsSumType = new OmsSumType();
			accountType.setOmsSum(omsSumType);
			omsSumType.setLastStatementDate(StatementProcessorBatchUtil.getDate(customerContractTriad.getStatementProducedDate()));
			FPWODateAmtListType fpwoDateAmtListType = new FPWODateAmtListType();
			fpwoDateAmtListType.setFPDate(StatementProcessorBatchUtil.getDate(new Date())); //change with correct value
			fpwoDateAmtListType.setFPAmount(new BigDecimal("111")); //change with correct value
			omsSumType.getFPWODateAmtList().add(fpwoDateAmtListType);
			if (accountRule != null && accountRule.getOmsSum() != null) {
			List<FPWODateAmt> fpwoDateAmtLst = accountRule.getOmsSum().getFpwoDateAmtList();
				for (FPWODateAmt fpwoDateAmt : fpwoDateAmtLst) {
					fpwoDateAmtListType.setFPDate(StatementProcessorBatchUtil.getDate(fpwoDateAmt.getFpDate().getTime()));
					fpwoDateAmtListType.setFPAmount(fpwoDateAmt.getFpAmount());
					omsSumType.getFPWODateAmtList().add(fpwoDateAmtListType);
				}
			}

			NSFIndType nsfIndType = new NSFIndType();
			accountType.setNSFInd(nsfIndType);
			nsfIndType.setTodaysAccountingDate(StatementProcessorBatchUtil.getDate(batchDetails.getTodaysAccountingDate()));
			
			DateNSFType dateNSFType = new DateNSFType();
			nsfIndType.setDateNSF(dateNSFType);
			
			dateNSFType.setDateNSFCredit(StatementProcessorBatchUtil.getDate(agreementTriad.getNsfDate()));
			dateNSFType.setDateNSFRetail(StatementProcessorBatchUtil.getDate(agreementTriad.getNsfDate()));
			
			PaymentsTotalType paymentsTotalType = new PaymentsTotalType();
			accountType.setPaymentsTotal(paymentsTotalType);
			paymentsTotalType.setPaymentsTotalRetail(retailContractTriad.getCreditPaymentsTotal());
			paymentsTotalType.setPaymentsTotalCredit(retailContractTriad.getCreditPaymentsTotal());
			PaymentsTotal paymentsTotal = accountRule.getPaymentsTotal();
			if (paymentsTotal != null) {
				paymentsTotalType.setPaymentsTotalRetail(paymentsTotal.getPaymentsTotalRetail());
				paymentsTotalType.setPaymentsTotalCredit(paymentsTotal.getPaymentsTotalCredit());
			}
			
			ScheduledPaymentsPastDueType scheduledPaymentsPastDueType = new ScheduledPaymentsPastDueType();
			accountType.setScheduledPaymentsPastDue(scheduledPaymentsPastDueType);
			scheduledPaymentsPastDueType.setScheduledPaymentAmount(accountingSnapshot.getScheduledPaymentAmt());
			scheduledPaymentsPastDueType.setAdjustedPastDue(BigDecimal.ONE);
			scheduledPaymentsPastDueType.setPastDueAmount(accountingSnapshot.getPastDue());
			scheduledPaymentsPastDueType.setAdjustedSPPDRate(BigDecimal.ONE);
			scheduledPaymentsPastDueType.setSPPDRate(BigDecimal.ONE);
			
			PastDueType pastDueType = new PastDueType();
			accountType.setPastDue(pastDueType);
			pastDueType.setScheduledPaymentAmount(accountingSnapshot.getScheduledPaymentAmt());
			pastDueType.setAdjustedPastDue(BigDecimal.ONE);
			pastDueType.setPastDueAmount(accountingSnapshot.getPastDue());
			pastDueType.setAdjustedSPPDRate(BigDecimal.ONE);
			pastDueType.setSPPDRate(BigDecimal.ONE);
			
			BNPLTermMaxWklyType bnplTermMaxWklyType = new BNPLTermMaxWklyType();
			accountType.setBNPLTermMaxWkly(bnplTermMaxWklyType);
			bnplTermMaxWklyType.getBNPLDuration().add(new BigDecimal(accountingSnapshotList.size()));
			
			ScheduledPaymentAmtType scheduledPaymentAmtType = new ScheduledPaymentAmtType();
			accountType.setScheduledPaymentAmt(scheduledPaymentAmtType);
			scheduledPaymentAmtType.setScheduledPaymentAmount(accountingSnapshot.getScheduledPaymentAmt());
			scheduledPaymentAmtType.setAdjustedPastDue(BigDecimal.ONE);
			scheduledPaymentAmtType.setPastDueAmount(accountingSnapshot.getPastDue());
			scheduledPaymentAmtType.setAdjustedSPPDRate(BigDecimal.ONE);
			scheduledPaymentAmtType.setSPPDRate(BigDecimal.ONE);
			
			triadDataRequestType.getAccount().add(accountType);
		}
		
		UpdateEligibilityRequestType updateEligibilityRequestType = new UpdateEligibilityRequestType();
		bnplEligibilityRequestType.setUpdateEligibilityRequest(updateEligibilityRequestType);
		
		UpdateEligibilityType updateEligibilityType = new UpdateEligibilityType();
		updateEligibilityRequestType.setUpdateEligibility(updateEligibilityType);
		
		updateEligibilityType.setStatementNumber(agreementTriad.getFnStatNo());
		logger.debug("[CheckBNPLEligibilityRequestTransformer -- checkBNPLEligibilityRequest] -- End");
	}
}
