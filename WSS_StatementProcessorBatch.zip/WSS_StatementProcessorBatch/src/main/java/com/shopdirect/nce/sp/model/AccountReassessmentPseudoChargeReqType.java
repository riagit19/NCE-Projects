/**
 * 
 */
package com.shopdirect.nce.sp.model;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.xml.bind.annotation.XmlRootElement;

import com.shopdirect.fcm.xsd.forecastmodeller.BrandCreditProductType;
import com.shopdirect.fcm.xsd.forecastmodeller.CreditProductType;
import com.shopdirect.fcm.xsd.forecastmodeller.CustomerAccountType;
import com.shopdirect.fcm.xsd.forecastmodeller.DailyRateType;
import com.shopdirect.fcm.xsd.forecastmodeller.DrawdownTermItemType;
import com.shopdirect.fcm.xsd.forecastmodeller.CurrentDDTWithTransactionsAndIncomesType;
import com.shopdirect.fcm.xsd.forecastmodeller.PaymentType;
import com.shopdirect.fcm.xsd.forecastmodeller.SPPDRate;

/**
 * @author VijayaprakashPrathip
 * 
 */

@XmlRootElement
public class AccountReassessmentPseudoChargeReqType {

	private CustomerAccountType customerAccountType;
	private CurrentDDTWithTransactionsAndIncomesType drawdownTermType;
	private CreditProductType creditProductType;
	private BrandCreditProductType brandCreditProductType;
	private DailyRateType dailyRateType;
	private DrawdownTermItemType drawdownTermItemType;
	private PaymentType paymentType;
	private SPPDRate sppdRateType;
	private String creditAccountNumber;
	private String publicAccountNumber;
	private String retailAccountNumber;
	private String brandType;
	private long paymentDayOfMonth;
	private long paymentPeriod;
	private boolean stopFees;
	private boolean stopInterest;
	private boolean stopDefaultFees;
	private BigDecimal minPayThreshold;
	private BigDecimal minPayPercentageThreshold;
	private BigDecimal otbAmount;
	private BigDecimal currentBalance_CustAcctType;
	private BigDecimal arrearsAmount;
	private String cashPrice_DrawdownTerm;
	private String currentBalance_DrawdownTerm;
	private long id;
	private String type;
	private Date chargeDate;
	private long terminDays;
	private long deferredTerminDays;
	private long terminMonths;
	private long deferredTerminMonths;
	private BigDecimal rate;
	private Date startDate;
	private Date endDate;
	private BigDecimal cashPrice_Items;
	private BigDecimal paymentAmount;
	
	private Set<CurrentDDTWithTransactionsAndIncomesType> drawdownTermTypeList;
	private Set<CreditProductType> creditProductTypeList;
	private Set<BrandCreditProductType> brandCreditProductTypeList;
	private Set<DailyRateType> dailyRateTypeList;
	private Set<DrawdownTermItemType> drawdownTermItemTypeList;
	private Set<PaymentType> paymentTypeList;
	private List<Set<PaymentType>> currentPeriodMovement;

	
	
	public AccountReassessmentPseudoChargeReqType(){}
	
	public AccountReassessmentPseudoChargeReqType(CustomerAccountType customerAccountType1, CurrentDDTWithTransactionsAndIncomesType drawdownTermType1, 
			CreditProductType creditProductType1, BrandCreditProductType brandCreditProductType1,
		    DailyRateType dailyRateType1, DrawdownTermItemType drawdownTermItemType1, PaymentType paymentType1, SPPDRate sppdRateType1,
		    String creditAccountNumber1, String publicAccountNumber1, String retailAccountNumber1,
		    String brandType1, long paymentDayOfMonth1, long paymentPeriod1, boolean stopFees1, boolean stopInterest1, boolean stopDefaultFees1,
		    BigDecimal minPayThreshold1, BigDecimal minPayPercentageThreshold1, BigDecimal otbAmount1, BigDecimal currentBalance_CustAcctType1,
		    BigDecimal arrearsAmount1, String cashPrice_DrawdownTerm1, String currentBalance_DrawdownTerm1, long id1, String type1,
		    Date chargeDate1, long terminDays1, long deferredTerminDays1, long terminMonths1, long deferredTerminMonths1, BigDecimal rate1,
		    Date startDate1, Date endDate1, BigDecimal cashPrice_Items1,BigDecimal paymentAmount)	{
		
		customerAccountType = customerAccountType1;
		drawdownTermType = drawdownTermType1; 
		creditProductType = creditProductType1;
		brandCreditProductType = brandCreditProductType1;
	    dailyRateType = dailyRateType1;
	    drawdownTermItemType = drawdownTermItemType1;
	    paymentType = paymentType1;
	    sppdRateType =  sppdRateType1;
	    
		creditAccountNumber = creditAccountNumber1;
		publicAccountNumber = publicAccountNumber1;
		retailAccountNumber = retailAccountNumber1;
		brandType = brandType1;
		paymentDayOfMonth = paymentDayOfMonth1;
		paymentPeriod = paymentPeriod1;
		stopFees = stopFees1;
		stopInterest = stopInterest1;
		stopDefaultFees = stopDefaultFees1;
		minPayThreshold = minPayThreshold1;
		minPayPercentageThreshold = minPayPercentageThreshold1;
		otbAmount = otbAmount1;
		currentBalance_CustAcctType = currentBalance_CustAcctType1;
		arrearsAmount = arrearsAmount1;
		cashPrice_DrawdownTerm = cashPrice_DrawdownTerm1;
		currentBalance_DrawdownTerm = currentBalance_DrawdownTerm1;
		id = id1;
		type = type1;
		chargeDate = chargeDate1;
		terminDays = terminDays1;
		deferredTerminDays = deferredTerminDays1;
		terminMonths = terminMonths1;
		deferredTerminMonths = deferredTerminMonths1;
		rate = rate1;
		startDate = startDate1;
		endDate = endDate1;
		cashPrice_Items = cashPrice_Items1;
		paymentAmount=paymentAmount;
	}
	
	
	/**
	 * @return the customerAccountType
	 */
	public CustomerAccountType getCustomerAccountType() {
		return customerAccountType;
	}

	/**
	 * @param customerAccountType the customerAccountType to set
	 */
	public void setCustomerAccountType(CustomerAccountType customerAccountType) {
		this.customerAccountType = customerAccountType;
	}

	/**
	 * @return the drawdownTermType
	 */
	public CurrentDDTWithTransactionsAndIncomesType getDrawdownTermType() {
		return drawdownTermType;
	}

	/**
	 * @param drawdownTermType the drawdownTermType to set
	 */
	public void setDrawdownTermType(CurrentDDTWithTransactionsAndIncomesType drawdownTermType) {
		this.drawdownTermType = drawdownTermType;
	}

	/**
	 * @return the brandCreditProductType
	 */
	public BrandCreditProductType getBrandCreditProductType() {
		return brandCreditProductType;
	}

	/**
	 * @param brandCreditProductType the brandCreditProductType to set
	 */
	public void setBrandCreditProductType(BrandCreditProductType brandCreditProductType) {
		this.brandCreditProductType = brandCreditProductType;
	}

	
	/**
	 * @return the CreditProductType
	 */
	public CreditProductType getCreditProductType() {
		return creditProductType;
	}

	/**
	 * @param brandCreditProductType the brandCreditProductType to set
	 */
	public void setCreditProductType(CreditProductType creditProductType) {
		this.creditProductType = creditProductType;
	}
	
	/**
	 * @return the dailyRateType
	 */
	public DailyRateType getDailyRateType() {
		return dailyRateType;
	}

	/**
	 * @param dailyRateType the dailyRateType to set
	 */
	public void setDailyRateType(DailyRateType dailyRateType) {
		this.dailyRateType = dailyRateType;
	}

	/**
	 * @return the drawdownTermItemType
	 */
	public DrawdownTermItemType getDrawdownTermItemType() {
		return drawdownTermItemType;
	}

	/**
	 * @param drawdownTermItemType the drawdownTermItemType to set
	 */
	public void setDrawdownTermItemType(DrawdownTermItemType drawdownTermItemType) {
		this.drawdownTermItemType = drawdownTermItemType;
	}

	/**
	 * @return the paymentType
	 */
	public PaymentType getPaymentType() {
		return paymentType;
	}

	/**
	 * @param paymentType the paymentType to set
	 */
	public void setPaymentType(PaymentType paymentType) {
		this.paymentType = paymentType;
	}
	
	
	/**
	 * @return the sppdRateType
	 */
	public SPPDRate getSppdRateType() {
		return sppdRateType;
	}

	/**
	 * @param sppdRateType the sppdRateType to set
	 */
	public void setSppdRateType(SPPDRate sppdRateType) {
		this.sppdRateType = sppdRateType;
	}
	

	
	
	/**
	 * @return the creditAccountNumber
	 */
	public String getCreditAccountNumber() {
		return creditAccountNumber;
	}
	/**
	 * @param creditAccountNumber the creditAccountNumber to set
	 */
	public void setCreditAccountNumber(String creditAccountNumber) {
		this.creditAccountNumber = creditAccountNumber;
	}
	/**
	 * @return the publicAccountNumber
	 */
	public String getPublicAccountNumber() {
		return publicAccountNumber;
	}
	/**
	 * @param publicAccountNumber the publicAccountNumber to set
	 */
	public void setPublicAccountNumber(String publicAccountNumber) {
		this.publicAccountNumber = publicAccountNumber;
	}
	/**
	 * @return the retailAccountNumber
	 */
	public String getRetailAccountNumber() {
		return retailAccountNumber;
	}
	/**
	 * @param retailAccountNumber the retailAccountNumber to set
	 */
	public void setRetailAccountNumber(String retailAccountNumber) {
		this.retailAccountNumber = retailAccountNumber;
	}
	
	/**
	 * @return the brandType
	 */
	public String getBrandType() {
		return brandType;
	}
	/**
	 * @param brandType the brandType to set
	 */
	public void setBrandType(String brandType) {
		this.brandType = brandType;
	}
	/**
	 * @return the paymentDayOfMonth
	 */
	public long getPaymentDayOfMonth() {
		return paymentDayOfMonth;
	}
	/**
	 * @param paymentDayOfMonth the paymentDayOfMonth to set
	 */
	public void setPaymentDayOfMonth(long paymentDayOfMonth) {
		this.paymentDayOfMonth = paymentDayOfMonth;
	}
	/**
	 * @return the paymentPeriod
	 */
	public long getPaymentPeriod() {
		return paymentPeriod;
	}
	/**
	 * @param paymentPeriod the paymentPeriod to set
	 */
	public void setPaymentPeriod(long paymentPeriod) {
		this.paymentPeriod = paymentPeriod;
	}
	/**
	 * @return the stopFees
	 */
	public boolean isStopFees() {
		return stopFees;
	}
	/**
	 * @param stopFees the stopFees to set
	 */
	public void setStopFees(boolean stopFees) {
		this.stopFees = stopFees;
	}
	/**
	 * @return the stopInterest
	 */
	public boolean isStopInterest() {
		return stopInterest;
	}
	/**
	 * @param stopInterest the stopInterest to set
	 */
	public void setStopInterest(boolean stopInterest) {
		this.stopInterest = stopInterest;
	}
	/**
	 * @return the stopDefaultFees
	 */
	public boolean isStopDefaultFees() {
		return stopDefaultFees;
	}
	/**
	 * @param stopDefaultFees the stopDefaultFees to set
	 */
	public void setStopDefaultFees(boolean stopDefaultFees) {
		this.stopDefaultFees = stopDefaultFees;
	}
	/**
	 * @return the minPayThreshold
	 */
	public BigDecimal getMinPayThreshold() {
		return minPayThreshold;
	}
	/**
	 * @param minPayThreshold the minPayThreshold to set
	 */
	public void setMinPayThreshold(BigDecimal minPayThreshold) {
		this.minPayThreshold = minPayThreshold;
	}
	/**
	 * @return the minPayPercentageThreshold
	 */
	public BigDecimal getMinPayPercentageThreshold() {
		return minPayPercentageThreshold;
	}
	/**
	 * @param minPayPercentageThreshold the minPayPercentageThreshold to set
	 */
	public void setMinPayPercentageThreshold(BigDecimal minPayPercentageThreshold) {
		this.minPayPercentageThreshold = minPayPercentageThreshold;
	}
	/**
	 * @return the otbAmount
	 */
	public BigDecimal getOtbAmount() {
		return otbAmount;
	}
	/**
	 * @param otbAmount the otbAmount to set
	 */
	public void setOtbAmount(BigDecimal otbAmount) {
		this.otbAmount = otbAmount;
	}
	/**
	 * @return the currentBalance_CustAcctType
	 */
	public BigDecimal getCurrentBalance_CustAcctType() {
		return currentBalance_CustAcctType;
	}
	/**
	 * @param currentBalance_CustAcctType the currentBalance_CustAcctType to set
	 */
	public void setCurrentBalance_CustAcctType(BigDecimal currentBalance_CustAcctType) {
		this.currentBalance_CustAcctType = currentBalance_CustAcctType;
	}
	/**
	 * @return the arrearsAmount
	 */
	public BigDecimal getArrearsAmount() {
		return arrearsAmount;
	}
	/**
	 * @param arrearsAmount the arrearsAmount to set
	 */
	public void setArrearsAmount(BigDecimal arrearsAmount) {
		this.arrearsAmount = arrearsAmount;
	}
	/**
	 * @return the cashPrice_DrawdownTerm
	 */
	public String getCashPrice_DrawdownTerm() {
		return cashPrice_DrawdownTerm;
	}
	/**
	 * @param cashPrice_DrawdownTerm the cashPrice_DrawdownTerm to set
	 */
	public void setCashPrice_DrawdownTerm(String cashPrice_DrawdownTerm) {
		this.cashPrice_DrawdownTerm = cashPrice_DrawdownTerm;
	}
	/**
	 * @return the currentBalance_DrawdownTerm
	 */
	public String getCurrentBalance_DrawdownTerm() {
		return currentBalance_DrawdownTerm;
	}
	/**
	 * @param currentBalance_DrawdownTerm the currentBalance_DrawdownTerm to set
	 */
	public void setCurrentBalance_DrawdownTerm(String currentBalance_DrawdownTerm) {
		this.currentBalance_DrawdownTerm = currentBalance_DrawdownTerm;
	}
	/**
	 * @return the id
	 */
	public long getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(long id) {
		this.id = id;
	}
	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}
	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}
	/**
	 * @return the chargeDate
	 */
	public Date getChargeDate() {
		return chargeDate;
	}
	/**
	 * @param chargeDate the chargeDate to set
	 */
	public void setChargeDate(Date chargeDate) {
		this.chargeDate = chargeDate;
	}
	/**
	 * @return the terminDays
	 */
	public long getTerminDays() {
		return terminDays;
	}
	/**
	 * @param terminDays the terminDays to set
	 */
	public void setTerminDays(long terminDays) {
		this.terminDays = terminDays;
	}
	/**
	 * @return the deferredTerminDays
	 */
	public long getDeferredTerminDays() {
		return deferredTerminDays;
	}
	/**
	 * @param deferredTerminDays the deferredTerminDays to set
	 */
	public void setDeferredTerminDays(long deferredTerminDays) {
		this.deferredTerminDays = deferredTerminDays;
	}
	/**
	 * @return the terminMonths
	 */
	public long getTerminMonths() {
		return terminMonths;
	}
	/**
	 * @param terminMonths the terminMonths to set
	 */
	public void setTerminMonths(long terminMonths) {
		this.terminMonths = terminMonths;
	}
	/**
	 * @return the deferredTerminMonths
	 */
	public long getDeferredTerminMonths() {
		return deferredTerminMonths;
	}
	/**
	 * @param deferredTerminMonths the deferredTerminMonths to set
	 */
	public void setDeferredTerminMonths(long deferredTerminMonths) {
		this.deferredTerminMonths = deferredTerminMonths;
	}
	/**
	 * @return the rate
	 */
	public BigDecimal getRate() {
		return rate;
	}
	/**
	 * @param rate the rate to set
	 */
	public void setRate(BigDecimal rate) {
		this.rate = rate;
	}
	/**
	 * @return the startDate
	 */
	public Date getStartDate() {
		return startDate;
	}
	/**
	 * @param startDate the startDate to set
	 */
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	/**
	 * @return the endDate
	 */
	public Date getEndDate() {
		return endDate;
	}
	/**
	 * @param endDate the endDate to set
	 */
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	/**
	 * @return the cashPrice_Items
	 */
	public BigDecimal getCashPrice_Items() {
		return cashPrice_Items;
	}
	/**
	 * @param cashPrice_Items the cashPrice_Items to set
	 */
	public void setCashPrice_Items(BigDecimal cashPrice_Items) {
		this.cashPrice_Items = cashPrice_Items;
	}
	/**
	 * @return the paymentAmount
	 */
	public BigDecimal getPaymentAmount() {
		return paymentAmount;
	}
	/**
	 * @param paymentAmount the paymentAmount to set
	 */
	public void setPaymentAmount(BigDecimal paymentAmount) {
		this.paymentAmount = paymentAmount;
	}

	public Set<CurrentDDTWithTransactionsAndIncomesType> getDrawdownTermTypeList() {
		return drawdownTermTypeList;
	}

	public void setDrawdownTermTypeList(Set<CurrentDDTWithTransactionsAndIncomesType> drawdownTermTypeList) {
		this.drawdownTermTypeList = drawdownTermTypeList;
	}

	public Set<CreditProductType> getCreditProductTypeList() {
		return creditProductTypeList;
	}

	public void setCreditProductTypeList(Set<CreditProductType> creditProductTypeList) {
		this.creditProductTypeList = creditProductTypeList;
	}

	public Set<BrandCreditProductType> getBrandCreditProductTypeList() {
		return brandCreditProductTypeList;
	}

	public void setBrandCreditProductTypeList(Set<BrandCreditProductType> brandCreditProductTypeList) {
		this.brandCreditProductTypeList = brandCreditProductTypeList;
	}

	public Set<DailyRateType> getDailyRateTypeList() {
		return dailyRateTypeList;
	}

	public void setDailyRateTypeList(Set<DailyRateType> dailyRateTypeList) {
		this.dailyRateTypeList = dailyRateTypeList;
	}

	public Set<DrawdownTermItemType> getDrawdownTermItemTypeList() {
		return drawdownTermItemTypeList;
	}

	public void setDrawdownTermItemTypeList(Set<DrawdownTermItemType> drawdownTermItemTypeList) {
		this.drawdownTermItemTypeList = drawdownTermItemTypeList;
	}

	public Set<PaymentType> getPaymentTypeList() {
		return paymentTypeList;
	}

	public void setPaymentTypeList(Set<PaymentType> paymentTypeList) {
		this.paymentTypeList = paymentTypeList;
	}

	public List<Set<PaymentType>> getCurrentPeriodMovement() {
		return currentPeriodMovement;
	}

	public void setCurrentPeriodMovement(List<Set<PaymentType>> currentPeriodMovement) {
		this.currentPeriodMovement = currentPeriodMovement;
	}
	
	
}
