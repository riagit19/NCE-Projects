package com.shopdirect.nce.sp.jms;

import java.util.Date;
import java.util.Hashtable;
import java.util.List;

import javax.jms.JMSException;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;

import com.shopdirect.nce.common.extcnfg.ExternalFileDataConfiguration;
import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.dao.StatementProcessorARDao;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.util.CommonConfigHelper;


/**
 * @author GouravChakraborty
 * JMS processor 
 */
public class QueueSend {
	
	private static SDLoggerImpl logger = new SDLoggerImpl();
	private QueueConnection qcon;
	private QueueSession qsession;
	private QueueSender qsender;
	private TextMessage msg;
	StatementProcessorARDao statementProcessorARDao;

	public QueueSend () throws StatementProcessorBatchException {
		statementProcessorARDao = getStatementProcessorARDao();
	}
	
	/**
	 * Called from client to evoke message sending over queue
	 * @param message
	 * @param customerId
	 * @param messageList
	 * @param queueName
	 */
	public void sendAsyncMessage(String message,String customerId,Date statementDate, String queueName) throws Exception {
		logger.debug("[QueueSend -- sendAsyncMessage for request queue] -- Start"); 
		statementProcessorARDao = new StatementProcessorARDao();
		CommonConfigHelper commonConfigHelper = CommonConfigHelper.getInstance();
		ExternalFileDataConfiguration externalClientConfig = commonConfigHelper.loadPropertyConfig(StatementProcessorBatchConstants.AUDITLOG_CONFIGURATION_FILE_KEY);
		QueueSend qs=new QueueSend();
		try{
			qs.init(queueName);
			logger.debug("JMS message : "+message);
			qs.send(message);
			statementProcessorARDao.updateARStatusMessage(customerId,commonConfigHelper.readConfigData(externalClientConfig, "startedAR"),new java.sql.Date(statementDate.getTime()));

		}catch(Exception e){
			statementProcessorARDao.updateARStatusMessage(customerId,commonConfigHelper.readConfigData(externalClientConfig, "newAR"),new java.sql.Date(statementDate.getTime()));
			logger.debug("[QueueSend -- sendAsyncMessage  for request queue] -- Exception: " + e.getMessage());
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_BUSINESS_ERROR_CODE,
					"[QueueSend-sendAsyncMessage for Request Queue] Exception Block",
					"Business exception generated at time to process the data collection " + e.getMessage(), null, null,
					e);
		}finally{
			qs.close();
		}
		logger.debug("[QueueSend -- sendAsyncMessage for request queue] -- End"); 
	}
	
	/**
	 * Overriden method
	 * Called from client to evoke message sending over queue
	 * @param messageList
	 * @param queueName
	 */
	public void sendAsyncMessage(List<String> messageList, String queueName) throws Exception {
		logger.debug("[QueueSend -- sendAsyncMessage for response queue] -- start"); 
		QueueSend qs=new QueueSend();
		try{
			qs.init(queueName);
			for(String message:messageList){
				logger.debug("JMS message : "+message);
				qs.send(message);
			}	
		}catch(Exception e){
			logger.debug("[QueueSend -- sendAsyncMessage  for response queue] -- Exception: " + e);
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_BUSINESS_ERROR_CODE,
					"[QueueSend-sendAsyncMessage for Response Queue] Exception Block",
					"Business exception generated at time to process the data collection " + e, null, null,
					e);
		}finally{
			qs.close();
		}
		logger.debug("[QueueSend -- sendAsyncMessage for response queue] -- End"); 
	}

	/**
	 * Loads external configuration files and instantiate connection factory
	 * @param queueName
	 */
	public void init(String queueName) throws StatementProcessorBatchException {
		logger.debug("[QueueSend -- init] -- start"); 
		Queue queue = null;
		QueueConnectionFactory qconFactory = null;
		try{
			CommonConfigHelper commonConfigHelper = CommonConfigHelper.getInstance();
			ExternalFileDataConfiguration externalClientConfig = commonConfigHelper.loadPropertyConfig("externalClientConfig");
			Hashtable<String, String> env = new Hashtable<>();
			env.put(Context.INITIAL_CONTEXT_FACTORY,commonConfigHelper.readConfigData(externalClientConfig, "JNDI_FACTORY"));
			env.put(Context.PROVIDER_URL, commonConfigHelper.readConfigData(externalClientConfig, "SERVER"));
			InitialContext ctx = new InitialContext(env);
			qconFactory = (QueueConnectionFactory) ctx.lookup(commonConfigHelper.readConfigData(externalClientConfig, "JMS_FACTORY"));
			qcon = qconFactory.createQueueConnection();
			qsession = qcon.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
			queue = (Queue) ctx.lookup(commonConfigHelper.readConfigData(externalClientConfig, queueName));
			qsender = qsession.createSender(queue);
			msg = qsession.createTextMessage();
		}catch(Exception e){
			logger.debug("[QueueSend -- init] -- Exception: " + e.getMessage());
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.FILE_CONFIG_ERROR_CODE,"[QueueSend-init]","Connection or Configuration related problem",null, null, e);
			
		}
		logger.debug("[QueueSend -- init] -- end"); 
		
	}

	/**
	 * Sends message over queue
	 * @param message
	 */
	public void send(String message) throws JMSException {
		logger.debug("[QueueSend -- send] -- start"); 
		if (!message.isEmpty()) {
			msg.setText(message);
			qsender.send(msg);
		}
		logger.debug("[QueueSend -- send] -- end"); 
	}

	/**
	 * Close JMS session and connection
	 */
	public void close() throws JMSException {
		logger.debug("[QueueSend -- close] -- start"); 
		qsender.close();
		qsession.close();
		qcon.close();
		logger.debug("[QueueSend -- close] -- end"); 
	}
	
	public StatementProcessorARDao getStatementProcessorARDao() throws StatementProcessorBatchException {
		if (this.statementProcessorARDao != null) {
			return this.statementProcessorARDao;
		}
		return new StatementProcessorARDao();
	}

	public void setStatementProcessorARDao(StatementProcessorARDao statementProcessorARDao) {
		this.statementProcessorARDao = statementProcessorARDao;
	}
	
}