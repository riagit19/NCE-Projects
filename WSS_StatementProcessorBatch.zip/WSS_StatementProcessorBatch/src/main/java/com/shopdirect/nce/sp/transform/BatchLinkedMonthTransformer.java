package com.shopdirect.nce.sp.transform;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.model.AccountingSnapshot;
import com.shopdirect.nce.sp.model.BatchDetails;
import com.shopdirect.nce.sp.model.BatchLinkedMonth;
import com.shopdirect.nce.sp.model.CustomerAccountInfo;

public class BatchLinkedMonthTransformer {

	private static SDLoggerImpl logger = new SDLoggerImpl();
	
	public List<BatchLinkedMonth> getBatchLinkedMonth(BatchDetails batchDetails,
			List<AccountingSnapshot> accountingSnapshotList, CustomerAccountInfo accountInfo) {
		
		logger.debug("[BatchLinkedMonthTransformer - getBatchLinkedMonth] - Start");
		
		List<BatchLinkedMonth> batchLinkedMonthList = new ArrayList<BatchLinkedMonth>();
		BatchLinkedMonth batchLinkedMonthObj;
		
		for (int i = 0; i < accountingSnapshotList.size(); i++) {
			batchLinkedMonthObj = new BatchLinkedMonth();
			
			if (i == 0) {
				batchLinkedMonthObj.setCustomerAccountNumber(accountInfo.getPublicAccountId());
				batchLinkedMonthObj.setBatchLinkedMonthOccurence(new BigDecimal(i+1));
				batchLinkedMonthObj.setScheduledPaymentsPastDue(batchDetails.getScheduledPaymentsPastDue());
				batchLinkedMonthObj.setInterestChargedAmtTSP(batchDetails.getInterestChargedAmtTSP());
				batchLinkedMonthObj.setNumPurchasesTSP(batchDetails.getNumPurchasesTSP());
				batchLinkedMonthObj.setRiskNavScore(batchDetails.getRiskNavScore());
				batchLinkedMonthObj.setOverIndebtScore(batchDetails.getOverIndebtScore());
				batchLinkedMonthObj.setBehaviourScore(batchDetails.getBehaviourScore());
				batchLinkedMonthObj.setcRF(batchDetails.getcRF());
				batchLinkedMonthObj.setBehaviourRawScore(batchDetails.getBehaviourRawScore());
				batchLinkedMonthObj.setScorecardId(batchDetails.getScorecardId());
				batchLinkedMonthObj.setAcdScorecardId(batchDetails.getAcdScorecardId());
				batchLinkedMonthObj.setAcdRawScore(batchDetails.getAcdRawScore());
				batchLinkedMonthObj.setAcdAlignedScore(batchDetails.getAcdAlignedScore());
				batchLinkedMonthObj.setNdrScorecardId(batchDetails.getNdrScorecardId());
				batchLinkedMonthObj.setNdrRawScore(batchDetails.getNdrRawScore());
				batchLinkedMonthObj.setNdrAlignedScore(batchDetails.getNdrAlignedScore());
				batchLinkedMonthObj.setCustScorecardId(batchDetails.getCustScorecardId());
				batchLinkedMonthObj.setCustRawScore(batchDetails.getCustRawScore());
				batchLinkedMonthObj.setCustAlignedScore(batchDetails.getCustAlignedScore());
				batchLinkedMonthObj.setRebatesAmountTSP(batchDetails.getRebatesAmountTSP());
				batchLinkedMonthObj.setoTB(batchDetails.getoTB());
				batchLinkedMonthObj.setNumPaymentsTSP(batchDetails.getNumPaymentsTSP());
				batchLinkedMonthObj.setNumNSF(batchDetails.getNumNSF());
				batchLinkedMonthObj.setDateStatement(accountingSnapshotList.get(i).getAssessmentDate());
				batchLinkedMonthObj.setBlockCode(null);
				batchLinkedMonthObj.setCurrentBalance(batchDetails.getCurrentBalance());
				batchLinkedMonthObj.setPurchaseAmountTSP(batchDetails.getPurchaseAmountTSP());
				batchLinkedMonthObj.setTotalFeesTSP(batchDetails.getTotalFeesTSP());
				batchLinkedMonthObj.setOtherDebits(batchDetails.getOtherDebits());
				batchLinkedMonthObj.setPaymentAmountTSP(batchDetails.getPaymentAmountTSP());
				batchLinkedMonthObj.setOtherCredits(batchDetails.getOtherCredits());
				batchLinkedMonthObj.setNumFailedPayments(batchDetails.getNumFailedPayments());
				batchLinkedMonthObj.setValueFailedPayments(batchDetails.getValueFailedPayments());
				batchLinkedMonthObj.setMinPayment(batchDetails.getMinPayment());
				batchLinkedMonthObj.setPastDue(batchDetails.getPastDue());
				batchLinkedMonthObj.setFidScoreWorst(batchDetails.getFidScoreWorst());
				batchLinkedMonthObj.setBnplBalance(batchDetails.getBnplBalance());
				batchLinkedMonthObj.setReturnsAmountTSP(batchDetails.getReturnsAmountTSP());
				batchLinkedMonthObj.setNetSalesValueTSPAmt(batchDetails.getNetSalesValueTSPAmt());
				batchLinkedMonthObj.setReturnsAmountTSP(batchDetails.getReturnsAmountTSP());
			} else {
				
				AccountingSnapshot accSnapshot = accountingSnapshotList.get(i);
				batchLinkedMonthObj.setCustomerAccountNumber(accountInfo.getPublicAccountId());
				batchLinkedMonthObj.setBatchLinkedMonthOccurence(new BigDecimal(i));
				batchLinkedMonthObj.setScheduledPaymentsPastDue(accSnapshot.getScheduledPaymentsPastDue());
				batchLinkedMonthObj.setInterestChargedAmtTSP(accSnapshot.getInterestChargedAmtTSP());
				batchLinkedMonthObj.setNumPurchasesTSP(accSnapshot.getNumPurchasesTSP());
				batchLinkedMonthObj.setRiskNavScore(accSnapshot.getRiskNavScore());
				batchLinkedMonthObj.setOverIndebtScore(accSnapshot.getOverIndebtScore());
				batchLinkedMonthObj.setBehaviourScore(accSnapshot.getBehaviourScore());
				batchLinkedMonthObj.setcRF(accSnapshot.getcRF());
				batchLinkedMonthObj.setBehaviourRawScore(accSnapshot.getBehaviourRawScore());
				batchLinkedMonthObj.setScorecardId(accSnapshot.getScorecardId());
				batchLinkedMonthObj.setAcdScorecardId(accSnapshot.getAcdScorecardId());
				batchLinkedMonthObj.setAcdRawScore(accSnapshot.getAcdRawScore());
				batchLinkedMonthObj.setAcdAlignedScore(accSnapshot.getAcdAlignedScore());
				batchLinkedMonthObj.setNdrScorecardId(accSnapshot.getNdrScorecardId());
				batchLinkedMonthObj.setNdrRawScore(accSnapshot.getNdrRawScore());
				batchLinkedMonthObj.setNdrAlignedScore(accSnapshot.getNdrAlignedScore());
				batchLinkedMonthObj.setCustScorecardId(accSnapshot.getCustScorecardId());
				batchLinkedMonthObj.setCustRawScore(accSnapshot.getCustRawScore());
				batchLinkedMonthObj.setCustAlignedScore(accSnapshot.getCustAlignedScore());
				batchLinkedMonthObj.setRebatesAmountTSP(accSnapshot.getRebatesAmountTSP());
				batchLinkedMonthObj.setoTB(accSnapshot.getoTB());
				batchLinkedMonthObj.setNumPaymentsTSP(accSnapshot.getNumPaymentsTSP());
				batchLinkedMonthObj.setNumNSF(accSnapshot.getNumNSF());
				batchLinkedMonthObj.setDateStatement(accSnapshot.getAssessmentDate());
				batchLinkedMonthObj.setBlockCode(accSnapshot.getBlockCode());
				batchLinkedMonthObj.setCurrentBalance(accSnapshot.getCurrentBalance());
				batchLinkedMonthObj.setPurchaseAmountTSP(accSnapshot.getPurchaseAmountTSP());
				batchLinkedMonthObj.setTotalFeesTSP(accSnapshot.getTotalFeesTSP());
				batchLinkedMonthObj.setOtherDebits(accSnapshot.getOtherDebits());
				batchLinkedMonthObj.setPaymentAmountTSP(accSnapshot.getPaymentAmountTSP());
				batchLinkedMonthObj.setOtherCredits(accSnapshot.getOtherCredits());
				batchLinkedMonthObj.setNumFailedPayments(accSnapshot.getNumFailedPayments());
				batchLinkedMonthObj.setValueFailedPayments(accSnapshot.getValueFailedPayments());
				batchLinkedMonthObj.setMinPayment(accSnapshot.getMinPayment());
				batchLinkedMonthObj.setPastDue(accSnapshot.getPastDue());
				batchLinkedMonthObj.setFidScoreWorst(accSnapshot.getFidScoreWorst());
				batchLinkedMonthObj.setBnplBalance(accSnapshot.getBnplBalance());
				batchLinkedMonthObj.setReturnsAmountTSP(accSnapshot.getReturnsAmountTSP());
				batchLinkedMonthObj.setNetSalesValueTSPAmt(accSnapshot.getNetSalesValueTSPAmt());
				batchLinkedMonthObj.setReturnsAmountTSP(accSnapshot.getReturnsAmountTSP());

			}
			batchLinkedMonthList.add(batchLinkedMonthObj);	
		}
		
		logger.debug("[BatchLinkedMonthTransformer - getBatchLinkedMonth] - End");
		return batchLinkedMonthList;
	
	}
}
