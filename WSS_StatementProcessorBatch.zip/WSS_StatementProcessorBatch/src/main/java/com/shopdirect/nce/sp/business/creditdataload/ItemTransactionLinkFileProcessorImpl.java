package com.shopdirect.nce.sp.business.creditdataload;

import java.io.File;
import java.io.FileReader;
import java.io.LineNumberReader;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.shopdirect.nce.sp.constants.CreditLoadDataConstants;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.dao.creditdataload.ItemTransactionLinkDaoImpl;
import com.shopdirect.nce.sp.dao.creditdataload.SpCreditFilLoadControlDaoImpl;
import com.shopdirect.nce.sp.exception.BuisnessException;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.ItemTransactionLink;
import com.shopdirect.nce.sp.util.FinFileBaseProcessor;
import com.shopdirect.nce.sp.util.StatementProcessorBatchUtil;

public class ItemTransactionLinkFileProcessorImpl extends  FinFileBaseProcessor implements DataFileProcessor{

	private ItemTransactionLinkDaoImpl itemTransactionLinkDaoImpl;
	
	public ItemTransactionLinkFileProcessorImpl() throws StatementProcessorBatchException {
		super();
	}
	
	
	public boolean processFile(File folder, long batchID, int user , String batchRunDate) throws StatementProcessorBatchException {
			
			getLogger().debug("[ItemTransactionLinkFileProcessorImpl -- processFile]  -- START");
			List<Map<String, Object>> columns;
			File file;
			String line;
			final String fileName = StatementProcessorBatchUtil.generateFileName(CreditLoadDataConstants.ITEMTRANSACTIONLINK,
					CreditLoadDataConstants.NEW_STATUS, batchRunDate);
			file = getFile(folder, fileName);
			line = "";
			String comma = ",";
			columns = getColumns(StatementProcessorBatchConstants.ITEM_TRANSACTION_LINK_DATA_MAPPING,
					StatementProcessorBatchConstants.ITEM_TRANSACTION_LINK_MAP);
			String fileIdentifier = getCommonConfigHelper().readConfigData(getDataconfig(), "ITEMTRANSACTIONLINK");
			String insertedMessage = null;
			String errorMessage = StatementProcessorBatchConstants.EMPTY_STRING;
			int insertCount;
			List<ItemTransactionLink> itemTransactionLinkRecords = null;
			boolean insertedItemTransactionLink = false;
			SpCreditFilLoadControlDaoImpl spCreditFilLoadControlDaoImpl = new SpCreditFilLoadControlDaoImpl();
			
			Object[] procReturnVal = new Object[2];
			int retCode = 0;
			String retMsg = null;

			try (LineNumberReader reader = new LineNumberReader(new FileReader(file))) {
				int records = getRecordsCount(this.getFinancierFilePath() + file.getName());
				insertSpLoadControlData(batchID, file.getName(), fileIdentifier, user);
				String header = reader.readLine();
				if(records == StatementProcessorBatchConstants.HEADER_RECORD){
					insertedItemTransactionLink = true ;
				}
				else {
					while ((reader.getLineNumber()) < records) {
						itemTransactionLinkRecords = new ArrayList<>();
						for (insertCount = 0; insertCount<getBatchInsertcount() ;insertCount++ ){					
							if ((line = reader.readLine())!= null){						
								String[] contents = line.split(comma, -1);
								//Check number of data in xml and .dat file is same or not
								if (columns.size() != contents.length) {
									throw new Exception(CreditLoadDataConstants.MISMATCH_ON_COLUMN_COUNT);
								}
								ItemTransactionLink itemTransactionLink = new ItemTransactionLink();						
								itemTransactionLink.setBatchId(batchID);
								itemTransactionLink.setCreatedByUser(Long.valueOf(user));
								itemTransactionLinkRecords.add(itemTransactionLink);
								constructObjects(contents, columns, itemTransactionLink);
							} else{
								break;
							}
						}
						
						procReturnVal = getItemTransactionLinkDaoImpl().insertItemTransactionLinkData(itemTransactionLinkRecords);
						retCode = (int) procReturnVal[0];
						retMsg = (String) procReturnVal[1];
						
						// update the CONTROL table and DELETE if INSERTION fails
						if (retCode == 0) {
							insertedItemTransactionLink = true;
						} else {
							insertedItemTransactionLink = false;
							errorMessage = retMsg;
						}
					}
				}

				/**
				 * Update the CONTROL table with batch id and error message
				 */
				spCreditFilLoadControlDaoImpl.updateControlData(batchID, insertedItemTransactionLink, errorMessage, fileIdentifier);

			} catch (Exception exception) {
				insertedMessage = exception.getMessage();
				errorMessage = insertedMessage;
				insertedItemTransactionLink = false;
				/**
				 * Update the CONTROL table with batch id and error messege
				 */
				try {
					spCreditFilLoadControlDaoImpl.updateControlData(batchID, insertedItemTransactionLink, errorMessage, fileIdentifier);
				}  catch (BuisnessException | SQLException ex) {
					getLogger()
					.debug("[ItemTransactionLinkFileProcessorImpl -- processFile] -- Control Table Update Exception: "
							+ ex);
				} catch (Exception exception2) {
					getLogger()
							.debug("[ItemTransactionLinkFileProcessorImpl -- processFile] -- Control Table Update Exception: "
									+ exception2);
				}

				getLogger()
						.error("[ItemTransactionLinkFileProcessorImpl -- processFile] -- ItemTransaction insert Error occured ");
				getLogger().debug(
						"[ItemTransactionLinkFileProcessorImpl -- processFile] -- ItemTransaction Exception: " + exception);
				
				throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_BUSINESS_ERROR_CODE,
						"[ItemTransactionLinkFileProcessorImpl-processFile] StatementProcessorBatchException Block",
						"Item Transaction Exception " + errorMessage, null, null,
						new StatementProcessorBatchException());
			}
			getLogger().debug("[ItemTransactionLinkFileProcessorImpl -- processFile]  -- END");
			return insertedItemTransactionLink;
		}

		
		/**
		 * @return the itemTransactionLinkDaoImpl
		 * @throws StatementProcessorBatchException 
		 */
		public ItemTransactionLinkDaoImpl getItemTransactionLinkDaoImpl() throws StatementProcessorBatchException {
			if(itemTransactionLinkDaoImpl == null) {
				itemTransactionLinkDaoImpl = new ItemTransactionLinkDaoImpl();
			}
			return itemTransactionLinkDaoImpl;
		}

		/**
		 * @param ItemTransactionLinkDaoImpl 
		 */
		public void setItemTransactionLinkDaoImpl(ItemTransactionLinkDaoImpl itemTransactionLinkDaoImpl) {
			this.itemTransactionLinkDaoImpl = itemTransactionLinkDaoImpl;
		}	


}
