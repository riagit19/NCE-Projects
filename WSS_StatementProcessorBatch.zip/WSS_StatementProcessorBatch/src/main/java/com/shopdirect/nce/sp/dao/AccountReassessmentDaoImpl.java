package com.shopdirect.nce.sp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.Query;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.util.DBConnectionUCP;

public class AccountReassessmentDaoImpl extends AccountReassessmentBaseDao  {

private SDLoggerImpl logger = new SDLoggerImpl();
	
	
	public AccountReassessmentDaoImpl() throws StatementProcessorBatchException{
		super();
		setSpMainSchema(getSchema(StatementProcessorBatchConstants.DB_SCHEMA_MAIN_SP_KEY));
	}
	
	public int updateAccReassessment(Connection con, String pubAccNo, String creditLimitAction, String creditLimitAmount, String clStatus) throws StatementProcessorBatchException, SQLException {
		logger.debug("[AccountReassessmentDaoImpl -- updateAccReassessment]  -- START");
		int status = -1;
		PreparedStatement  stmt = null;
	    try {
	    	String queryStr = Query.getUpdateAccReassessmentQuery(getSpMainSchema());
	    	logger.info("***********************"+queryStr);
	    	logger.info("**************pubAccNo= "+pubAccNo);
	    	stmt = con.prepareStatement(queryStr);
	    	stmt.setString(1, creditLimitAction);
	    	stmt.setString(2, creditLimitAmount);
	    	stmt.setString(3, clStatus);
	    	stmt.setString(4, pubAccNo);
    		status = stmt.executeUpdate();
		} catch (SQLException sqlException) {
	    	throw sqlException;
	    } catch(Exception exception){
				throw new StatementProcessorBatchException(StatementProcessorBatchConstants.CONNECTTION_DB_ERROR_CODE,
						"[AccountReassessmentDaoImpl -- updateAccReassessment] Exception Block",
						"Database execution exception "+ exception,
						null, null,exception);
		 }finally {
			   
			   try {
				   if(stmt != null){
					   stmt.close();
				   }
				} catch (Exception e) {
					getLogger().error("[AccountReassessmentDaoImpl -- updateAccReassessment] finally Block: failed to close DB objects. " + e);
				}
		   }
		    
		    logger.debug("[AccountReassessmentDaoImpl -- updateAccReassessment]  -- END");
			return status;
	}
	
	public boolean insertAccReassessment(Connection con, String pubAccNo, String creditLimitAction, String creditLimitAmount, String clStatus) throws StatementProcessorBatchException,SQLException {
		logger.debug("[AccountReassessmentDaoImpl -- insertAccReassessment]  -- START");
		
		boolean status = false;
		PreparedStatement  stmt = null;
	    try {
	    	String queryStr = Query.getInsertAccReassessmentQuery(getSpMainSchema(), pubAccNo, creditLimitAction, creditLimitAmount, clStatus);
	    	logger.info("***********************"+queryStr);
	    	logger.info("**************pubAccNo= "+pubAccNo);
	    	stmt = con.prepareStatement(queryStr);
	    	status = stmt.execute();
		 } catch (SQLException sqlException) {
	    	throw sqlException;
		 }	catch(Exception exception){
				throw new StatementProcessorBatchException(StatementProcessorBatchConstants.CONNECTTION_DB_ERROR_CODE,
						"[AccountReassessmentDaoImpl -- insertAccReassessment] Exception Block",
						"Database execution exception "+ exception,
						null, null,exception);
		 }	finally {
			   
			   try {
				   if(stmt != null){
					   stmt.close();
				   }
				 
				} catch (Exception e) {
					getLogger().error("[AccountReassessmentDaoImpl -- insertAccReassessment] finally Block: failed to close DB objects. " + e);
				}
		   }
		    
		    logger.debug("[AccountReassessmentDaoImpl -- insertAccReassessment]  -- END");
			return status;
	}
	
	/**
	 * @return the logger
	 */
	@Override
	public SDLoggerImpl getLogger() {
		return logger;
	}
	
}
