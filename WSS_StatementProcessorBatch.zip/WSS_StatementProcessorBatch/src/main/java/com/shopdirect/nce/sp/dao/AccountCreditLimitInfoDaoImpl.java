package com.shopdirect.nce.sp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.Query;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;

public class AccountCreditLimitInfoDaoImpl extends AccountReassessmentBaseDao  {

private SDLoggerImpl logger = new SDLoggerImpl();
	
	
	public AccountCreditLimitInfoDaoImpl() throws StatementProcessorBatchException{
		super();
		setSpMainSchema(getSchema(StatementProcessorBatchConstants.DB_SCHEMA_MAIN_SP_KEY));
	}
		
	public int insertAccCreditLimitInfo(Connection con, String pubAccNo, String creditLimitAction, String proposeCreditLimitAmount, 
			String clStatus, String actualCreditLimit, String statementDate, String arrearsStatus,
			String creditLimitReasonCode, String creditRiskFactor,
			String authStrategyID, String custBehaviourScore, String daysProposedLimitExpires, 
			String limitCapValue, String shadowCreditMonetoryLimit,
			String actualCreditMonetroyLimit, String tradingCode) throws StatementProcessorBatchException, SQLException {
		logger.debug("[AccountCreditLimitInfoDaoImpl -- insertAccReassessment]  -- START");
		int status = 0;
		PreparedStatement  stmt = null;
		try {
	    	String queryStr = Query.getInsertAcCreditLimitInfoQuery(getSpMainSchema(), pubAccNo, creditLimitAction, proposeCreditLimitAmount, 
	    			statementDate, actualCreditLimit, arrearsStatus, creditLimitReasonCode, creditRiskFactor,
    				authStrategyID, custBehaviourScore, daysProposedLimitExpires, limitCapValue, shadowCreditMonetoryLimit,
    				actualCreditMonetroyLimit, tradingCode);
	    	logger.info("AccountCreditLimitInfoDaoImpl ***********************" + queryStr);
	    	logger.info("AccountCreditLimitInfoDaoImpl **************pubAccNo= " + pubAccNo);
	    	stmt = con.prepareStatement(queryStr);
	    	status = stmt.executeUpdate();

	    } catch (SQLException sqlException) {
	    	throw sqlException;
		 } catch(Exception exception){
				throw new StatementProcessorBatchException(StatementProcessorBatchConstants.CONNECTTION_DB_ERROR_CODE,
						"[AccountCreditLimitInfoDaoImpl -- insertAccReassessment] Exception Block",
						"Database execution exception "+ exception,
						null, null,exception);
		 }	finally {
			   try {
				   if(stmt != null){
					   stmt.close();
				   }				    
				} catch (Exception e) {
					getLogger().error("[AccountCreditLimitInfoDaoImpl -- insertAccReassessment] finally Block: failed to close DB objects. " + e);
				}
		   }
		    
		    logger.debug("[AccountCreditLimitInfoDaoImpl -- insertAccReassessment]  -- END");
			return status;
	}
	
	public int updateAccCreditLimitInfo(Connection con, String pubAccNo, String creditLimitAction, String proposeCreditLimitAmount, 
			String clStatus, String actualCreditLimit, String statementDate, String arrearsStatus,
			String creditLimitReasonCode, String creditRiskFactor,
			String authStrategyID, String custBehaviourScore, String daysProposedLimitExpires, 
			String limitCapValue, String shadowCreditMonetoryLimit,
			String actualCreditMonetroyLimit) throws StatementProcessorBatchException, SQLException {
			logger.debug("[AccountCreditLimitInfoDaoImpl -- updateAccCreditLimitInfo]  -- START");
			int status = 0;
			PreparedStatement  stmt = null;
			try {
			String queryStr = Query.getUpdateAcCreditLimitInfoQuery(getSpMainSchema());
			logger.info("***********************"+queryStr);
			logger.info("**************pubAccNo= "+pubAccNo);
	    	stmt = con.prepareStatement(queryStr);
	    	stmt.setString(1, creditLimitAction);
	    	stmt.setString(2, proposeCreditLimitAmount);
	    	stmt.setString(3, creditLimitReasonCode);
	    	stmt.setString(4, creditRiskFactor);
	    	stmt.setString(5, authStrategyID);
	    	stmt.setString(6, custBehaviourScore);
	    	stmt.setString(7, daysProposedLimitExpires);
	    	stmt.setString(8, limitCapValue);
	    	stmt.setString(9, shadowCreditMonetoryLimit);
	    	stmt.setString(10, actualCreditMonetroyLimit);
	    	stmt.setString(11, pubAccNo);
	    	stmt.setString(12, statementDate);
    		status = stmt.executeUpdate();
		} catch (SQLException sqlException) {
	    	throw sqlException;
		 } catch(Exception exception){
				throw new StatementProcessorBatchException(StatementProcessorBatchConstants.CONNECTTION_DB_ERROR_CODE,
						"[AccountCreditLimitInfoDaoImpl -- updateAccCreditLimitInfo] Exception Block",
						"Database execution exception "+ exception,
						null, null,exception);
		 }	finally {
			   try {
				   if(stmt != null){
					   stmt.close();
				   }				    
				} catch (Exception e) {
					getLogger().error("[AccountCreditLimitInfoDaoImpl -- updateAccCreditLimitInfo] finally Block: failed to close DB objects. " + e);
				}
		   }
		    
		    logger.debug("[AccountCreditLimitInfoDaoImpl -- updateAccCreditLimitInfo]  -- END");
			return status;
	}
	
	/**
	 * @return the logger
	 */
	@Override
	public SDLoggerImpl getLogger() {
		return logger;
	}
	
}
