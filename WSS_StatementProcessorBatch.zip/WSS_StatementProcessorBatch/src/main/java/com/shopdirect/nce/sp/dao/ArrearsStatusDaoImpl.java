package com.shopdirect.nce.sp.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.shopdirect.nce.common.extcnfg.ExternalFileDataConfiguration;
import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.Query;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.util.CommonConfigHelper;
import com.shopdirect.nce.sp.util.UCPConnection;

/**
 * This class use to get arrears status code Dao implementation
 * @author manojkumar
 *
 */
public class ArrearsStatusDaoImpl extends AccountReassessmentBaseDao {
	
	private SDLoggerImpl logger = new SDLoggerImpl();
	
	public ArrearsStatusDaoImpl() throws StatementProcessorBatchException{
		super();
		setSpMainSchema(getSchema(StatementProcessorBatchConstants.DB_SCHEMA_MAIN_SP_KEY));
	}
	
	/**
	 * This main method to get Arrears Status code.
	 * @param pubAccNum
	 * @param statementDate
	 * @return arrearsStatusCode
	 * @throws StatementProcessorBatchException
	 */
	public Map<String, String> getArrearsStatus(String pubAccNum, Date statementDate) throws StatementProcessorBatchException{
		
		logger.debug("[ArrearsStatusDaoImpl - getArrearsStatus] -- Start");
		
		Connection connection = null;
		CallableStatement stmt = null;
		String arrearsStatusCode = null;
		Integer tradingCode = 0;
		int returnCode = 0;
		Map<String, String> returnMap = new HashMap<>();
		String returnMsg = null;
		java.sql.Date sqlDate = null;
		if (statementDate != null) {
			sqlDate = new java.sql.Date(statementDate.getTime());
		}
		
		final String pack = getConfigValue(StatementProcessorBatchConstants.PACK_ACCOUNT_ARREARS);
		final String procedure = getConfigValue(StatementProcessorBatchConstants.PROC_ACCOUNT_ARREARS_STATUS);
		
    	final String spDetail = Query.getAccountArrearsStatusQuery(pack, procedure);
    	
    	try {
			connection = UCPConnection.getConnection();
			
			stmt = connection.prepareCall(spDetail);
			stmt.setString(1, pubAccNum);
			stmt.setDate(2, sqlDate);
			stmt.registerOutParameter(3, Types.VARCHAR);
			stmt.registerOutParameter(4, Types.INTEGER);
			stmt.registerOutParameter(5, Types.INTEGER);
			stmt.registerOutParameter(6, Types.VARCHAR);
			stmt.execute();
			
			arrearsStatusCode = stmt.getString(3);
			tradingCode = stmt.getInt(4);
			returnCode = stmt.getInt(5);
			returnMsg = stmt.getString(6);
			
			if (returnCode == 0) {
				returnMap.put(StatementProcessorBatchConstants.ARREARS_STATUS_CODE, arrearsStatusCode);
				returnMap.put(StatementProcessorBatchConstants.TRADING_CODE, tradingCode.toString());
				logger.debug("[ArrearsStatusDaoImpl - getArrearsStatus] -- SP successfully executed");
			}
			
    	} catch (SQLException exception) {
    		logger.error("[ArrearsStatusDaoImpl - getArrearsStatus] -- Exception: " + exception);
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_DB_ERROR_CODE,
					"[ArrearsStatusDaoImpl - getArrearsStatus] Exception", exception.getMessage(), null, null, exception);
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}

				if (connection != null) {
					connection.close();
				}
			} catch (SQLException sqle) {
				logger.error("[ArrearsStatusDaoImpl - getArrearsStatus] -- Exception in finally block: " + sqle);
			}
		}
    	
		logger.debug("[ArrearsStatusDaoImpl - getArrearsStatus] -- End");
		
		return returnMap;
	}
	
	/**
	 * @return the logger
	 */
	@Override
	public SDLoggerImpl getLogger() {
		return logger;
	}

	private String getConfigValue(String key) throws StatementProcessorBatchException {
		CommonConfigHelper commonConfigHelper = CommonConfigHelper.getInstance();
		ExternalFileDataConfiguration dbconfig = commonConfigHelper
				.loadPropertyConfig(StatementProcessorBatchConstants.DATABASE_CONFIGURATION_FILE_KEY);
		return commonConfigHelper.readConfigData(dbconfig, key);
	}
}
