package com.shopdirect.nce.sp.model;

public class CreditLimit {

	private Integer actualCreditLimit;
	private Integer proposedCreditLimit;
	private String statementMessage;
	private String creditLineReasonCode;
	private String daysProposedLimitExpires;
	private Integer creditRiskFactor;
	private Integer custBehaviourScore;
	private Integer annotationsTriadDecisionKeyBatch;
	private Integer authStrategyId;
	private Integer authDigitsLowerLimit;
	private Integer authDigitsUpperLimit;
	private Double barFactory;
	private Integer scoreCardId;
	private Integer rawBehaviourScore;
	private Integer alignedBehaviourScore;
	private Integer triadBehaviourScorecardTypeCode;
	private String collTimedAction;
	private Integer acdScoreCardId;
	private Integer acdRawBehaviourScore;
	private Integer acdAlignedBehaviourScore;
	private Integer ndrScoreId;
	private Integer ndrAlignedBehaviourScore;
	private Integer custScorecardId;
	private Integer custRawBehaviourScore;
	private Integer custAlignedBehaviourScore;
	private Integer limitCapValue;
	private Integer affordabilityUpdateRequiredCode;
	private Integer derivedIncome;
	private Integer creditLimitOutcomeCode;
	private Integer derivedIncomeFlag;
	private Integer bnplScore;

	/**
	 * @return the actualCreditLimit
	 */
	public Integer getActualCreditLimit() {
		return actualCreditLimit;
	}

	/**
	 * @param actualCreditLimit
	 *            the actualCreditLimit to set
	 */
	public void setActualCreditLimit(Integer actualCreditLimit) {
		this.actualCreditLimit = actualCreditLimit;
	}

	/**
	 * @return the proposedCreditLimit
	 */
	public Integer getProposedCreditLimit() {
		return proposedCreditLimit;
	}

	/**
	 * @param proposedCreditLimit
	 *            the proposedCreditLimit to set
	 */
	public void setProposedCreditLimit(Integer proposedCreditLimit) {
		this.proposedCreditLimit = proposedCreditLimit;
	}

	/**
	 * @return the statementMessage
	 */
	public String getStatementMessage() {
		return statementMessage;
	}

	/**
	 * @param statementMessage
	 *            the statementMessage to set
	 */
	public void setStatementMessage(String statementMessage) {
		this.statementMessage = statementMessage;
	}

	/**
	 * @return the creditLineReasonCode
	 */
	public String getCreditLineReasonCode() {
		return creditLineReasonCode;
	}

	/**
	 * @param creditLineReasonCode
	 *            the creditLineReasonCode to set
	 */
	public void setCreditLineReasonCode(String creditLineReasonCode) {
		this.creditLineReasonCode = creditLineReasonCode;
	}

	/**
	 * @return the daysProposedLimitExpires
	 */
	public String getDaysProposedLimitExpires() {
		return daysProposedLimitExpires;
	}

	/**
	 * @param daysProposedLimitExpires
	 *            the daysProposedLimitExpires to set
	 */
	public void setDaysProposedLimitExpires(String daysProposedLimitExpires) {
		this.daysProposedLimitExpires = daysProposedLimitExpires;
	}

	/**
	 * @return the creditRiskFactor
	 */
	public Integer getCreditRiskFactor() {
		return creditRiskFactor;
	}

	/**
	 * @param creditRiskFactor
	 *            the creditRiskFactor to set
	 */
	public void setCreditRiskFactor(Integer creditRiskFactor) {
		this.creditRiskFactor = creditRiskFactor;
	}

	/**
	 * @return the custBehaviourScore
	 */
	public Integer getCustBehaviourScore() {
		return custBehaviourScore;
	}

	/**
	 * @param custBehaviourScore
	 *            the custBehaviourScore to set
	 */
	public void setCustBehaviourScore(Integer custBehaviourScore) {
		this.custBehaviourScore = custBehaviourScore;
	}

	/**
	 * @return the annotationsTriadDecisionKeyBatch
	 */
	public Integer getAnnotationsTriadDecisionKeyBatch() {
		return annotationsTriadDecisionKeyBatch;
	}

	/**
	 * @param annotationsTriadDecisionKeyBatch
	 *            the annotationsTriadDecisionKeyBatch to set
	 */
	public void setAnnotationsTriadDecisionKeyBatch(Integer annotationsTriadDecisionKeyBatch) {
		this.annotationsTriadDecisionKeyBatch = annotationsTriadDecisionKeyBatch;
	}

	/**
	 * @return the authStrategyId
	 */
	public Integer getAuthStrategyId() {
		return authStrategyId;
	}

	/**
	 * @param authStrategyId
	 *            the authStrategyId to set
	 */
	public void setAuthStrategyId(Integer authStrategyId) {
		this.authStrategyId = authStrategyId;
	}

	/**
	 * @return the authDigitsLowerLimit
	 */
	public Integer getAuthDigitsLowerLimit() {
		return authDigitsLowerLimit;
	}

	/**
	 * @param authDigitsLowerLimit
	 *            the authDigitsLowerLimit to set
	 */
	public void setAuthDigitsLowerLimit(Integer authDigitsLowerLimit) {
		this.authDigitsLowerLimit = authDigitsLowerLimit;
	}

	/**
	 * @return the authDigitsUpperLimit
	 */
	public Integer getAuthDigitsUpperLimit() {
		return authDigitsUpperLimit;
	}

	/**
	 * @param authDigitsUpperLimit
	 *            the authDigitsUpperLimit to set
	 */
	public void setAuthDigitsUpperLimit(Integer authDigitsUpperLimit) {
		this.authDigitsUpperLimit = authDigitsUpperLimit;
	}

	/**
	 * @return the barFactory
	 */
	public Double getBarFactory() {
		return barFactory;
	}

	/**
	 * @param barFactory
	 *            the barFactory to set
	 */
	public void setBarFactory(Double barFactory) {
		this.barFactory = barFactory;
	}

	/**
	 * @return the scoreCardId
	 */
	public Integer getScoreCardId() {
		return scoreCardId;
	}

	/**
	 * @param scoreCardId
	 *            the scoreCardId to set
	 */
	public void setScoreCardId(Integer scoreCardId) {
		this.scoreCardId = scoreCardId;
	}

	/**
	 * @return the rawBehaviourScore
	 */
	public Integer getRawBehaviourScore() {
		return rawBehaviourScore;
	}

	/**
	 * @param rawBehaviourScore
	 *            the rawBehaviourScore to set
	 */
	public void setRawBehaviourScore(Integer rawBehaviourScore) {
		this.rawBehaviourScore = rawBehaviourScore;
	}

	/**
	 * @return the alignedBehaviourScore
	 */
	public Integer getAlignedBehaviourScore() {
		return alignedBehaviourScore;
	}

	/**
	 * @param alignedBehaviourScore
	 *            the alignedBehaviourScore to set
	 */
	public void setAlignedBehaviourScore(Integer alignedBehaviourScore) {
		this.alignedBehaviourScore = alignedBehaviourScore;
	}

	/**
	 * @return the triadBehaviourScorecardTypeCode
	 */
	public Integer getTriadBehaviourScorecardTypeCode() {
		return triadBehaviourScorecardTypeCode;
	}

	/**
	 * @param triadBehaviourScorecardTypeCode
	 *            the triadBehaviourScorecardTypeCode to set
	 */
	public void setTriadBehaviourScorecardTypeCode(Integer triadBehaviourScorecardTypeCode) {
		this.triadBehaviourScorecardTypeCode = triadBehaviourScorecardTypeCode;
	}

	/**
	 * @return the collTimedAction
	 */
	public String getCollTimedAction() {
		return collTimedAction;
	}

	/**
	 * @param collTimedAction
	 *            the collTimedAction to set
	 */
	public void setCollTimedAction(String collTimedAction) {
		this.collTimedAction = collTimedAction;
	}

	/**
	 * @return the acdScoreCardId
	 */
	public Integer getAcdScoreCardId() {
		return acdScoreCardId;
	}

	/**
	 * @param acdScoreCardId
	 *            the acdScoreCardId to set
	 */
	public void setAcdScoreCardId(Integer acdScoreCardId) {
		this.acdScoreCardId = acdScoreCardId;
	}

	/**
	 * @return the acdRawBehaviourScore
	 */
	public Integer getAcdRawBehaviourScore() {
		return acdRawBehaviourScore;
	}

	/**
	 * @param acdRawBehaviourScore
	 *            the acdRawBehaviourScore to set
	 */
	public void setAcdRawBehaviourScore(Integer acdRawBehaviourScore) {
		this.acdRawBehaviourScore = acdRawBehaviourScore;
	}

	/**
	 * @return the acdAlignedBehaviourScore
	 */
	public Integer getAcdAlignedBehaviourScore() {
		return acdAlignedBehaviourScore;
	}

	/**
	 * @param acdAlignedBehaviourScore
	 *            the acdAlignedBehaviourScore to set
	 */
	public void setAcdAlignedBehaviourScore(Integer acdAlignedBehaviourScore) {
		this.acdAlignedBehaviourScore = acdAlignedBehaviourScore;
	}

	/**
	 * @return the ndrScoreId
	 */
	public Integer getNdrScoreId() {
		return ndrScoreId;
	}

	/**
	 * @param ndrScoreId
	 *            the ndrScoreId to set
	 */
	public void setNdrScoreId(Integer ndrScoreId) {
		this.ndrScoreId = ndrScoreId;
	}

	/**
	 * @return the ndrAlignedBehaviourScore
	 */
	public Integer getNdrAlignedBehaviourScore() {
		return ndrAlignedBehaviourScore;
	}

	/**
	 * @param ndrAlignedBehaviourScore
	 *            the ndrAlignedBehaviourScore to set
	 */
	public void setNdrAlignedBehaviourScore(Integer ndrAlignedBehaviourScore) {
		this.ndrAlignedBehaviourScore = ndrAlignedBehaviourScore;
	}

	/**
	 * @return the custScorecardId
	 */
	public Integer getCustScorecardId() {
		return custScorecardId;
	}

	/**
	 * @param custScorecardId
	 *            the custScorecardId to set
	 */
	public void setCustScorecardId(Integer custScorecardId) {
		this.custScorecardId = custScorecardId;
	}

	/**
	 * @return the custRawBehaviourScore
	 */
	public Integer getCustRawBehaviourScore() {
		return custRawBehaviourScore;
	}

	/**
	 * @param custRawBehaviourScore
	 *            the custRawBehaviourScore to set
	 */
	public void setCustRawBehaviourScore(Integer custRawBehaviourScore) {
		this.custRawBehaviourScore = custRawBehaviourScore;
	}

	/**
	 * @return the custAlignedBehaviourScore
	 */
	public Integer getCustAlignedBehaviourScore() {
		return custAlignedBehaviourScore;
	}

	/**
	 * @param custAlignedBehaviourScore
	 *            the custAlignedBehaviourScore to set
	 */
	public void setCustAlignedBehaviourScore(Integer custAlignedBehaviourScore) {
		this.custAlignedBehaviourScore = custAlignedBehaviourScore;
	}

	/**
	 * @return the limitCapValue
	 */
	public Integer getLimitCapValue() {
		return limitCapValue;
	}

	/**
	 * @param limitCapValue
	 *            the limitCapValue to set
	 */
	public void setLimitCapValue(Integer limitCapValue) {
		this.limitCapValue = limitCapValue;
	}

	/**
	 * @return the affordabilityUpdateRequiredCode
	 */
	public Integer getAffordabilityUpdateRequiredCode() {
		return affordabilityUpdateRequiredCode;
	}

	/**
	 * @param affordabilityUpdateRequiredCode
	 *            the affordabilityUpdateRequiredCode to set
	 */
	public void setAffordabilityUpdateRequiredCode(Integer affordabilityUpdateRequiredCode) {
		this.affordabilityUpdateRequiredCode = affordabilityUpdateRequiredCode;
	}

	/**
	 * @return the derivedIncome
	 */
	public Integer getDerivedIncome() {
		return derivedIncome;
	}

	/**
	 * @param derivedIncome
	 *            the derivedIncome to set
	 */
	public void setDerivedIncome(Integer derivedIncome) {
		this.derivedIncome = derivedIncome;
	}

	/**
	 * @return the creditLimitOutcomeCode
	 */
	public Integer getCreditLimitOutcomeCode() {
		return creditLimitOutcomeCode;
	}

	/**
	 * @param creditLimitOutcomeCode
	 *            the creditLimitOutcomeCode to set
	 */
	public void setCreditLimitOutcomeCode(Integer creditLimitOutcomeCode) {
		this.creditLimitOutcomeCode = creditLimitOutcomeCode;
	}

	/**
	 * @return the derivedIncomeFlag
	 */
	public Integer getDerivedIncomeFlag() {
		return derivedIncomeFlag;
	}

	/**
	 * @param derivedIncomeFlag
	 *            the derivedIncomeFlag to set
	 */
	public void setDerivedIncomeFlag(Integer derivedIncomeFlag) {
		this.derivedIncomeFlag = derivedIncomeFlag;
	}

	/**
	 * @return the bnplScore
	 */
	public Integer getBnplScore() {
		return bnplScore;
	}

	/**
	 * @param bnplScore
	 *            the bnplScore to set
	 */
	public void setBnplScore(Integer bnplScore) {
		this.bnplScore = bnplScore;
	}

}
