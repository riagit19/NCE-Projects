package com.shopdirect.nce.sp.model;

public class AccountResponseType {

	private TriadDataType triadDataType;
	private String accountNumber;

	public TriadDataType getTriadDataType() {
		return triadDataType;
	}

	public void setTriadDataType(TriadDataType triadDataType) {
		this.triadDataType = triadDataType;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
}
