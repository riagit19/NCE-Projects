package com.shopdirect.nce.sp.model;

import java.math.BigDecimal;
import java.sql.Date;

public class BatchLinkedMonth extends BatchDetails{

	private BigDecimal batchLinkedMonthOccurence;
	private Date dateStatement;
	
	public BatchLinkedMonth() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BatchLinkedMonth(BigDecimal batchLinkedMonthOccurence, Date dateStatement) {
		super();
		this.batchLinkedMonthOccurence = batchLinkedMonthOccurence;
		this.dateStatement = dateStatement;
	}

	public BigDecimal getBatchLinkedMonthOccurence() {
		return batchLinkedMonthOccurence;
	}

	public void setBatchLinkedMonthOccurence(BigDecimal batchLinkedMonthOccurence) {
		this.batchLinkedMonthOccurence = batchLinkedMonthOccurence;
	}

	public Date getDateStatement() {
		return dateStatement;
	}

	public void setDateStatement(Date dateStatement) {
		this.dateStatement = dateStatement;
	}
}
