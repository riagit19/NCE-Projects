package com.shopdirect.nce.sp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.Query;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.util.DBConnectionUCP;
import com.shopdirect.nce.sp.util.UCPConnection;

/*
 * This class updates staus of CIM_ACCOUNT_INFO with updateStatus for a given statementDate and publicAccountNumber
 */
public class CustomerDetailsDao extends AccountReassessmentBaseDao {
	
	private SDLoggerImpl logger = new SDLoggerImpl();
	
	
	public CustomerDetailsDao() throws StatementProcessorBatchException{
		super();
		setSpMainSchema(getSchema(StatementProcessorBatchConstants.DB_SCHEMA_MAIN_SP_KEY));
	}
	/*
	 * @param updateSTaus,inputDate,publicAccountNumber
	 */
	public int updateAccountdetails(String updateStatus, String cimCustomerInfoId) throws StatementProcessorBatchException {
		logger.debug("[CustomerDetailsDao -- updateAccountdetails]  -- START");
		
		DBConnectionUCP dbConnectionUCP = null;
		Connection con = null;
		int status = -1;
		PreparedStatement  stmt = null;
	    try {
			con = UCPConnection.getConnection();
	    	con.setAutoCommit(false);

	    	String queryStr = Query.updateAccountStatusQuery(getSpMainSchema());
	    	logger.info("***********************"+queryStr);
	    	logger.info("**************cimCustomerInfoId="+cimCustomerInfoId);
	    	int i = 0;
	    	  if(cimCustomerInfoId != null && !cimCustomerInfoId.isEmpty()){
			     stmt = con.prepareStatement(queryStr);
			     stmt.setString(++i, updateStatus);
			     stmt.setInt(++i, Integer.valueOf(cimCustomerInfoId));
			    status = stmt.executeUpdate();
			    con.commit();
	    	  }

	    } catch(StatementProcessorBatchException batchEx){
	    	throw batchEx;
	    }catch (SQLException sqlException) {
	    	if(con != null){
	    		try {
					con.rollback();
				} catch (SQLException e) {
					getLogger().error("[CustomerDetailsDao -- updateAccountdetails] finally Block: failed to Rollback DB objects. " + e);
				}
	    	}
	    	
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_DB_ERROR_CODE,
					"[CustomerDetailsDao -- updateAccountdetails] SQLException Block",
					"Database execution exception [SQLCode: "+ sqlException.getSQLState() + "] , SQL Detail "+sqlException.getMessage(),
					null, null,sqlException);
		      
		       
		 }catch(Exception exception){
				throw new StatementProcessorBatchException(StatementProcessorBatchConstants.CONNECTTION_DB_ERROR_CODE,
						"[CustomerDetailsDao -- updateAccountdetails] Exception Block",
						"Database execution exception "+ exception.getMessage(),
						null, null,exception);
		 }finally {
			   
			   try {
				   if(stmt != null){
					   stmt.close();
				   }
				 
				   if (con != null) {
						con.close();
					}
				    
				} catch (Exception e) {
					getLogger().error("[CustomerDetailsDao -- updateAccountdetails] finally Block: failed to close DB objects. " + e);
				}
		   }
		    
		    logger.debug("[CustomerDetailsDao -- updateAccountdetails]  -- START");
			return status;
	}
	

	/**
	 * @return the logger
	 */
	@Override
	public SDLoggerImpl getLogger() {
		return logger;
	}


}
