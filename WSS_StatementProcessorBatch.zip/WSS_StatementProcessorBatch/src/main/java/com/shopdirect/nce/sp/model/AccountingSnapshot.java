package com.shopdirect.nce.sp.model;

import java.math.BigDecimal;
import java.sql.Date;

public class AccountingSnapshot extends BatchDetails{
	private BigDecimal occurence;
	private Date assessmentDate;
	private BigDecimal closingBalance;
	private BigDecimal openingBalance;
	private Date timestampCreated;
	private BigDecimal takeAll;
	private String debtType;
	private BigDecimal statementNumber;
	private String statPromtMessageCodeRec;
	private BigDecimal dailyInterestRate;
	private BigDecimal customerCreditTSP;
	private BigDecimal numReturnedPaymentTSP;
	private BigDecimal salesFor6Months;
	private BigDecimal salesFor12Months;
	private BigDecimal salesLifetime;
	private BigDecimal worstFollowUP;
	private BigDecimal balanceBeforePPI;
	private BigDecimal nextAssessmentAPR;
	private BigDecimal nextAccountAPR;
	private BigDecimal openingBNPLBalance;
	
	public AccountingSnapshot() {
		super();
	}

	public AccountingSnapshot(BigDecimal occurence, Date assessmentDate, BigDecimal closingBalance, 
			BigDecimal openingBalance, Date timestampCreated, String debtType,
			BigDecimal statementNumber, String statPromtMessageCodeRec, BigDecimal dailyInterestRate,
			BigDecimal customerCreditTSP, BigDecimal numReturnedPaymentTSP, BigDecimal salesFor6Months,
			BigDecimal salesFor12Months, BigDecimal salesLifetime, BigDecimal worstFollowUP,
			BigDecimal balanceBeforePPI, BigDecimal nextAssessmentAPR, BigDecimal nextAccountAPR,
			BigDecimal openingBNPLBalance, BigDecimal takeAll) {
		super();
		this.occurence = occurence;
		this.assessmentDate = assessmentDate;
		this.closingBalance = closingBalance;
		this.openingBalance = openingBalance;
		this.timestampCreated = timestampCreated;
		this.debtType = debtType;
		this.statementNumber = statementNumber;
		this.statPromtMessageCodeRec = statPromtMessageCodeRec;
		this.dailyInterestRate = dailyInterestRate;
		this.customerCreditTSP = customerCreditTSP;
		this.numReturnedPaymentTSP = numReturnedPaymentTSP;
		this.salesFor6Months = salesFor6Months;
		this.salesFor12Months = salesFor12Months;
		this.salesLifetime = salesLifetime;
		this.worstFollowUP = worstFollowUP;
		this.balanceBeforePPI = balanceBeforePPI;
		this.nextAssessmentAPR = nextAssessmentAPR;
		this.nextAccountAPR = nextAccountAPR;
		this.openingBNPLBalance = openingBNPLBalance;
		this.takeAll = takeAll;
	}

	public BigDecimal getOccurence() {
		return occurence;
	}

	public void setOccurence(BigDecimal occurence) {
		this.occurence = occurence;
	}

	public Date getAssessmentDate() {
		return assessmentDate;
	}

	public void setAssessmentDate(Date assessmentDate) {
		this.assessmentDate = assessmentDate;
	}

	public BigDecimal getClosingBalance() {
		return closingBalance;
	}

	public void setClosingBalance(BigDecimal closingBalance) {
		this.closingBalance = closingBalance;
	}

	public BigDecimal getOpeningBalance() {
		return openingBalance;
	}

	public void setOpeningBalance(BigDecimal openingBalance) {
		this.openingBalance = openingBalance;
	}

	public Date getTimestampCreated() {
		return timestampCreated;
	}

	public void setTimestampCreated(Date timestampCreated) {
		this.timestampCreated = timestampCreated;
	}

	public String getDebtType() {
		return debtType;
	}

	public void setDebtType(String debtType) {
		this.debtType = debtType;
	}

	public BigDecimal getStatementNumber() {
		return statementNumber;
	}

	public void setStatementNumber(BigDecimal statementNumber) {
		this.statementNumber = statementNumber;
	}

	public String getStatPromtMessageCodeRec() {
		return statPromtMessageCodeRec;
	}

	public void setStatPromtMessageCodeRec(String statPromtMessageCodeRec) {
		this.statPromtMessageCodeRec = statPromtMessageCodeRec;
	}

	public BigDecimal getDailyInterestRate() {
		return dailyInterestRate;
	}

	public void setDailyInterestRate(BigDecimal dailyInterestRate) {
		this.dailyInterestRate = dailyInterestRate;
	}

	public BigDecimal getCustomerCreditTSP() {
		return customerCreditTSP;
	}

	public void setCustomerCreditTSP(BigDecimal customerCreditTSP) {
		this.customerCreditTSP = customerCreditTSP;
	}

	public BigDecimal getNumReturnedPaymentTSP() {
		return numReturnedPaymentTSP;
	}

	public void setNumReturnedPaymentTSP(BigDecimal numReturnedPaymentTSP) {
		this.numReturnedPaymentTSP = numReturnedPaymentTSP;
	}

	public BigDecimal getSalesFor6Months() {
		return salesFor6Months;
	}

	public void setSalesFor6Months(BigDecimal salesFor6Months) {
		this.salesFor6Months = salesFor6Months;
	}

	public BigDecimal getSalesFor12Months() {
		return salesFor12Months;
	}

	public void setSalesFor12Months(BigDecimal salesFor12Months) {
		this.salesFor12Months = salesFor12Months;
	}

	public BigDecimal getSalesLifetime() {
		return salesLifetime;
	}

	public void setSalesLifetime(BigDecimal salesLifetime) {
		this.salesLifetime = salesLifetime;
	}

	public BigDecimal getWorstFollowUP() {
		return worstFollowUP;
	}

	public void setWorstFollowUP(BigDecimal worstFollowUP) {
		this.worstFollowUP = worstFollowUP;
	}

	public BigDecimal getBalanceBeforePPI() {
		return balanceBeforePPI;
	}

	public void setBalanceBeforePPI(BigDecimal balanceBeforePPI) {
		this.balanceBeforePPI = balanceBeforePPI;
	}

	public BigDecimal getNextAssessmentAPR() {
		return nextAssessmentAPR;
	}

	public void setNextAssessmentAPR(BigDecimal nextAssessmentAPR) {
		this.nextAssessmentAPR = nextAssessmentAPR;
	}

	public BigDecimal getNextAccountAPR() {
		return nextAccountAPR;
	}

	public void setNextAccountAPR(BigDecimal nextAccountAPR) {
		this.nextAccountAPR = nextAccountAPR;
	}

	public BigDecimal getOpeningBNPLBalance() {
		return openingBNPLBalance;
	}

	public void setOpeningBNPLBalance(BigDecimal openingBNPLBalance) {
		this.openingBNPLBalance = openingBNPLBalance;
	}

	public BigDecimal getTakeAll() {
		return takeAll;
	}

	public void setTakeAll(BigDecimal takeAll) {
		this.takeAll = takeAll;
	}
	
	
	
}
