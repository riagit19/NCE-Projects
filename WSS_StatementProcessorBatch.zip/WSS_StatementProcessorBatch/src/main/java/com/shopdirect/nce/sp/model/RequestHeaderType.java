/**
 * 
 */
package com.shopdirect.nce.sp.model;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author VijayaprakashPrathip
 *
 */

@XmlRootElement
public class RequestHeaderType {

	private String headerType;

	public RequestHeaderType(){}
	
	public RequestHeaderType(String headerType1){headerType = headerType1;}
	/**
	 * @return the headerType
	 */
	public String getHeaderType() {
		return headerType;
	}

	/**
	 * @param headerType the headerType to set
	 */
	public void setHeaderType(String headerType) {
		this.headerType = headerType;
	}
	

}
