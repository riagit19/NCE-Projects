package com.shopdirect.nce.sp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.Query;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;


/**
 * @author AyantikaBiswas
 *
 */
public class AccountDormancyCheckDao extends AccountReassessmentBaseDao  {
	


	private static final String SQL_DETAIL = "] , SQL Detail ";
	private static final String DATABASE_EXCEPTION_SQL_CODE = "Database execution exception [SQLCode: ";
	private static final String DATABASE_EXECUTION_EXCEPTION = "Database execution exception ";
	private static SDLoggerImpl logger = new SDLoggerImpl();
	private Connection con;
	
	


	public AccountDormancyCheckDao() throws StatementProcessorBatchException, SQLException {
		super();
		setSpMainSchema(getSchema(StatementProcessorBatchConstants.DB_SCHEMA_MAIN_SP_KEY));
		 

	}
	/**
	 * 
	 * @param custAccountId
	 * @return
	 * @throws Exception
	 */
	public double getAccountBalance(String creditAccountNo) throws StatementProcessorBatchException {
		getLogger().debug("[AccountDormancyCheckDao -- getAccountBalance]  -- START");
		double custAccntBalance = 0;

		ResultSet accountBalanceResultset = null;

	    try {
	    	
	    	getLogger().debug("Start of getAccountBalance :"+creditAccountNo);
	    	String queryStr = Query.custAccountBalanceQuery(getSpMainSchema());	    	
	    	con = getCon();
			try (PreparedStatement stmt = con.prepareStatement(queryStr)) {
				stmt.setString(1, creditAccountNo);

				accountBalanceResultset = stmt.executeQuery();
				custAccntBalance = getCustomerBalance(accountBalanceResultset);
			}
	    }catch (SQLException sqlException) {
	    	
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_DB_ERROR_CODE,
					"[AccountDormancyCheckDao-getAccountBalance] SQLException Block",
					DATABASE_EXCEPTION_SQL_CODE+ sqlException.getSQLState() + SQL_DETAIL+sqlException.getMessage(),
					null, null,sqlException);
		      
		       
		 
	    }catch(Exception exception){
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.CONNECTTION_DB_ERROR_CODE,
					"[AccountDormancyCheckDao-getAccountBalance] Exception Block",
					DATABASE_EXECUTION_EXCEPTION+ exception.getMessage(),
					null, null,exception);
	 }finally {
		   
		   try {
			   if(accountBalanceResultset != null){
				   accountBalanceResultset.close();
			   }
				if (con != null) {
					con.close();
				}
			} catch (Exception e) {
				getLogger().error("[AccountDormancyCheckDao - getAccountBalance] finally: failed to close DB objects: " + e);
			}
	    }
    	logger.debug("[AccountDormancyCheckDao -- getAccountBalance]  -- END");
	    return custAccntBalance;
		
	}
	private double getCustomerBalance(ResultSet accountBalanceResultset) throws SQLException {
		double custAccntBalance = 0;
		if (accountBalanceResultset != null) {
			while (accountBalanceResultset.next()) {
				custAccntBalance = accountBalanceResultset.getFloat("CLOSING_BALANCE");
			}
		}
		return custAccntBalance;
	}

	/**
	 * @param custAccountId
	 * @param statementDate
	 * @return
	 * @throws Exception
	 */	
	public Date getLastTransDt(String contractNumber, Date statementDate) throws StatementProcessorBatchException {
		logger.debug("[AccountDormancyCheckDao -- getLastTransDt]  -- START");
		Date lastTransDate = null;
		ResultSet lastTransactionDtResultset = null;
	    try {

	    	logger.info("statementDate==="+statementDate.toString());
	    	String queryStr = Query.lastTransDateQuery(getSpMainSchema());	    	
	    	con = getCon();
			try (PreparedStatement stmt = con.prepareStatement(queryStr)) {
				stmt.setString(1, contractNumber);
				stmt.setString(2, statementDate.toString());

				lastTransactionDtResultset = stmt.executeQuery();
				lastTransDate = getLastTransactionDate(lastTransactionDtResultset);
			}
		    
	    }catch (SQLException sqlException) {
	    	
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_DB_ERROR_CODE,
					"[AccountDormancyCheckDao-getLastTransDt] SQLException Block",
					DATABASE_EXCEPTION_SQL_CODE + sqlException.getSQLState() + SQL_DETAIL+sqlException.getMessage(),
					null, null,sqlException);
		      		       
		 }
	    catch(Exception exception){
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.CONNECTTION_DB_ERROR_CODE,
					"[AccountDormancyCheckDao-getLastTransDt] Exception Block",
					DATABASE_EXECUTION_EXCEPTION+ exception.getMessage(),
					null, null,exception);
	 }
		finally {
			try{
				if (lastTransDate == null) {
					logger.error("Last transaction date for contractNumber " + contractNumber + " is null");
				}
				if(lastTransactionDtResultset != null){
					lastTransactionDtResultset.close();
				}
				if (con != null) {
					con.close();
				}
			} catch (Exception e) {
				getLogger().error("[AccountDormancyCheckDao - getLastTransDt] finally: failed to close DB objects: " + e);
			}
		}
		
	    logger.info("lastTransDate="+statementDate.toString());
	    getLogger().debug("[AccountDormancyCheckDao -- getLastTransDt]  -- END");
	    return lastTransDate;
	}
	private Date getLastTransactionDate(ResultSet lastTransactionDtResultset) throws SQLException {
		Date lastTransDate = null;
		if (lastTransactionDtResultset != null) {
			while (lastTransactionDtResultset.next()) {
				lastTransDate = lastTransactionDtResultset.getDate("DATE_OF_TRXN");
			}
		}
		return lastTransDate;
	}

	/**
	 * @param custAccountId
	 * @return
	 * @throws Exception
	 */	
	public String getCreditStatus(String custAccountId) throws StatementProcessorBatchException {
		String creditStatus = null;
		PreparedStatement  stmt = null;
		ResultSet creditStatusRs = null;
	    try {

	    	logger.info("Start of getCreditStatus:::::::::::::::::::::::::::::::::");
	    	logger.info("custAccountId======="+custAccountId);
	    	String queryStr = Query.getCreditStatus().toString();	    	
	    	con = getCon();
	    	stmt = con.prepareStatement(queryStr);		    
		    stmt.setString(1, custAccountId);
		    		    
		    creditStatusRs = stmt.executeQuery();
		    if(creditStatusRs != null){
			    while(creditStatusRs.next()){
			    	creditStatus = creditStatusRs.getString("CREDIT_STATUS");
			    }
		    }
		    
	    }catch (SQLException sqlException) {
	    	
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_DB_ERROR_CODE,
					"[AccountDormancyCheckDao-getCreditStatus] SQLException Block",
					DATABASE_EXCEPTION_SQL_CODE+ sqlException.getSQLState() + SQL_DETAIL+sqlException.getMessage(),
					null, null,sqlException);
		      		       
		 }
	    catch(Exception exception){
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.CONNECTTION_DB_ERROR_CODE,
					"[AccountDormancyCheckDao-getCreditStatus] Exception Block",
					DATABASE_EXECUTION_EXCEPTION+ exception.getMessage(),
					null, null,exception);
	       
		 }
		finally {
			try{
				if(stmt != null){
					stmt.close();
				}
				if(creditStatusRs != null){
					creditStatusRs.close();
				}
				if (con != null) {
					con.close();
				}
			}catch(Exception e){
				getLogger().error("[AccountDormancyCheckDao - getCreditStatus] finally: failed to close DB objects: " + e);
			}
		}
		
	    logger.info("End of getCreditStatus:::::::::::::::::::::::::::::::::");
	    return creditStatus;

	}

	/**
	 * @param custAccountId
	 * @param creditAccountNo
	 * @param statusCode
	 * @return updateFlag
	 * @throws Exception
	 */		
	public Integer updateAccountStatus(String custAccountInfoId, String creditAccountNo, int statusCode) throws StatementProcessorBatchException {
		PreparedStatement  stmt = null;
		Integer updateFlag =0;
		
	    try {

	    	logger.info("Start of updateAccountStatus:::::::::::::::::::::::::::::::::"+custAccountInfoId);
	    	String queryStr = Query.updateAccountStatus().toString();	    	
	    	con = getCon();
	    	stmt = con.prepareStatement(queryStr);		    
		    stmt.setInt(1, statusCode);
		    stmt.setString(2, creditAccountNo);
		    stmt.setString(3, custAccountInfoId);
		    		    
		    updateFlag = stmt.executeUpdate();
		    
		    
		    
	    }catch (SQLException sqlException) {
	    	
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_DB_ERROR_CODE,
					"[AccountDormancyCheckDao-updateAccountStatus] SQLException Block",
					DATABASE_EXCEPTION_SQL_CODE+ sqlException.getSQLState() + SQL_DETAIL+sqlException.getMessage(),
					null, null,sqlException);
		      		       
		 }
	    catch(Exception exception){
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.CONNECTTION_DB_ERROR_CODE,
					"[AccountDormancyCheckDao-updateAccountStatus] Exception Block",
					DATABASE_EXECUTION_EXCEPTION+ exception.getMessage(),
					null, null,exception);
	       
		 }
		finally {
		 try{
			if(stmt != null){
			stmt.close();
			}
			if (con != null) {
				con.close();
			}
		 }catch(Exception e){
				getLogger().error("[AccountDormancyCheckDao - updateAccountStatus] finally: failed to close DB objects: " + e);
		}
		 
		}
	    logger.info("End of updateAccountStatus:::::::::::::::::::::::::::::::::");
	    return updateFlag;
		
	}
	/**
	 * @return the logger
	 */
	@Override
	public SDLoggerImpl getLogger() {
		return logger;
	}
	
	public Date getAccountOpenedDate(String custAccountInfoId) throws StatementProcessorBatchException {
		Date accntOpenedDate = null;
		PreparedStatement  stmt = null;
		ResultSet accntOpenedRs = null;
	    try {

	    	logger.info("Start of getAccountOpenedDate:::::::::::::::::::::::::::::::::");
	    	logger.info("custAccountInfoId======="+custAccountInfoId);
	    	String queryStr = Query.getAccountOpenedDate().toString();	    	
	    	con = getCon();
	    	stmt = con.prepareStatement(queryStr);		    
		    stmt.setString(1, custAccountInfoId);
		    		    
		    accntOpenedRs = stmt.executeQuery();
		    if(accntOpenedRs != null){
			    while(accntOpenedRs.next()){
			    	accntOpenedDate = accntOpenedRs.getDate("CREDIT_START_DATE");
			    }
		    }
		    
	    }catch (SQLException sqlException) {
	    	
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_DB_ERROR_CODE,
					"[AccountDormancyCheckDao-getAccountOpenedDate] SQLException Block",
					DATABASE_EXCEPTION_SQL_CODE+ sqlException.getSQLState() + SQL_DETAIL+sqlException.getMessage(),
					null, null,sqlException);
		      		       
		 }
	    catch(Exception exception){
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.CONNECTTION_DB_ERROR_CODE,
					"[AccountDormancyCheckDao-getAccountOpenedDate] Exception Block",
					DATABASE_EXECUTION_EXCEPTION+ exception.getMessage(),
					null, null,exception);
	       
		 }
		finally {
			try{
				if(stmt != null){
					stmt.close();
				}
				if(accntOpenedRs != null){
					accntOpenedRs.close();
				}
				if (con != null) {
					con.close();
				}
			}catch(Exception e){
				getLogger().error("[AccountDormancyCheckDao - getAccountOpenedDate] finally Block: failed to close DB objects . "+e.getMessage());
			}
		}
		
	    logger.info("End of getAccountOpenedDate:::::::::::::::::::::::::::::::::");
	    return accntOpenedDate;
	}



	public Date getLastOrderDate(String publicAccountNo, Date accountCreationDate) throws StatementProcessorBatchException {
		Date lastOrderDate = null;
		PreparedStatement  stmt = null;
		ResultSet astOrderRs = null;
	    try {
	
	    	logger.info("Start of getLastOrderDate:::::::::::::::::::::::::::::::::");
	    	logger.info("publicAccountNo======="+publicAccountNo);
	    	logger.info("accountCreationDate======="+accountCreationDate);
	    	String queryStr = Query.getLastOrderDate(getSpMainSchema());	    	
	    	con = getCon();
	    	stmt = con.prepareStatement(queryStr);		    
		    stmt.setString(1, publicAccountNo);
		    stmt.setString(2, accountCreationDate.toString());
		    		    
		    astOrderRs = stmt.executeQuery();
		    if(astOrderRs != null){
			    while(astOrderRs.next()){
			    	lastOrderDate = astOrderRs.getDate("DATE_OF_TRXN");
			    }
		    }
		    
	    }catch (SQLException sqlException) {
	    	
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_DB_ERROR_CODE,
					"[AccountDormancyCheckDao-getLastOrderDate] SQLException Block",
					DATABASE_EXCEPTION_SQL_CODE+ sqlException.getSQLState() + SQL_DETAIL+sqlException.getMessage(),
					null, null,sqlException);
		      		       
		 }
	    catch(Exception exception){
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.CONNECTTION_DB_ERROR_CODE,
					"[AccountDormancyCheckDao-getLastOrderDate] Exception Block",
					DATABASE_EXECUTION_EXCEPTION+ exception.getMessage(),
					null, null,exception);
	       
		 }
		finally {
			try{
				if(stmt != null){
					stmt.close();
				}
				if(astOrderRs != null){
					astOrderRs.close();
				}
				if (con != null) {
					con.close();
				}
			}catch(Exception e){
				getLogger().error("[AccountDormancyCheckDao - getLastOrderDate] finally Block: failed to close DB objects . "+e.getMessage());
			}
		}
		
	    logger.info("End of getLastOrderDate:::::::::::::::::::::::::::::::::");
	    return lastOrderDate;
	}	

}
