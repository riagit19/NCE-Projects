/**
 * 
 */
package com.shopdirect.nce.sp.externalclient;

import java.net.URL;
import java.util.Map;

import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;

import com.shopdirect.nce.common.extcnfg.ExternalFileDataConfiguration;
import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.util.CommonConfigHelper;
import com.shopdirect.osb.reassesstriadar.ReassessTRIADAR;
import com.shopdirect.osb.reassesstriadar.ReassessTRIADARPT;
import com.shopdirect.osb.xsd.header.RequestHeaderType;
import com.shopdirect.osb.reassesstriadar.ReassessTRIADARRequestType;
import com.shopdirect.osb.reassesstriadar.ReassessTRIADARResponseType;
/**
 * This class initiates AssessTRIAD process
 *
 */
public class AssessTriadExternalClient extends AccountReassessmentBaseExternalClient {
	/**
	 * @return AssessTRIADPT
	 * @throws StatementProcessorBatchException
	 */
	private static SDLoggerImpl logger = new SDLoggerImpl();
	private ExternalFileDataConfiguration extFileDataCfg = null;
	private String namespacheUri=null;
	private String serviceName=null;
	private String resourcePath=null;
	private BindingProvider bindingProvider;
	private ReassessTRIADARPT triadPortType;
	private ReassessTRIADAR assessTriad;
	
	/**
	 * Default constructor Set the CommonConfigHelper class Set the
	 * ExternalFileDataConfiguration object
	 * 
	 * @throws StatementProcessorBatchException
	 */
	public AssessTriadExternalClient() throws StatementProcessorBatchException {
		setCommonConfigHelper(CommonConfigHelper.getInstance());
		initExternalConfig();

	}
	
	
	/*
	 * this is primary method for calling triad process
	 * @param RequestHeaderType,AssessTRIADRequestType
	 */
	public ReassessTRIADARResponseType retrieveTRIADContent(RequestHeaderType headerType, ReassessTRIADARRequestType request) throws StatementProcessorBatchException {
		getLogger().debug("[AssessTriadExternalClient -- retrieveTRIADContent] -- Entry");
		ReassessTRIADARResponseType response = null;
		try {
			triadPortType = getTRIADPort();
			
			String endpoint =
					getCommonConfigHelper().readConfigData(getExtFileDataCfg(), StatementProcessorBatchConstants.TRIAD_ENDPOINT_URL);
			
					if (this.getBindingProvider() == null) {
						this.setBindingProvider((BindingProvider) this.getTriadPortType());
					}
			
					Map<String, Object> requestContextMap = bindingProvider.getRequestContext();
					requestContextMap.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, endpoint);
					populateLocalHeader();
					addEndpointAddressAndHandlers(getBindingProvider(), endpoint,"process");
					
			response = triadPortType.process(headerType,request);
		} catch(Exception exception){
			getLogger().error("[AssessTriadExternalClient -- retrieveTRIADContent] -- Exception: " + exception);
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.TRAID_BUSINESS_ERROR_CODE,
					"[AssessTriadExternalClient -- retrieveTRIADContent] Exception",
					"Webservice exception generated at time to retrieveTRIADContent "+ exception.getMessage(),
					null, null,exception);
			
		}
		getLogger().debug("[AssessTriadExternalClient -- retrieveTRIADContent] -- Exit");
		return response;
				
	}
	
	/*
	 * this method sets queue name and end point url to portType object
	 */
	private ReassessTRIADARPT getTRIADPort() {
		getLogger().debug("[AssessTriadExternalClient -- getTRIADPortType] -- Entry");
		try {
			QName qName = new QName(getNamespacheUri(), getServiceName());
			URL url = ReassessTRIADARPT.class.getResource(getResourcePath());

			if(triadPortType == null){
				assessTriad = new ReassessTRIADAR(url,qName);

			}
			
			setTriadPortType(assessTriad.getReassessTRIADARPortHttp());
	
		} catch (Exception e) {
			getLogger().error("[AssessTriadExternalClient -- getTRIADPortType] -- Exception: " + e);
		}
		getLogger().debug("[AssessTriadExternalClient -- getTRIADPortType] -- Exit");
		return triadPortType;
	}

	public ReassessTRIADARPT getTriadPortType(){
		return this.triadPortType;
	}
	public void setTriadPortType(ReassessTRIADARPT triadPortType){
		
		this.triadPortType = triadPortType;
	}
	public String getResourcePath() {
		return resourcePath;
	}


	public void setResourcePath(String resourcePath) {
		
		this.resourcePath = resourcePath;
	}


	public ExternalFileDataConfiguration getExtFileDataCfg() {
		return extFileDataCfg;
	}


	public void setExtFileDataCfg(ExternalFileDataConfiguration extFileDataCfg) {
		this.extFileDataCfg = extFileDataCfg;
	}


	public String getServiceName() {
		
		return serviceName;
	}


	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}


	public BindingProvider getBindingProvider() {
		return bindingProvider;
	}

	public void setBindingProvider(BindingProvider bindingProvider) {
		this.bindingProvider = bindingProvider;
	}

	

	public String getNamespacheUri() {
		
		return namespacheUri;
	}

	public void setNamespacheUri(String namespacheUri) {
		this.namespacheUri = namespacheUri;
	}

	/**
	 * @return the logger
	 */
	public static SDLoggerImpl getLogger() {
		return logger;
	}

	/**
	 * Configuration Object creation
	 * 
	 * @throws StatementProcessorBatchException
	 */
	private void initExternalConfig() throws StatementProcessorBatchException {
		logger.debug("[AssessTriadExternalClient -- initExternalConfig]  -- START");

		this.extFileDataCfg = getCommonConfigHelper()
				.loadPropertyConfig("externalClientConfig");
		
		this.setNamespacheUri(getCommonConfigHelper().readConfigData(getExtFileDataCfg(),  StatementProcessorBatchConstants.SERVICE_NAMESPACE_URI));
		this.setServiceName(getCommonConfigHelper().readConfigData(getExtFileDataCfg(), StatementProcessorBatchConstants.EXTERNAL_SERVICE_NAME));
		this.setResourcePath(getCommonConfigHelper().readConfigData(getExtFileDataCfg(), StatementProcessorBatchConstants.SERVICE_WSDL_PATH));
		logger.debug("[AssessTriadExternalClient -- initExternalConfig]  -- END");
	}

	
}

