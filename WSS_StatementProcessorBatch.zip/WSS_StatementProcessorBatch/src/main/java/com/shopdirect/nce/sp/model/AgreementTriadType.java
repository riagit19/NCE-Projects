package com.shopdirect.nce.sp.model;

import java.util.Date;

public class AgreementTriadType {

	private String agreementID;

	private Long fnStatNo;

	private Date statementDate;

	private Long sourceRowNumber;

	private Double creditLimit;

	private Double lastPayMethod;

	private Double currentBalance;

	private Date dateLastMiv;

	private Date dateLastOrder;

	private Date dateLastPay;

	private Date paymentDueDate;

	private Date lastStatementDate;

	private Date nextStatementDate;

	private Date dateSection87;

	private Date dateNsf;

	private Double scheduledPaymentAmount;

	private Double scheduledPaymentPastDue;

	private Double pastDueAmount;

	private Double availableToSpend;

	private Double bnplBalance;

	private Double apr;

	private Double totPay30Days;

	private Double instArrears;

	private Date dateLastArrangement;

	private Double payAmtTsp;

	private Date dateLastZeroBal;

	private Double returnsAmtTsp;

	private Double otherAdjAmtTsp;

	private Double lastPaymentAmount;

	private Long paymentPreviousInd;

	private Long paymentCurrentInd;

	private Double numPurchasesTsp;

	private Double totFeesTsp;

	private Double custCreditsTsp;

	private Double totPayYear;

	private Double numPayTsp;

	private Double intChargedTsp;

	private Double purchaseAmtTsp;

	private Double rebatesAmtTsp;

	private Double bnplIntAmtTsp;

	private Double numRatePayTsp;

	private Double lastArrearsWks;

	private Double lastPaymentDays;

	private Double nilBalanceDays;

	private Long batchId;

	private String errorFlag;

	private String errorMessage;

	private Date creationDate;

	private Long createdByUser;

	private Date lastUpdateDate;

	private Long lastUpdateByUser;
	
	private Long valueFailedPayments;
	
	private Long balanceBeforePpi;
	
	private Long otherCredits;
	
	private Long otherDebits;
	
	private Long payLastColl;
	
	private Long lateInsufFeesTsp;
	
	private Long collAdminFeesTsp;
	
	private Long orderFeesAmtTsp;
	
	private Long creditLimitUtil;
	

	public String getAgreementID() {
		return agreementID;
	}

	public void setAgreementID(String agreementID) {
		this.agreementID = agreementID;
	}

	public Long getFnStatNo() {
		return fnStatNo;
	}

	public void setFnStatNo(Long fnStatNo) {
		this.fnStatNo = fnStatNo;
	}

	public Date getStatementDate() {
		return statementDate;
	}

	public void setStatementDate(Date statementDate) {
		this.statementDate = statementDate;
	}

	public Long getSourceRowNumber() {
		return sourceRowNumber;
	}

	public void setSourceRowNumber(Long sourceRowNumber) {
		this.sourceRowNumber = sourceRowNumber;
	}

	public Double getCreditLimit() {
		return creditLimit;
	}

	public void setCreditLimit(Double creditLimit) {
		this.creditLimit = creditLimit;
	}

	public Double getLastPayMethod() {
		return lastPayMethod;
	}

	public void setLastPayMethod(Double lastPayMethod) {
		this.lastPayMethod = lastPayMethod;
	}

	public Double getCurrentBalance() {
		return currentBalance;
	}

	public void setCurrentBalance(Double currentBalance) {
		this.currentBalance = currentBalance;
	}

	public Date getDateLastMiv() {
		return dateLastMiv;
	}

	public void setDateLastMiv(Date dateLastMiv) {
		this.dateLastMiv = dateLastMiv;
	}

	public Date getDateLastOrder() {
		return dateLastOrder;
	}

	public void setDateLastOrder(Date dateLastOrder) {
		this.dateLastOrder = dateLastOrder;
	}

	public Date getDateLastPay() {
		return dateLastPay;
	}

	public void setDateLastPay(Date dateLastPay) {
		this.dateLastPay = dateLastPay;
	}


	public Date getLastStatementDate() {
		return lastStatementDate;
	}

	public void setLastStatementDate(Date lastStatementDate) {
		this.lastStatementDate = lastStatementDate;
	}

	public Date getNextStatementDate() {
		return nextStatementDate;
	}

	public void setNextStatementDate(Date nextStatementDate) {
		this.nextStatementDate = nextStatementDate;
	}

	public Date getDateSection87() {
		return dateSection87;
	}

	public void setDateSection87(Date dateSection87) {
		this.dateSection87 = dateSection87;
	}

	public Date getDateNsf() {
		return dateNsf;
	}

	public void setDateNsf(Date dateNsf) {
		this.dateNsf = dateNsf;
	}

	public Double getScheduledPaymentAmount() {
		return scheduledPaymentAmount;
	}

	public void setScheduledPaymentAmount(Double scheduledPaymentAmount) {
		this.scheduledPaymentAmount = scheduledPaymentAmount;
	}

	public Double getScheduledPaymentPastDue() {
		return scheduledPaymentPastDue;
	}

	public void setScheduledPaymentPastDue(Double scheduledPaymentPastDue) {
		this.scheduledPaymentPastDue = scheduledPaymentPastDue;
	}

	public Double getPastDueAmount() {
		return pastDueAmount;
	}

	public void setPastDueAmount(Double pastDueAmount) {
		this.pastDueAmount = pastDueAmount;
	}

	public Double getAvailableToSpend() {
		return availableToSpend;
	}

	public void setAvailableToSpend(Double availableToSpend) {
		this.availableToSpend = availableToSpend;
	}

	public Double getBnplBalance() {
		return bnplBalance;
	}

	public void setBnplBalance(Double bnplBalance) {
		this.bnplBalance = bnplBalance;
	}

	public Double getApr() {
		return apr;
	}

	public void setApr(Double apr) {
		this.apr = apr;
	}

	public Double getTotPay30Days() {
		return totPay30Days;
	}

	public void setTotPay30Days(Double totPay30Days) {
		this.totPay30Days = totPay30Days;
	}

	public Double getInstArrears() {
		return instArrears;
	}

	public void setInstArrears(Double instArrears) {
		this.instArrears = instArrears;
	}

	public Date getDateLastArrangement() {
		return dateLastArrangement;
	}

	public void setDateLastArrangement(Date dateLastArrangement) {
		this.dateLastArrangement = dateLastArrangement;
	}

	public Double getPayAmtTsp() {
		return payAmtTsp;
	}

	public void setPayAmtTsp(Double payAmtTsp) {
		this.payAmtTsp = payAmtTsp;
	}

	public Date getDateLastZeroBal() {
		return dateLastZeroBal;
	}

	public void setDateLastZeroBal(Date dateLastZeroBal) {
		this.dateLastZeroBal = dateLastZeroBal;
	}

	public Double getReturnsAmtTsp() {
		return returnsAmtTsp;
	}

	public void setReturnsAmtTsp(Double returnsAmtTsp) {
		this.returnsAmtTsp = returnsAmtTsp;
	}

	public Double getOtherAdjAmtTsp() {
		return otherAdjAmtTsp;
	}

	public void setOtherAdjAmtTsp(Double otherAdjAmtTsp) {
		this.otherAdjAmtTsp = otherAdjAmtTsp;
	}

	public Double getLastPaymentAmount() {
		return lastPaymentAmount;
	}

	public void setLastPaymentAmount(Double lastPaymentAmount) {
		this.lastPaymentAmount = lastPaymentAmount;
	}

	public Long getPaymentPreviousInd() {
		return paymentPreviousInd;
	}

	public void setPaymentPreviousInd(Long paymentPreviousInd) {
		this.paymentPreviousInd = paymentPreviousInd;
	}

	public Long getPaymentCurrentInd() {
		return paymentCurrentInd;
	}

	public void setPaymentCurrentInd(Long paymentCurrentInd) {
		this.paymentCurrentInd = paymentCurrentInd;
	}

	public Double getNumPurchasesTsp() {
		return numPurchasesTsp;
	}

	public void setNumPurchasesTsp(Double numPurchasesTsp) {
		this.numPurchasesTsp = numPurchasesTsp;
	}

	public Double getTotFeesTsp() {
		return totFeesTsp;
	}

	public void setTotFeesTsp(Double totFeesTsp) {
		this.totFeesTsp = totFeesTsp;
	}

	public Double getCustCreditsTsp() {
		return custCreditsTsp;
	}

	public void setCustCreditsTsp(Double custCreditsTsp) {
		this.custCreditsTsp = custCreditsTsp;
	}

	public Double getTotPayYear() {
		return totPayYear;
	}

	public void setTotPayYear(Double totPayYear) {
		this.totPayYear = totPayYear;
	}

	public Double getNumPayTsp() {
		return numPayTsp;
	}

	public void setNumPayTsp(Double numPayTsp) {
		this.numPayTsp = numPayTsp;
	}

	public Double getIntChargedTsp() {
		return intChargedTsp;
	}

	public void setIntChargedTsp(Double intChargedTsp) {
		this.intChargedTsp = intChargedTsp;
	}

	public Double getPurchaseAmtTsp() {
		return purchaseAmtTsp;
	}

	public void setPurchaseAmtTsp(Double purchaseAmtTsp) {
		this.purchaseAmtTsp = purchaseAmtTsp;
	}

	public Double getRebatesAmtTsp() {
		return rebatesAmtTsp;
	}

	public void setRebatesAmtTsp(Double rebatesAmtTsp) {
		this.rebatesAmtTsp = rebatesAmtTsp;
	}

	public Double getBnplIntAmtTsp() {
		return bnplIntAmtTsp;
	}

	public void setBnplIntAmtTsp(Double bnplIntAmtTsp) {
		this.bnplIntAmtTsp = bnplIntAmtTsp;
	}

	public Double getNumRatePayTsp() {
		return numRatePayTsp;
	}

	public void setNumRatePayTsp(Double numRatePayTsp) {
		this.numRatePayTsp = numRatePayTsp;
	}

	public Double getLastArrearsWks() {
		return lastArrearsWks;
	}

	public void setLastArrearsWks(Double lastArrearsWks) {
		this.lastArrearsWks = lastArrearsWks;
	}

	public Double getLastPaymentDays() {
		return lastPaymentDays;
	}

	public void setLastPaymentDays(Double lastPaymentDays) {
		this.lastPaymentDays = lastPaymentDays;
	}

	public Double getNilBalanceDays() {
		return nilBalanceDays;
	}

	public void setNilBalanceDays(Double nilBalanceDays) {
		this.nilBalanceDays = nilBalanceDays;
	}

	public Long getBatchId() {
		return batchId;
	}

	public void setBatchId(Long batchId) {
		this.batchId = batchId;
	}

	public String getErrorFlag() {
		return errorFlag;
	}

	public void setErrorFlag(String errorFlag) {
		this.errorFlag = errorFlag;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public Long getCreatedByUser() {
		return createdByUser;
	}

	public void setCreatedByUser(Long createdByUser) {
		this.createdByUser = createdByUser;
	}

	public Date getLastUpdateDate() {
		return lastUpdateDate;
	}

	public void setLastUpdateDate(Date lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}

	public Long getLastUpdateByUser() {
		return lastUpdateByUser;
	}

	public void setLastUpdateByUser(Long lastUpdateByUser) {
		this.lastUpdateByUser = lastUpdateByUser;
	}

	/**
	 * @return the paymentDueDate
	 */
	public Date getPaymentDueDate() {
		return paymentDueDate;
	}

	/**
	 * @param paymentDueDate the paymentDueDate to set
	 */
	public void setPaymentDueDate(Date paymentDueDate) {
		this.paymentDueDate = paymentDueDate;
	}

	public Long getValueFailedPayments() {
		return valueFailedPayments;
	}

	public void setValueFailedPayments(Long valueFailedPayments) {
		this.valueFailedPayments = valueFailedPayments;
	}

	public Long getBalanceBeforePpi() {
		return balanceBeforePpi;
	}

	public void setBalanceBeforePpi(Long balanceBeforePpi) {
		this.balanceBeforePpi = balanceBeforePpi;
	}


	public Long getOtherCredits() {
		return otherCredits;
	}

	public void setOtherCredits(Long otherCredits) {
		this.otherCredits = otherCredits;
	}

	public Long getOtherDebits() {
		return otherDebits;
	}

	public void setOtherDebits(Long otherDebits) {
		this.otherDebits = otherDebits;
	}

	public Long getPayLastColl() {
		return payLastColl;
	}

	public void setPayLastColl(Long payLastColl) {
		this.payLastColl = payLastColl;
	}

	public Long getLateInsufFeesTsp() {
		return lateInsufFeesTsp;
	}

	public void setLateInsufFeesTsp(Long lateInsufFeesTsp) {
		this.lateInsufFeesTsp = lateInsufFeesTsp;
	}

	public Long getCollAdminFeesTsp() {
		return collAdminFeesTsp;
	}

	public void setCollAdminFeesTsp(Long collAdminFeesTsp) {
		this.collAdminFeesTsp = collAdminFeesTsp;
	}

	public Long getOrderFeesAmtTsp() {
		return orderFeesAmtTsp;
	}

	public void setOrderFeesAmtTsp(Long orderFeesAmtTsp) {
		this.orderFeesAmtTsp = orderFeesAmtTsp;
	}

	public Long getCreditLimitUtil() {
		return creditLimitUtil;
	}

	public void setCreditLimitUtil(Long creditLimitUtil) {
		this.creditLimitUtil = creditLimitUtil;
	}


}
