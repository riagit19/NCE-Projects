package com.shopdirect.nce.sp.transform;

import java.math.BigDecimal;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.model.CurrentAccoutingSnapshotTriad;

public class CurAccSnapshotTriadDBTransformer {

	private static SDLoggerImpl logger = new SDLoggerImpl();
	
	public void setCurrentAccoutingSnapshotTriadObject(CurrentAccoutingSnapshotTriad currentAccoutingSnapshotTriad,
			Object[] attributes) {

		logger.debug("[CurAccSnapshotTriadDBTransformer - setCurrentAccoutingSnapshotTriadObject] - Start");
		int index = 0;
		currentAccoutingSnapshotTriad.setCustomerAccountNumber(attributes[index] != null ? attributes[index].toString() : null);
		++index;
		currentAccoutingSnapshotTriad.setInterestChargedAmtTSP(attributes[index] != null ? new BigDecimal(attributes[index].toString()) : null);
		++index;
		currentAccoutingSnapshotTriad.setStatPromtMessageCodeRec(attributes[index] != null ? attributes[index].toString() : null);
		++index;
		currentAccoutingSnapshotTriad.setaPR(attributes[index] != null ? new BigDecimal(attributes[index].toString()) : null);
		++index;
		currentAccoutingSnapshotTriad.setTotalFeesTSP(attributes[index] != null ? new BigDecimal(attributes[index].toString()) : null);
		++index;
		currentAccoutingSnapshotTriad.setBnplBalance(attributes[index] != null ? new BigDecimal(attributes[index].toString()) : null);
		++index;
		currentAccoutingSnapshotTriad.setNumPaymentsTSP(attributes[index] != null ? new BigDecimal(attributes[index].toString()) : null);
		++index;
		currentAccoutingSnapshotTriad.setNumPurchasesTSP(attributes[index] != null ? new BigDecimal(attributes[index].toString()) : null);
		++index;
		currentAccoutingSnapshotTriad.setNetSalesValueTSPAmt(attributes[index] != null ? new BigDecimal(attributes[index].toString()) : null);
		++index;
		currentAccoutingSnapshotTriad.setSalesFor6Months(attributes[index] != null ? new BigDecimal(attributes[index].toString()) : null);
		++index;
		currentAccoutingSnapshotTriad.setSalesFor12Months(attributes[index] != null ? new BigDecimal(attributes[index].toString()) : null);
		++index;
		currentAccoutingSnapshotTriad.setSalesLifetime(attributes[index] != null ? new BigDecimal(attributes[index].toString()) : null);
		
		logger.debug("[CurAccSnapshotTriadDBTransformer - setCurrentAccoutingSnapshotTriadObject] - End");
	}
}
