package com.shopdirect.nce.sp.model;

import java.util.Date;


public class Nosia {
	
	private Double previousNosiaBalance;
	
	private Double previousNosiaArrears;
	
	private Date nosiaDate;
	
	private Double closingBalance;
	
	private Double arrearsAmount;
	
	private Double mostRecentPaymentAmount;
	
	private String agreementId;
    
    private Long agreementSeq;
    
    private Double previousPaymentAmount;
    
    private Long batchId;
	
	private String errorFlag;
	
	private String errorMessage;
	
	private Date creationDate;
	
	private Long createdByUser;
	
	private Date lastUpdateDate;
	
	private Long lastUpdateByUser;
	
	private Date prevPayDueDate;
	
	private Date prev2PayDueDate;
	
	private Double prevArrearsAmount;
	
	private Double prev2ArrearsAmount;
	
	private Double prevMinPayAmount;
	
	private Double prev2MinPayAmount;
	
	private Double totPrevPayAmount;
	
	private Double totPrev2PayAmount;
	
	public Date getPrevPayDueDate() {
		return prevPayDueDate;
	}

	public void setPrevPayDueDate(Date prevPayDueDate) {
		this.prevPayDueDate = prevPayDueDate;
	}

	public Date getPrev2PayDueDate() {
		return prev2PayDueDate;
	}

	public void setPrev2PayDueDate(Date prev2PayDueDate) {
		this.prev2PayDueDate = prev2PayDueDate;
	}

	public Double getPrevArrearsAmount() {
		return prevArrearsAmount;
	}

	public void setPrevArrearsAmount(Double prevArrearsAmount) {
		this.prevArrearsAmount = prevArrearsAmount;
	}

	public Double getPrev2ArrearsAmount() {
		return prev2ArrearsAmount;
	}

	public void setPrev2ArrearsAmount(Double prev2ArrearsAmount) {
		this.prev2ArrearsAmount = prev2ArrearsAmount;
	}

	public Double getPrevMinPayAmount() {
		return prevMinPayAmount;
	}

	public void setPrevMinPayAmount(Double prevMinPayAmount) {
		this.prevMinPayAmount = prevMinPayAmount;
	}

	public Double getPrev2MinPayAmount() {
		return prev2MinPayAmount;
	}

	public void setPrev2MinPayAmount(Double prev2MinPayAmount) {
		this.prev2MinPayAmount = prev2MinPayAmount;
	}

	public Double getTotPrevPayAmount() {
		return totPrevPayAmount;
	}

	public void setTotPrevPayAmount(Double totPrevPayAmount) {
		this.totPrevPayAmount = totPrevPayAmount;
	}

	public Double getTotPrev2PayAmount() {
		return totPrev2PayAmount;
	}

	public void setTotPrev2PayAmount(Double totPrev2PayAmount) {
		this.totPrev2PayAmount = totPrev2PayAmount;
	}

	public Double getPreviousNosiaBalance() {
		return previousNosiaBalance;
	}

	public void setPreviousNosiaBalance(Double previousNosiaBalance) {
		this.previousNosiaBalance = previousNosiaBalance;
	}

	public Double getPreviousNosiaArrears() {
		return previousNosiaArrears;
	}

	public void setPreviousNosiaArrears(Double previousNosiaArrears) {
		this.previousNosiaArrears = previousNosiaArrears;
	}

	public Date getNosiaDate() {
		return nosiaDate;
	}

	public void setNosiaDate(Date nosiaDate) {
		this.nosiaDate = nosiaDate;
	}

	public Double getClosingBalance() {
		return closingBalance;
	}

	public void setClosingBalance(Double closingBalance) {
		this.closingBalance = closingBalance;
	}

	public Double getArrearsAmount() {
		return arrearsAmount;
	}

	public void setArrearsAmount(Double arrearsAmount) {
		this.arrearsAmount = arrearsAmount;
	}

	public Double getMostRecentPaymentAmount() {
		return mostRecentPaymentAmount;
	}

	public void setMostRecentPaymentAmount(Double mostRecentPaymentAmount) {
		this.mostRecentPaymentAmount = mostRecentPaymentAmount;
	}

	public String getAgreementId() {
		return agreementId;
	}

	public void setAgreementId(String agreementId) {
		this.agreementId = agreementId;
	}

	public Long getAgreementSeq() {
		return agreementSeq;
	}

	public void setAgreementSeq(Long agreementSeq) {
		this.agreementSeq = agreementSeq;
	}

	public Double getPreviousPaymentAmount() {
		return previousPaymentAmount;
	}

	public void setPreviousPaymentAmount(Double previousPaymentAmount) {
		this.previousPaymentAmount = previousPaymentAmount;
	}

	public Long getBatchId() {
		return batchId;
	}

	public void setBatchId(Long batchId) {
		this.batchId = batchId;
	}

	public String getErrorFlag() {
		return errorFlag;
	}

	public void setErrorFlag(String errorFlag) {
		this.errorFlag = errorFlag;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public Long getCreatedByUser() {
		return createdByUser;
	}

	public void setCreatedByUser(Long createdByUser) {
		this.createdByUser = createdByUser;
	}

	public Date getLastUpdateDate() {
		return lastUpdateDate;
	}

	public void setLastUpdateDate(Date lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}

	public Long getLastUpdateByUser() {
		return lastUpdateByUser;
	}

	public void setLastUpdateByUser(Long lastUpdateByUser) {
		this.lastUpdateByUser = lastUpdateByUser;
	}


}
