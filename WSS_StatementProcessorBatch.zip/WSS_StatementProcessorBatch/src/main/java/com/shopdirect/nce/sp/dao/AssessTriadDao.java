package com.shopdirect.nce.sp.dao;

import java.sql.Array;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Struct;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Set;

import com.shopdirect.nce.common.extcnfg.ExternalFileDataConfiguration;
import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.Query;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.AccountingSnapshotTriad;
import com.shopdirect.nce.sp.model.AgreementTriad;
import com.shopdirect.nce.sp.model.CurrentAccoutingSnapshotTriad;
import com.shopdirect.nce.sp.model.CustomerContractTriad;
import com.shopdirect.nce.sp.model.PeriodPaymentTriad;
import com.shopdirect.nce.sp.model.RetailContractTriad;
import com.shopdirect.nce.sp.transform.AccountingSnapshotTriadDBTransformer;
import com.shopdirect.nce.sp.transform.AgreementTriadDBTransformer;
import com.shopdirect.nce.sp.transform.CurAccSnapshotTriadDBTransformer;
import com.shopdirect.nce.sp.transform.CustomerContractTriadDBTransformer;
import com.shopdirect.nce.sp.transform.PeriodPaymentTriadDBTransformer;
import com.shopdirect.nce.sp.transform.RetailContractTriadDBTransformer;
import com.shopdirect.nce.sp.util.CommonConfigHelper;
import com.shopdirect.nce.sp.util.UCPConnection;

import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;

/**
 * 
 * @author manojkumar
 *
 */
public class AssessTriadDao extends AccountReassessmentBaseDao {

	private static final SDLoggerImpl LOGGER = new SDLoggerImpl();

	public AssessTriadDao() throws StatementProcessorBatchException {
		super();
		setStgSchema(getSchema(StatementProcessorBatchConstants.DB_SCHEMA_STG_KEY));
		setSpMainSchema(getSchema(StatementProcessorBatchConstants.DB_SCHEMA_MAIN_SP_KEY));
	}

	
	public Object[] getAllTriadData(String publicAccNum, Date statementDate, Set<String> linkedAccountNumSet)
			throws StatementProcessorBatchException {
		LOGGER.debug("[AssessTriadDao -- getAllTriadData] -- Start");
		
		String status = null;
		
		List<CustomerContractTriad> customerContractTriadList = new ArrayList<CustomerContractTriad>();
		List<RetailContractTriad> retailContractTriadList = new ArrayList<RetailContractTriad>();
		List<AccountingSnapshotTriad> accountingSnapshotTriadList = new ArrayList<AccountingSnapshotTriad>();
		List<AgreementTriad> agreementTriadList = new ArrayList<AgreementTriad>();
		List<CurrentAccoutingSnapshotTriad> currentAccSnapshotTriadList = new ArrayList<CurrentAccoutingSnapshotTriad>();
		List<PeriodPaymentTriad> periodPaymentTriadList = new ArrayList<PeriodPaymentTriad>();
		
		Object[] allTriadObject = new Object[6];
		
		java.sql.Date sqlDate = null;
		if (statementDate != null) {
			sqlDate = new java.sql.Date(statementDate.getTime());
		}
		
		final String pack = getConfigValue(StatementProcessorBatchConstants.PACK_ACC_RSMT_DATA_RET);
		final String procedure = getConfigValue(StatementProcessorBatchConstants.GET_ALL_ACCT_REASMNT);
		final String typeTableNameCustomerContract = StatementProcessorBatchConstants.TY_TAB_CUST_CON_TRIAD;
		final String typeTableNameRetailContract = StatementProcessorBatchConstants.TY_TAB_RETAIL_CONTRACT_TRIAD;
		final String typeTableNameAccountSnapshot = StatementProcessorBatchConstants.TY_TAB_ACCT_SNAPSHOT_TRIAD;
		final String typeTableNameAgreement = StatementProcessorBatchConstants.TY_TAB_AGREEMENT_TRIAD;
		final String typeTableNameCurrentAccountSnapshot = StatementProcessorBatchConstants.TY_TAB_CURACCT_SNAPSHOT_TRIAD;
		final String typeTableNamePeriodPayment = StatementProcessorBatchConstants.TY_TAB_PERIOD_PAYMENT_TRIAD;
		final String typeNameLinkedAccount = StatementProcessorBatchConstants.TY_OBJ_LINKED_ACCOUNT;
		
		Connection connection = null;
		CallableStatement stmt = null;
		final String spDetail = Query.getTriadDataQuery(pack, procedure);
		
		try {
			connection = UCPConnection.getConnection();
			
			Struct linkedAcctStructArray[] = new Struct[linkedAccountNumSet.size()];
			
			int ctr = 0;
			for (String linkedAccountNum : linkedAccountNumSet) {

				Object[] linkedAccountObj = new Object[] {linkedAccountNum};
						
				Struct linkedAccountStructObj = connection.createStruct(typeNameLinkedAccount.toUpperCase(), linkedAccountObj);
				linkedAcctStructArray[ctr++] = linkedAccountStructObj;
			}
			ArrayDescriptor desc = ArrayDescriptor.createDescriptor(StatementProcessorBatchConstants.TY_TAB_LINKED_ACCOUNT, connection);
			ARRAY linkedAcctArray = new ARRAY(desc, connection, linkedAcctStructArray);
			LOGGER.debug("linkedAcctStructArray=======" + Arrays.toString(linkedAcctStructArray));
			
			
			stmt = connection.prepareCall(spDetail);
			stmt.setString(1, publicAccNum);
			stmt.setDate(2, sqlDate);
			stmt.registerOutParameter(3, Types.ARRAY, typeTableNameRetailContract.toUpperCase());
			stmt.registerOutParameter(4, Types.ARRAY, typeTableNameAccountSnapshot.toUpperCase());
			stmt.registerOutParameter(5, Types.ARRAY, typeTableNameCustomerContract.toUpperCase());
			stmt.registerOutParameter(6, Types.ARRAY, typeTableNameAgreement.toUpperCase());
			stmt.registerOutParameter(7, Types.ARRAY, typeTableNameCurrentAccountSnapshot.toUpperCase());
			stmt.setArray(8, linkedAcctArray);
			stmt.registerOutParameter(9, Types.ARRAY, typeTableNamePeriodPayment);
			stmt.registerOutParameter(10, Types.VARCHAR);
			stmt.execute();
			
			Array retailContractArray = stmt.getArray(3);
			Array accountSnapshotArray = stmt.getArray(4);
			Array customerContractArray = stmt.getArray(5);
			Array agreementArray = stmt.getArray(6);
			Array currentAccSnapshotArray = stmt.getArray(7);
			Array periodPaymentArray = stmt.getArray(9);
			status = stmt.getString(10);
			
			Object[] values = null;
			if (retailContractArray != null) {
				values = (Object[]) retailContractArray.getArray();
				RetailContractTriadDBTransformer retailContractTriadDBTransformer = new RetailContractTriadDBTransformer();
				for (Object row : values) {
					Struct rowData = (Struct) row;
					RetailContractTriad retailContractTriad = new RetailContractTriad();
					retailContractTriadDBTransformer.setRetailContractTriadObject(retailContractTriad, rowData.getAttributes());
					retailContractTriadList.add(retailContractTriad);
				}
			}
			
			if (accountSnapshotArray != null) {
				values = (Object[]) accountSnapshotArray.getArray();
				AccountingSnapshotTriadDBTransformer accountingSnapshotTriadDBTransformer = new AccountingSnapshotTriadDBTransformer();
				for (Object row : values) {
					Struct rowData = (Struct) row;
					AccountingSnapshotTriad accountingSnapshotTriad = new AccountingSnapshotTriad();
					accountingSnapshotTriadDBTransformer.setAccountingSnapshotTriadObject(accountingSnapshotTriad, rowData.getAttributes());
					accountingSnapshotTriadList.add(accountingSnapshotTriad);
				}
			}
			
			if (customerContractArray != null) {
				values = (Object[]) customerContractArray.getArray();
				CustomerContractTriadDBTransformer customerContractTriadDBTransformer = new CustomerContractTriadDBTransformer();
				for (Object row : values) {
					Struct rowData = (Struct) row;
					CustomerContractTriad customerContractTriad = new CustomerContractTriad();
					customerContractTriadDBTransformer.setCustomerContractTriadObject(customerContractTriad, rowData.getAttributes());
					customerContractTriadList.add(customerContractTriad);
				}
			}
			
			if (agreementArray != null) {
				values = (Object[]) agreementArray.getArray();
				AgreementTriadDBTransformer agreementTriadDBTransformer = new AgreementTriadDBTransformer();
				for (Object row : values) {
					Struct rowData = (Struct) row;
					AgreementTriad agreementTriad = new AgreementTriad();
					agreementTriadDBTransformer.setAgreementTriadObject(agreementTriad, rowData.getAttributes());
					agreementTriadList.add(agreementTriad);
				}
			}
			
			if (currentAccSnapshotArray != null) {
				values = (Object[]) currentAccSnapshotArray.getArray();
				CurAccSnapshotTriadDBTransformer curAccSnapshotTriadDBTransformer = new CurAccSnapshotTriadDBTransformer();
				for (Object row : values) {
					Struct rowData = (Struct) row;
					CurrentAccoutingSnapshotTriad currentAccoutingSnapshotTriad = new CurrentAccoutingSnapshotTriad();
					curAccSnapshotTriadDBTransformer.setCurrentAccoutingSnapshotTriadObject(currentAccoutingSnapshotTriad, rowData.getAttributes());
					currentAccSnapshotTriadList.add(currentAccoutingSnapshotTriad);
				}
			}
			
			if (periodPaymentArray != null) {
				values = (Object[]) periodPaymentArray.getArray();
				PeriodPaymentTriadDBTransformer periodPaymentTriadDBTransformer = new PeriodPaymentTriadDBTransformer();
				for (Object row : values) {
					Struct rowData = (Struct) row;
					PeriodPaymentTriad periodPaymentTriad = new PeriodPaymentTriad();
					periodPaymentTriadDBTransformer.setPeriodPaymentTriadObject(periodPaymentTriad, rowData.getAttributes());
					periodPaymentTriadList.add(periodPaymentTriad);
				}
			}
			
			allTriadObject[0] = retailContractTriadList;
			allTriadObject[1] = accountingSnapshotTriadList;
			allTriadObject[2] = customerContractTriadList;
			allTriadObject[3] = agreementTriadList;
			allTriadObject[4] = currentAccSnapshotTriadList;
			allTriadObject[5] = periodPaymentTriadList;
			
		} catch (SQLException exception) {
			LOGGER.error("[AssessTriadDao -- getAllTriadData] -- Exception: " + exception);
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_DB_ERROR_CODE,
					"[AssessTriadDao -- getAllTriadData] Exception", exception.getMessage(), null, null, exception);
		} finally {
			try {
				if (stmt != null) {
					stmt.close();
				}

				if (connection != null) {
					connection.close();
				}
			} catch (SQLException sqle) {
				LOGGER.error("[AssessTriadDao -- getAllTriadData] -- Exception in finally block: " + sqle);
			}
		}
		LOGGER.debug("[AssessTriadDao -- getAllTriadData] -- End");
		return allTriadObject;
	}

	private String getConfigValue(String key) throws StatementProcessorBatchException {
		CommonConfigHelper commonConfigHelper = CommonConfigHelper.getInstance();
		ExternalFileDataConfiguration dbconfig = commonConfigHelper
				.loadPropertyConfig(StatementProcessorBatchConstants.DATABASE_CONFIGURATION_FILE_KEY);
		return commonConfigHelper.readConfigData(dbconfig, key);
	}
}
