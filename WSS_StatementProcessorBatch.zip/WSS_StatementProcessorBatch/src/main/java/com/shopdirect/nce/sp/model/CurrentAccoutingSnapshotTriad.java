package com.shopdirect.nce.sp.model;

import java.sql.SQLData;
import java.sql.SQLException;
import java.sql.SQLInput;
import java.sql.SQLOutput;

public class CurrentAccoutingSnapshotTriad extends AccountingSnapshot implements SQLData{

	private String sqlType;
	
	@Override
	public void readSQL(SQLInput stream, String typeName) throws SQLException {
		
		sqlType = typeName;
		setInterestChargedAmtTSP(stream.readBigDecimal());
		setStatPromtMessageCodeRec(stream.readString());
		setaPR(stream.readBigDecimal());
		setTotalFeesTSP(stream.readBigDecimal());
		setBnplBalance(stream.readBigDecimal());
		setNumPaymentsTSP(stream.readBigDecimal());
		setNumPurchasesTSP(stream.readBigDecimal());
		setNetSalesValueTSPAmt(stream.readBigDecimal());
		setSalesFor6Months(stream.readBigDecimal());
		setSalesFor12Months(stream.readBigDecimal());
		setSalesLifetime(stream.readBigDecimal());
	}
	
	@Override
	public void writeSQL(SQLOutput stream) throws SQLException {
		
	}
	
	@Override
	public String getSQLTypeName() throws SQLException {
		return sqlType;
	}

	public String getSqlType() {
		return sqlType;
	}

	public void setSqlType(String sqlType) {
		this.sqlType = sqlType;
	}
}
