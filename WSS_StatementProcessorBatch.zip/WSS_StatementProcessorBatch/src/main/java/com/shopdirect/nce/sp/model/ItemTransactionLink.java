package com.shopdirect.nce.sp.model;

import java.util.Date;

public class ItemTransactionLink {
	
	private String drawdownItemId;
	
	private String drawdownTransactionId;
	
	private Long batchId;
	
	private String errorFlag;
	
	private String errorMessage;
	
	private Date creationDate;
	
	private Long createdByUser;
	
	private Date lastUpdateDate;
	
	private Long lastUpdateByUser;

	public String getDrawdownItemId() {
		return drawdownItemId;
	}

	public void setDrawdownItemId(String drawdownItemId) {
		this.drawdownItemId = drawdownItemId;
	}

	public String getDrawdownTransactionId() {
		return drawdownTransactionId;
	}

	public void setDrawdownTransactionId(String drawdownTransactionId) {
		this.drawdownTransactionId = drawdownTransactionId;
	}

	public Long getBatchId() {
		return batchId;
	}

	public void setBatchId(Long batchId) {
		this.batchId = batchId;
	}

	public String getErrorFlag() {
		return errorFlag;
	}

	public void setErrorFlag(String errorFlag) {
		this.errorFlag = errorFlag;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public Long getCreatedByUser() {
		return createdByUser;
	}

	public void setCreatedByUser(Long createdByUser) {
		this.createdByUser = createdByUser;
	}

	public Date getLastUpdateDate() {
		return lastUpdateDate;
	}

	public void setLastUpdateDate(Date lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}

	public Long getLastUpdateByUser() {
		return lastUpdateByUser;
	}

	public void setLastUpdateByUser(Long lastUpdateByUser) {
		this.lastUpdateByUser = lastUpdateByUser;
	}
	
	


}
