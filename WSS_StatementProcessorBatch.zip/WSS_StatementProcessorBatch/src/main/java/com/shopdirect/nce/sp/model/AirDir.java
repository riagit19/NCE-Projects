package com.shopdirect.nce.sp.model;

import java.math.BigDecimal;
import java.util.Date;

public class AirDir {

	private BigDecimal air;
	private BigDecimal nonBnplDir;
	private BigDecimal bnplDir;
	private BigDecimal dir;
	private Date effectiveDate;

	public BigDecimal getAir() {
		return air;
	}

	public void setAir(BigDecimal air) {
		this.air = air;
	}

	public BigDecimal getNonBnplDir() {
		return nonBnplDir;
	}

	public void setNonBnplDir(BigDecimal nonBnplDir) {
		this.nonBnplDir = nonBnplDir;
	}

	public BigDecimal getBnplDir() {
		return bnplDir;
	}

	public void setBnplDir(BigDecimal bnplDir) {
		this.bnplDir = bnplDir;
	}

	public BigDecimal getDir() {
		return dir;
	}

	public void setDir(BigDecimal dir) {
		this.dir = dir;
	}

	public Date getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

}
