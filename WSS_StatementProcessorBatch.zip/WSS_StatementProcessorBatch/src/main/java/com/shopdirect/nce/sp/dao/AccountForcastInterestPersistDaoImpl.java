package com.shopdirect.nce.sp.dao;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import com.shopdirect.fcm.xsd.forecastmodeller.BNPLDefIntByMonth;
import com.shopdirect.fcm.xsd.forecastmodeller.CustomerAccountInterestRespType;
import com.shopdirect.fcm.xsd.forecastmodeller.EstIntWithDDTType;
import com.shopdirect.nce.common.extcnfg.ExternalFileDataConfiguration;
import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.exception.BuisnessException;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.util.CommonConfigHelper;
import com.shopdirect.nce.sp.util.UCPConnection;

import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;

/**
 * This class interacts with Database for inserting or updating data into the SP
 * DB.
 * 
 * @author ibm
 *
 */

public class AccountForcastInterestPersistDaoImpl extends AccountReassessmentBaseDao {

	Connection connection = null;
	CallableStatement callStmt = null;
	private static SDLoggerImpl logger = new SDLoggerImpl();

	public AccountForcastInterestPersistDaoImpl() throws StatementProcessorBatchException {
		super();
	}

	
	/**
	 * @param fcmResponse
	 * @return
	 * @throws BuisnessException
	 * @throws StatementProcessorBatchException 
	 * @throws Exception
	 */
	
	public String persistForcastInterest(CustomerAccountInterestRespType fcmResponse, String agreementId, Date stmtDt) throws StatementProcessorBatchException{

		logger.debug("[AccountForcastInterestPersistDaoImpl -- persistForcastInterest]  -- START");
		String isInsertSuccessMessege = null;
		CommonConfigHelper commonConfigHelper = CommonConfigHelper.getInstance();
		ExternalFileDataConfiguration Dbconfig = commonConfigHelper.loadPropertyConfig("spDbConfig");
		final String PACK_PERSIST_FCM_DATA = commonConfigHelper.readConfigData(Dbconfig, "PACK_EST_INT");
		final String PROC_PERSIST_FCM_DATA = commonConfigHelper.readConfigData(Dbconfig, "PRC_LOAD_EST_INT");
		setSpMainSchema(getSchema(StatementProcessorBatchConstants.DB_SCHEMA_MAIN_SP_KEY));

		try {
			connection = UCPConnection.getConnection();
			String callQueryStr = "{call " + PACK_PERSIST_FCM_DATA + "." + PROC_PERSIST_FCM_DATA + "(?, ?, ?, ?, ?)}";
			callStmt = connection.prepareCall(callQueryStr);
			
			int ctr = 0;
			List<EstIntWithDDTType> estIntByDDtList = fcmResponse.getEstIntByDDT();
			java.sql.Struct estIntByDDtStructArray[] = new java.sql.Struct[estIntByDDtList.size()];
			for (EstIntWithDDTType estIntByDDt : estIntByDDtList){
				
				List<BNPLDefIntByMonth> bNPLDefIntByMonthsList = estIntByDDt.getBNPLDefIntByMonths();
				java.sql.Struct bNPLDefIntByMonthsStructArray[] = new java.sql.Struct[bNPLDefIntByMonthsList.size()];
				int innerCntr = 0;
				for(BNPLDefIntByMonth bNPLDefIntByMonthTemp : bNPLDefIntByMonthsList){
					BigDecimal dailyRates = new BigDecimal(0);
					if(estIntByDDt.getDailyRates().size()>0)
						dailyRates = estIntByDDt.getDailyRates().get(0).getRate();
					Object[] bNPLDefIntByMonth = new Object[] { bNPLDefIntByMonthTemp.getAmount(), 
							new java.sql.Date(bNPLDefIntByMonthTemp.getStatementDate().getTimeInMillis()), estIntByDDt.getDrawdownTermId(),  
							dailyRates};
					java.sql.Struct bNPLDefIntByMonthsStructObj = connection.createStruct("TY_OBJ_BNPL_HIST", bNPLDefIntByMonth);
					bNPLDefIntByMonthsStructArray[innerCntr++] = bNPLDefIntByMonthsStructObj;
				}
				ArrayDescriptor BnplHistDesc = ArrayDescriptor.createDescriptor("TY_TAB_BNPL_HIST", connection);
				ARRAY BNPLHistArray = new ARRAY(BnplHistDesc, connection, bNPLDefIntByMonthsStructArray);
				
				BigDecimal bnplCumultvIntrst = new BigDecimal(0);
				if(estIntByDDt.getBNPLDefCumulativeInterest()!=null){
					bnplCumultvIntrst = estIntByDDt.getBNPLDefCumulativeInterest();
				}
				
				Object[] DDEstObj = new Object[] { estIntByDDt.getEstimatedInterest(), estIntByDDt.getDrawdownTermId(), 
						bnplCumultvIntrst, BNPLHistArray};
				java.sql.Struct DDEstStructObj = connection.createStruct("TY_OBJ_DD_EST", DDEstObj);
				estIntByDDtStructArray[ctr++] = DDEstStructObj;
			}
			ArrayDescriptor desc = ArrayDescriptor.createDescriptor("TY_TAB_DD_EST", connection);
			ARRAY DDEstArray = new ARRAY(desc, connection, estIntByDDtStructArray);
			
			callStmt.setString(1, agreementId);
			callStmt.setBigDecimal(2, fcmResponse.getEstimatedInterest());
			callStmt.setDate(3,new java.sql.Date(stmtDt.getTime()));
			callStmt.setArray(4, DDEstArray);
			callStmt.registerOutParameter(5, java.sql.Types.VARCHAR);
			callStmt.executeUpdate();

			logger.info("[AccountForcastInterestPersistDaoImpl] -Persist Data Service Call successful:"+callStmt.getString(5));
			logger.debug("[AccountForcastInterestPersistDaoImpl -- persistForcastInterest]  -- END");

		} catch (SQLException sqlException) {
			logger.error("AccountForcastInterestPersistDaoImpl SQLException =======" + sqlException);
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_DB_ERROR_CODE,
					"[AccountForcastInterestPersistDaoImpl-persistForcastInterest] SQLException Block",
					"Database execution exception [SQLCode: " + sqlException.getSQLState() + "] , SQL Detail "
							+ sqlException,
					null, null, sqlException);
		} catch (Exception exception) {
			logger.error("AccountForcastInterestPersistDaoImpl Generic Exception =======" + exception);
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.CONNECTTION_DB_ERROR_CODE,
					"[AccountForcastInterestPersistDaoImpl-persistForcastInterest] Exception Block",
					"Database execution exception " + exception, null, null, exception);
		} finally {
			try {
				if (callStmt != null)
					callStmt.close();
				if (connection != null)
					connection.close();
			} catch (Exception e) {
				logger.error("[AccountForcastInterestPersistDaoImpl-persistForcastInterest]  -- Exception Block, Database execution exception "+e);					
			}
		}

		return isInsertSuccessMessege;
	}

}