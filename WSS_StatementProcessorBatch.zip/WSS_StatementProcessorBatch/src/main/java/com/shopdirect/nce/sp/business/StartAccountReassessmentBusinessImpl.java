package com.shopdirect.nce.sp.business;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import com.shopdirect.nce.common.extcnfg.ExternalFileDataConfiguration;
import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.dao.StatementProcessorARDao;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.externalclient.CustomerARProcessMsgSend;
import com.shopdirect.nce.sp.model.CustomerAccountInfo;
import com.shopdirect.nce.sp.model.StartAccountReassessmentRequestType;
import com.shopdirect.nce.sp.model.StartAccountReassessmentResponseType;
import com.shopdirect.nce.sp.util.CommonConfigHelper;
import com.shopdirect.nce.sp.util.StatementProcessorBatchUtil;


/**
 * This class holds the business logic for the following:
 * 1. retrieve record in bulk from CIM_ACCOUNT_INFO table
 * 2. call Queue with this list retrieved from CIM_ACCOUNT_INFO.
 * @author ibm
 *
 */
public class StartAccountReassessmentBusinessImpl {

	private static SDLoggerImpl logger = new SDLoggerImpl();
	private CommonConfigHelper commonConfigHelper = null;
	private ExternalFileDataConfiguration extFileDataCfg = null;
	private StatementProcessorARDao statementProcessorARDao = null;
	
	/**
	 * Default constructor
	 *  Set the CommonConfigHelper class
	 *  Set the ExternalFileDataConfiguration object 
	 * @throws StatementProcessorBatchException
	 */
	public StartAccountReassessmentBusinessImpl() throws StatementProcessorBatchException{
		setCommonConfigHelper(CommonConfigHelper.getInstance());
		initExternalConfig();
		setStatementProcessorARDao(new StatementProcessorARDao());
	}
    /**
     * Configuration Object creation 
     * @throws StatementProcessorBatchException 
     */
	private void initExternalConfig() throws StatementProcessorBatchException  {
		logger.debug("[StartAccountReassessmentBusinessImpl -- initExternalConfig]  -- START");
		
		 this.extFileDataCfg = getCommonConfigHelper().loadPropertyConfig(StatementProcessorBatchConstants.AUDITLOG_CONFIGURATION_FILE_KEY);
		
		logger.debug("[StartAccountReassessmentBusinessImpl -- initExternalConfig]  -- END");
	}
	
	/**
	 *  This mail business implementation method to perform Data collection activities for Statement processor Account Reassessment 
	 *  It will execute the only 10000 in  each iteration , put those customer information to JMS queue on by one. 
	 *  The condition to pull the customer detail whose Statement date is same asCustomer Passing date. (Mostly it will be Current date) and Status is 'NEW' 
	 * @param arProcessRequestType
	 * @return
	 * @throws Exception
	 */
	public StartAccountReassessmentResponseType startAR(StartAccountReassessmentRequestType arProcessRequestType) throws StatementProcessorBatchException {
		
		logger.debug("[StartAccountReassessmentBusinessImpl -- startAR]  -- START");
		StartAccountReassessmentResponseType startAccountReassessmentResponseType = null;
		try {
			String startCount = commonConfigHelper.readConfigData(getExtFileDataCfg(), StatementProcessorBatchConstants.EXTERNAL_CONFIG_VARIABLE_STARTCOUT);
			String endCount = commonConfigHelper.readConfigData(getExtFileDataCfg(), StatementProcessorBatchConstants.EXTERNAL_CONFIG_VARIABLE_ENDCOUT);
			int startCountVal = StatementProcessorBatchUtil.convertToInteger(startCount);
			int endCountVal = StatementProcessorBatchUtil.convertToInteger(endCount);
			getLogger().debug("Start Count "+startCount +" end count "+endCount);
			


			int newEndCountVal = endCountVal;
			List<CustomerAccountInfo> customerList;
			int dbresultCount = 0;
			int noofloopOfBatch = 0;
			int totalaccountArStart = 0;
			getLogger().info("[Data Collection Batch Started : Date ["+new Date()+"]");
			boolean isIterationRequired = true;
			do {
				/**
				 * capture all the account with Status = New. 
				 */
				customerList = callARProcessDao(startCountVal, newEndCountVal,
						arProcessRequestType.getTxBatchRunDt());
				if(customerList != null && !customerList.isEmpty() ) {
					dbresultCount = customerList.size();
					totalaccountArStart = totalaccountArStart+dbresultCount;
					noofloopOfBatch++;
					startCountVal = newEndCountVal + 1;
					newEndCountVal = newEndCountVal * 2;
					
					getLogger().info("[Accounts put in JMS queue :-- "+noofloopOfBatch);
					callARProcessMsgSend(customerList);
					getLogger().info("[Successfully Accounts put in JMS queue :-- "+dbresultCount);
				}else {
					getLogger().info("Data Collection Batch not picked any account !!!!");
					isIterationRequired = false;
				}

			} while (dbresultCount < endCountVal && isIterationRequired);
			startAccountReassessmentResponseType =  populateResponseData(totalaccountArStart);

			getLogger().info("[Data Collection Batch Completed successfully : date ["+new Date()+"]");
			
			logger.debug("[StartAccountReassessmentBusinessImpl -- startAR]  -- END");
		}catch(StatementProcessorBatchException statementProcessorBatchException) {
			throw statementProcessorBatchException;
		}catch (Exception e) {
			
			getLogger().error("[StartAccountReassessmentBusinessImpl -- startAR] Exception Block "+ e.getMessage());
			StatementProcessorBatchUtil.getprintStackTraceString(e);
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_BUSINESS_ERROR_CODE,
					"[StartAccountReassessmentBusinessImpl-startAR] Exception Block",
					"Business exception generated at time to process the data collection "+ e.getMessage(),
					null, null,e);
			
		}
		
		return startAccountReassessmentResponseType;
		
		
	}
	
	/**
	 * 
	 * @param totalaccountArStart
	 * @return
	 */
	private StartAccountReassessmentResponseType populateResponseData(int totalaccountArStart) {
		StartAccountReassessmentResponseType response = new StartAccountReassessmentResponseType();
		response.setTotalCustomersARApply(totalaccountArStart);
		return response;
	}
	/**
	 * @return the commonConfigHelper
	 */
	public CommonConfigHelper getCommonConfigHelper() {
		return commonConfigHelper;
	}
	/**
	 * @param commonConfigHelper the commonConfigHelper to set
	 */
	public void setCommonConfigHelper(CommonConfigHelper commonConfigHelper) {
		this.commonConfigHelper = commonConfigHelper;
	}
	/**
	 * @return the extFileDataCfg
	 */
	public ExternalFileDataConfiguration getExtFileDataCfg() {
		return extFileDataCfg;
	}
	/**
	 * @param extFileDataCfg the extFileDataCfg to set
	 */
	public void setExtFileDataCfg(ExternalFileDataConfiguration extFileDataCfg) {
		this.extFileDataCfg = extFileDataCfg;
	}
	/**
	 * @return the statementProcessorARDao
	 */
	public StatementProcessorARDao getStatementProcessorARDao() {
		return statementProcessorARDao;
	}
	/**
	 * @param statementProcessorARDao the statementProcessorARDao to set
	 */
	public void setStatementProcessorARDao(StatementProcessorARDao statementProcessorARDao) {
		this.statementProcessorARDao = statementProcessorARDao;
	}
	/**
	 * @return the logger
	 */
	public static SDLoggerImpl getLogger() {
		return logger;
	}
	
	/*
	 * @param arList sends customerAccountList to jms queue
	 */
	public void callARProcessMsgSend(List<CustomerAccountInfo> arList) throws StatementProcessorBatchException {
		CustomerARProcessMsgSend.customerMsgPut(arList);
	}
    
	/*
	 * @param startCountVal,newEndCountVal,txBatchRunDt
	 * @return customerAccountList retrived from DAO layer
	 */
	public List<CustomerAccountInfo> callARProcessDao(int startCountVal, int newEndCountVal,Calendar txBatchRunDt) throws StatementProcessorBatchException {
		return getStatementProcessorARDao().getAccountList(startCountVal, newEndCountVal,
				txBatchRunDt);
	}
	
}
