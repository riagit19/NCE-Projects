package com.shopdirect.nce.sp.dao.creditdataload;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;

import com.shopdirect.nce.common.extcnfg.ExternalFileDataConfiguration;
import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.Query;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.dao.AccountReassessmentBaseDao;
import com.shopdirect.nce.sp.exception.BuisnessException;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.DrawdownItem;
import com.shopdirect.nce.sp.util.CommonConfigHelper;
import com.shopdirect.nce.sp.util.UCPConnection;

import oracle.jdbc.OracleTypes;
import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;

public class DrawDownItemDaoImpl extends AccountReassessmentBaseDao {

	boolean isInsertSuccess = false;
	Connection connection = null;
	private static SDLoggerImpl logger = new SDLoggerImpl();
	Object[] procReturnVal = new Object[2];
	String errMsg = null;

	public DrawDownItemDaoImpl() throws StatementProcessorBatchException {
		super();
	}

	
	public Object[] insertDrawDownItemtData(List<DrawdownItem> drawdownItemList) throws BuisnessException, StatementProcessorBatchException {

		logger.debug("[DrawDownItemDaoImpl -- insertDrawDownItemtData]  -- START");
		String isInsertSuccessMessege = null;
		CommonConfigHelper commonConfigHelper = CommonConfigHelper.getInstance();
		CallableStatement callStmt = null;
		int retCode = 0;
		String retMsg = null;
		ExternalFileDataConfiguration Dbconfig = commonConfigHelper.loadPropertyConfig("spDbConfig");
		String CREDIT_DATA_LOAD_PACK = commonConfigHelper.readConfigData(Dbconfig, "CREDIT_DATA_LOAD_PACK");
		String PRC_POPULATE_DATA_DDI = commonConfigHelper.readConfigData(Dbconfig, "PRC_POPULATE_DATA_DDI");

		try {
			connection = UCPConnection.getConnection();
			String callQueryStr = Query.getInsertFinDataQuery(CREDIT_DATA_LOAD_PACK, PRC_POPULATE_DATA_DDI);
			callStmt = connection.prepareCall(callQueryStr);	
			
			java.sql.Struct drawDownItemStructArray[] = new java.sql.Struct[drawdownItemList.size()];
			
			int ctr = 0;
			for (DrawdownItem drawdownItem : drawdownItemList) {

				Object[] drawDownItemObj = new Object[] {(new BigDecimal(drawdownItem.getDrawdownItemId())),(new BigDecimal(drawdownItem.getDrawdownId())),drawdownItem.getDdiStatus(),
						drawdownItem.getOrderNumber(),drawdownItem.getItemLineNumber(),drawdownItem.getItemCode(),drawdownItem.getItemText(),drawdownItem.getRetailPrice(),
						drawdownItem.getBatchId(), drawdownItem.getDrawdownOldId(), drawdownItem.getCreatedByUser()};
				
				java.sql.Struct drawDownItemStructObj = connection.createStruct("TY_OBJ_INST_CREDIT_DDI", drawDownItemObj);
				drawDownItemStructArray[ctr++] = drawDownItemStructObj;
			}
			ArrayDescriptor desc = ArrayDescriptor.createDescriptor("TY_TAB_INST_CREDIT_DDI", connection);
			ARRAY drawDownItemArray = new ARRAY(desc, connection, drawDownItemStructArray);
			logger.debug("agreementStructArray=======" + Arrays.toString(drawDownItemStructArray));
			callStmt.setArray(1, drawDownItemArray);
			callStmt.registerOutParameter(2, OracleTypes.ARRAY, "TY_TAB_INST_CREDIT_DDI_OUT");
			callStmt.registerOutParameter(3, java.sql.Types.INTEGER);
			callStmt.registerOutParameter(4, java.sql.Types.CHAR);
			callStmt.executeUpdate();

			retCode = callStmt.getInt(3);
			retMsg = callStmt.getString(4);
			ARRAY outArray = (ARRAY) callStmt.getArray(2);
			Object[] outList = (Object[]) outArray.getArray();

			if (retCode == 0) {
				isInsertSuccess = true;
			} else {
				if (outList.length > 29)
					errMsg = (String) outList[29];
				else
					errMsg = retMsg + "[ID]";
				logger.debug("DrawDownItem Insertion Exception errMsg=========" + errMsg);
				isInsertSuccess = false;
				throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_BUSINESS_ERROR_CODE,
						"[DrawDownItemDaoImpl-insertDrawDownItemtData] StatementProcessorBatchException Block",
						"Database Failed Insertion execution exception " + errMsg, 
						null, null, new StatementProcessorBatchException());
			}
			
			isInsertSuccessMessege = retMsg;
			procReturnVal[0]= retCode;
			procReturnVal[1]= retMsg;
			
			logger.debug("[DrawDownItemDaoImpl -- insertDrawDownItemtData]  -- END");

		} catch (SQLException sqlException) {
			isInsertSuccess = true;
			isInsertSuccessMessege = sqlException.getMessage();
			logger.error("DrawDownItem SQLException Exception =======" + isInsertSuccessMessege);
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_DB_ERROR_CODE,
					"[DrawDownItemDaoImpl-insertDrawDownItemtData] SQLException Block",
					"Database execution exception [SQLCode: " + sqlException.getSQLState() + "] , SQL Detail "
							+ sqlException.getMessage(),
					null, null, sqlException);

		} catch (Exception exception) {
			isInsertSuccess = true;
			isInsertSuccessMessege = exception.getMessage();
			logger.error("DrawDownItem Generic Exception =======" + isInsertSuccessMessege);
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.CONNECTTION_DB_ERROR_CODE,
					"[DrawDownItemDaoImpl-insertDrawDownItemtData] Exception Block",
					"Database execution exception " + exception.getMessage(), null, null, exception);
		} finally {

			try {

				if (callStmt != null) {
					callStmt.close();
				}

				if (connection != null) {
					connection.close();
				}

			} catch (Exception e) {
				logger.error("[DrawDownItemDaoImpl-insertDrawDownItemtData]  -- Exception Block, Database execution exception "+e.getMessage());				
			}
		}

		return procReturnVal;
	}

}
