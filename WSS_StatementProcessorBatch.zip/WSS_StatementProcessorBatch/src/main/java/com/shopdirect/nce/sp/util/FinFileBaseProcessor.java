package com.shopdirect.nce.sp.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.LineNumberReader;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.shopdirect.nce.common.extcnfg.ExternalFileDataConfiguration;
import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.business.creditdataload.DataFileProcessor;
import com.shopdirect.nce.sp.constants.CreditLoadDataConstants;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.dao.SPErrorLogDaoImpl;
import com.shopdirect.nce.sp.dao.creditdataload.FinancierDataDeleteDaoImpl;
import com.shopdirect.nce.sp.dao.creditdataload.SpCreditFilLoadControlDaoImpl;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.SpCreditFilLoadControl;
import com.shopdirect.nce.sp.model.SpErrorLog;

public class FinFileBaseProcessor implements DataFileProcessor{
	
	private static final String EMPTY_QUOTES = "\"\"";
	private static final String COLUMN_NAME = "ColumnName";
	private static final String DATE_TYPE = "java.util.Date";
	private static final String STRING_TYPE = "java.lang.String";
	private static final String DOUBLE_TYPE = "java.lang.Double";
	private static final String INTEGER_TYPE = "java.lang.Integer";
	private static final String LONG_TYPE = "java.lang.Long";
	private static final String TIMESTAMP_TYPE = "java.sql.Timestamp";
	private static final String SEQUENCE = "Sequence";
	private static final String DATA_TYPE = "DataType";
	Map<String, Double> statMap = new HashMap<>();
	Integer logTraceId = 0;
	boolean isValid = false;	
	private static SDLoggerImpl logger = new SDLoggerImpl();
	private CommonConfigHelper commonConfigHelper = null;
	String financierFilePath = null;
	private ExternalFileDataConfiguration extFileDataCfg = null;
	int batchInsertcount;
	private ExternalFileDataConfiguration dataconfig;
	private String batchRunDate;
	
	SpCreditFilLoadControl inputFilLoadControl = new SpCreditFilLoadControl();
	SpCreditFilLoadControl outputFilLoadControl = new SpCreditFilLoadControl();	
	
	/**
	 * @throws StatementProcessorBatchException
	 */
	public FinFileBaseProcessor() throws StatementProcessorBatchException {
		setCommonConfigHelper(CommonConfigHelper.getInstance());
		initExternalConfig();
	}	
	
	/**
	 * @return the dataconfig
	 */
	public ExternalFileDataConfiguration getDataconfig() {
		return dataconfig;
	}

	/**
	 * @param dataconfig the dataconfig to set
	 */
	public void setDataconfig(ExternalFileDataConfiguration dataconfig) {
		this.dataconfig = dataconfig;
	}
	
	public int getBatchInsertcount() throws StatementProcessorBatchException {
		batchInsertcount = Integer.parseInt(
				commonConfigHelper.readConfigData(getExtFileDataCfg(), CreditLoadDataConstants.FIN_BATCH_COUNT));
		return batchInsertcount;
	}

	public void setBatchInsertcount(int batchInsertcount) {
		this.batchInsertcount = batchInsertcount;
	}

	public ExternalFileDataConfiguration getExtFileDataCfg() {
		return extFileDataCfg;
	}

	public void setExtFileDataCfg(ExternalFileDataConfiguration extFileDataCfg) {
		this.extFileDataCfg = extFileDataCfg;
	}

	protected void initExternalConfig() throws StatementProcessorBatchException {
		logger.debug("[FinFileBaseProcessor -- initExternalConfig]  -- START");

		this.extFileDataCfg = getCommonConfigHelper()
				.loadPropertyConfig(StatementProcessorBatchConstants.LOAD_FINANCIERDATA_CONFIGURATION_FILE_KEY);
		this.setFinancierFilePath(
				commonConfigHelper.readConfigData(getExtFileDataCfg(), CreditLoadDataConstants.FINANCIER_FILES_PATH));
		
		this.dataconfig = getCommonConfigHelper().loadPropertyConfig("dataConfig");

		logger.debug("[FinFileBaseProcessor -- initExternalConfig]  -- END");
	}

	public String getFinancierFilePath() {
		getLogger().debug("FinFileBaseProcessor getFinancierFilePath START" + financierFilePath);
		return financierFilePath;
	}

	public void setFinancierFilePath(String financierFilePath) {
		this.financierFilePath = financierFilePath;
	}

	public static SDLoggerImpl getLogger() {
		return logger;
	}

	public static void setLogger(SDLoggerImpl logger) {
		FinFileBaseProcessor.logger = logger;
	}

	public CommonConfigHelper getCommonConfigHelper() {
		return commonConfigHelper;
	}

	public void setCommonConfigHelper(CommonConfigHelper commonConfigHelper) {
		this.commonConfigHelper = commonConfigHelper;
	}

	public File getFile(File folder, String filename) {
		File[] listOfFiles = folder.listFiles(new FilenameFilter(){
			@Override
			public boolean accept(File dir, String name) {
				return name.startsWith(filename);
			}
		});

		File file = null;
		if (listOfFiles.length > 0 && isValidFile(listOfFiles[0])) {
			file = listOfFiles[0];
		}

		return file;
	}

	/**
	 * @param file
	 * @return
	 */
	protected boolean isValidFile(File file) {
		return file.isFile() && file.getName() != null
				&& !file.getName().contains(CreditLoadDataConstants.PROCESSED_STATUS)
				&& !file.getName().contains(CreditLoadDataConstants.STATDELIVERY);
	}
	
	/**
	 * @return
	 * @throws StatementProcessorBatchException
	 */
	@SuppressWarnings("unchecked")
	protected List<Map<String, Object>> getColumns(String mappingFile, String rootNode)
			throws StatementProcessorBatchException {
		ExternalFileDataConfiguration extConf = getCommonConfigHelper().loadXmlConfig(mappingFile);
		@SuppressWarnings("unchecked")
		Map<String, Object> objectMap = extConf.getXmlDataStructure(rootNode);
		return (List<Map<String, Object>>) objectMap.get(COLUMN_NAME);
	}

	/**
	 * @param contents
	 * @param columns
	 * @param instance
	 * @throws NoSuchMethodException
	 * @throws IllegalAccessException
	 * @throws InvocationTargetException
	 * @throws ParseException
	 */
	protected void constructObjects(String[] contents, List<Map<String, Object>> columns, Object instance)
			throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, ParseException, Exception {
		for (Map<String, Object> column : columns) {

			String setterMethodName = getSetterMethodName(column);

			int index = Integer.parseInt(column.get(SEQUENCE).toString());
			String content = contents[index];
			if (isValidContent(content)) {
				content = content.trim();
				try {
					if (STRING_TYPE.equals(column.get(DATA_TYPE).toString())) {
						String value = content.replaceAll("^\"|\"$", "");
						Method method = instance.getClass().getMethod(setterMethodName, String.class);
						method.invoke(instance, value);
					} else if (DOUBLE_TYPE.equals(column.get(DATA_TYPE).toString())) {
						Double value = Double.parseDouble(content);
						Method method = instance.getClass().getMethod(setterMethodName, Double.class);
						method.invoke(instance, value);
					} else if (DATE_TYPE.equals(column.get(DATA_TYPE).toString())) {
						setDate(instance, setterMethodName, content);
					} else if (INTEGER_TYPE.equals(column.get(DATA_TYPE).toString())) {
						Integer value = Integer.parseInt(content);
						Method method = instance.getClass().getMethod(setterMethodName, Integer.class);
						method.invoke(instance, value);
					}else if (LONG_TYPE.equals(column.get(DATA_TYPE).toString())) {
						Long value = Long.parseLong(content);
						Method method = instance.getClass().getMethod(setterMethodName, Long.class);
						method.invoke(instance, value);			
					}else if (TIMESTAMP_TYPE.equals(column.get(DATA_TYPE).toString())) {
						Date date = StatementProcessorBatchUtil.parseDateSafely(content);
						Timestamp value = new Timestamp(date.getTime());
						Method method = instance.getClass().getMethod(setterMethodName, Timestamp.class);
						method.invoke(instance, value);
					}else if ("primitive-double".equals(column.get(DATA_TYPE).toString())) {
						double value = Double.parseDouble(content);
						Method method = instance.getClass().getMethod(setterMethodName, double.class);
						method.invoke(instance, value);
					}
				} catch (Exception e) {
					String msg = "Setter: " + setterMethodName + " Value:" + content;
					getLogger().error("[FinFileBaseProcessor -- constructObjects] -- Exception: " + msg); 
					throw new Exception(e.getMessage() + "- ID is -" + contents[0]);
				}
			}
		}
	}

	/**
	 * @param instance
	 * @param setterMethodName
	 * @param content
	 * @throws NoSuchMethodException
	 * @throws IllegalAccessException
	 * @throws InvocationTargetException
	 */
	protected void setDate(Object instance, String setterMethodName, String content)
			throws NoSuchMethodException, IllegalAccessException, InvocationTargetException {
		Date value = StatementProcessorBatchUtil.parseDateSafely(content);
		if ("setCreatedDateTime".equalsIgnoreCase(setterMethodName)) {
			value = new Date();
		}
		Method method = instance.getClass().getMethod(setterMethodName, Date.class);
		method.invoke(instance, value);
	}

	/**
	 * @param content
	 * @return
	 */
	protected boolean isValidContent(String content) {
		return content != null && !content.isEmpty() && !content.equals(EMPTY_QUOTES);
	}

	/**
	 * @param column
	 * @return
	 */
	protected String getSetterMethodName(Map<String, Object> column) {
		String attribute = column.get("ClassAttributeName").toString();
		String setterMethodName = attribute.substring(0, 1).toUpperCase();
		setterMethodName = setterMethodName + attribute.substring(1, attribute.length());
		setterMethodName = "set" + setterMethodName;
		return setterMethodName;
	}

	/**
	 * This method renames all the file status to <processed> after the load and
	 * BR validations.
	 * @param status 
	 */
	public void renameFiles(String status) {
		File folder = new File(this.getFinancierFilePath());
		File[] listOfFiles = folder.listFiles();
		if (listOfFiles != null) {
			for (File file : listOfFiles) {
				executeFileRename(status, file);
			}

		}

	}

	private void executeFileRename(String status, File file) {
		if (file.isFile()) {
			String fileName = file.getName();
			String[] token = fileName.split("_");
			if (token[0].equals(batchRunDate) && CreditLoadDataConstants.NEW_STATUS.equals(token[2])) {
				String newFileName = fileName.replace(token[2], status);
				boolean isRenameSuccess = file.renameTo(new File(this.getFinancierFilePath() + newFileName));

				getLogger().debug("FinFileBaseProcessor -- renameFiles] Status: " + status + " Success: " + isRenameSuccess);
			}
		}
	}

	protected boolean isValidFileName(String batchRunDt) throws StatementProcessorBatchException {
		getLogger().debug("FinFileBaseProcessor isValidFileName START");
		boolean result = false;

		File folder = new File(this.getFinancierFilePath());
		getLogger().debug("FinFileBaseProcessor isValidFileName folder" + folder);

		String batchRunDate = setBatchRunDate(batchRunDt);
		File[] listOfFiles = folder.listFiles(new FilenameFilter() {
			
			@Override
			public boolean accept(File dir, String name) {
				return name.startsWith(batchRunDate) && name.contains(CreditLoadDataConstants.NEW_STATUS);
			}
		});
		if (listOfFiles == null || listOfFiles.length == 0) {
			throw new StatementProcessorBatchException(CreditLoadDataConstants.FILENOTFOUNDERRORCODE,
					"[FinFileBaseProcessor-isValidFileName] ", CreditLoadDataConstants.FILENOTFOUNDERRORDESC, null, null, null);
		}
		if (listOfFiles != null) {
			for (File file : listOfFiles) {
				if (isNewFile(file)) {
						String fileName = file.getName();
						String[] token = fileName.split("_");
						String statementDate = token[0];
						String str = token[3];
						String lastupdateDate = str.split("\\.")[0];
						getLogger()
								.debug("FinFileBaseProcessor isValidFileName statementDate=" + statementDate);
						List<String> dateList = new ArrayList<>();
						dateList.add(statementDate);
						dateList.add(lastupdateDate);

						for (String dt : dateList) {
							result = validateDate(dt);
							if (!result) {
								getLogger().debug("FinFileBaseProcessor isValidFileName result=" + result);
								break;
							}
						}
				}
				if (!result) {
					break;
				}
			}
		}
		getLogger().debug("FinFileBaseProcessor isValidFileName END result=" + result);
		return result;
	}

	protected boolean validateDate(String dateToValidate) {
		String dateFromat = "yyyyMMdd";
		boolean result;
		SimpleDateFormat sdf = new SimpleDateFormat(dateFromat);
		sdf.setLenient(false);
		if (dateToValidate == null) {
			return false;
		}
		try {
			/**
			 * If date is not Valid
			 * then it will throw 
			 * ParseException
			 */
			sdf.parse(dateToValidate);
			result = true;
		} catch (ParseException e) {
			logger.error("ParseException = " + e);
			return false;
		} catch (Exception e) {
			logger.error("Generic Exception = " + e);
			return false;
		}

		return result;

	}

	/**
	 * This method validates the BR1: Prior loading check correct amount of
	 * records per file against the information given by the stat file
	 * 
	 * @return boolean true or false.
	 * @throws IOException
	 */
	public boolean validateRequest() throws IOException {

		boolean result = false;

		int agreementRecordsCount = 0;
		int serviceChargeRecordsCount = 0;

		int drawdownTermRecordsCount = 0;
		int drawdownItemRecordsCount = 0;

		int nosiaRecordsCount = 0;
		int periodPaymentRecordsCount = 0;
		int targetedPaymentRecordsCount = 0;
		int ppiStatementRecordsCount = 0;
		
		int drawdownTransactionRecordsCount = 0;
		int itemTransactionLinkRecordsCount = 0;

		File folder = new File(this.getFinancierFilePath());
		getLogger().debug("FinancierFileLoadBusinessImpl validateRequest folder " + folder);
		File[] listOfFiles = folder.listFiles();
		getLogger().debug("FinancierFileLoadBusinessImpl validateRequest listOfFiles " + listOfFiles);
		if (listOfFiles != null) {
			getLogger().debug("FinancierFileLoadBusinessImpl validateRequest listOfFiles inside if " + listOfFiles);
			for (File file : listOfFiles) {
				if (isNewFile(file)) {
						if (!file.getName().contains(CreditLoadDataConstants.STATDELIVERY)) {
							StatementProcessorBatchUtil.processFile(file);
							String fileName = file.getName();
							String[] token = fileName.split("_");

							switch (token[1]) {

							case CreditLoadDataConstants.AGREEMENT:
								agreementRecordsCount = getRecordsCount(this.getFinancierFilePath() + fileName);
								break;

							case CreditLoadDataConstants.DRAWDOWN:
								drawdownTermRecordsCount = getRecordsCount(
										this.getFinancierFilePath() + fileName);
								break;

							case CreditLoadDataConstants.DRAWDOWNITEM:
								drawdownItemRecordsCount = getRecordsCount(
										this.getFinancierFilePath() + fileName);
								break;

							case CreditLoadDataConstants.NOSIA:
								nosiaRecordsCount = getRecordsCount(this.getFinancierFilePath() + fileName);
								break;

							case CreditLoadDataConstants.PERIODPAYMENT:
								periodPaymentRecordsCount = getRecordsCount(
										this.getFinancierFilePath() + fileName);
								break;

							case CreditLoadDataConstants.TARGETEDPAYMENT:
								targetedPaymentRecordsCount = getRecordsCount(
										this.getFinancierFilePath() + fileName);
								break;

							case CreditLoadDataConstants.PPISTATEMENT:
								ppiStatementRecordsCount = getRecordsCount(
										this.getFinancierFilePath() + fileName);
								break;

							case CreditLoadDataConstants.SERVICECHARGE:
								serviceChargeRecordsCount = getRecordsCount(
										this.getFinancierFilePath() + fileName);
								break;
								
							case CreditLoadDataConstants.DRAWDOWNTRANSACTION:
								drawdownTransactionRecordsCount = getRecordsCount(
										this.getFinancierFilePath() + fileName);
								break;	
								
							case CreditLoadDataConstants.ITEMTRANSACTIONLINK:
								itemTransactionLinkRecordsCount = getRecordsCount(
										this.getFinancierFilePath() + fileName);
								break;	

							}

						} else {
							// read stat file and get total count of each file
							statMap = readStatFile(this.getFinancierFilePath() + file.getName());

						}
				}
			}

			logger.debug("[FinFileBaseProcessor -- isValidFile]  --"
					+ statMap.get(CreditLoadDataConstants.AGREEMENT));
			if ((statMap.get(CreditLoadDataConstants.AGREEMENT) != null
					&& (statMap.get(CreditLoadDataConstants.AGREEMENT).intValue() == agreementRecordsCount - 1))
					&& (statMap.get(CreditLoadDataConstants.DRAWDOWN) != null && (statMap
							.get(CreditLoadDataConstants.DRAWDOWN).intValue() == drawdownTermRecordsCount - 1))
					&& (statMap.get(CreditLoadDataConstants.DRAWDOWNITEM) != null && (statMap
							.get(CreditLoadDataConstants.DRAWDOWNITEM).intValue() == drawdownItemRecordsCount - 1))
					&& (statMap.get(CreditLoadDataConstants.TARGETEDPAYMENT) != null
							&& (statMap.get(CreditLoadDataConstants.TARGETEDPAYMENT)
									.intValue() == targetedPaymentRecordsCount - 1))
					&& (statMap.get(CreditLoadDataConstants.PPISTATEMENT) != null && (statMap
							.get(CreditLoadDataConstants.PPISTATEMENT).intValue() == ppiStatementRecordsCount - 1))
					&& (statMap.get(CreditLoadDataConstants.SERVICECHARGE) != null && (statMap
							.get(CreditLoadDataConstants.SERVICECHARGE).intValue() == serviceChargeRecordsCount - 1))
					&& (statMap.get(CreditLoadDataConstants.NOSIA) != null
							&& (statMap.get(CreditLoadDataConstants.NOSIA).intValue() == nosiaRecordsCount - 1))
					&& (statMap.get(CreditLoadDataConstants.PERIODPAYMENT) != null && (statMap
							.get(CreditLoadDataConstants.PERIODPAYMENT).intValue() == periodPaymentRecordsCount - 1))
					&& (statMap.get(CreditLoadDataConstants.DRAWDOWNTRANSACTION) != null && (statMap
							.get(CreditLoadDataConstants.DRAWDOWNTRANSACTION).intValue() == drawdownTransactionRecordsCount - 1))
					&& (statMap.get(CreditLoadDataConstants.ITEMTRANSACTIONLINK) != null && (statMap
							.get(CreditLoadDataConstants.ITEMTRANSACTIONLINK).intValue() == itemTransactionLinkRecordsCount - 1))) {

				result = true;
				logger.debug("[FinFileBaseProcessor -- validateRequest with Stat File Count] Result: " + result);
			}

		}

		return result;
	}

	/**
	 * @param file
	 * @return
	 */
	protected boolean isNewFile(File file) {
		return file != null && file.isFile() && file.getName() != null && file.getName().contains(CreditLoadDataConstants.NEW_STATUS);
	}

	/**
	 * This method gives the total count of records for a given file.
	 * 
	 * @param fileName
	 * @return totalRecordsCount
	 */
	protected int getRecordsCount(String fileName) throws IOException {

		LineNumberReader lnr;

		lnr = new LineNumberReader(new FileReader(new File(fileName)));
		lnr.skip(Long.MAX_VALUE);
		int totalRecordsCount = lnr.getLineNumber() + 1; // index starts with 0.
		lnr.close(); // Finally, the LineNumberReader object should be closed to
						// prevent resource leak

		return totalRecordsCount;
	}

	/**
	 * This method reads the STAT_DELIVERY file and creates a map with key,value
	 * pair.
	 * 
	 * @param path
	 * @return a map with Key as: file name and Value as: totalRecords
	 */
	protected Map<String, Double> readStatFile(String path) throws IOException {

		Map<String, Double> statisticsMap = new HashMap<>();

		BufferedReader br;

		br = new BufferedReader(new FileReader(new File(path)));

		String str = br.readLine();
		while ((str = br.readLine()) != null) {

			String key = null;
			if (!("").equals(str.trim())) 
				key = str.split(",")[0];

			statisticsMap.put(key, Double.parseDouble(str.split(",")[1]));
			statisticsMap.put(key + "OpeningBalance", Double.parseDouble(str.split(",")[2]));
			statisticsMap.put(key + "ClosingBalance", Double.parseDouble(str.split(",")[3]));
		}
		br.close();

		return statisticsMap;

	}

	protected void insertErrorLog(String errorCode, String errorDesc, String executionStat, String programName,
			String stepNumber, String statusMsg, String stepStatus) throws Exception {
		SpErrorLog spErrLog = new SpErrorLog();
		spErrLog.setErrCode(errorCode);
		spErrLog.setErrDesc(errorDesc);
		spErrLog.setExeStat(executionStat);
		spErrLog.setProgramName(programName);
		spErrLog.setStartDate(new Timestamp(System.currentTimeMillis()));
		spErrLog.setStepNumber(stepNumber);
		spErrLog.setStatusMsg(statusMsg);
		spErrLog.setStepDesc(CreditLoadDataConstants.STEP_DESCRIPTION);
		spErrLog.setStepStatus(stepStatus);
		spErrLog.setEndDate(new Timestamp(System.currentTimeMillis()));

		SPErrorLogDaoImpl spErrorLogDao = new SPErrorLogDaoImpl();
		spErrorLogDao.insertErrorLogData(spErrLog);

	}

	/**
	 * INSERT into the CONTROL TABLE PROVIDING before INSERT IN AGREEMENT TABLE
	 * with BATCH ID and PASS THE BATCH ID to insert into AGREEMENT TABLE
	 * 
	 * @throws StatementProcessorBatchException
	 */
	protected boolean insertSpLoadControlData(long batchID, String fileName, String fileIdentifier, int createdBy)
			throws StatementProcessorBatchException {

		/**
		 * INSERT into the CONTROL TABLE PROVIDING before INSERT IN AGREEMENT
		 * TABLE with BATCH ID and PASS THE BATCH ID to insert into AGREEMENT
		 * TABLE
		 */
		Date currentDate = new Date();
		java.sql.Date currDBDate = null;
		boolean insertControlSuccess = false;
		SpCreditFilLoadControlDaoImpl spCreditFilLoadControlDaoImpl = new SpCreditFilLoadControlDaoImpl();
		try {
			currDBDate = new java.sql.Date(currentDate.getTime());
			inputFilLoadControl.setBatchId(batchID);
			inputFilLoadControl.setFileName(fileName);
			inputFilLoadControl.setFileRunStatus(StatementProcessorBatchConstants.RUN_STATUS_NOT_STARTED);
			inputFilLoadControl.setErrorMessage(StatementProcessorBatchConstants.EMPTY_STRING);
			inputFilLoadControl.setCreatedDate(currDBDate);
			inputFilLoadControl.setCreatedBy(createdBy);
			inputFilLoadControl.setFileIdentifier(fileIdentifier);
			inputFilLoadControl.setProcessName(StatementProcessorBatchConstants.FINANCIER_DATA_LOAD_PROCESS_NAME);
			insertControlSuccess = spCreditFilLoadControlDaoImpl.insertControlData(inputFilLoadControl);
		} catch (ParseException parseException) {
			logger.error(parseException.getMessage());
		} catch (Exception exception) {
			logger.error(exception.getMessage());
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_BUSINESS_ERROR_CODE,
					"[FinFileBaseProcessor-insertSpLoadControlData] Exception Block",
					"Database execution exception " + exception.getMessage(), null, null, exception);
		}
		return insertControlSuccess;
	}

	/**
	 * INSERT into the CONTROL TABLE PROVIDING before INSERT IN AGREEMENT TABLE
	 * with BATCH ID and PASS THE BATCH ID to insert into AGREEMENT TABLE
	 * 
	 * @throws StatementProcessorBatchException
	 */
	protected boolean deleteAllData(long batchID)
			throws StatementProcessorBatchException {

		/**
		 * DELETE DATA 
		 * FROM ALL THE TABLES
		 * ON OCCURANCE OF EXCEPTION
		 */
		boolean deleteDataSuccess = false;
		FinancierDataDeleteDaoImpl financierDataDeleteDaoImpl = new FinancierDataDeleteDaoImpl();
		try {
			deleteDataSuccess = financierDataDeleteDaoImpl.deleteAllData(batchID);
		} catch (Exception exception) {
			logger.error(exception.getMessage());
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_BUSINESS_ERROR_CODE,
					"[FinFileBaseProcessor-deleteAllData] Exception Block",
					"Database execution exception " + exception.getMessage(), null, null, exception);
		}
		return deleteDataSuccess;
	}
	
	
	protected String setBatchRunDate(String batchRunDt) {
		if(batchRunDt != null && !batchRunDt.isEmpty() && batchRunDt.length() == 10) {
			batchRunDate = batchRunDt.replaceAll("-", "");
		}
		return batchRunDate;
	}	
}
