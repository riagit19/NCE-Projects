package com.shopdirect.nce.sp.model;

public class StartAccountReassessmentResponseType {
	
    private Integer totalCustomersARApply;
    
    
    

	public StartAccountReassessmentResponseType() {
		super();
		
	}

	public Integer getTotalCustomersARApply() {
		return totalCustomersARApply;
	}

	public void setTotalCustomersARApply(Integer totalCustomersARApply) {
		this.totalCustomersARApply = totalCustomersARApply;
	}
    
 

}
