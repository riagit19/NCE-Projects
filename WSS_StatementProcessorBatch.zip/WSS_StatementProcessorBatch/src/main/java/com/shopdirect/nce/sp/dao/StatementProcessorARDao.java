package com.shopdirect.nce.sp.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.Query;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.CustomerAccountInfo;
import com.shopdirect.nce.sp.util.UCPConnection;

public class StatementProcessorARDao  extends AccountReassessmentBaseDao {
	
	private static SDLoggerImpl logger = new SDLoggerImpl();
	
	/**
	 * Default constructor.
	 * @throws StatementProcessorBatchException
	 */
	public StatementProcessorARDao() throws StatementProcessorBatchException{
		super();
		setStgSchema(getSchema(StatementProcessorBatchConstants.DB_SCHEMA_STG_KEY));
		setSpMainSchema(getSchema(StatementProcessorBatchConstants.DB_SCHEMA_MAIN_SP_KEY));
	}
	

	/**
	 * @Method to retrieve the CustomerAccountInfo from DB
	 * @param startRowNum
	 * @param endRowNum
	 * @param inputDate
	 * @return
	 * @throws Exception
	 */
	public List<CustomerAccountInfo> getAccountList(Integer startRowNum, Integer endRowNum , Calendar inputDate) throws StatementProcessorBatchException {
		getLogger().debug("[StatementProcessorARDao -- getAccountList]  -- START");
		List<CustomerAccountInfo> customerAccountInfoList = new ArrayList<>(); 
    	Connection con = null;
		ResultSet accountInforesultSet = null;
		
		    try {
		    	con = UCPConnection.getConnection();
		    	String queryStr = Query.getCustrAccountInfoQuery(getSpMainSchema());
		    	Date inputStmtDate = getDate(inputDate.getTime());
		    	logger.debug("Run queryStr-->"+queryStr);
		    	logger.info("Query Date"+inputStmtDate.toString());
		    	int i = 0;
				try (PreparedStatement stmt = con.prepareStatement(queryStr)) {
	
					stmt.setString(++i, inputStmtDate.toString());
					stmt.setInt(++i, startRowNum);
					stmt.setInt(++i, endRowNum);
	
					accountInforesultSet = stmt.executeQuery();
					while (accountInforesultSet.next()) {
						CustomerAccountInfo custAccountInfo = new CustomerAccountInfo();
						custAccountInfo.setCustomerId(accountInforesultSet.getString("CUSTOMER_ID"));
						custAccountInfo.setStatementDate(inputStmtDate);
	
						customerAccountInfoList.add(custAccountInfo);
					}
				}
		    
		    } catch (SQLException sqlException) {
		    	
				throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_DB_ERROR_CODE,
						"[StatementProcessorARDao -- getAccountList] SQLException ",
						"Database execution exception [SQLCode: "+ sqlException.getSQLState() + "] , SQL Detail "+sqlException.getMessage(),
						null, null,sqlException);
			      
			       
			 }catch(Exception exception){
					throw new StatementProcessorBatchException(StatementProcessorBatchConstants.CONNECTTION_DB_ERROR_CODE,
							"[StatementProcessorARDao -- getAccountList] Exception ",
							"Database execution exception "+ exception.getMessage(),
							null, null,exception);
			 }finally {
				   
				   try {
					   if(accountInforesultSet != null){
						   accountInforesultSet.close();
					   }
					 
						   if (con != null) {
								con.close();
							}
					    
				} catch (SQLException e) {
					getLogger().error("[StatementProcessorARDao -- getAccountList] Finally: failed to close DB objects. " + e);
				}
			    }
		    getLogger().debug("[StatementProcessorARDao -- getAccountList]  -- END");
			return customerAccountInfoList;
	}
	
	/*
	 * This is utility method for getting current Date
	 */
	private static java.sql.Date getDate(java.util.Date inputDate) {
		return new java.sql.Date(inputDate.getTime());
	}	
	
	/**
	 * Updates the STATUS column in Database
	 * @param publicID
	 * @param dbStatus
	 * @param accountId
	 * @return Number of Rows Affected
	 * @throws StatementProcessorBatchException
	 * @throws SQLException
	 */
	public int updateStatusMessage(String publicID, String status,String accountId) throws Exception {
		logger.debug("[StatementProcessorARDao -- updateStatusMessage] -- Start"); 
		Connection con = null;
		int rowAffected = 0;
		PreparedStatement stmt = null;
		try {
	    	con = UCPConnection.getConnection();
	    	String dbStatus = trimStatus(status);
			con.setAutoCommit(false);
			
			String queryStr = Query.getSuccessfulARQuery(getSpMainSchema()).toString();
			getLogger().debug("[StatementProcessorARDao -- updateStatusMessage]  -- " + queryStr);
			stmt = con.prepareStatement(queryStr);

			stmt.setString(1, dbStatus);
			stmt.setString(2, publicID);
			stmt.setString(3, accountId);
			rowAffected = stmt.executeUpdate();
			con.commit();

		} catch (Exception e) {
			logger.debug("[StatementProcessorARDao -- updateStatusMessage] -- Exception : " + e.getMessage());
			if(con != null){
				con.rollback();
			}
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_BUSINESS_ERROR_CODE,
					"[StatementProcessorARDao -- updateStatusMessage] Exception Block",
					"Business exception generated at time to update STATUS " + e.getMessage(), null, null,
					e);
		} finally {
			try {
				if (stmt!=null){
					stmt.close();
				}
				
				if (con != null) {
					con.close();
				}
			} catch (Exception e) {
				logger.debug("[StatementProcessorARDao -- updateStatusMessage] -- Exception in finally block: " + e);
			}
		}
		logger.debug("[StatementProcessorARDao -- updateStatusMessage] -- End"); 
		return rowAffected;
	}
	
	public void updateARStatusMessage(String customerId, String status,Date statementDate) throws Exception {
		logger.debug("[StatementProcessorARDao -- updateARStatusMessage] -- Start"); 
		Connection con = null;
		PreparedStatement stmt = null;
		try {
	    	con = UCPConnection.getConnection();
	    	String dbStatus = trimStatus(status);
			con.setAutoCommit(false);
			logger.debug("***********************" + customerId);
			String queryStr = Query.startARQuery(getSpMainSchema()).toString();
			logger.debug("***********************" + queryStr);
			stmt = con.prepareStatement(queryStr);

			stmt.setString(1, dbStatus);
			stmt.setString(2, customerId);
			stmt.setString(3, statementDate.toString());
			stmt.executeUpdate();
			con.commit();

		} catch (Exception e) {
			logger.debug("[StatementProcessorARDao -- updateARStatusMessage] -- Exception : " + e.getMessage());
			if(con != null){
				con.rollback();
			}
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_BUSINESS_ERROR_CODE,
					"[StatementProcessorARDao-updateARStatusMessage] Exception Block",
					"Business exception generated at time to process the data collection " + e.getMessage(), null, null,
					e);
		} finally {
			try {
				if (stmt!=null){
					stmt.close();
				}
				
				if (con != null) {
					con.close();
				}
			} catch (Exception e) {
				logger.debug("[StatementProcessorARDao -- updateARStatusMessage] -- Exception in finally block: " + e);
			}
		}
		logger.debug("[StatementProcessorARDao -- updateARStatusMessage] -- End"); 
	}


	private String trimStatus(String status) {
		String dbStatus = status;
		if(status != null && status.length() > 20){
			dbStatus = status.substring(0, 20);
		} 
		return dbStatus;
	}
}
