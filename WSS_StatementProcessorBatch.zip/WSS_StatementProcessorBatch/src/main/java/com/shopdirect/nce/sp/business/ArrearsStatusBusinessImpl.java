package com.shopdirect.nce.sp.business;


import java.util.Date;
import java.util.Map;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.dao.ArrearsStatusDaoImpl;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.CustomerAccountInfo;
/**
 * @author amitkumar4
 *This class updates Account status of CIM_ACCOUNT_INFO, if it is not same with status returned from dormancy check
 */
public class ArrearsStatusBusinessImpl extends AccountReassessmentBaseBusinessImpl {

	private SDLoggerImpl logger = new SDLoggerImpl();
	private ArrearsStatusDaoImpl arrearsStatusDaoImpl = null;
	/**
	 * 
	 */
	public ArrearsStatusBusinessImpl() throws StatementProcessorBatchException {
		super();
		setArrearsStatusDaoImpl(new ArrearsStatusDaoImpl());
	}

	/**
	 * This method determine the arrears status 
	 * @param customerAccountInfo
	 * @return
	 * @throws StatementProcessorBatchException
	 */
	public Map<String, String> process(CustomerAccountInfo customerAccountInfo) throws StatementProcessorBatchException {
		logger.debug("[ArrearsStatusDaoImpl -- process]  -- START");
		Map<String, String> arrearsStatusMap = null;
		
		try {
			/**
			 * Validate, If the account not a Linked account
			 */
			boolean isNotLinkedAccount = isLinkAccount(customerAccountInfo.getLinkedAccntIndex());
			if(!isNotLinkedAccount){
				
				arrearsStatusMap = accountArrearsStatus(customerAccountInfo);
					
			}
			logger.debug("[ArrearsStatusDaoImpl -- process]  -- END");
		}
		catch(StatementProcessorBatchException statementProcessorBatchException){
			getLogger().error("[ArrearsStatusDaoImpl] - StatementProcessorBatchException exception"+statementProcessorBatchException.getMessage());
			statementProcessorBatchException.setErrorKey(StatementProcessorBatchConstants.ERROR_CUST_STATUS);
			throw statementProcessorBatchException;
			
		}
		catch (Exception e) {
			getLogger().error("[ArrearsStatusDaoImpl -- process] Exception Block "+ e);
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_BUSINESS_ERROR_CODE,
					"[ArrearsStatusDaoImpl -- process] Exception Block",
					"Business exception generated at time to process ChangeRate "+ e.getMessage(),
					StatementProcessorBatchConstants.ERROR_CUST_STATUS, null,e);
		}
		
		return arrearsStatusMap;
	}
	private Map<String, String> accountArrearsStatus(CustomerAccountInfo customerAccountInfo) throws StatementProcessorBatchException {

		String pubAccNum = customerAccountInfo.getPublicAccountId();
		Date statementDate = customerAccountInfo.getStatementDate();
		
		return getArrearsStatusDaoImpl().getArrearsStatus(pubAccNum, statementDate);
	}

	
	public ArrearsStatusDaoImpl getArrearsStatusDaoImpl() throws StatementProcessorBatchException {
		if (arrearsStatusDaoImpl == null) {
			arrearsStatusDaoImpl = new ArrearsStatusDaoImpl();
		}
		return arrearsStatusDaoImpl;
	}

	public void setArrearsStatusDaoImpl(ArrearsStatusDaoImpl arrearsStatusDaoImpl) {
		this.arrearsStatusDaoImpl = arrearsStatusDaoImpl;
	}

}
