package com.shopdirect.nce.sp.business.creditdataload;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.CreditLoadDataConstants;
import com.shopdirect.nce.sp.dao.creditdataload.SpCreditFilLoadControlDaoImpl;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.SpErrorLog;
import com.shopdirect.nce.sp.model.TargetedPayment;
import com.shopdirect.nce.sp.util.CommonConfigHelper;
import com.shopdirect.nce.sp.util.FinFileBaseProcessor;
import com.shopdirect.nce.sp.util.StatementProcessorBatchUtil;

/**
 * This class holds the business logic for the following: 1. Load Financier Data
 * into SP Staging tables. 2. Insert Forecast Data.
 * 
 * @author ibm
 *
 */
public class FinancierDataLoadBusinessImpl extends  FinFileBaseProcessor{


	private static SDLoggerImpl logger = new SDLoggerImpl();
	String batchRunDate = "";
	List<TargetedPayment> targetedPaymentRecords = null;
	List<SpErrorLog> errorLogRecords = null;
	boolean isDeleted = false;
	long batchID = 0;
	SpCreditFilLoadControlDaoImpl spCreditFilLoadControlDaoImpl = null;
	AgreementFileProcessorImpl agreementFileProcessor = null;
	DrawDownFileProcessorImpl drawDownTermProcessor = null;
	DrawDownItemFileProcessorImpl drawDownItemProcessor = null;
	NosiaFileProcessorImpl nosiaProcessor = null;
	PeriodPmntFileProcessorImpl periodPmntProcessor = null;
	PPIStatementFileProcessorImpl pPIStatementProcessor = null;
	ServiceChargeFileProcessorImpl serviceChargeProcessor = null;
	TargetedPmntFileProcessorImpl targetedPmntProcessor = null;
	DrawDownTransactionFileProcessorImpl drawDownTransactionFileProcessor;
	ItemTransactionLinkFileProcessorImpl itemTransactionLinkFileProcessor;
	AgreementTriadFileProcessorImpl agreementTriadFileProcessor;
	DrawDownIncomeFileProcessorImpl  drawDownIncomeFileProcessorImpl;
	

	public FinancierDataLoadBusinessImpl() throws StatementProcessorBatchException {
		super();
		setCommonConfigHelper(CommonConfigHelper.getInstance());
		initExternalConfig();
		this.spCreditFilLoadControlDaoImpl = new SpCreditFilLoadControlDaoImpl();
		this.agreementFileProcessor = new AgreementFileProcessorImpl();
		this.drawDownTermProcessor = new DrawDownFileProcessorImpl();
		this.drawDownItemProcessor = new DrawDownItemFileProcessorImpl();
		this.nosiaProcessor = new NosiaFileProcessorImpl();
		this.periodPmntProcessor = new PeriodPmntFileProcessorImpl();
		this.pPIStatementProcessor = new PPIStatementFileProcessorImpl();
		this.serviceChargeProcessor = new ServiceChargeFileProcessorImpl();
		this.targetedPmntProcessor = new TargetedPmntFileProcessorImpl();
		this.drawDownTransactionFileProcessor = new DrawDownTransactionFileProcessorImpl();
		this.itemTransactionLinkFileProcessor = new ItemTransactionLinkFileProcessorImpl();
		this.agreementTriadFileProcessor = new AgreementTriadFileProcessorImpl();
		this.drawDownIncomeFileProcessorImpl = new DrawDownIncomeFileProcessorImpl();
	}



	public boolean dispatch(String user, int batchId, String batchRunDt) throws StatementProcessorBatchException {
		logger.debug("[FinancierDataLoadBusinessImpl -- dispatch]  -- START");
		boolean isValidRequest = false;
		boolean isInserted = false;
		int userId = Integer.parseInt(user);
		try {
			boolean fileNameValidation = isValidFileName(batchRunDt);

			if (fileNameValidation) {
				errorLogRecords = new ArrayList<>();
				isValidRequest = validateRequest();
				batchRunDate = setBatchRunDate(batchRunDt);
				logger.debug("[FinancierDataLoadBusinessImpl -- dispatch]  -- valid request" + isValidRequest);

				if (isValidRequest) {
					try {
						File folder = new File(getFinancierFilePath());

						// get New BatchId for new INSERT
						batchID = spCreditFilLoadControlDaoImpl.fetchBatchId();
						
						boolean insertedAgreement = agreementFileProcessor.processFile(folder, batchID, userId, batchRunDate);
						
						boolean insertedDrawdownTerm = drawDownTermProcessor.processFile(folder, batchID, userId,batchRunDate);
						
						boolean insertedDrawDownItem = drawDownItemProcessor.processFile(folder, batchID, userId,batchRunDate);

						boolean insertedNosia = nosiaProcessor.processFile(folder, batchID, userId,batchRunDate);
						
						boolean insertedPP = periodPmntProcessor.processFile(folder, batchID, userId,batchRunDate);

						boolean insertedPPIStmt = pPIStatementProcessor.processFile(folder, batchID, userId,batchRunDate);

						boolean insertedServiceCharge = serviceChargeProcessor.processFile(folder, batchID, userId,batchRunDate);
						
						boolean insertedTp = targetedPmntProcessor.processFile(folder, batchID, userId,batchRunDate);
						
						boolean insertedDrawdownTransaction = drawDownTransactionFileProcessor.processFile(folder, batchID, userId,batchRunDate);
						
						boolean insertedItemTransactionLink = itemTransactionLinkFileProcessor.processFile(folder, batchID, userId,batchRunDate);
						
						boolean insertedAgreementTriad = agreementTriadFileProcessor.processFile(folder, batchID, userId,batchRunDate);
						
						boolean insertedDrawDownIncome = drawDownIncomeFileProcessorImpl.processFile(folder, batchID, userId,batchRunDate);
						

						if ((insertedAgreement) && (insertedDrawdownTerm) && (insertedDrawDownItem)
								&& (insertedNosia) && (insertedPP) && (insertedPPIStmt)
								&& (insertedServiceCharge) && (insertedTp) && (insertedDrawdownTransaction) 
								&& (insertedItemTransactionLink) && (insertedAgreementTriad)
								&& (insertedDrawDownIncome)) {
							isInserted = true;
						}
						
						if (isInserted) {						
							getLogger().debug("FinancierFileLoadBusinessImpl after chreck load");
							renameFiles(CreditLoadDataConstants.PROCESSED_STATUS);
							return isInserted;
						} 
						else {
							return false;
						}						

					} catch (IOException ioExc) {
						StatementProcessorBatchUtil.printExceptionInformation(ioExc);
						getLogger().error("FinancierDataLoadBusinessImpl IOException " + ioExc.getMessage());
						return false;
					} catch (Exception e) {
						deleteInserted();		
						StatementProcessorBatchUtil.printExceptionInformation(e);
						getLogger().error("FinancierDataLoadBusinessImpl inner TRY generic exception " + e);
						return false;
					}

				}// end of IsValidRequest
			}		
			return isInserted;
		} catch (StatementProcessorBatchException sbe) {
			throw new StatementProcessorBatchException(CreditLoadDataConstants.FILENOTFOUNDERRORCODE,
					"[FinancierDataLoadBusinessImpl-dispatch] ", CreditLoadDataConstants.FILENOTFOUNDERRORDESC, null, null, null);
		}
		catch (Exception e) {
			StatementProcessorBatchUtil.printExceptionInformation(e);
			getLogger().error("FinancierDataLoadBusinessImpl generic exception " + e);
			return false;
		}

	}



	private void deleteInserted() {
		try{
			/**
			 * DELETE ALL THE RECORDS
			 * FROM THE DATABASE
			 */
			isDeleted = deleteAllData(batchID);
			if(isDeleted){
				renameFiles(CreditLoadDataConstants.ERROR_STATUS);
				insertErrorLog(CreditLoadDataConstants.MISMATCH_ON_RECORD_COUNT,
						CreditLoadDataConstants.MISMATCH_RECORD_COUNT_STATUS_MESSAGE, CreditLoadDataConstants.FAIL,
						CreditLoadDataConstants.PROGRAMNAME, CreditLoadDataConstants.STEPNUMBER,
						CreditLoadDataConstants.MISMATCH_RECORD_COUNT_STATUS_MESSAGE,
						CreditLoadDataConstants.STEPSTATUS);				
			}else{
				getLogger().debug("FinancierFileLoadBusinessImpl - Data Deletion Failed ");
			}
		}catch(Exception exception){
			isDeleted = false;
			StatementProcessorBatchUtil.printExceptionInformation(exception);
			getLogger().error("FinancierDataLoadBusinessImpl generic exception " + exception);
		}						

		
	}
	
	
	
}
