package com.shopdirect.nce.sp.model;

import java.math.BigDecimal;

public class BatchGroup {

	private String customerAccountNumber;
	private BigDecimal batchGroupOccurence;
	private BigDecimal valFees;
	private BigDecimal delqNumCycles;
	
	public BatchGroup() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BatchGroup(String customerAccountNumber, BigDecimal batchGroupOccurence, BigDecimal valFees,
			BigDecimal delqNumCycles) {
		super();
		this.customerAccountNumber = customerAccountNumber;
		this.batchGroupOccurence = batchGroupOccurence;
		this.valFees = valFees;
		this.delqNumCycles = delqNumCycles;
	}

	public String getCustomerAccountNumber() {
		return customerAccountNumber;
	}

	public void setCustomerAccountNumber(String customerAccountNumber) {
		this.customerAccountNumber = customerAccountNumber;
	}

	public BigDecimal getBatchGroupOccurence() {
		return batchGroupOccurence;
	}

	public void setBatchGroupOccurence(BigDecimal batchGroupOccurence) {
		this.batchGroupOccurence = batchGroupOccurence;
	}

	public BigDecimal getValFees() {
		return valFees;
	}

	public void setValFees(BigDecimal valFees) {
		this.valFees = valFees;
	}

	public BigDecimal getDelqNumCycles() {
		return delqNumCycles;
	}

	public void setDelqNumCycles(BigDecimal delqNumCycles) {
		this.delqNumCycles = delqNumCycles;
	}
	
	
}
