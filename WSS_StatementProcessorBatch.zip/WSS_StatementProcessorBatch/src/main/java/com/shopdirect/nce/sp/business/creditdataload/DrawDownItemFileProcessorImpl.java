/**
 * 
 */
package com.shopdirect.nce.sp.business.creditdataload;

import java.io.File;
import java.io.FileReader;
import java.io.LineNumberReader;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.shopdirect.nce.sp.constants.CreditLoadDataConstants;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.dao.creditdataload.DrawDownItemDaoImpl;
import com.shopdirect.nce.sp.dao.creditdataload.SpCreditFilLoadControlDaoImpl;
import com.shopdirect.nce.sp.exception.BuisnessException;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.DrawdownItem;
import com.shopdirect.nce.sp.util.FinFileBaseProcessor;
import com.shopdirect.nce.sp.util.StatementProcessorBatchUtil;

/**
 * @author AyantikaBiswas
 *
 */
public class DrawDownItemFileProcessorImpl extends FinFileBaseProcessor implements DataFileProcessor {

	private DrawDownItemDaoImpl drawDownItemDaoImpl;	

	public DrawDownItemFileProcessorImpl() throws StatementProcessorBatchException {
		super();
	}

	/**
	 * @param folder
	 * @return
	 * @throws StatementProcessorBatchException
	 */
	public boolean processFile(File folder, long batchID, int user, String batchRunDate) throws StatementProcessorBatchException {
		getLogger().debug("[DrawDownItemFileProcessorImpl -- processFile]  -- START");
		String fileName = StatementProcessorBatchUtil.generateFileName(CreditLoadDataConstants.DRAWDOWNITEM,
				CreditLoadDataConstants.NEW_STATUS, batchRunDate);
		File file = getFile(folder, fileName);
		String line = "";
		String comma = ",";
		List<Map<String, Object>> columns = getColumns(StatementProcessorBatchConstants.DRAWDOWN_ITEM_DATA_MAPPING,
				StatementProcessorBatchConstants.DRAWDOWN_ITEM_MAP);
		String fileIdentifier = getCommonConfigHelper().readConfigData(getDataconfig(), "DRAWDOWNITEM");
		String insertedMessage = null;
		String errorMessage = StatementProcessorBatchConstants.EMPTY_STRING;
		int insertCount;
		List<DrawdownItem> drawdownItemRecords = null;
		boolean insertedDrawDownItem = false;
		SpCreditFilLoadControlDaoImpl spCreditFilLoadControlDaoImpl = new SpCreditFilLoadControlDaoImpl();
		
		Object[] procReturnVal = new Object[2];
		int retCode = 0;
		String retMsg = null;

		try (LineNumberReader reader = new LineNumberReader(new FileReader(file))) {
			int records = getRecordsCount(this.getFinancierFilePath() + file.getName());
			/**
			 * Insert data in Control Table and pass the Batch Id
			 */
			insertSpLoadControlData(batchID, file.getName(), fileIdentifier, user);
			String header = reader.readLine();
			if(records == StatementProcessorBatchConstants.HEADER_RECORD){
				insertedDrawDownItem = true ;
			}
			else {				
				while ((reader.getLineNumber()) < records) {
					drawdownItemRecords = new ArrayList<>();
					for (insertCount = 0; insertCount<getBatchInsertcount() ;insertCount++ ){					
						if ((line = reader.readLine())!= null){	
							String[] contents = line.split(comma, -1);
							//Check number of data in xml and .dat file is same or not
							if (columns.size() != contents.length) {
								throw new Exception(CreditLoadDataConstants.MISMATCH_ON_COLUMN_COUNT);
							}
							DrawdownItem drawDownItem = new DrawdownItem();
							// Set batchId in DrawdownItem
							drawDownItem.setBatchId(batchID);
							drawDownItem.setCreatedByUser(Long.valueOf(user));
							drawdownItemRecords.add(drawDownItem);
							constructObjects(contents, columns, drawDownItem);
						} else{
							break;
						}
					}
					procReturnVal = getDrawDownItemDaoImpl().insertDrawDownItemtData(drawdownItemRecords);
					retCode = (int) procReturnVal[0];
					retMsg = (String) procReturnVal[1];
					
					// update the CONTROL table and DELETE if INSERTION fails
					if (retCode == 0) {
						insertedDrawDownItem = true;
					} else {
						insertedDrawDownItem = false;
						errorMessage = retMsg;
					}				
				}
			}

			/**
			 * Update the CONTROL table with batch id and error messege
			 */
			spCreditFilLoadControlDaoImpl.updateControlData(batchID, insertedDrawDownItem, errorMessage, fileIdentifier);

		} catch (Exception exception) {
			insertedMessage = exception.getMessage();
			errorMessage = insertedMessage;
			insertedDrawDownItem = false;
			/**
			 * Update the CONTROL table with batch id and error messege
			 */
			try {
				spCreditFilLoadControlDaoImpl.updateControlData(batchID, insertedDrawDownItem, errorMessage, fileIdentifier);
			} catch (BuisnessException buisnessException) {
				getLogger()
						.debug("[DrawDownItemFileProcessorImpl -- processFile] -- Control Table Update Exception: "
								+ buisnessException);
			} catch (SQLException sqlException) {
				getLogger()
						.debug("[DrawDownItemFileProcessorImpl -- processFile] -- Control Table Update Exception: "
								+ sqlException);
			} catch (Exception exception2) {
				getLogger()
						.debug("[DrawDownItemFileProcessorImpl -- processFile] -- Control Table Update Exception: "
								+ exception2);
			}

			getLogger()
					.error("[DrawDownItemFileProcessorImpl -- processFile] -- Drawdown Item insert Error occured");
			getLogger().debug(
					"[DrawDownItemFileProcessorImpl -- processFile] -- Drawdown Item Exception: " + exception);
			
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_BUSINESS_ERROR_CODE,
					"[DrawDownItemFileProcessorImpl-processDrawdownItem] StatementProcessorBatchException Block",
					"Drawdown Item Exception " + errorMessage, null, null,
					new StatementProcessorBatchException());
		}
		getLogger().debug("[DrawDownItemFileProcessorImpl -- processFile]  -- END");
		return insertedDrawDownItem;
	}
	
	/**
	 * @return the drawDownItemDaoImpl
	 * @throws StatementProcessorBatchException 
	 */
	public DrawDownItemDaoImpl getDrawDownItemDaoImpl() throws StatementProcessorBatchException {
		if(drawDownItemDaoImpl == null) {
			drawDownItemDaoImpl = new DrawDownItemDaoImpl();
		}
		return drawDownItemDaoImpl;
	}

	/**
	 * @param drawDownItemDaoImpl the drawDownItemDaoImpl to set
	 */
	public void setDrawDownItemDaoImpl(DrawDownItemDaoImpl drawDownItemDaoImpl) {
		this.drawDownItemDaoImpl = drawDownItemDaoImpl;
	}	
}
