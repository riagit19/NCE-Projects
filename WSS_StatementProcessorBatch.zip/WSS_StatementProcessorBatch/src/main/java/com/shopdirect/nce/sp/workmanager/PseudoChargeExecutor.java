package com.shopdirect.nce.sp.workmanager;

import java.util.concurrent.Callable;

import com.shopdirect.nce.sp.business.AccountReassessmentBaseBusinessImpl;
import com.shopdirect.nce.sp.business.PseudoChargeCalculationBusinessImpl;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.CustomerAccountInfo;
import com.shopdirect.nce.sp.model.PseudoChargeResponseType;

/**
 * 
 * @author SudiptaRoy
 *
 */
public class PseudoChargeExecutor extends AccountReassessmentBaseBusinessImpl
		implements Callable<PseudoChargeExecutor> {

	CustomerAccountInfo customerAccountInfo;
	PseudoChargeResponseType pseudoChargeResponse;
	
	public PseudoChargeExecutor() throws StatementProcessorBatchException {
		// Default Constructor
	}

	public PseudoChargeExecutor(CustomerAccountInfo customerAccountInfo) throws StatementProcessorBatchException {
		this.customerAccountInfo = customerAccountInfo;
	}

	@Override
	public PseudoChargeExecutor call() throws Exception {
		getLogger().debug("[PseudoChargeExecutor -- Call] -- Start"); 
		Integer linkedAccountIndex = getCustomerAccountInfo().getLinkedAccntIndex();
		boolean isLinkedAccount = isLinkAccount(linkedAccountIndex);
		if (isLinkedAccount) {
			PseudoChargeCalculationBusinessImpl pseudoChargeImpl = new PseudoChargeCalculationBusinessImpl();
			long start = System.currentTimeMillis();
			pseudoChargeResponse = pseudoChargeImpl.process(getCustomerAccountInfo());
			long time = System.currentTimeMillis() - start;
			getLogger().debug("||| Pseudo Charge took " + logTime(time)); 
		}
		getLogger().debug("[PseudoChargeExecutor -- Call] -- End"); 
		return this;
	}
	
	private String logTime(long time) {
		return time + "ms for Public Account No. " + getCustomerAccountInfo().getPublicAccountId() + " and Customer Id "
				+ getCustomerAccountInfo().getCustomerId();
	}


	/**
	 * @return the customerAccountInfo
	 */
	public CustomerAccountInfo getCustomerAccountInfo() {
		return customerAccountInfo;
	}

	/**
	 * @param customerAccountInfo
	 *            the customerAccountInfo to set
	 */
	public void setCustomerAccountInfo(CustomerAccountInfo customerAccountInfo) {
		this.customerAccountInfo = customerAccountInfo;
	}

	/**
	 * @return the pseudoChargeResponse
	 */
	public PseudoChargeResponseType getPseudoChargeResponse() {
		return pseudoChargeResponse;
	}

	/**
	 * @param pseudoChargeResponse the pseudoChargeResponse to set
	 */
	public void setPseudoChargeResponse(PseudoChargeResponseType pseudoChargeResponse) {
		this.pseudoChargeResponse = pseudoChargeResponse;
	}

}
