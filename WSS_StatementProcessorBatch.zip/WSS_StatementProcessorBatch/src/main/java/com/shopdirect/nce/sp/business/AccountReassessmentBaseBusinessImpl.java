/**
 * 
 */
package com.shopdirect.nce.sp.business;

import com.shopdirect.nce.common.extcnfg.ExternalFileDataConfiguration;
import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.util.CommonConfigHelper;

/**
 * @author amitkumar4
 *
 */
public class AccountReassessmentBaseBusinessImpl {
	
	private static SDLoggerImpl logger = new SDLoggerImpl();
	
	private CommonConfigHelper commonConfigHelper = null;
	private ExternalFileDataConfiguration extFileDataCfg = null;
	
	/**
	 * Default Constructor
	 * @throws StatementProcessorBatchException
	 */
	public AccountReassessmentBaseBusinessImpl() throws StatementProcessorBatchException {
		setCommonConfigHelper(CommonConfigHelper.getInstance());
		initExternalConfig();
	}

    /**
     * Configuration Object creation 
     * @throws StatementProcessorBatchException 
     */
	protected void initExternalConfig() throws StatementProcessorBatchException  {
		logger.debug("[AccountReassessmentBaseBusinessImpl -- initExternalConfig]  -- START");
		
		 this.extFileDataCfg = getCommonConfigHelper().loadPropertyConfig(StatementProcessorBatchConstants.AUDITLOG_CONFIGURATION_FILE_KEY);
		
		logger.debug("[AccountReassessmentBaseBusinessImpl -- initExternalConfig]  -- END");
	}
	/**
	 * IF the account is a Linked Account , (CIM_ACCOUNT_INFO.LINKED_ACCOUNT_INDEX==1 ) then retun true else false.
	 * @param linkedAccntIndex
	 * @return boolean 
	 */
	protected boolean isLinkAccount(Integer linkedAccntIndex) {
		logger.debug("[AccountReassessmentBaseBusinessImpl -- isLinkAccount]  -- START");
		boolean isLinkedAccount = false;
		String linkAcctVal =  getExtFileDataCfg().getConfigData(StatementProcessorBatchConstants.LINKED_ACCOUNT_INDEX_KEY);
		if(linkAcctVal != null && linkedAccntIndex != null && linkedAccntIndex.equals(Integer.parseInt(linkAcctVal))) {
			isLinkedAccount = true;
		}
		logger.debug("[AccountReassessmentBaseBusinessImpl -- isLinkAccount]  -- END");
		return isLinkedAccount;
	}

	public CommonConfigHelper getCommonConfigHelper() {
		return commonConfigHelper;
	}


	public void setCommonConfigHelper(CommonConfigHelper commonConfigHelper) {
		this.commonConfigHelper = commonConfigHelper;
	}


	public ExternalFileDataConfiguration getExtFileDataCfg() {
		return extFileDataCfg;
	}


	public void setExtFileDataCfg(ExternalFileDataConfiguration extFileDataCfg) {
		this.extFileDataCfg = extFileDataCfg;
	}


	public SDLoggerImpl getLogger() {
		return logger;
	}
	
	

}
