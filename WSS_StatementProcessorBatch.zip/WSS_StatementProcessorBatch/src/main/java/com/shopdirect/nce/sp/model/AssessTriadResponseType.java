package com.shopdirect.nce.sp.model;

public class AssessTriadResponseType {

	private String accountNumber;
	private Integer callType;
	private CreditLimit creditLimit;

	/**
	 * @return the accountNumber
	 */
	public String getAccountNumber() {
		return accountNumber;
	}

	/**
	 * @param accountNumber
	 *            the accountNumber to set
	 */
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	/**
	 * @return the callType
	 */
	public Integer getCallType() {
		return callType;
	}

	/**
	 * @param callType
	 *            the callType to set
	 */
	public void setCallType(Integer callType) {
		this.callType = callType;
	}

	/**
	 * @return the creditLimit
	 */
	public CreditLimit getCreditLimit() {
		return creditLimit;
	}

	/**
	 * @param creditLimit
	 *            the creditLimit to set
	 */
	public void setCreditLimit(CreditLimit creditLimit) {
		this.creditLimit = creditLimit;
	}

}
