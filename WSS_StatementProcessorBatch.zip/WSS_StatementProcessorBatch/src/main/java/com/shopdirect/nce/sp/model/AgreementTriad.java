package com.shopdirect.nce.sp.model;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.SQLData;
import java.sql.SQLException;
import java.sql.SQLInput;
import java.sql.SQLOutput;

public class AgreementTriad implements SQLData{

	private String sqlType;
	private String agreementID;
	private BigDecimal fnStatNo;
	private Date statementDate;
	private BigDecimal creditLimit;
	private BigDecimal lastPayMethod;
	private BigDecimal balance;
	private Date lastMIVDate;
	private Date lastOrderDate;
	private Date lastPayDate;
	private Date nextPaymentDueDate;
	private Date lastStatementDate;
	private Date nextStatementDate;
	private Date dateSection87;
	private Date nsfDate;
	private String payDateAmtList;
	private BigDecimal scheduledPaymentAmt;
	private BigDecimal scheduledPaymentPastDue;
	private BigDecimal pastDueAmt;
	private BigDecimal availableToSpend;
	private BigDecimal bnplBalance;
	private BigDecimal apr;
	private BigDecimal totPay30Days;
	private BigDecimal instArrears;
	private Date lastArrangementDate;
	private BigDecimal payAmtTSP;
	private Date lastZeroBal;
	private BigDecimal returnsAmtTSP;
	private BigDecimal otherAdjAmtTSP;
	private BigDecimal lastPayAmt;
	private BigDecimal paymentPreviousIND;
	private BigDecimal paymentCurrentIND;
	private BigDecimal numPurchasesTSP;
	private BigDecimal totFeesTSP;
	private BigDecimal custCreditsTSP;
	private BigDecimal totPayYear;
	private BigDecimal numPayTSP;
	private BigDecimal intChargedTSP;
	private BigDecimal purchaseAmtTSP;
	private BigDecimal rebatesAmtTSP;
	private BigDecimal bnplIntAmtTSP;
	private BigDecimal numRetPayTSP;
	private BigDecimal lastArrearsWks;
	private BigDecimal creditLimitUtil;
	private BigDecimal lastPaymentDays;
	private BigDecimal nillBalanceDays;
	private Date createdDate;
	private BigDecimal takeAll;
	
	
	public AgreementTriad() {
		// Default Constructor
	}

	public AgreementTriad(String agreementID, BigDecimal fnStatNo, Date statementDate, BigDecimal creditLimit,
			BigDecimal lastPayMethod, BigDecimal balance, Date lastMIVDate, Date lastOrderDate, Date lastPayDate,
			Date nextPaymentDueDate, Date lastStatementDate, Date nextStatementDate, Date dateSection87, Date nsfDate,
			String payDateAmtList, BigDecimal scheduledPaymentAmt, BigDecimal scheduledPaymentPastDue,
			BigDecimal pastDueAmt, BigDecimal availableToSpend, BigDecimal bnplBalance, BigDecimal apr,
			BigDecimal totPay30Days, BigDecimal instArrears, Date lastArrangementDate, BigDecimal payAmtTSP,
			Date lastZeroBal, BigDecimal returnsAmtTSP, BigDecimal otherAdjAmtTSP, BigDecimal lastPayAmt,
			BigDecimal paymentPreviousIND, BigDecimal paymentCurrentIND, BigDecimal numPurchasesTSP,
			BigDecimal totFeesTSP, BigDecimal custCreditsTSP, BigDecimal totPayYear, BigDecimal numPayTSP,
			BigDecimal intChargedTSP, BigDecimal purchaseAmtTSP, BigDecimal rebatesAmtTSP, BigDecimal bnplIntAmtTSP,
			BigDecimal numRetPayTSP, BigDecimal lastArrearsWks, BigDecimal creditLimitUtil, BigDecimal lastPaymentDays,
			BigDecimal nillBalanceDays, Date createdDat, BigDecimal takeAlle) {
		super();
		this.agreementID = agreementID;
		this.fnStatNo = fnStatNo;
		this.statementDate = statementDate;
		this.creditLimit = creditLimit;
		this.lastPayMethod = lastPayMethod;
		this.balance = balance;
		this.lastMIVDate = lastMIVDate;
		this.lastOrderDate = lastOrderDate;
		this.lastPayDate = lastPayDate;
		this.nextPaymentDueDate = nextPaymentDueDate;
		this.lastStatementDate = lastStatementDate;
		this.nextStatementDate = nextStatementDate;
		this.dateSection87 = dateSection87;
		this.nsfDate = nsfDate;
		this.payDateAmtList = payDateAmtList;
		this.scheduledPaymentAmt = scheduledPaymentAmt;
		this.scheduledPaymentPastDue = scheduledPaymentPastDue;
		this.pastDueAmt = pastDueAmt;
		this.availableToSpend = availableToSpend;
		this.bnplBalance = bnplBalance;
		this.apr = apr;
		this.totPay30Days = totPay30Days;
		this.instArrears = instArrears;
		this.lastArrangementDate = lastArrangementDate;
		this.payAmtTSP = payAmtTSP;
		this.lastZeroBal = lastZeroBal;
		this.returnsAmtTSP = returnsAmtTSP;
		this.otherAdjAmtTSP = otherAdjAmtTSP;
		this.lastPayAmt = lastPayAmt;
		this.paymentPreviousIND = paymentPreviousIND;
		this.paymentCurrentIND = paymentCurrentIND;
		this.numPurchasesTSP = numPurchasesTSP;
		this.totFeesTSP = totFeesTSP;
		this.custCreditsTSP = custCreditsTSP;
		this.totPayYear = totPayYear;
		this.numPayTSP = numPayTSP;
		this.intChargedTSP = intChargedTSP;
		this.purchaseAmtTSP = purchaseAmtTSP;
		this.rebatesAmtTSP = rebatesAmtTSP;
		this.bnplIntAmtTSP = bnplIntAmtTSP;
		this.numRetPayTSP = numRetPayTSP;
		this.lastArrearsWks = lastArrearsWks;
		this.creditLimitUtil = creditLimitUtil;
		this.lastPaymentDays = lastPaymentDays;
		this.nillBalanceDays = nillBalanceDays;
		this.createdDate = createdDate;
		this.takeAll = takeAll;
	}

	@Override
	public void readSQL(SQLInput stream, String typeName) throws SQLException {
		
		sqlType = typeName;
		setAgreementID(stream.readString());
		setFnStatNo(stream.readBigDecimal());
		setStatementDate(stream.readDate());
		setCreditLimit(stream.readBigDecimal());
		setLastPayMethod(stream.readBigDecimal());
		setBalance(stream.readBigDecimal());
		setLastMIVDate(stream.readDate());
		setLastOrderDate(stream.readDate());
		setLastPayDate(stream.readDate());
		setNextPaymentDueDate(stream.readDate());
		setLastStatementDate(stream.readDate());
		setNextStatementDate(stream.readDate());
		setDateSection87(stream.readDate());
		setNsfDate(stream.readDate());
		setPayDateAmtList(stream.readString());
		setScheduledPaymentAmt(stream.readBigDecimal());
		setScheduledPaymentPastDue(stream.readBigDecimal());
		setPastDueAmt(stream.readBigDecimal());
		setAvailableToSpend(stream.readBigDecimal());
		setBnplBalance(stream.readBigDecimal());
		setApr(stream.readBigDecimal());
		setTotPay30Days(stream.readBigDecimal());
		setInstArrears(stream.readBigDecimal());
		setLastArrangementDate(stream.readDate());
		setPayAmtTSP(stream.readBigDecimal());
		setLastZeroBal(stream.readDate());
		setReturnsAmtTSP(stream.readBigDecimal());
		setOtherAdjAmtTSP(stream.readBigDecimal());
		setLastPayAmt(stream.readBigDecimal());
		setPaymentPreviousIND(stream.readBigDecimal());
		setPaymentCurrentIND(stream.readBigDecimal());
		setNumPurchasesTSP(stream.readBigDecimal());
		setTotFeesTSP(stream.readBigDecimal());
		setCustCreditsTSP(stream.readBigDecimal());
		setTotPayYear(stream.readBigDecimal());
		setNumPayTSP(stream.readBigDecimal());
		setIntChargedTSP(stream.readBigDecimal());
		setPurchaseAmtTSP(stream.readBigDecimal());
		setRebatesAmtTSP(stream.readBigDecimal());
		setBnplIntAmtTSP(stream.readBigDecimal());
		setNumRetPayTSP(stream.readBigDecimal());
		setLastArrearsWks(stream.readBigDecimal());
		setCreditLimitUtil(stream.readBigDecimal());
		setLastPaymentDays(stream.readBigDecimal());
		setNillBalanceDays(stream.readBigDecimal());
		setTakeAll(stream.readBigDecimal());
		
	}
			
	@Override
	public void writeSQL(SQLOutput stream) throws SQLException {
		
	}

	@Override
	public String getSQLTypeName() throws SQLException {
		return sqlType;
	}

	public String getSqlType() {
		return sqlType;
	}

	public void setSqlType(String sqlType) {
		this.sqlType = sqlType;
	}

	public String getAgreementID() {
		return agreementID;
	}

	public void setAgreementID(String agreementID) {
		this.agreementID = agreementID;
	}

	public BigDecimal getFnStatNo() {
		return fnStatNo;
	}

	public void setFnStatNo(BigDecimal fnStatNo) {
		this.fnStatNo = fnStatNo;
	}

	public Date getStatementDate() {
		return statementDate;
	}

	public void setStatementDate(Date statementDate) {
		this.statementDate = statementDate;
	}

	public BigDecimal getCreditLimit() {
		return creditLimit;
	}

	public void setCreditLimit(BigDecimal creditLimit) {
		this.creditLimit = creditLimit;
	}

	public BigDecimal getLastPayMethod() {
		return lastPayMethod;
	}

	public void setLastPayMethod(BigDecimal lastPayMethod) {
		this.lastPayMethod = lastPayMethod;
	}

	public BigDecimal getBalance() {
		return balance;
	}

	public void setBalance(BigDecimal balance) {
		this.balance = balance;
	}

	public Date getLastMIVDate() {
		return lastMIVDate;
	}

	public void setLastMIVDate(Date lastMIVDate) {
		this.lastMIVDate = lastMIVDate;
	}

	public Date getLastOrderDate() {
		return lastOrderDate;
	}

	public void setLastOrderDate(Date lastOrderDate) {
		this.lastOrderDate = lastOrderDate;
	}

	public Date getLastPayDate() {
		return lastPayDate;
	}

	public void setLastPayDate(Date lastPayDate) {
		this.lastPayDate = lastPayDate;
	}

	public Date getNextPaymentDueDate() {
		return nextPaymentDueDate;
	}

	public void setNextPaymentDueDate(Date nextPaymentDueDate) {
		this.nextPaymentDueDate = nextPaymentDueDate;
	}

	public Date getLastStatementDate() {
		return lastStatementDate;
	}

	public void setLastStatementDate(Date lastStatementDate) {
		this.lastStatementDate = lastStatementDate;
	}

	public Date getNextStatementDate() {
		return nextStatementDate;
	}

	public void setNextStatementDate(Date nextStatementDate) {
		this.nextStatementDate = nextStatementDate;
	}

	public Date getDateSection87() {
		return dateSection87;
	}

	public void setDateSection87(Date dateSection87) {
		this.dateSection87 = dateSection87;
	}

	public Date getNsfDate() {
		return nsfDate;
	}

	public void setNsfDate(Date nsfDate) {
		this.nsfDate = nsfDate;
	}

	public String getPayDateAmtList() {
		return payDateAmtList;
	}

	public void setPayDateAmtList(String payDateAmtList) {
		this.payDateAmtList = payDateAmtList;
	}

	public BigDecimal getScheduledPaymentAmt() {
		return scheduledPaymentAmt;
	}

	public void setScheduledPaymentAmt(BigDecimal scheduledPaymentAmt) {
		this.scheduledPaymentAmt = scheduledPaymentAmt;
	}

	public BigDecimal getScheduledPaymentPastDue() {
		return scheduledPaymentPastDue;
	}

	public void setScheduledPaymentPastDue(BigDecimal scheduledPaymentPastDue) {
		this.scheduledPaymentPastDue = scheduledPaymentPastDue;
	}

	public BigDecimal getPastDueAmt() {
		return pastDueAmt;
	}

	public void setPastDueAmt(BigDecimal pastDueAmt) {
		this.pastDueAmt = pastDueAmt;
	}

	public BigDecimal getAvailableToSpend() {
		return availableToSpend;
	}

	public void setAvailableToSpend(BigDecimal availableToSpend) {
		this.availableToSpend = availableToSpend;
	}

	public BigDecimal getBnplBalance() {
		return bnplBalance;
	}

	public void setBnplBalance(BigDecimal bnplBalance) {
		this.bnplBalance = bnplBalance;
	}

	public BigDecimal getApr() {
		return apr;
	}

	public void setApr(BigDecimal apr) {
		this.apr = apr;
	}

	public BigDecimal getTotPay30Days() {
		return totPay30Days;
	}

	public void setTotPay30Days(BigDecimal totPay30Days) {
		this.totPay30Days = totPay30Days;
	}

	public BigDecimal getInstArrears() {
		return instArrears;
	}

	public void setInstArrears(BigDecimal instArrears) {
		this.instArrears = instArrears;
	}

	public Date getLastArrangementDate() {
		return lastArrangementDate;
	}

	public void setLastArrangementDate(Date lastArrangementDate) {
		this.lastArrangementDate = lastArrangementDate;
	}

	public BigDecimal getPayAmtTSP() {
		return payAmtTSP;
	}

	public void setPayAmtTSP(BigDecimal payAmtTSP) {
		this.payAmtTSP = payAmtTSP;
	}

	public Date getLastZeroBal() {
		return lastZeroBal;
	}

	public void setLastZeroBal(Date lastZeroBal) {
		this.lastZeroBal = lastZeroBal;
	}

	public BigDecimal getReturnsAmtTSP() {
		return returnsAmtTSP;
	}

	public void setReturnsAmtTSP(BigDecimal returnsAmtTSP) {
		this.returnsAmtTSP = returnsAmtTSP;
	}

	public BigDecimal getOtherAdjAmtTSP() {
		return otherAdjAmtTSP;
	}

	public void setOtherAdjAmtTSP(BigDecimal otherAdjAmtTSP) {
		this.otherAdjAmtTSP = otherAdjAmtTSP;
	}

	public BigDecimal getLastPayAmt() {
		return lastPayAmt;
	}

	public void setLastPayAmt(BigDecimal lastPayAmt) {
		this.lastPayAmt = lastPayAmt;
	}

	public BigDecimal getPaymentPreviousIND() {
		return paymentPreviousIND;
	}

	public void setPaymentPreviousIND(BigDecimal paymentPreviousIND) {
		this.paymentPreviousIND = paymentPreviousIND;
	}

	public BigDecimal getPaymentCurrentIND() {
		return paymentCurrentIND;
	}

	public void setPaymentCurrentIND(BigDecimal paymentCurrentIND) {
		this.paymentCurrentIND = paymentCurrentIND;
	}

	public BigDecimal getNumPurchasesTSP() {
		return numPurchasesTSP;
	}

	public void setNumPurchasesTSP(BigDecimal numPurchasesTSP) {
		this.numPurchasesTSP = numPurchasesTSP;
	}

	public BigDecimal getTotFeesTSP() {
		return totFeesTSP;
	}

	public void setTotFeesTSP(BigDecimal totFeesTSP) {
		this.totFeesTSP = totFeesTSP;
	}

	public BigDecimal getCustCreditsTSP() {
		return custCreditsTSP;
	}

	public void setCustCreditsTSP(BigDecimal custCreditsTSP) {
		this.custCreditsTSP = custCreditsTSP;
	}

	public BigDecimal getTotPayYear() {
		return totPayYear;
	}

	public void setTotPayYear(BigDecimal totPayYear) {
		this.totPayYear = totPayYear;
	}

	public BigDecimal getNumPayTSP() {
		return numPayTSP;
	}

	public void setNumPayTSP(BigDecimal numPayTSP) {
		this.numPayTSP = numPayTSP;
	}

	public BigDecimal getIntChargedTSP() {
		return intChargedTSP;
	}

	public void setIntChargedTSP(BigDecimal intChargedTSP) {
		this.intChargedTSP = intChargedTSP;
	}

	public BigDecimal getPurchaseAmtTSP() {
		return purchaseAmtTSP;
	}

	public void setPurchaseAmtTSP(BigDecimal purchaseAmtTSP) {
		this.purchaseAmtTSP = purchaseAmtTSP;
	}

	public BigDecimal getRebatesAmtTSP() {
		return rebatesAmtTSP;
	}

	public void setRebatesAmtTSP(BigDecimal rebatesAmtTSP) {
		this.rebatesAmtTSP = rebatesAmtTSP;
	}

	public BigDecimal getBnplIntAmtTSP() {
		return bnplIntAmtTSP;
	}

	public void setBnplIntAmtTSP(BigDecimal bnplIntAmtTSP) {
		this.bnplIntAmtTSP = bnplIntAmtTSP;
	}

	public BigDecimal getNumRetPayTSP() {
		return numRetPayTSP;
	}

	public void setNumRetPayTSP(BigDecimal numRetPayTSP) {
		this.numRetPayTSP = numRetPayTSP;
	}

	public BigDecimal getLastArrearsWks() {
		return lastArrearsWks;
	}

	public void setLastArrearsWks(BigDecimal lastArrearsWks) {
		this.lastArrearsWks = lastArrearsWks;
	}

	public BigDecimal getCreditLimitUtil() {
		return creditLimitUtil;
	}

	public void setCreditLimitUtil(BigDecimal creditLimitUtil) {
		this.creditLimitUtil = creditLimitUtil;
	}

	public BigDecimal getLastPaymentDays() {
		return lastPaymentDays;
	}

	public void setLastPaymentDays(BigDecimal lastPaymentDays) {
		this.lastPaymentDays = lastPaymentDays;
	}

	public BigDecimal getNillBalanceDays() {
		return nillBalanceDays;
	}

	public void setNillBalanceDays(BigDecimal nillBalanceDays) {
		this.nillBalanceDays = nillBalanceDays;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public BigDecimal getTakeAll() {
		return takeAll;
	}

	public void setTakeAll(BigDecimal takeAll) {
		this.takeAll = takeAll;
	}
	
	
}
