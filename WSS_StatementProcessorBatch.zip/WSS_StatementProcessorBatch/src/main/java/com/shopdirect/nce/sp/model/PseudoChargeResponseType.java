/**
 * 
 */
package com.shopdirect.nce.sp.model;

import java.math.BigDecimal;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

import com.shopdirect.fcm.xsd.forecastmodeller.PseudoChargeInfoByCustomerType;
import com.shopdirect.fcm.xsd.forecastmodeller.PseudoChargeInfoByDDTType;
import com.shopdirect.fcm.xsd.forecastmodeller.PseudoChargeRespType;

/**
 * @author VijayaprakashPrathip
 *
 */

@XmlRootElement
public class PseudoChargeResponseType {

	private String ddtId;
	private BigDecimal amendedPrevSchPayment;
	private BigDecimal pastDueAmount;
	private BigDecimal minIntfreePayment;
	private BigDecimal sppdRate;
	private BigDecimal futureDue;
	private PseudoChargeInfoByCustomerType pseudoChargeInfoType;
	private List<PseudoChargeInfoByDDTType> pseudoChargeInfoByDDTType;
	private PseudoChargeRespType pseudoChargeRespType;
	
	public PseudoChargeResponseType() {}
	
	public PseudoChargeResponseType(String ddtId1, BigDecimal amendedPrevSchPayment1, BigDecimal pastDueAmount1,
			BigDecimal minIntfreePayment1, BigDecimal sppdRate1, BigDecimal futureDue1, PseudoChargeInfoByCustomerType pseudoChargeInfoType1,
			List<PseudoChargeInfoByDDTType> pseudoChargeInfoByDDTType1, PseudoChargeRespType pseudoChargeRespType1){
		
		ddtId = ddtId1;
		amendedPrevSchPayment = amendedPrevSchPayment1;
		pastDueAmount = pastDueAmount1;
		minIntfreePayment = minIntfreePayment1;
		sppdRate = sppdRate1;
		futureDue = futureDue1;
		pseudoChargeInfoType = pseudoChargeInfoType1;
		pseudoChargeInfoByDDTType = pseudoChargeInfoByDDTType1;
		pseudoChargeRespType = pseudoChargeRespType1;
	}
	
	/**
	 * @return the ddtId
	 */
	public String getDdtId() {
		return ddtId;
	}
	/**
	 * @param ddtId the ddtId to set
	 */
	public void setDdtId(String ddtId) {
		this.ddtId = ddtId;
	}
	/**
	 * @return the amendedPrevSchPayment
	 */
	public BigDecimal getAmendedPrevSchPayment() {
		return amendedPrevSchPayment;
	}
	/**
	 * @param amendedPrevSchPayment the amendedPrevSchPayment to set
	 */
	public void setAmendedPrevSchPayment(BigDecimal amendedPrevSchPayment) {
		this.amendedPrevSchPayment = amendedPrevSchPayment;
	}
	/**
	 * @return the pastDueAmount
	 */
	public BigDecimal getPastDueAmount() {
		return pastDueAmount;
	}
	/**
	 * @param pastDueAmount the pastDueAmount to set
	 */
	public void setPastDueAmount(BigDecimal pastDueAmount) {
		this.pastDueAmount = pastDueAmount;
	}
	/**
	 * @return the minIntfreePayment
	 */
	public BigDecimal getMinIntfreePayment() {
		return minIntfreePayment;
	}
	/**
	 * @param minIntfreePayment the minIntfreePayment to set
	 */
	public void setMinIntfreePayment(BigDecimal minIntfreePayment) {
		this.minIntfreePayment = minIntfreePayment;
	}
	/**
	 * @return the sppdRate
	 */
	public BigDecimal getSppdRate() {
		return sppdRate;
	}
	/**
	 * @param sppdRate the sppdRate to set
	 */
	public void setSppdRate(BigDecimal sppdRate) {
		this.sppdRate = sppdRate;
	}
	/**
	 * @return the futureDue
	 */
	public BigDecimal getFutureDue() {
		return futureDue;
	}
	/**
	 * @param futureDue the futureDue to set
	 */
	public void setFutureDue(BigDecimal futureDue) {
		this.futureDue = futureDue;
	}
	
	/**
	 * @return the pseudoChargeInfoType
	 */
	public PseudoChargeInfoByCustomerType getPseudoChargeInfoType() {
		return pseudoChargeInfoType;
	}

	/**
	 * @param pseudoChargeInfoType the pseudoChargeInfoType to set
	 */
	public void setPseudoChargeInfoType(PseudoChargeInfoByCustomerType pseudoChargeInfoType) {
		this.pseudoChargeInfoType = pseudoChargeInfoType;
	}
	
	/**
	 * @param pseudoChargeInfoByDDTType the pseudoChargeInfoByDDTType to set
	 */
	public void setPseudoChargeInfoByDDTType(List<PseudoChargeInfoByDDTType> pseudoChargeInfoByDDTType) {
		this.pseudoChargeInfoByDDTType = pseudoChargeInfoByDDTType;
	}

	/**
	 * @return the pseudoChargeRespType
	 */
	public PseudoChargeRespType getPseudoChargeRespType() {
		return pseudoChargeRespType;
	}

	/**
	 * @param pseudoChargeRespType the pseudoChargeRespType to set
	 */
	public void setPseudoChargeRespType(PseudoChargeRespType pseudoChargeRespType) {
		this.pseudoChargeRespType = pseudoChargeRespType;
	}
}
