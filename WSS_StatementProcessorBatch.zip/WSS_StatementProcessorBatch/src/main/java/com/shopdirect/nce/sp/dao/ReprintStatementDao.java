package com.shopdirect.nce.sp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.Query;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.CustomerAccountInfo;
import com.shopdirect.nce.sp.util.UCPConnection;

public class ReprintStatementDao extends AccountReassessmentBaseDao {

	public ReprintStatementDao() throws StatementProcessorBatchException {
		super();

	}

	SDLoggerImpl logger = new SDLoggerImpl();

	public List getReprintAccountList() throws Exception {

		Connection con = UCPConnection.getConnection();
		List accountList = null;
		try {
			logger.debug("[ReprintStatementDao -- getReprintAccountList] -- Start");

			String queryStr = Query.getAccountList(getSpMainSchema()).toString();
			logger.info("***********************" + queryStr);

			PreparedStatement stmt = con.prepareStatement(queryStr);

			ResultSet result = stmt.executeQuery();

			accountList = new ArrayList();
			while (result.next()) {
				accountList.add(result.getString("ACCOUNT_NUMBER"));

			}

		} catch (SQLException e) {
			getLogger().error("[ReprintStatementDao -- getReprintAccountList] -- SQLException: " + e);
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_BUSINESS_ERROR_CODE,
					"[ReprintStatementDao -- getReprintAccountList] Exception Block",
					"exception generated at time to process PERIODIC_STATEMENT " + e.getMessage(),
					StatementProcessorBatchConstants.ERROR_CUST_STATUS, null, e);

		} finally {
			if (con != null) {
				con.close();
			}
		}
		logger.debug("[ReprintStatementDao -- getReprintAccountList] -- End");
		return accountList;
	}

	public void populateCimAccInfo(CustomerAccountInfo custInfo) throws Exception {

		Connection con = UCPConnection.getConnection();
		List accountList = null;
		try {
			logger.debug("[ReprintStatementDao -- populateCimAccInfo] -- Start");
			Timestamp timestamp = new Timestamp(System.currentTimeMillis());
			String queryStr = Query.insertAccountList(getSpMainSchema(),custInfo,timestamp).toString();
			logger.info("***********************" + queryStr);

			PreparedStatement stmt = con.prepareStatement(queryStr);

			int result = stmt.executeUpdate();

			if(result>0) {
				logger.debug("[ReprintStatementDao -- populateCimAccInfo] result "+result);

			}
			

		} catch (SQLException e) {

			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_BUSINESS_ERROR_CODE,
					"[ReprintStatementDao -- populateCimAccInfo] -- Exception ",
					"exception generated at time to populateCimAccInfo " + e.getMessage(),
					StatementProcessorBatchConstants.ERROR_CUST_STATUS, null, e);

		} finally {
			if (con != null) {
				con.close();
			}
		}
		logger.debug("[ReprintStatementDao -- populateCimAccInfo] -- End");
		
	}
}
