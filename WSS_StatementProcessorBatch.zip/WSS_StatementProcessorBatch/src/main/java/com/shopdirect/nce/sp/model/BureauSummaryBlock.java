package com.shopdirect.nce.sp.model;

import java.sql.SQLData;
import java.sql.SQLException;
import java.sql.SQLInput;
import java.sql.SQLOutput;
import java.util.Date;

public class BureauSummaryBlock implements SQLData {

	private String sqlType;
	private String retailAccountNumber;
	private Date timestampCreated;
	private Date timestampUpdated;
	private Double bsbGaugeScore;
	private Double bsbHG;
	private Double bsbIG;
	private Double bsbJG;
	private Double bsbPG;
	private Double bsbWG;
	private String bsbJH;
	private Double bsbARB;
	private Double bsbCRB;
	private Double bsbDRB;
	private Double bsbTDB;
	private Double bsbRRB;
	private Double bsbVH;
	private Double bsbFI;
	private Double bsbOL;
	private Double bsbPL;
	private Double bsbQL;
	private Double bsbXL;
	private Double bsbDM;
	private Double bsbEM;
	private Double bsbFM;
	private Double bsbSM;
	private Double bsbTM;
	private Double bsbUM;
	private Double bsbVM;
	private Double bsbWM;
	private Double bsbXM;
	private Double bsbMRB;
	private Double bsbPOB;
	private Double bsbZM;
	private Double bsbBN;
	private Double bsbMN;
	private Double bsbNN;
	private Double bsbON;
	private Double bsbPN;
	private Double bsbQN;
	private Double bsbSJC;
	private Double bsbRN;
	private Double bsbSN;
	private Double bsbTN;
	private Double bsbUN;
	private Double bsbWN;
	private String bsbBQ;
	private String bsbCQ;
	private String bsbDQ;
	private String bsbEQ;
	private String bsbFRB;
	private Double bsbLRB;
	private String bsbABC;
	private Double bsbXHC;
	private Double bsbZHC;
	private Double bsbBIC;
	private Double bsbCIC;
	private Double bsbMIC;
	private Double bsbEJC;
	private Double bsbIIC;
	private String bsbJIC;
	private Double bsbYHC;
	private Double bsbAIC;
	private Double bsbEIC;
	private Double bsbFIC;
	private Double bsbGIC;
	private Double bsbFJC;
	private Double bsbPJC;
	private Double bsbHIC;
	private Double bsbKJC;
	private String bsbHCB;
	private String bsbTRB;
	private String bsbKCB;
	private String bsbMOB;
	private String bsbNOB;
	private String bsbOOB;
	private String bsbCSB;
	private Double bsbHSB;
	private Double bsbLCB;
	private Double bsbMCB;
	private Double bsbNCB;
	private Double bsbOCB;
	private Double bsbFDB;
	private Double bsbGDB;
	private Double bsbQCB;
	private Double bsbRCB;
	private Double bsbXCB;
	private Double bsbYCB;
	private Double bsbSCB;
	private Double bsbADB;
	private Double bsbBDB;
	private Double bsbHDB;
	private Double bsbIWB;
	private Double bsbKWB;
	private Double bsbKDB;
	private String bsbLDB;
	private Double bsbMFB;
	private Double bsbNFB;
	private Double bsbNIC;
	private Double bsbDJC;
	private Double bsbAYB;
	private Double bsbBYB;
	private Double bsbCYB;
	private Double bsbDYB;
	private Double bsbEYB;
	private Double bsbPYB;
	private Double bsbQYB;
	private Double bsbUYB;
	private Double bsbVYB;
	private Double bsbZYB;
	private Double bsbAZB;
	private Double recordId;
	private Double createdBy;
	private Date creationDate;
	private Double lastUpdatedBy;
	private Date lastUpdatedDate;
	private Double batchId;
	private String interfaceStatus;
	private String errorMessage;

	@Override
	public void readSQL(SQLInput stream, String typeName) throws SQLException {
		sqlType = typeName;
		setRetailAccountNumber(stream.readString());
		setTimestampCreated(stream.readDate());
		setTimestampUpdated(stream.readDate());
		setBsbGaugeScore(stream.readDouble());
		setBsbHG(stream.readDouble());
		setBsbIG(stream.readDouble());
		setBsbJG(stream.readDouble());
		setBsbPG(stream.readDouble());
		setBsbWG(stream.readDouble());
		setBsbJH(stream.readString());
		setBsbARB(stream.readDouble());
		setBsbCRB(stream.readDouble());
		setBsbDRB(stream.readDouble());
		setBsbTDB(stream.readDouble());
		setBsbRRB(stream.readDouble());
		setBsbVH(stream.readDouble());
		setBsbFI(stream.readDouble());
		setBsbOL(stream.readDouble());
		setBsbPL(stream.readDouble());
		setBsbQL(stream.readDouble());
		setBsbXL(stream.readDouble());
		setBsbDM(stream.readDouble());
		setBsbEM(stream.readDouble());
		setBsbFM(stream.readDouble());
		setBsbSM(stream.readDouble());
		setBsbTM(stream.readDouble());
		setBsbUM(stream.readDouble());
		setBsbVM(stream.readDouble());
		setBsbWM(stream.readDouble());
		setBsbXM(stream.readDouble());
		setBsbMRB(stream.readDouble());
		setBsbPOB(stream.readDouble());
		setBsbZM(stream.readDouble());
		setBsbBN(stream.readDouble());
		setBsbMN(stream.readDouble());
		setBsbNN(stream.readDouble());
		setBsbON(stream.readDouble());
		setBsbPN(stream.readDouble());
		setBsbQN(stream.readDouble());
		setBsbSJC(stream.readDouble());
		setBsbRN(stream.readDouble());
		setBsbSN(stream.readDouble());
		setBsbTN(stream.readDouble());
		setBsbUN(stream.readDouble());
		setBsbWN(stream.readDouble());
		setBsbBQ(stream.readString());
		setBsbCQ(stream.readString());
		setBsbDQ(stream.readString());
		setBsbEQ(stream.readString());
		setBsbFRB(stream.readString());
		setBsbLRB(stream.readDouble());
		setBsbABC(stream.readString());
		setBsbXHC(stream.readDouble());
		setBsbZHC(stream.readDouble());
		setBsbBIC(stream.readDouble());
		setBsbCIC(stream.readDouble());
		setBsbMIC(stream.readDouble());
		setBsbEJC(stream.readDouble());
		setBsbIIC(stream.readDouble());
		setBsbJIC(stream.readString());
		setBsbYHC(stream.readDouble());
		setBsbAIC(stream.readDouble());
		setBsbEIC(stream.readDouble());
		setBsbFIC(stream.readDouble());
		setBsbGIC(stream.readDouble());
		setBsbFJC(stream.readDouble());
		setBsbPJC(stream.readDouble());
		setBsbHIC(stream.readDouble());
		setBsbKJC(stream.readDouble());
		setBsbHCB(stream.readString());
		setBsbTRB(stream.readString());
		setBsbKCB(stream.readString());
		setBsbMOB(stream.readString());
		setBsbNOB(stream.readString());
		setBsbOOB(stream.readString());
		setBsbCSB(stream.readString());
		setBsbHSB(stream.readDouble());
		setBsbLCB(stream.readDouble());
		setBsbMCB(stream.readDouble());
		setBsbNCB(stream.readDouble());
		setBsbOCB(stream.readDouble());
		setBsbFDB(stream.readDouble());
		setBsbGDB(stream.readDouble());
		setBsbQCB(stream.readDouble());
		setBsbRCB(stream.readDouble());
		setBsbXCB(stream.readDouble());
		setBsbYCB(stream.readDouble());
		setBsbSCB(stream.readDouble());
		setBsbADB(stream.readDouble());
		setBsbBDB(stream.readDouble());
		setBsbHDB(stream.readDouble());
		setBsbIWB(stream.readDouble());
		setBsbKWB(stream.readDouble());
		setBsbKDB(stream.readDouble());
		setBsbLDB(stream.readString());
		setBsbMFB(stream.readDouble());
		setBsbNFB(stream.readDouble());
		setBsbNIC(stream.readDouble());
		setBsbDJC(stream.readDouble());
		setBsbAYB(stream.readDouble());
		setBsbBYB(stream.readDouble());
		setBsbCYB(stream.readDouble());
		setBsbDYB(stream.readDouble());
		setBsbEYB(stream.readDouble());
		setBsbPYB(stream.readDouble());
		setBsbQYB(stream.readDouble());
		setBsbUYB(stream.readDouble());
		setBsbVYB(stream.readDouble());
		setBsbZYB(stream.readDouble());
		setBsbAZB(stream.readDouble());
		setRecordId(stream.readDouble());
		setCreationDate(stream.readDate());
		setCreatedBy(stream.readDouble());
		setLastUpdatedBy(stream.readDouble());
		setLastUpdatedDate(stream.readDate());
		setBatchId(stream.readDouble());
		setInterfaceStatus(stream.readString());
		setErrorMessage(stream.readString());
	}

	@Override
	public void writeSQL(SQLOutput stream) throws SQLException {
		stream.writeString(getRetailAccountNumber());
		stream.writeDate(new java.sql.Date(getTimestampCreated().getTime()));
		stream.writeDate(new java.sql.Date(getTimestampUpdated().getTime()));
		stream.writeDouble(getBsbGaugeScore());
		stream.writeDouble(getBsbHG());
		stream.writeDouble(getBsbIG());
		stream.writeDouble(getBsbJG());
		stream.writeDouble(getBsbPG());
		stream.writeDouble(getBsbWG());
		stream.writeString(getBsbJH());
		stream.writeDouble(getBsbARB());
		stream.writeDouble(getBsbCRB());
		stream.writeDouble(getBsbDRB());
		stream.writeDouble(getBsbTDB());
		stream.writeDouble(getBsbRRB());
		stream.writeDouble(getBsbVH());
		stream.writeDouble(getBsbFI());
		stream.writeDouble(getBsbOL());
		stream.writeDouble(getBsbPL());
		stream.writeDouble(getBsbQL());
		stream.writeDouble(getBsbXL());
		stream.writeDouble(getBsbDM());
		stream.writeDouble(getBsbEM());
		stream.writeDouble(getBsbFM());
		stream.writeDouble(getBsbSM());
		stream.writeDouble(getBsbTM());
		stream.writeDouble(getBsbUM());
		stream.writeDouble(getBsbVM());
		stream.writeDouble(getBsbWM());
		stream.writeDouble(getBsbXM());
		stream.writeDouble(getBsbMRB());
		stream.writeDouble(getBsbPOB());
		stream.writeDouble(getBsbZM());
		stream.writeDouble(getBsbBN());
		stream.writeDouble(getBsbMN());
		stream.writeDouble(getBsbNN());
		stream.writeDouble(getBsbON());
		stream.writeDouble(getBsbPN());
		stream.writeDouble(getBsbQN());
		stream.writeDouble(getBsbSJC());
		stream.writeDouble(getBsbRN());
		stream.writeDouble(getBsbSN());
		stream.writeDouble(getBsbTN());
		stream.writeDouble(getBsbUN());
		stream.writeDouble(getBsbWN());
		stream.writeString(getBsbBQ());
		stream.writeString(getBsbCQ());
		stream.writeString(getBsbDQ());
		stream.writeString(getBsbEQ());
		stream.writeString(getBsbFRB());
		stream.writeDouble(getBsbLRB());
		stream.writeString(getBsbABC());
		stream.writeDouble(getBsbXHC());
		stream.writeDouble(getBsbZHC());
		stream.writeDouble(getBsbBIC());
		stream.writeDouble(getBsbCIC());
		stream.writeDouble(getBsbMIC());
		stream.writeDouble(getBsbEJC());
		stream.writeDouble(getBsbIIC());
		stream.writeString(getBsbJIC());
		stream.writeDouble(getBsbYHC());
		stream.writeDouble(getBsbAIC());
		stream.writeDouble(getBsbEIC());
		stream.writeDouble(getBsbFIC());
		stream.writeDouble(getBsbGIC());
		stream.writeDouble(getBsbFJC());
		stream.writeDouble(getBsbPJC());
		stream.writeDouble(getBsbHIC());
		stream.writeDouble(getBsbKJC());
		stream.writeString(getBsbHCB());
		stream.writeString(getBsbTRB());
		stream.writeString(getBsbKCB());
		stream.writeString(getBsbMOB());
		stream.writeString(getBsbNOB());
		stream.writeString(getBsbOOB());
		stream.writeString(getBsbCSB());
		stream.writeDouble(getBsbHSB());
		stream.writeDouble(getBsbLCB());
		stream.writeDouble(getBsbMCB());
		stream.writeDouble(getBsbNCB());
		stream.writeDouble(getBsbOCB());
		stream.writeDouble(getBsbFDB());
		stream.writeDouble(getBsbGDB());
		stream.writeDouble(getBsbQCB());
		stream.writeDouble(getBsbRCB());
		stream.writeDouble(getBsbXCB());
		stream.writeDouble(getBsbYCB());
		stream.writeDouble(getBsbSCB());
		stream.writeDouble(getBsbADB());
		stream.writeDouble(getBsbBDB());
		stream.writeDouble(getBsbHDB());
		stream.writeDouble(getBsbIWB());
		stream.writeDouble(getBsbKWB());
		stream.writeDouble(getBsbKDB());
		stream.writeString(getBsbLDB());
		stream.writeDouble(getBsbMFB());
		stream.writeDouble(getBsbNFB());
		stream.writeDouble(getBsbNIC());
		stream.writeDouble(getBsbDJC());
		stream.writeDouble(getBsbAYB());
		stream.writeDouble(getBsbBYB());
		stream.writeDouble(getBsbCYB());
		stream.writeDouble(getBsbDYB());
		stream.writeDouble(getBsbEYB());
		stream.writeDouble(getBsbPYB());
		stream.writeDouble(getBsbQYB());
		stream.writeDouble(getBsbUYB());
		stream.writeDouble(getBsbVYB());
		stream.writeDouble(getBsbZYB());
		stream.writeDouble(getBsbAZB());
		stream.writeDouble(getRecordId());
		stream.writeDouble(getCreatedBy());
		stream.writeDate(new java.sql.Date(getCreationDate().getTime()));
		stream.writeDouble(getLastUpdatedBy());
		stream.writeDate(new java.sql.Date(getLastUpdatedDate().getTime()));
		stream.writeDouble(getBatchId());
		stream.writeString(getInterfaceStatus());
		stream.writeString(getErrorMessage());
	}

	@Override
	public String getSQLTypeName() throws SQLException {
		return sqlType;
	}

	public String getSqlType() {
		return sqlType;
	}

	public void setSqlType(String sqlType) {
		this.sqlType = sqlType;
	}

	public String getRetailAccountNumber() {
		return retailAccountNumber;
	}

	public void setRetailAccountNumber(String retailAccountNumber) {
		this.retailAccountNumber = retailAccountNumber;
	}

	public Date getTimestampCreated() {
		return timestampCreated;
	}

	public void setTimestampCreated(Date timestampCreated) {
		this.timestampCreated = timestampCreated;
	}

	public Date getTimestampUpdated() {
		return timestampUpdated;
	}

	public void setTimestampUpdated(Date timestampUpdated) {
		this.timestampUpdated = timestampUpdated;
	}

	public Double getBsbGaugeScore() {
		return bsbGaugeScore;
	}

	public void setBsbGaugeScore(Double bsbGaugeScore) {
		this.bsbGaugeScore = bsbGaugeScore;
	}

	public Double getBsbHG() {
		return bsbHG;
	}

	public void setBsbHG(Double bsbHG) {
		this.bsbHG = bsbHG;
	}

	public Double getBsbIG() {
		return bsbIG;
	}

	public void setBsbIG(Double bsbIG) {
		this.bsbIG = bsbIG;
	}

	public Double getBsbJG() {
		return bsbJG;
	}

	public void setBsbJG(Double bsbJG) {
		this.bsbJG = bsbJG;
	}

	public Double getBsbPG() {
		return bsbPG;
	}

	public void setBsbPG(Double bsbPG) {
		this.bsbPG = bsbPG;
	}

	public Double getBsbWG() {
		return bsbWG;
	}

	public void setBsbWG(Double bsbWG) {
		this.bsbWG = bsbWG;
	}

	public String getBsbJH() {
		return bsbJH;
	}

	public void setBsbJH(String bsbJH) {
		this.bsbJH = bsbJH;
	}

	public Double getBsbARB() {
		return bsbARB;
	}

	public void setBsbARB(Double bsbARB) {
		this.bsbARB = bsbARB;
	}

	public Double getBsbCRB() {
		return bsbCRB;
	}

	public void setBsbCRB(Double bsbCRB) {
		this.bsbCRB = bsbCRB;
	}

	public Double getBsbDRB() {
		return bsbDRB;
	}

	public void setBsbDRB(Double bsbDRB) {
		this.bsbDRB = bsbDRB;
	}

	public Double getBsbTDB() {
		return bsbTDB;
	}

	public void setBsbTDB(Double bsbTDB) {
		this.bsbTDB = bsbTDB;
	}

	public Double getBsbRRB() {
		return bsbRRB;
	}

	public void setBsbRRB(Double bsbRRB) {
		this.bsbRRB = bsbRRB;
	}

	public Double getBsbVH() {
		return bsbVH;
	}

	public void setBsbVH(Double bsbVH) {
		this.bsbVH = bsbVH;
	}

	public Double getBsbFI() {
		return bsbFI;
	}

	public void setBsbFI(Double bsbFI) {
		this.bsbFI = bsbFI;
	}

	public Double getBsbOL() {
		return bsbOL;
	}

	public void setBsbOL(Double bsbOL) {
		this.bsbOL = bsbOL;
	}

	public Double getBsbPL() {
		return bsbPL;
	}

	public void setBsbPL(Double bsbPL) {
		this.bsbPL = bsbPL;
	}

	public Double getBsbQL() {
		return bsbQL;
	}

	public void setBsbQL(Double bsbQL) {
		this.bsbQL = bsbQL;
	}

	public Double getBsbXL() {
		return bsbXL;
	}

	public void setBsbXL(Double bsbXL) {
		this.bsbXL = bsbXL;
	}

	public Double getBsbDM() {
		return bsbDM;
	}

	public void setBsbDM(Double bsbDM) {
		this.bsbDM = bsbDM;
	}

	public Double getBsbEM() {
		return bsbEM;
	}

	public void setBsbEM(Double bsbEM) {
		this.bsbEM = bsbEM;
	}

	public Double getBsbFM() {
		return bsbFM;
	}

	public void setBsbFM(Double bsbFM) {
		this.bsbFM = bsbFM;
	}

	public Double getBsbSM() {
		return bsbSM;
	}

	public void setBsbSM(Double bsbSM) {
		this.bsbSM = bsbSM;
	}

	public Double getBsbTM() {
		return bsbTM;
	}

	public void setBsbTM(Double bsbTM) {
		this.bsbTM = bsbTM;
	}

	public Double getBsbUM() {
		return bsbUM;
	}

	public void setBsbUM(Double bsbUM) {
		this.bsbUM = bsbUM;
	}

	public Double getBsbVM() {
		return bsbVM;
	}

	public void setBsbVM(Double bsbVM) {
		this.bsbVM = bsbVM;
	}

	public Double getBsbWM() {
		return bsbWM;
	}

	public void setBsbWM(Double bsbWM) {
		this.bsbWM = bsbWM;
	}

	public Double getBsbXM() {
		return bsbXM;
	}

	public void setBsbXM(Double bsbXM) {
		this.bsbXM = bsbXM;
	}

	public Double getBsbMRB() {
		return bsbMRB;
	}

	public void setBsbMRB(Double bsbMRB) {
		this.bsbMRB = bsbMRB;
	}

	public Double getBsbPOB() {
		return bsbPOB;
	}

	public void setBsbPOB(Double bsbPOB) {
		this.bsbPOB = bsbPOB;
	}

	public Double getBsbZM() {
		return bsbZM;
	}

	public void setBsbZM(Double bsbZM) {
		this.bsbZM = bsbZM;
	}

	public Double getBsbBN() {
		return bsbBN;
	}

	public void setBsbBN(Double bsbBN) {
		this.bsbBN = bsbBN;
	}

	public Double getBsbMN() {
		return bsbMN;
	}

	public void setBsbMN(Double bsbMN) {
		this.bsbMN = bsbMN;
	}

	public Double getBsbNN() {
		return bsbNN;
	}

	public void setBsbNN(Double bsbNN) {
		this.bsbNN = bsbNN;
	}

	public Double getBsbON() {
		return bsbON;
	}

	public void setBsbON(Double bsbON) {
		this.bsbON = bsbON;
	}

	public Double getBsbPN() {
		return bsbPN;
	}

	public void setBsbPN(Double bsbPN) {
		this.bsbPN = bsbPN;
	}

	public Double getBsbQN() {
		return bsbQN;
	}

	public void setBsbQN(Double bsbQN) {
		this.bsbQN = bsbQN;
	}

	public Double getBsbSJC() {
		return bsbSJC;
	}

	public void setBsbSJC(Double bsbSJC) {
		this.bsbSJC = bsbSJC;
	}

	public Double getBsbRN() {
		return bsbRN;
	}

	public void setBsbRN(Double bsbRN) {
		this.bsbRN = bsbRN;
	}

	public Double getBsbSN() {
		return bsbSN;
	}

	public void setBsbSN(Double bsbSN) {
		this.bsbSN = bsbSN;
	}

	public Double getBsbTN() {
		return bsbTN;
	}

	public void setBsbTN(Double bsbTN) {
		this.bsbTN = bsbTN;
	}

	public Double getBsbUN() {
		return bsbUN;
	}

	public void setBsbUN(Double bsbUN) {
		this.bsbUN = bsbUN;
	}

	public Double getBsbWN() {
		return bsbWN;
	}

	public void setBsbWN(Double bsbWN) {
		this.bsbWN = bsbWN;
	}

	public String getBsbBQ() {
		return bsbBQ;
	}

	public void setBsbBQ(String bsbBQ) {
		this.bsbBQ = bsbBQ;
	}

	public String getBsbCQ() {
		return bsbCQ;
	}

	public void setBsbCQ(String bsbCQ) {
		this.bsbCQ = bsbCQ;
	}

	public String getBsbDQ() {
		return bsbDQ;
	}

	public void setBsbDQ(String bsbDQ) {
		this.bsbDQ = bsbDQ;
	}

	public String getBsbEQ() {
		return bsbEQ;
	}

	public void setBsbEQ(String bsbEQ) {
		this.bsbEQ = bsbEQ;
	}

	public String getBsbFRB() {
		return bsbFRB;
	}

	public void setBsbFRB(String bsbFRB) {
		this.bsbFRB = bsbFRB;
	}

	public Double getBsbLRB() {
		return bsbLRB;
	}

	public void setBsbLRB(Double bsbLRB) {
		this.bsbLRB = bsbLRB;
	}

	public String getBsbABC() {
		return bsbABC;
	}

	public void setBsbABC(String bsbABC) {
		this.bsbABC = bsbABC;
	}

	public Double getBsbXHC() {
		return bsbXHC;
	}

	public void setBsbXHC(Double bsbXHC) {
		this.bsbXHC = bsbXHC;
	}

	public Double getBsbZHC() {
		return bsbZHC;
	}

	public void setBsbZHC(Double bsbZHC) {
		this.bsbZHC = bsbZHC;
	}

	public Double getBsbBIC() {
		return bsbBIC;
	}

	public void setBsbBIC(Double bsbBIC) {
		this.bsbBIC = bsbBIC;
	}

	public Double getBsbCIC() {
		return bsbCIC;
	}

	public void setBsbCIC(Double bsbCIC) {
		this.bsbCIC = bsbCIC;
	}

	public Double getBsbMIC() {
		return bsbMIC;
	}

	public void setBsbMIC(Double bsbMIC) {
		this.bsbMIC = bsbMIC;
	}

	public Double getBsbEJC() {
		return bsbEJC;
	}

	public void setBsbEJC(Double bsbEJC) {
		this.bsbEJC = bsbEJC;
	}

	public Double getBsbIIC() {
		return bsbIIC;
	}

	public void setBsbIIC(Double bsbIIC) {
		this.bsbIIC = bsbIIC;
	}

	public String getBsbJIC() {
		return bsbJIC;
	}

	public void setBsbJIC(String bsbJIC) {
		this.bsbJIC = bsbJIC;
	}

	public Double getBsbYHC() {
		return bsbYHC;
	}

	public void setBsbYHC(Double bsbYHC) {
		this.bsbYHC = bsbYHC;
	}

	public Double getBsbAIC() {
		return bsbAIC;
	}

	public void setBsbAIC(Double bsbAIC) {
		this.bsbAIC = bsbAIC;
	}

	public Double getBsbEIC() {
		return bsbEIC;
	}

	public void setBsbEIC(Double bsbEIC) {
		this.bsbEIC = bsbEIC;
	}

	public Double getBsbFIC() {
		return bsbFIC;
	}

	public void setBsbFIC(Double bsbFIC) {
		this.bsbFIC = bsbFIC;
	}

	public Double getBsbGIC() {
		return bsbGIC;
	}

	public void setBsbGIC(Double bsbGIC) {
		this.bsbGIC = bsbGIC;
	}

	public Double getBsbFJC() {
		return bsbFJC;
	}

	public void setBsbFJC(Double bsbFJC) {
		this.bsbFJC = bsbFJC;
	}

	public Double getBsbPJC() {
		return bsbPJC;
	}

	public void setBsbPJC(Double bsbPJC) {
		this.bsbPJC = bsbPJC;
	}

	public Double getBsbHIC() {
		return bsbHIC;
	}

	public void setBsbHIC(Double bsbHIC) {
		this.bsbHIC = bsbHIC;
	}

	public Double getBsbKJC() {
		return bsbKJC;
	}

	public void setBsbKJC(Double bsbKJC) {
		this.bsbKJC = bsbKJC;
	}

	public String getBsbHCB() {
		return bsbHCB;
	}

	public void setBsbHCB(String bsbHCB) {
		this.bsbHCB = bsbHCB;
	}

	public String getBsbTRB() {
		return bsbTRB;
	}

	public void setBsbTRB(String bsbTRB) {
		this.bsbTRB = bsbTRB;
	}

	public String getBsbKCB() {
		return bsbKCB;
	}

	public void setBsbKCB(String bsbKCB) {
		this.bsbKCB = bsbKCB;
	}

	public String getBsbMOB() {
		return bsbMOB;
	}

	public void setBsbMOB(String bsbMOB) {
		this.bsbMOB = bsbMOB;
	}

	public String getBsbNOB() {
		return bsbNOB;
	}

	public void setBsbNOB(String bsbNOB) {
		this.bsbNOB = bsbNOB;
	}

	public String getBsbOOB() {
		return bsbOOB;
	}

	public void setBsbOOB(String bsbOOB) {
		this.bsbOOB = bsbOOB;
	}

	public String getBsbCSB() {
		return bsbCSB;
	}

	public void setBsbCSB(String bsbCSB) {
		this.bsbCSB = bsbCSB;
	}

	public Double getBsbHSB() {
		return bsbHSB;
	}

	public void setBsbHSB(Double bsbHSB) {
		this.bsbHSB = bsbHSB;
	}

	public Double getBsbLCB() {
		return bsbLCB;
	}

	public void setBsbLCB(Double bsbLCB) {
		this.bsbLCB = bsbLCB;
	}

	public Double getBsbMCB() {
		return bsbMCB;
	}

	public void setBsbMCB(Double bsbMCB) {
		this.bsbMCB = bsbMCB;
	}

	public Double getBsbNCB() {
		return bsbNCB;
	}

	public void setBsbNCB(Double bsbNCB) {
		this.bsbNCB = bsbNCB;
	}

	public Double getBsbOCB() {
		return bsbOCB;
	}

	public void setBsbOCB(Double bsbOCB) {
		this.bsbOCB = bsbOCB;
	}

	public Double getBsbFDB() {
		return bsbFDB;
	}

	public void setBsbFDB(Double bsbFDB) {
		this.bsbFDB = bsbFDB;
	}

	public Double getBsbGDB() {
		return bsbGDB;
	}

	public void setBsbGDB(Double bsbGDB) {
		this.bsbGDB = bsbGDB;
	}

	public Double getBsbQCB() {
		return bsbQCB;
	}

	public void setBsbQCB(Double bsbQCB) {
		this.bsbQCB = bsbQCB;
	}

	public Double getBsbRCB() {
		return bsbRCB;
	}

	public void setBsbRCB(Double bsbRCB) {
		this.bsbRCB = bsbRCB;
	}

	public Double getBsbXCB() {
		return bsbXCB;
	}

	public void setBsbXCB(Double bsbXCB) {
		this.bsbXCB = bsbXCB;
	}

	public Double getBsbYCB() {
		return bsbYCB;
	}

	public void setBsbYCB(Double bsbYCB) {
		this.bsbYCB = bsbYCB;
	}

	public Double getBsbSCB() {
		return bsbSCB;
	}

	public void setBsbSCB(Double bsbSCB) {
		this.bsbSCB = bsbSCB;
	}

	public Double getBsbADB() {
		return bsbADB;
	}

	public void setBsbADB(Double bsbADB) {
		this.bsbADB = bsbADB;
	}

	public Double getBsbBDB() {
		return bsbBDB;
	}

	public void setBsbBDB(Double bsbBDB) {
		this.bsbBDB = bsbBDB;
	}

	public Double getBsbHDB() {
		return bsbHDB;
	}

	public void setBsbHDB(Double bsbHDB) {
		this.bsbHDB = bsbHDB;
	}

	public Double getBsbIWB() {
		return bsbIWB;
	}

	public void setBsbIWB(Double bsbIWB) {
		this.bsbIWB = bsbIWB;
	}

	public Double getBsbKWB() {
		return bsbKWB;
	}

	public void setBsbKWB(Double bsbKWB) {
		this.bsbKWB = bsbKWB;
	}

	public Double getBsbKDB() {
		return bsbKDB;
	}

	public void setBsbKDB(Double bsbKDB) {
		this.bsbKDB = bsbKDB;
	}

	public String getBsbLDB() {
		return bsbLDB;
	}

	public void setBsbLDB(String bsbLDB) {
		this.bsbLDB = bsbLDB;
	}

	public Double getBsbMFB() {
		return bsbMFB;
	}

	public void setBsbMFB(Double bsbMFB) {
		this.bsbMFB = bsbMFB;
	}

	public Double getBsbNFB() {
		return bsbNFB;
	}

	public void setBsbNFB(Double bsbNFB) {
		this.bsbNFB = bsbNFB;
	}

	public Double getBsbNIC() {
		return bsbNIC;
	}

	public void setBsbNIC(Double bsbNIC) {
		this.bsbNIC = bsbNIC;
	}

	public Double getBsbDJC() {
		return bsbDJC;
	}

	public void setBsbDJC(Double bsbDJC) {
		this.bsbDJC = bsbDJC;
	}

	public Double getBsbAYB() {
		return bsbAYB;
	}

	public void setBsbAYB(Double bsbAYB) {
		this.bsbAYB = bsbAYB;
	}

	public Double getBsbBYB() {
		return bsbBYB;
	}

	public void setBsbBYB(Double bsbBYB) {
		this.bsbBYB = bsbBYB;
	}

	public Double getBsbCYB() {
		return bsbCYB;
	}

	public void setBsbCYB(Double bsbCYB) {
		this.bsbCYB = bsbCYB;
	}

	public Double getBsbDYB() {
		return bsbDYB;
	}

	public void setBsbDYB(Double bsbDYB) {
		this.bsbDYB = bsbDYB;
	}

	public Double getBsbEYB() {
		return bsbEYB;
	}

	public void setBsbEYB(Double bsbEYB) {
		this.bsbEYB = bsbEYB;
	}

	public Double getBsbPYB() {
		return bsbPYB;
	}

	public void setBsbPYB(Double bsbPYB) {
		this.bsbPYB = bsbPYB;
	}

	public Double getBsbQYB() {
		return bsbQYB;
	}

	public void setBsbQYB(Double bsbQYB) {
		this.bsbQYB = bsbQYB;
	}

	public Double getBsbUYB() {
		return bsbUYB;
	}

	public void setBsbUYB(Double bsbUYB) {
		this.bsbUYB = bsbUYB;
	}

	public Double getBsbVYB() {
		return bsbVYB;
	}

	public void setBsbVYB(Double bsbVYB) {
		this.bsbVYB = bsbVYB;
	}

	public Double getBsbZYB() {
		return bsbZYB;
	}

	public void setBsbZYB(Double bsbZYB) {
		this.bsbZYB = bsbZYB;
	}

	public Double getBsbAZB() {
		return bsbAZB;
	}

	public void setBsbAZB(Double bsbAZB) {
		this.bsbAZB = bsbAZB;
	}

	public Double getRecordId() {
		return recordId;
	}

	public void setRecordId(Double recordId) {
		this.recordId = recordId;
	}

	public Double getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Double createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public Double getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(Double lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public Double getBatchId() {
		return batchId;
	}

	public void setBatchId(Double batchId) {
		this.batchId = batchId;
	}

	public String getInterfaceStatus() {
		return interfaceStatus;
	}

	public void setInterfaceStatus(String interfaceStatus) {
		this.interfaceStatus = interfaceStatus;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

}
