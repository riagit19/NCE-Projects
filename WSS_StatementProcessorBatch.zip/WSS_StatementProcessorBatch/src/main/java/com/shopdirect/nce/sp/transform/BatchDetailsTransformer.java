package com.shopdirect.nce.sp.transform;

import java.math.BigDecimal;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.rule.model.Account;
import com.shopdirect.nce.sp.model.AccountingSnapshotTriad;
import com.shopdirect.nce.sp.model.AgreementTriad;
import com.shopdirect.nce.sp.model.BatchDetails;
import com.shopdirect.nce.sp.model.CustomerAccountInfo;
import com.shopdirect.nce.sp.model.CustomerContractTriad;
import com.shopdirect.nce.sp.model.RetailContractTriad;

public class BatchDetailsTransformer {

	private static SDLoggerImpl logger = new SDLoggerImpl();
	
	public BatchDetails getBatchDetails(RetailContractTriad retailContractTriad,
			AccountingSnapshotTriad accountingSnapshotTriad, CustomerContractTriad customerContractTriad, AgreementTriad agreementTriad,
			CustomerAccountInfo accountInfo, Account accountRule) throws Exception{
		
		logger.debug("[BatchDetailsTransformer - getBatchDetails] - Start");

		BatchDetails batchDetails = new BatchDetails();
		
		batchDetails.setAccountTypeCode(customerContractTriad.getAccountTypeCode());
		batchDetails.setAcdAlignedScore(customerContractTriad.getAcdAlignedScore());
		batchDetails.setAcdRawScore(customerContractTriad.getAcdRawScore());
		batchDetails.setAcdScorecardId(customerContractTriad.getAcdScorecardRefno());
		batchDetails.setAlignedBehaviourScore(customerContractTriad.getAlignedBehaviourScore());
		batchDetails.setAnnotationPeriodInd(retailContractTriad.getAnnotationPeriodInd());
		batchDetails.setApplicationCreditScore(customerContractTriad.getApplicationCreditScore());
		batchDetails.setaPR(agreementTriad.getApr());
		batchDetails.setBehaviourRawScore(customerContractTriad.getRawBehaviourScore());
		batchDetails.setBehaviourScore(customerContractTriad.getAlignedBehaviourScore());
		batchDetails.setBlockCode(accountInfo.getSpecialAttCode());
		batchDetails.setBnplBalance(agreementTriad.getBnplBalance());
		batchDetails.setCreditBandCodeInd(customerContractTriad.getCreditBandInd1());
		batchDetails.setCollectionMethodCode(customerContractTriad.getCollection_Method_Code());
		batchDetails.setCustomerAccountNumber(accountInfo.getPublicAccountId());
		batchDetails.setRetailAccountNumber(customerContractTriad.getRetailAccountNumber());
		batchDetails.setAgreementNumber(agreementTriad.getAgreementID());
		batchDetails.setCreditBand(customerContractTriad.getCreditBand());
		batchDetails.setCreditLimit(agreementTriad.getCreditLimit());
		batchDetails.setCreditStatusCode(customerContractTriad.getCreditStatusCode());
		batchDetails.setCreditStatusSubCode(customerContractTriad.getCreditStatusSubCode());
		batchDetails.setcRF(customerContractTriad.getCreditRiskFactor());
		batchDetails.setCurrentBalance(agreementTriad.getBalance());
		batchDetails.setCurrentBURef(retailContractTriad.getCurrentBUReference());
		batchDetails.setAccountStatusCode(customerContractTriad.getAccountStatusCode());
		batchDetails.setCustAlignedScore(customerContractTriad.getCustAlignedScore());
		batchDetails.setCustNoMailInd(customerContractTriad.getMailOptOutPreferenceInd());
		batchDetails.setCustRawScore(customerContractTriad.getCustRawScore());
		batchDetails.setCustScorecardId(customerContractTriad.getCustScorecardRefno());
		batchDetails.setCustomerType(customerContractTriad.getStaffType());
		batchDetails.setDateBankrupt(customerContractTriad.getActualDrdDate());
		batchDetails.setTodaysAccountingDate(customerContractTriad.getAccountingDate());
		batchDetails.setDateClosed(customerContractTriad.getAccountClosedDate());
		batchDetails.setDateLastZeroBalance(agreementTriad.getLastZeroBal());
		batchDetails.setDateSection87(agreementTriad.getDateSection87());
		batchDetails.setDateLastArrangement(agreementTriad.getLastArrangementDate());
		batchDetails.setDateLastCreditLimitDecrease(customerContractTriad.getCredLimitDecDate());
		batchDetails.setDateLastCreditLimitIncrease(customerContractTriad.getCreditLimitIncrDate());
		batchDetails.setDateLastCreditOrder(retailContractTriad.getLastOrderDate());
		batchDetails.setDateLastDelinquent(retailContractTriad.getLastDelinquentDate());
		batchDetails.setDateLastRetailOrder(retailContractTriad.getLastOrderDate());
		batchDetails.setDateLastPayment(agreementTriad.getLastPayDate());
		batchDetails.setDateLastPhoneCheck(customerContractTriad.getLastPhoneCheckDate());
		batchDetails.setDateLastStatement(agreementTriad.getLastStatementDate());
		batchDetails.setDateMigratedToCredit(customerContractTriad.getMigrationDate());
		batchDetails.setDateNextStatement(agreementTriad.getNextStatementDate());
		batchDetails.setDateNSF(agreementTriad.getNsfDate());
		batchDetails.setDateOfBirth(customerContractTriad.getDateOfBirth());
		batchDetails.setDatePaymentDue(agreementTriad.getNextPaymentDueDate());
		batchDetails.setDateRestart(customerContractTriad.getAccountRestartDate());
		batchDetails.setDateRiskNavScoreUpdated(retailContractTriad.getRnOIScoreUpdatedDate());
		batchDetails.setDateStart(customerContractTriad.getStartDate());
		batchDetails.setDateStartDelinquency(customerContractTriad.getStartDellDate());
		batchDetails.setDateEndDelinquency(customerContractTriad.getEndDellDate());
		batchDetails.setAccountStatusChangeDate(customerContractTriad.getAccountStatusChangedDate());
		batchDetails.setdCAReturnCode(customerContractTriad.getCollAgencyReturnCode());
		batchDetails.setDebitSaleFlag(customerContractTriad.getDebitSaleFlag());
		batchDetails.setDeceasedInd(customerContractTriad.getDeceasedInd());
		batchDetails.setEmailAddressInd(customerContractTriad.getEmailAddress());
		batchDetails.setFidScore(retailContractTriad.getFidScore());
		batchDetails.setFidScoreDate(retailContractTriad.getFidScoreDate());
		batchDetails.setFidScoreWorst(retailContractTriad.getFidScoreWorst());
		batchDetails.setCreditLimitFrozenInd(customerContractTriad.getCreditLimitFrozenCode());
		batchDetails.setHighBalance(accountingSnapshotTriad.getHighBalanceAmt());
		batchDetails.setHighDelq(accountingSnapshotTriad.getHighDelq());
		batchDetails.setHomePhoneInd(customerContractTriad.getTelephoneNumber());
		batchDetails.setLastFollowUpCode(customerContractTriad.getLastFollowUpCode());
		batchDetails.setLastSpecialCommentCode(customerContractTriad.getLastSpecialCommentCode());
		batchDetails.setCreditLimitLastReview(customerContractTriad.getCreditLimitLastRev());
		batchDetails.setMinPayment(accountRule.getMinPayment() != null ? accountRule.getMinPayment().getValue() : null);
		batchDetails.setMobileNumInd(customerContractTriad.getMobileNumInd());
		batchDetails.setNdrAlignedScore(customerContractTriad.getNdrAlignedScore());
		batchDetails.setNdrRawScore(customerContractTriad.getNdrRawScore());
		batchDetails.setNdrScorecardId(customerContractTriad.getNdrScorecardRefno());
		batchDetails.setNumAccts(customerContractTriad.getNumAllAccts());
		if (customerContractTriad.getNumAllAccts() != null && customerContractTriad.getNumCredAccts() != null) {
			batchDetails.setNumCashAccts(customerContractTriad.getNumAllAccts().subtract(customerContractTriad.getNumCredAccts()));
		}
		batchDetails.setNumCreditAccts( customerContractTriad.getNumCredAccts());
		batchDetails.setNumCycle1(accountingSnapshotTriad.getNumCycle1());
		batchDetails.setNumCycle2(accountingSnapshotTriad.getNumCycle2());
		batchDetails.setNumCycle3(accountingSnapshotTriad.getNumCycle3());
		batchDetails.setNumCycle4(accountingSnapshotTriad.getNumCycle4());
		batchDetails.setNumIBCAccts(customerContractTriad.getConsolidationLoanInd());
		batchDetails.setNumPaymentsTSP(agreementTriad.getNumPayTSP());
		batchDetails.setNumInstallmentsInArrears(agreementTriad.getInstArrears());
		batchDetails.setOrdersDeclined3mths(retailContractTriad.getOrdersDeclined3Mths());
		batchDetails.setoTB(agreementTriad.getAvailableToSpend());
		batchDetails.setOtherAdjustmentsAmountTSP(agreementTriad.getOtherAdjAmtTSP());
		batchDetails.setOverIndebtScore(retailContractTriad.getOverIndebtScore());
		batchDetails.setPastDue(agreementTriad.getPastDueAmt());
		batchDetails.setLastPaymentAmount(retailContractTriad.getLastPaymentAmt());
		batchDetails.setPaymentCurrentInd(agreementTriad.getPaymentCurrentIND());
		batchDetails.setLastPaymentMethod(agreementTriad.getLastPayMethod());
		batchDetails.setPaymentPreviousInd(agreementTriad.getPaymentPreviousIND());
		batchDetails.setPaymentReschedInd(customerContractTriad.getPayRescInd());
		batchDetails.setCreditPaymentsTotal(retailContractTriad.getCreditPaymentsTotal());
		batchDetails.setPpiInd(retailContractTriad.getPpiInd());
		batchDetails.setPrincipalBrand(customerContractTriad.getBrandCode());
		batchDetails.setPromiseToPayInd(customerContractTriad.getPromiseToPayInd());
		if ((agreementTriad.getNumPayTSP() != null) && (agreementTriad.getNumPayTSP().compareTo(BigDecimal.ZERO) == 1)) {
			batchDetails.setPaymentsTSPInd(BigDecimal.ONE);
		} else {
			batchDetails.setPaymentsTSPInd(BigDecimal.ZERO);
		}
		//batchDetails.setPaymtsSinceLastCollEntry(agreementTriad.getPaym); //TBC
		batchDetails.setRecruitmentCRF(customerContractTriad.getRecruitCrf());
		batchDetails.setRecruitmentSource(retailContractTriad.getRecruitmentSource());
		batchDetails.setReturnsAmountTSP(agreementTriad.getReturnsAmtTSP());
		batchDetails.setRiskNavScore(retailContractTriad.getRiskNavScore());
		batchDetails.setScheduledPaymentAmt(agreementTriad.getScheduledPaymentAmt());
		batchDetails.setScorecardId(customerContractTriad.getScorecardRefno());
		if (agreementTriad.getBalance() != null && agreementTriad.getBnplBalance() != null) {
			batchDetails.setScreenBalance(agreementTriad.getBalance().subtract(agreementTriad.getBnplBalance()));
		}
		batchDetails.setSpid(customerContractTriad.getSpID());
		batchDetails.setScheduledPaymentsPastDue(agreementTriad.getScheduledPaymentPastDue());
		batchDetails.setTcuMonitorStatusCode(customerContractTriad.getTcuMonitorStatusCode());
		batchDetails.setTotalPayments30Days(agreementTriad.getTotPay30Days());
		batchDetails.setPaymentAmountTSP(agreementTriad.getPayAmtTSP());
		batchDetails.setNumPurchasesTSP(agreementTriad.getNumPurchasesTSP());
		batchDetails.setTotalFeesTSP(agreementTriad.getTotFeesTSP());
		batchDetails.setNumFailedPayments(agreementTriad.getNumRetPayTSP());
		batchDetails.setValueFailedPayments(agreementTriad.getReturnsAmtTSP());
		batchDetails.setInterestChargedAmtTSP(agreementTriad.getIntChargedTSP());
		batchDetails.setPurchaseAmountTSP(agreementTriad.getPurchaseAmtTSP());
		batchDetails.setNumNSF(agreementTriad.getNumRetPayTSP());
		batchDetails.setRebatesAmountTSP(agreementTriad.getRebatesAmtTSP());
		if (agreementTriad.getPurchaseAmtTSP() != null && agreementTriad.getReturnsAmtTSP() != null) {
			batchDetails.setNetSalesValueTSPAmt(agreementTriad.getPurchaseAmtTSP().add(agreementTriad.getReturnsAmtTSP()));
		}
		batchDetails.setTotalNumCreditPayments(retailContractTriad.getNumCreditPayments());
		batchDetails.setDaysInCollPeriod(BigDecimal.ONE);
		batchDetails.setFirstCollStmtDate(customerContractTriad.getFirstCollStmtDate());
		batchDetails.setInCollectionsInd(customerContractTriad.getCollInd());
		batchDetails.setInDebtManagerInd(customerContractTriad.getDmInd());
		batchDetails.setAnnualSalary(retailContractTriad.getAnnualSalary());
		batchDetails.setHouseholdIncome(retailContractTriad.getHouseholdIncome());
		batchDetails.setNoOfDependants(retailContractTriad.getNoOfDependants());
		batchDetails.setEmploymentStatus(retailContractTriad.getEmploymentStatus());
		batchDetails.setResidentStatus(retailContractTriad.getResidentStatus());
		batchDetails.setSixMonthIncomeVerificationCode(retailContractTriad.getSixCode());
		batchDetails.setTwelveMonthIncomeVerificationCode(retailContractTriad.getTwelveCode());
		batchDetails.setDateOfChangeRequest(retailContractTriad.getDateOfRequest());
		batchDetails.setPreviousAnnualSalary(retailContractTriad.getPreviousSalary());
		batchDetails.setPreviousHouseholdIncome(retailContractTriad.getPreviousIncome());
		batchDetails.setDerivedIncome(retailContractTriad.getDerivedIncome());
		batchDetails.setOptOutCreditLimitIncInd(retailContractTriad.getOptOutCreditLimitIncInd());
		batchDetails.setLastPhoneCheckDate(customerContractTriad.getLastPhoneCheckDate());
		batchDetails.setOtherDebits(accountingSnapshotTriad.getOtherDebitsAmtSigned());
		batchDetails.setOtherCredits(accountingSnapshotTriad.getOtherCreditsAmtSigned());
		
		logger.debug("[BatchDetailsTransformer - getBatchDetails] - End");
		
		return batchDetails;
	}
}
