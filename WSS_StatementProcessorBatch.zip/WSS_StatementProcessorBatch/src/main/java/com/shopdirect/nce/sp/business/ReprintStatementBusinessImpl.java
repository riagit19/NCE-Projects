package com.shopdirect.nce.sp.business;

import java.util.Iterator;
import java.util.List;

import com.shopdirect.nce.common.extcnfg.ExternalFileDataConfiguration;
import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.dao.ReprintStatementDao;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.externalclient.ReprintStatementExternalClient;
import com.shopdirect.nce.sp.util.CommonConfigHelper;
import com.shopdirect.nce.sp.util.StatementProcessorBatchUtil;
import com.shopdirect.osb.xsd.customeraccount.AccountNo;
import com.shopdirect.osb.xsd.customeraccount.GetAccountDetailsRequestType;


public class ReprintStatementBusinessImpl {
	private static SDLoggerImpl logger = new SDLoggerImpl();
	private CommonConfigHelper commonConfigHelper = null;
	private ExternalFileDataConfiguration extFileDataCfg = null;
	private ReprintStatementDao reprintStatementDao = null;
	
	public ReprintStatementBusinessImpl() throws StatementProcessorBatchException{
		setCommonConfigHelper(CommonConfigHelper.getInstance());
		initExternalConfig();
		setReprintStatementDao(reprintStatementDao);
	}
	
	private void initExternalConfig() throws StatementProcessorBatchException  {
		logger.debug("[ReprintStatementBusinessImpl-- initExternalConfig]  -- START");
		
		 this.extFileDataCfg = getCommonConfigHelper().loadPropertyConfig(StatementProcessorBatchConstants.SPSTUB_CONFIGURATION_FILE_KEY);
		
		logger.debug("[ReprintStatementBusinessImpl -- initExternalConfig]  -- END");
	}
	
	public boolean getReprintAccountList() throws StatementProcessorBatchException {
		
		logger.debug("[ReprintStatementBusinessImpl -- getReprintAccountList]  -- START");
		boolean isSuccess = false;
		
		try {
			reprintStatementDao = new ReprintStatementDao();
			List accountList = reprintStatementDao.getReprintAccountList();
			if(accountList != null && !accountList.isEmpty()){
				
				ReprintStatementExternalClient reprintStmtExtClient = new ReprintStatementExternalClient();
				GetAccountDetailsRequestType   req = new GetAccountDetailsRequestType();
				AccountNo acc = new AccountNo();
				Iterator itr = accountList.iterator();
				while(itr.hasNext()){
					acc.setCustomerAccountNumber(itr.next().toString());
					req.setAccountNo(acc);	
					getCustomerAccountContent(reprintStmtExtClient, req);
				}
			}
	
			logger.debug("[ReprintStatementBusinessImpl -- getReprintAccountList]  -- END");
		} 
		catch(StatementProcessorBatchException se){
			getLogger().error("[ReprintStatementBusinessImpl -- getReprintAccountList] -- Statementprocessorbatch exception="+se.getMessage());
			StatementProcessorBatchUtil.printExceptionInformation(se);
		}
		
		catch (Exception e) {
		
			getLogger().error("[ReprintStatementBusinessImpl -- getReprintAccountList] Exception Block "+ e.getMessage());
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_BUSINESS_ERROR_CODE,
					"[ReprintStatementBusinessImpl -- getReprintAccountList] Exception Block",
					"Business exception generated at time to process ReprintStatement "+ e.getMessage(),
					StatementProcessorBatchConstants.ERROR_PERSIST_AR_RESULTS, null,e);
		}
		return isSuccess;
		
	}

	private void getCustomerAccountContent(ReprintStatementExternalClient reprintStmtExtClient,
			GetAccountDetailsRequestType req) {
		try{
		reprintStmtExtClient.getCustomerAccountContent(req);
		}
		catch(StatementProcessorBatchException e ){
			getLogger().error("[ReprintStatementBusinessImpl -- getCustomerAccountContent] -- Exception returned from externalclient="+e.getMessage());
			StatementProcessorBatchUtil.printExceptionInformation(e);
		}
	}
	
	
	
	public ReprintStatementDao getReprintStatementDao() {
		return reprintStatementDao;
	}

	public void setReprintStatementDao(ReprintStatementDao reprintStatementDao) {
		this.reprintStatementDao = reprintStatementDao;
	}

	public static SDLoggerImpl getLogger() {
		return logger;
	}

	public static void setLogger(SDLoggerImpl logger) {
		ReprintStatementBusinessImpl.logger = logger;
	}

	public CommonConfigHelper getCommonConfigHelper() {
		return commonConfigHelper;
	}

	public void setCommonConfigHelper(CommonConfigHelper commonConfigHelper) {
		this.commonConfigHelper = commonConfigHelper;
	}

	public ExternalFileDataConfiguration getExtFileDataCfg() {
		return extFileDataCfg;
	}

	public void setExtFileDataCfg(ExternalFileDataConfiguration extFileDataCfg) {
		this.extFileDataCfg = extFileDataCfg;
	}
	
}
