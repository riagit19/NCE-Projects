package com.shopdirect.nce.sp.business.creditdataload;

import java.io.File;
import java.io.FileReader;
import java.io.LineNumberReader;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.shopdirect.nce.sp.constants.CreditLoadDataConstants;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.dao.creditdataload.DrawdownTransactionDaoImpl;
import com.shopdirect.nce.sp.dao.creditdataload.SpCreditFilLoadControlDaoImpl;
import com.shopdirect.nce.sp.exception.BuisnessException;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.DrawdownTransaction;
import com.shopdirect.nce.sp.util.FinFileBaseProcessor;
import com.shopdirect.nce.sp.util.StatementProcessorBatchUtil;

public class DrawDownTransactionFileProcessorImpl extends FinFileBaseProcessor implements DataFileProcessor{
	
	private DrawdownTransactionDaoImpl drawdownTransactionDaoImpl;
	
	public DrawDownTransactionFileProcessorImpl() throws StatementProcessorBatchException {
		super();
	}

	
public boolean processFile(File folder, long batchID, int user , String batchRunDate) throws StatementProcessorBatchException {
		
		getLogger().debug("[DrawdownTransactionFileProcessorImpl -- processFile]  -- START");
		List<Map<String, Object>> columns;
		File file;
		String line;
		final String fileName = StatementProcessorBatchUtil.generateFileName(CreditLoadDataConstants.DRAWDOWNTRANSACTION,
				CreditLoadDataConstants.NEW_STATUS, batchRunDate);
		file = getFile(folder, fileName);
		line = "";
		String comma = ",";
		columns = getColumns(StatementProcessorBatchConstants.DRAWDOWN_TRANSACTION_DATA_MAPPING,
				StatementProcessorBatchConstants.DRAWDOWN_TRANSACTION_MAP);
		String fileIdentifier = getCommonConfigHelper().readConfigData(getDataconfig(), "DRAWDOWNTRANSACTION");
		String insertedMessage = null;
		String errorMessage = StatementProcessorBatchConstants.EMPTY_STRING;
		int insertCount;
		List<DrawdownTransaction> drawdownTransactionRecords = null;
		boolean insertedDrawdownTransaction = false;
		SpCreditFilLoadControlDaoImpl spCreditFilLoadControlDaoImpl = new SpCreditFilLoadControlDaoImpl();
		
		Object[] procReturnVal = new Object[2];
		int retCode = 0;
		String retMsg = null;

		try (LineNumberReader reader = new LineNumberReader(new FileReader(file))) {
			int records = getRecordsCount(this.getFinancierFilePath() + file.getName());
			insertSpLoadControlData(batchID, file.getName(), fileIdentifier, user);
			String header = reader.readLine();
			if(records == StatementProcessorBatchConstants.HEADER_RECORD){
				insertedDrawdownTransaction = true ;
			}
			else{			
				while ((reader.getLineNumber()) < records) {
					drawdownTransactionRecords = new ArrayList<>();
					for (insertCount = 0; insertCount<getBatchInsertcount() ;insertCount++ ){					
						if ((line = reader.readLine())!= null){						
							String[] contents = line.split(comma, -1);
							//Check number of data in xml and .dat file is same or not
							if (columns.size() != contents.length) {
								throw new Exception(CreditLoadDataConstants.MISMATCH_ON_COLUMN_COUNT);
							}
							DrawdownTransaction drawDownTransaction = new DrawdownTransaction();						
							drawDownTransaction.setBatchId(batchID);
							drawDownTransaction.setCreatedByUser(Long.valueOf(user));
							drawdownTransactionRecords.add(drawDownTransaction);
							constructObjects(contents, columns, drawDownTransaction);
						} else{
							break;
						}
					}
					
					procReturnVal = getDrawdownTransactionDaoImpl().insertDrawDownTransactionData(drawdownTransactionRecords);
					retCode = (int) procReturnVal[0];
					retMsg = (String) procReturnVal[1];
					
					// update the CONTROL table and DELETE if INSERTION fails
					if (retCode == 0) {
						insertedDrawdownTransaction = true;
					} else {
						insertedDrawdownTransaction = false;
						errorMessage = retMsg;
					}
				}
			}

			/**
			 * Update the CONTROL table with batch id and error message
			 */
			spCreditFilLoadControlDaoImpl.updateControlData(batchID, insertedDrawdownTransaction, errorMessage, fileIdentifier);

		} catch (Exception exception) {
			insertedMessage = exception.getMessage();
			errorMessage = insertedMessage;
			insertedDrawdownTransaction = false;
			/**
			 * Update the CONTROL table with batch id and error messege
			 */
			try {
				spCreditFilLoadControlDaoImpl.updateControlData(batchID, insertedDrawdownTransaction, errorMessage, fileIdentifier);
			}  catch (BuisnessException | SQLException ex) {
				getLogger()
				.debug("[DrawDownTransactionFileProcessorImpl -- processFile] -- Control Table Update Exception: "
						+ ex);
			} catch (Exception exception2) {
				getLogger()
						.debug("[DrawDownTransactionFileProcessorImpl -- processFile] -- Control Table Update Exception: "
								+ exception2);
			}

			getLogger()
					.error("[DrawDownTransactionFileProcessorImpl -- processFile] -- Drawdown Transaction insert Error occured ");
			getLogger().debug(
					"[DrawDownTransactionFileProcessorImpl -- processFile] -- Drawdown Transaction Exception: " + exception);
			
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_BUSINESS_ERROR_CODE,
					"[DrawDownTransactionFileProcessorImpl-processFile] StatementProcessorBatchException Block",
					"Drawdown Transaction Exception " + errorMessage, null, null,
					new StatementProcessorBatchException());
		}
		getLogger().debug("[DrawDownTransactionFileProcessorImpl -- processFile]  -- END");
		return insertedDrawdownTransaction;
	}

	
	/**
	 * @return the drawdownTransactionDaoImpl
	 * @throws StatementProcessorBatchException 
	 */
	public DrawdownTransactionDaoImpl getDrawdownTransactionDaoImpl() throws StatementProcessorBatchException {
		if(drawdownTransactionDaoImpl == null) {
			drawdownTransactionDaoImpl = new DrawdownTransactionDaoImpl();
		}
		return drawdownTransactionDaoImpl;
	}

	/**
	 * @param drawdownTransactionDaoImpl 
	 */
	public void setDrawdownTransactionDaoImpl(DrawdownTransactionDaoImpl drawdownTransactionDaoImpl) {
		this.drawdownTransactionDaoImpl = drawdownTransactionDaoImpl;
	}	


}
