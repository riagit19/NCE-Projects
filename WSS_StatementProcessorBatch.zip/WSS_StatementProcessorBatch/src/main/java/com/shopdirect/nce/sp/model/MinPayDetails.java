package com.shopdirect.nce.sp.model;

import java.math.BigDecimal;

import javax.xml.bind.annotation.XmlElement;

public class MinPayDetails {

    protected String minPayAction;

    protected BigDecimal minPayNumber;

    protected String minPayImplementAfter;

    /**
	 * @return the minPayAction
	 */
	public String getMinPayAction() {
		return minPayAction;
	}

	/**
	 * @param minPayAction the minPayAction to set
	 */
	public void setMinPayAction(String minPayAction) {
		this.minPayAction = minPayAction;
	}

	/**
	 * @return the minPayNumber
	 */
	public BigDecimal getMinPayNumber() {
		return minPayNumber;
	}

	/**
	 * @param minPayNumber the minPayNumber to set
	 */
	public void setMinPayNumber(BigDecimal minPayNumber) {
		this.minPayNumber = minPayNumber;
	}

	/**
	 * @return the minPayImplementAfter
	 */
	public String getMinPayImplementAfter() {
		return minPayImplementAfter;
	}

	/**
	 * @param minPayImplementAfter the minPayImplementAfter to set
	 */
	public void setMinPayImplementAfter(String minPayImplementAfter) {
		this.minPayImplementAfter = minPayImplementAfter;
	}

	/**
	 * @return the minPayGuardrailsHit
	 */
	public String getMinPayGuardrailsHit() {
		return minPayGuardrailsHit;
	}

	/**
	 * @param minPayGuardrailsHit the minPayGuardrailsHit to set
	 */
	public void setMinPayGuardrailsHit(String minPayGuardrailsHit) {
		this.minPayGuardrailsHit = minPayGuardrailsHit;
	}

	protected String minPayGuardrailsHit;
}
