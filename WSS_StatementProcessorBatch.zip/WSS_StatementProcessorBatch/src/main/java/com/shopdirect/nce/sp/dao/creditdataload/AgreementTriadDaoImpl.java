package com.shopdirect.nce.sp.dao.creditdataload;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;

import com.shopdirect.nce.common.extcnfg.ExternalFileDataConfiguration;
import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.Query;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.dao.AccountReassessmentBaseDao;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.AgreementTriadType;
import com.shopdirect.nce.sp.util.CommonConfigHelper;
import com.shopdirect.nce.sp.util.StatementProcessorBatchUtil;
import com.shopdirect.nce.sp.util.UCPConnection;

import oracle.jdbc.OracleTypes;
import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;

public class AgreementTriadDaoImpl extends AccountReassessmentBaseDao {

	boolean isInsertSuccess = false;
	Connection connection = null;
	int retCode = 0;
	String retMsg = null;
	AgreementTriadType agreementTriad = null;
	CallableStatement callStmt = null;
	private static SDLoggerImpl logger = new SDLoggerImpl();
	Object[] procReturnVal = new Object[2];
	String errMsg = null;
	
	public AgreementTriadDaoImpl() throws StatementProcessorBatchException {
		super();
	}

	public Object[] insertAgreementTriadData(List<AgreementTriadType> agreementTriadList) throws StatementProcessorBatchException {
		logger.debug("[AgreementTriadDaoImpl -- insertAgreementTriadData]  -- START");
		String isInsertSuccessMessege = null;
		CommonConfigHelper commonConfigHelper = CommonConfigHelper.getInstance();
		ExternalFileDataConfiguration Dbconfig = commonConfigHelper.loadPropertyConfig("spDbConfig");
		String CREDIT_DATA_LOAD_PACK = commonConfigHelper.readConfigData(Dbconfig, "CREDIT_DATA_LOAD_PACK");
		String PROC_POPULATE_AGREEMENT_TRIAD = commonConfigHelper.readConfigData(Dbconfig, "PRC_POPULATE_DATA_AGREEMENT_TRIAD");
		setSpMainSchema(getSchema(StatementProcessorBatchConstants.DB_SCHEMA_MAIN_SP_KEY));
		
		try {
			connection = UCPConnection.getConnection();
			String callQueryStr = Query.getInsertFinDataQuery(CREDIT_DATA_LOAD_PACK, PROC_POPULATE_AGREEMENT_TRIAD);
			callStmt = connection.prepareCall(callQueryStr);
			
			java.sql.Struct agreementTriadStructArray[] = new java.sql.Struct[agreementTriadList.size()];
			
			int ctr = 0;
			
			for (AgreementTriadType agreementTriad : agreementTriadList) {
				Object[] agreementTriadObj = new Object[] {agreementTriad.getAgreementID(), agreementTriad.getFnStatNo(), StatementProcessorBatchUtil.convertJavaDateToSqlDate(agreementTriad.getStatementDate()),
						agreementTriad.getCreditLimit(), agreementTriad.getLastPayMethod(), agreementTriad.getCurrentBalance(), StatementProcessorBatchUtil.convertJavaDateToSqlDate(agreementTriad.getDateLastMiv()),
						StatementProcessorBatchUtil.convertJavaDateToSqlDate(agreementTriad.getDateLastOrder()), StatementProcessorBatchUtil.convertJavaDateToSqlDate(agreementTriad.getDateLastPay()), StatementProcessorBatchUtil.convertJavaDateToSqlDate(agreementTriad.getPaymentDueDate()), 
						StatementProcessorBatchUtil.convertJavaDateToSqlDate(agreementTriad.getLastStatementDate()),
						StatementProcessorBatchUtil.convertJavaDateToSqlDate(agreementTriad.getNextStatementDate()), StatementProcessorBatchUtil.convertJavaDateToSqlDate(agreementTriad.getDateSection87()), StatementProcessorBatchUtil.convertJavaDateToSqlDate(agreementTriad.getDateNsf()), 
						agreementTriad.getScheduledPaymentAmount(), agreementTriad.getScheduledPaymentPastDue(), agreementTriad.getPastDueAmount(), 
						agreementTriad.getAvailableToSpend(), agreementTriad.getBnplBalance(),
						agreementTriad.getApr(), agreementTriad.getTotPay30Days(), agreementTriad.getInstArrears(), StatementProcessorBatchUtil.convertJavaDateToSqlDate(agreementTriad.getDateLastArrangement()),
						agreementTriad.getPayAmtTsp(), StatementProcessorBatchUtil.convertJavaDateToSqlDate(agreementTriad.getDateLastZeroBal()), agreementTriad.getReturnsAmtTsp(), agreementTriad.getOtherAdjAmtTsp(),
						agreementTriad.getLastPaymentAmount(), agreementTriad.getPaymentPreviousInd(), agreementTriad.getPaymentCurrentInd(), agreementTriad.getNumPurchasesTsp(),
						agreementTriad.getTotFeesTsp(), agreementTriad.getCustCreditsTsp(), agreementTriad.getTotPayYear(), agreementTriad.getNumPayTsp(),
						agreementTriad.getIntChargedTsp(), agreementTriad.getPurchaseAmtTsp(), agreementTriad.getRebatesAmtTsp(), agreementTriad.getBnplIntAmtTsp(),
						agreementTriad.getNumRatePayTsp(), agreementTriad.getLastArrearsWks(), agreementTriad.getLastPaymentDays(),
						agreementTriad.getNilBalanceDays(), agreementTriad.getBatchId(), agreementTriad.getErrorFlag(), agreementTriad.getErrorMessage(),
						agreementTriad.getCreatedByUser(), agreementTriad.getLastUpdateByUser(), agreementTriad.getSourceRowNumber(),
						agreementTriad.getValueFailedPayments(), agreementTriad.getBalanceBeforePpi(),  agreementTriad.getOtherCredits(),
						agreementTriad.getOtherDebits(), agreementTriad.getPayLastColl(), agreementTriad.getLateInsufFeesTsp(),
						agreementTriad.getCollAdminFeesTsp(), agreementTriad.getOrderFeesAmtTsp(),
						agreementTriad.getCreditLimitUtil()
				};

				java.sql.Struct agreementTriadStructObj = connection.createStruct("TY_OBJ_CREDIT_AGRTRIAD", agreementTriadObj);
				agreementTriadStructArray[ctr++] = agreementTriadStructObj;
			}
			
			ArrayDescriptor arrayDescriptor = ArrayDescriptor.createDescriptor("TY_TAB_CREDIT_AGRTRIAD", connection);
			ARRAY agreementTriadArray = new ARRAY(arrayDescriptor, connection, agreementTriadStructArray);
			
			logger.debug("====== AgreementTriadStructArray =======" + Arrays.toString(agreementTriadStructArray));
			
			callStmt.setArray(1, agreementTriadArray);
			callStmt.registerOutParameter(2, OracleTypes.ARRAY, "TY_TAB_CREDIT_AGRTRIAD_OUT");
			callStmt.registerOutParameter(3, java.sql.Types.INTEGER);
			callStmt.registerOutParameter(4, java.sql.Types.CHAR);
			callStmt.executeUpdate();

			retCode = callStmt.getInt(3);
			retMsg = callStmt.getString(4);
			ARRAY outArray = (ARRAY) callStmt.getArray(2);
			Object[] outList = (Object[]) outArray.getArray();
			
			
			if (retCode == 0) {
				isInsertSuccess = true;
			} else {
				if (outList.length > 29)
					errMsg = (String) outList[29];
				else
					errMsg = retMsg + "[ID]";
				logger.debug("Agreement Triad Insertion Exception errMsg=========" + errMsg);
				isInsertSuccess = false;
				throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_BUSINESS_ERROR_CODE,
						"[AgreementTriadDaoImpl-insertAgreementTriadData] StatementProcessorBatchException Block",
						"Database Failed Insertion execution exception " + isInsertSuccessMessege, null, null,
						new StatementProcessorBatchException());
			}
			
			isInsertSuccessMessege = retMsg;
			procReturnVal[0]= retCode;
			procReturnVal[1]= retMsg;
			
			logger.debug("AgreementTriad isInsertSuccess=======" + isInsertSuccess);
			logger.debug("[AgreementTriadDaoImpl -- insertAgreementTriadData]  -- END");
			
		} catch (SQLException sqlException) {
			isInsertSuccess = false;
			isInsertSuccessMessege = sqlException.getMessage();
			logger.error("Agreement Triad SQLException Exception =======" + isInsertSuccessMessege);
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_DB_ERROR_CODE,
					"[AgreementTriadDaoImpl-insertAgreementTriadData] SQLException Block",
					"Database execution exception [SQLCode: " + sqlException.getSQLState() + "] , SQL Detail "
							+ sqlException.getMessage(),
					null, null, sqlException);

		} catch (Exception exception) {
			isInsertSuccess = false;
			isInsertSuccessMessege = exception.getMessage();
			logger.error("Agreement Triad Generic Exception =======" + isInsertSuccessMessege);
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.CONNECTTION_DB_ERROR_CODE,
					"[AgreementTriadDaoImpl-insertAgreementTriadData] Exception Block",
					"Database execution exception " + exception.getMessage(), null, null, exception);
		} finally {

			try {

				/**
				 * UPDATE the CONTROL TABLE PROVIDING 
				 * IF INSERT IN AGREEMENT TRIAD
				 * TABLE IS SUCCESS OR FAILURE
				 */

				if (callStmt != null) {
					callStmt.close();
				}

				if (connection != null) {
					connection.close();
				}

			} catch (Exception e) {
				logger.error("[AgreementTriadDaoImpl-insertAgreementTriadData]  -- Finally Block, Database execution exception " + e.getMessage());					
			}
		}
		
		return procReturnVal;
	}
	
}
