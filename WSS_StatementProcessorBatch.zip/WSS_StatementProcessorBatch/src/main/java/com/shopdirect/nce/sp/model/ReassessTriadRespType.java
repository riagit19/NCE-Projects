package com.shopdirect.nce.sp.model;

public class ReassessTriadRespType {
	
	private TriadResponseType triadResponseType;

	public TriadResponseType getTriadResponseType() {
		return triadResponseType;
	}

	public void setTriadResponseType(TriadResponseType triadResponseType) {
		this.triadResponseType = triadResponseType;
	}
}
