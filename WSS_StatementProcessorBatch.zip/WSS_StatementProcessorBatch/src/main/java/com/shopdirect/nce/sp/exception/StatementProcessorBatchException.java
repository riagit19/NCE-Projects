package com.shopdirect.nce.sp.exception;

/**
 * It is the exception class which can be thrown for any kind of failures like
 * validations,
 * data base failures, 
 * common config failures
 * external client invocation failure
 * @author
 */
public class StatementProcessorBatchException extends Exception {

	
	private String errorCode;
	private String methodDetail;
	private String errorDesc;
	private String errorKey; 
	private String issuerId;
	private Throwable originException;
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public StatementProcessorBatchException() {
		// Default Constructor
	}

	
	public StatementProcessorBatchException(String errorCode,String errorDesc, Throwable originException) {
		super(errorDesc);
		this.errorCode = errorCode;
		
		this.errorDesc = errorDesc;
		
		this.originException = originException;
	}
	
	public StatementProcessorBatchException(String errorCode, String methodDetail, String errorDesc, String errorKey,
			String issuerId, Throwable originException) {
		super(errorDesc);
		this.errorCode = errorCode;
		this.methodDetail = methodDetail;
		this.errorDesc = errorDesc;
		this.errorKey = errorKey;
		this.issuerId = issuerId;
		this.originException = originException;
	}


	

	/**
	 * @return the methodDetail
	 */
	public String getMethodDetail() {
		return methodDetail;
	}


	/**
	 * @param methodDetail the methodDetail to set
	 */
	public void setMethodDetail(String methodDetail) {
		this.methodDetail = methodDetail;
	}


	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorDesc() {
		return errorDesc;
	}

	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}

	public String getErrorKey() {
		return errorKey;
	}

	public void setErrorKey(String errorKey) {
		this.errorKey = errorKey;
	}

	public String getIssuerId() {
		return issuerId;
	}

	public void setIssuerId(String issuerId) {
		this.issuerId = issuerId;
	}

	public Throwable getOriginException() {
		return originException;
	}

	public void setOriginException(Throwable originException) {
		this.originException = originException;
	}




	



}
