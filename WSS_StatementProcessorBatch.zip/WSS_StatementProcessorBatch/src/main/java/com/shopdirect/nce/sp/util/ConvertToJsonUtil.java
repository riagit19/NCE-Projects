package com.shopdirect.nce.sp.util;

import org.codehaus.jackson.map.ObjectMapper;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;

public class ConvertToJsonUtil {
	
private static SDLoggerImpl logger = new SDLoggerImpl();

	private ConvertToJsonUtil() {
		
	}
	
	public static String convertToJson(Object object) throws StatementProcessorBatchException{
		logger.debug("[ConvertToJsonUtil -- convertToJson] -- Start"); 
		String jsonFromObject = "";
			try{	
				ObjectMapper mapper=new ObjectMapper();
				jsonFromObject=mapper.writeValueAsString(object);
			}catch(Exception e){
				logger.debug("[ConvertToJsonUtil -- convertToJson] -- Exception: " + e.getMessage());
				throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_BUSINESS_ERROR_CODE,
						"[ConvertToJson-convertToJson] Exception Block",
						"Business exception generated at time to process the data collection "+ e.getMessage(),
						null, null,e);
			}
			logger.debug("[ConvertToJsonUtil -- convertToJson] -- End"); 
			return jsonFromObject;
	}
}
