package com.shopdirect.nce.sp.model;

import java.sql.SQLData;
import java.sql.SQLException;
import java.sql.SQLInput;
import java.sql.SQLOutput;
import java.util.Date;

public class RiskNavigatorParams implements SQLData {

	private String sqlType;
	private String publicAccountNumber;
	private String retailAccountNumber;
	private Date statementDate;
	private Double riskNavScore;
	private Double overIndebtScore;
	private String mOiScoreUpdated;
	private Double recordId;
	private Double createdBy;
	private Date creationDate;
	private Double lastUpdatedBy;
	private Date lastUpdatedDate;
	private Double batchId;
	private String interfaceStatus;
	private String errorMessage;

	@Override
	public void readSQL(SQLInput stream, String typeName) throws SQLException {
		sqlType = typeName;
		setPublicAccountNumber(stream.readString());
		setRetailAccountNumber(stream.readString());
		setStatementDate(stream.readDate());
		setRiskNavScore(stream.readDouble());
		setOverIndebtScore(stream.readDouble());
		setmOiScoreUpdated(stream.readString());
		setRecordId(stream.readDouble());
		setCreatedBy(stream.readDouble());
		setCreationDate(stream.readDate());
		setLastUpdatedBy(stream.readDouble());
		setLastUpdatedDate(stream.readDate());
		setBatchId(stream.readDouble());
		setInterfaceStatus(stream.readString());
		setErrorMessage(stream.readString());
	}

	@Override
	public void writeSQL(SQLOutput stream) throws SQLException {
		stream.writeString(getPublicAccountNumber());
		stream.writeString(getRetailAccountNumber());
		stream.writeDate(new java.sql.Date(getStatementDate().getTime()));
		stream.writeDouble(getRiskNavScore());
		stream.writeDouble(getOverIndebtScore());
		stream.writeString(getmOiScoreUpdated());
		stream.writeDouble(getRecordId());
		stream.writeDouble(getCreatedBy());
		stream.writeDate(new java.sql.Date(getCreationDate().getTime()));
		stream.writeDouble(getLastUpdatedBy());
		stream.writeDate(new java.sql.Date(getLastUpdatedDate().getTime()));
		stream.writeDouble(getBatchId());
		stream.writeString(getInterfaceStatus());
		stream.writeString(getErrorMessage());
	}

	@Override
	public String getSQLTypeName() throws SQLException {
		return sqlType;
	}

	public String getPublicAccountNumber() {
		return publicAccountNumber;
	}

	public void setPublicAccountNumber(String publicAccountNumber) {
		this.publicAccountNumber = publicAccountNumber;
	}

	public String getRetailAccountNumber() {
		return retailAccountNumber;
	}

	public void setRetailAccountNumber(String retailAccountNumber) {
		this.retailAccountNumber = retailAccountNumber;
	}

	public Date getStatementDate() {
		return statementDate;
	}

	public void setStatementDate(Date statementDate) {
		this.statementDate = statementDate;
	}

	public Double getRiskNavScore() {
		return riskNavScore;
	}

	public void setRiskNavScore(Double riskNavScore) {
		this.riskNavScore = riskNavScore;
	}

	public Double getOverIndebtScore() {
		return overIndebtScore;
	}

	public void setOverIndebtScore(Double overIndebtScore) {
		this.overIndebtScore = overIndebtScore;
	}

	public String getmOiScoreUpdated() {
		return mOiScoreUpdated;
	}

	public void setmOiScoreUpdated(String mOiScoreUpdated) {
		this.mOiScoreUpdated = mOiScoreUpdated;
	}

	public Double getRecordId() {
		return recordId;
	}

	public void setRecordId(Double recordId) {
		this.recordId = recordId;
	}

	public Double getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Double createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public Double getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(Double lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public Double getBatchId() {
		return batchId;
	}

	public void setBatchId(Double batchId) {
		this.batchId = batchId;
	}

	public String getInterfaceStatus() {
		return interfaceStatus;
	}

	public void setInterfaceStatus(String interfaceStatus) {
		this.interfaceStatus = interfaceStatus;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

}
