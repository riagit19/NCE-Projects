package com.shopdirect.nce.sp.business;

import java.sql.SQLException;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.shopdirect.nce.common.extcnfg.ExternalFileDataConfiguration;
import com.shopdirect.nce.rule.model.Account;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.dao.AccountInfoStatusDaoImpl;
import com.shopdirect.nce.sp.dao.AssessTriadDao;
import com.shopdirect.nce.sp.dao.MasterAcCreditAndReassessmentDaoImpl;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.externalclient.AssessTriadExternalClient;
import com.shopdirect.nce.sp.model.AccountingSnapshot;
import com.shopdirect.nce.sp.model.AccountingSnapshotTriad;
import com.shopdirect.nce.sp.model.AgreementTriad;
import com.shopdirect.nce.sp.model.AuthType;
import com.shopdirect.nce.sp.model.BatchDetails;
import com.shopdirect.nce.sp.model.BatchGroup;
import com.shopdirect.nce.sp.model.BatchLinked;
import com.shopdirect.nce.sp.model.BatchLinkedGroup;
import com.shopdirect.nce.sp.model.BatchLinkedMonth;
import com.shopdirect.nce.sp.model.BatchMonth;
import com.shopdirect.nce.sp.model.CreditLimitType;
import com.shopdirect.nce.sp.model.CurrentAccoutingSnapshotTriad;
import com.shopdirect.nce.sp.model.CustomerAccountInfo;
import com.shopdirect.nce.sp.model.CustomerContractTriad;
import com.shopdirect.nce.sp.model.PeriodPaymentTriad;
import com.shopdirect.nce.sp.model.PseudoChargeResponseType;
import com.shopdirect.nce.sp.model.RetailContractTriad;
import com.shopdirect.nce.sp.transform.AccountRuleTransformer;
import com.shopdirect.nce.sp.transform.AccountingSnapshotTransformer;
import com.shopdirect.nce.sp.transform.AssessTriadTransformer;
import com.shopdirect.nce.sp.transform.BatchDetailsTransformer;
import com.shopdirect.nce.sp.transform.BatchGroupTransformer;
import com.shopdirect.nce.sp.transform.BatchLinkedGroupTransformer;
import com.shopdirect.nce.sp.transform.BatchLinkedMonthTransformer;
import com.shopdirect.nce.sp.transform.BatchLinkedTransformer;
import com.shopdirect.nce.sp.transform.BatchMonthTransformer;
import com.shopdirect.nce.sp.util.CommonConfigHelper;
import com.shopdirect.osb.reassesstriadar.ReassessTRIADARRequestType;
import com.shopdirect.osb.reassesstriadar.ReassessTRIADARResponseType;
import com.shopdirect.osb.xsd.header.RequestHeaderType;


/**
 * 
 * @author SudiptaRoy
 *
 */
public class AssessTriadBusinessImpl extends AccountReassessmentBaseBusinessImpl{

	private CommonConfigHelper commonConfigHelper = null;
	private AssessTriadDao assessTriadDao;
	private AssessTriadTransformer transformer;
	private AssessTriadExternalClient triadExternalClient;

	public AssessTriadBusinessImpl() throws StatementProcessorBatchException {
		setCommonConfigHelper(CommonConfigHelper.getInstance());
	}

	@SuppressWarnings("unchecked")
	public com.shopdirect.nce.sp.model.ReassessTRIADARResponseType processTriad(CustomerAccountInfo accountInfo, Map<String, PseudoChargeResponseType> linkedAccPseudoRspMap,
			Map<String, String> updateCustomerMap) throws StatementProcessorBatchException {
		getLogger().debug("[AssessTriadBusinessImpl -- processTriad] -- Start");
		String publicAccNum = accountInfo.getPublicAccountId();
		String retailAccNum = accountInfo.getRetailAccountId();
		Date statementDate = accountInfo.getStatementDate();
		Format formatter = new SimpleDateFormat("dd-MMM-yy");
		String statementDt = formatter.format(statementDate);
		com.shopdirect.nce.sp.model.ReassessTRIADARResponseType response = null;
		String arrearsStatus = updateCustomerMap.get(StatementProcessorBatchConstants.ARREARS_STATUS_CODE);
		String tradingCode = updateCustomerMap.get(StatementProcessorBatchConstants.TRADING_CODE);
		AccountInfoStatusDaoImpl accountInfoStatusDaoImpl = new AccountInfoStatusDaoImpl();
		
		Set<String> linkedAccountNumSet = linkedAccPseudoRspMap.keySet();
		
		//Initialise all TRIAD data
		RetailContractTriad retailContractTriad = new RetailContractTriad();
		AccountingSnapshotTriad accountingSnapshotTriad = new AccountingSnapshotTriad();
		CustomerContractTriad customerContractTriad = new CustomerContractTriad();
		AgreementTriad agreementTriad = new AgreementTriad();
		CurrentAccoutingSnapshotTriad currentAccSnapshotTriad = new CurrentAccoutingSnapshotTriad();
		
		List<RetailContractTriad> retailContractTriadList = null;
		List<AccountingSnapshotTriad> accountingSnapshotTriadList = null;
		List<CustomerContractTriad> customerContractTriadList = null;
		List<AgreementTriad> agreementTriadList = null;
		List<CurrentAccoutingSnapshotTriad> currentAccSnapshotTriadList = null;
		List<PeriodPaymentTriad> periodPaymentTriadList = null;
		
		ExternalFileDataConfiguration externalClientConfig = commonConfigHelper
				.loadPropertyConfig(StatementProcessorBatchConstants.AUDITLOG_CONFIGURATION_FILE_KEY);
		String callType = getCommonConfigHelper().readConfigData(externalClientConfig, StatementProcessorBatchConstants.CALL_TYPE);
		String reasonCode = getCommonConfigHelper().readConfigData(externalClientConfig, StatementProcessorBatchConstants.REASON_CODE);
		
		try {
			//Call TRIAD DB data
			Object[] allTriadObject = getAssessTriadDao().getAllTriadData(publicAccNum, statementDate, linkedAccountNumSet);
			if (allTriadObject.length > 5) {
				retailContractTriadList = (List<RetailContractTriad>)allTriadObject[0];
				accountingSnapshotTriadList = (List<AccountingSnapshotTriad>)allTriadObject[1];
				customerContractTriadList = (List<CustomerContractTriad>)allTriadObject[2];
				agreementTriadList = (List<AgreementTriad>)allTriadObject[3];
				currentAccSnapshotTriadList = (List<CurrentAccoutingSnapshotTriad>)allTriadObject[4];
				periodPaymentTriadList = (List<PeriodPaymentTriad>)allTriadObject[5];
			}
			
			List<RetailContractTriad> linkedRetailContTriadList = new ArrayList<RetailContractTriad>();
			for (RetailContractTriad retContTriad : retailContractTriadList ) {
				if (retContTriad.getRetailAccountNumber().equalsIgnoreCase(retailAccNum)) {
					retailContractTriad = retContTriad;
				} else {
					linkedRetailContTriadList.add(retContTriad);
				}
			}
			
			if (!accountingSnapshotTriadList.isEmpty()) {
				accountingSnapshotTriad = accountingSnapshotTriadList.get(0);
			}
			
			List<CustomerContractTriad> linkedCustContTriadList = new ArrayList<CustomerContractTriad>();
			for (CustomerContractTriad custContTriad : customerContractTriadList) {
				if (custContTriad.getPublicAccountNumber().equalsIgnoreCase(publicAccNum)) {
					customerContractTriad = custContTriad;
				} else {
					linkedCustContTriadList.add(custContTriad);
				}
			}
			if (!agreementTriadList.isEmpty()) {
				agreementTriad = agreementTriadList.get(0);
			}
			if (!currentAccSnapshotTriadList.isEmpty()) {
				currentAccSnapshotTriad = currentAccSnapshotTriadList.get(0);
			}
			
			//Get all Java rule values
			Account accountRule = new Account();
			AccountRuleTransformer accountRuleTransformer = new AccountRuleTransformer();
			accountRuleTransformer.setAllJavaRuleVal(accountRule, accountInfo, retailContractTriadList, 
					customerContractTriadList, agreementTriadList, currentAccSnapshotTriad, callType, accountingSnapshotTriadList);
			
			BatchDetails batchDetailsObj;
			List<BatchLinked> batchLinkedList;
			List<AccountingSnapshot> accountingSnapshotList;
			List<BatchGroup> batchGroupList;
			List<BatchLinkedGroup> batchLinkedGroupList;
			List<BatchMonth> batchMonthList;
			List<BatchLinkedMonth> batchLinkedMonthList;
			
			AccountingSnapshotTransformer accountingSnapshotTransformer = new AccountingSnapshotTransformer();
			accountingSnapshotList = accountingSnapshotTransformer.getAccountingSnapshot(linkedRetailContTriadList, accountingSnapshotTriadList, currentAccSnapshotTriad, linkedCustContTriadList, agreementTriadList, accountInfo);
			
			BatchDetailsTransformer batchDetailsTransformer = new BatchDetailsTransformer();
			batchDetailsObj = batchDetailsTransformer.getBatchDetails(retailContractTriad, accountingSnapshotTriad, customerContractTriad, agreementTriad, accountInfo, accountRule);
			
			BatchGroupTransformer batchGroupTransformer = new BatchGroupTransformer();
			batchGroupList = batchGroupTransformer.getBatchGroup(accountingSnapshotList);
			
			BatchMonthTransformer batchMonthTransformer = new BatchMonthTransformer();
			batchMonthList = batchMonthTransformer.getBatchMonth(batchDetailsObj, accountingSnapshotList, accountInfo);
			
			BatchLinkedTransformer batchLinkedTransformer = new BatchLinkedTransformer();
			batchLinkedList = batchLinkedTransformer.getBatchLinked(linkedRetailContTriadList, accountingSnapshotTriadList, linkedCustContTriadList, agreementTriadList, accountInfo, accountRule);
			
			BatchLinkedGroupTransformer batchLinkedGroupTransformer = new BatchLinkedGroupTransformer();
			batchLinkedGroupList = batchLinkedGroupTransformer.getBatchLinkedGroup(accountingSnapshotList);
			
			BatchLinkedMonthTransformer batchLinkedMonthTransformer = new BatchLinkedMonthTransformer();
			batchLinkedMonthList = batchLinkedMonthTransformer.getBatchLinkedMonth(batchDetailsObj, accountingSnapshotList, accountInfo);

			//Transform Reassess TRIAD request
			ReassessTRIADARRequestType triadRequestType = getTransformer().transformRequest(batchDetailsObj, batchLinkedList,
						accountingSnapshotList, batchGroupList, batchLinkedGroupList, batchMonthList, batchLinkedMonthList, accountInfo, 
						customerContractTriad, retailContractTriad, agreementTriad, currentAccSnapshotTriad,  accountingSnapshotTriad, 
						accountRule, callType, reasonCode, tradingCode);
			
			//Call TRIAD client to retrieve response
			ReassessTRIADARResponseType triadResponseType = getTriadExternalClient().retrieveTRIADContent(new RequestHeaderType(), triadRequestType);
			
			//Transform own model object
			response = getTransformer().transformRespone(triadResponseType);
			
			if (isValidTRIADResponse(response)) {
				CreditLimitType creditLimitType = response.getReassessTriadRespType().getTriadResponseType().getAccountResponseType().getTriadDataType().getCreditLimitType();
				AuthType authType = response.getReassessTriadRespType().getTriadResponseType().getAccountResponseType().getTriadDataType().getAuthType();
				if (creditLimitType.getActualCreditLimit() != creditLimitType.getProposedCreditLimit()) {
					String creditLimitAction = getCommonConfigHelper().readConfigData(externalClientConfig, StatementProcessorBatchConstants.CREDIT_LIMIT_ACTION_CHANGE);
					String clStatus = getCommonConfigHelper().readConfigData(externalClientConfig, StatementProcessorBatchConstants.CL_STATUS);
					MasterAcCreditAndReassessmentDaoImpl masterAcCreditAndReassessmentDaoImpl = new MasterAcCreditAndReassessmentDaoImpl();
					int status = 0;
					if (creditLimitType.getProposedCreditLimit() != null && creditLimitType.getActualCreditLimit() != null) {
						status = masterAcCreditAndReassessmentDaoImpl.processUpdateCreditAndReassessment(creditLimitType, authType, publicAccNum, creditLimitAction,
								clStatus, statementDt, arrearsStatus, tradingCode);
					}
					if (status == 0) {
						creditLimitAction = getCommonConfigHelper().readConfigData(externalClientConfig, StatementProcessorBatchConstants.CREDIT_LIMIT_ACTION_NONE);
						if (creditLimitType.getProposedCreditLimit() != null && creditLimitType.getActualCreditLimit() != null) {
							status = masterAcCreditAndReassessmentDaoImpl.processInsertCreditAndReassessment(creditLimitType, authType, publicAccNum, creditLimitAction,
									clStatus, statementDt, arrearsStatus, tradingCode);
						}
					} 
					if (status != 0) {
						accountInfoStatusDaoImpl.updateCimAccountInfoStatus(publicAccNum,statementDt,StatementProcessorBatchConstants.AR_STATUS_COMPLETED);
					}
				}
			}

		} catch (StatementProcessorBatchException spbe) {
			getLogger().error("[AssessTriadBusinessImpl -- processTriad] -- SPBException: " + spbe);
			try {
				accountInfoStatusDaoImpl.updateCimAccountInfoStatus(publicAccNum,statementDt,StatementProcessorBatchConstants.AR_STATUS_ERROR);
			} catch(SQLException e) {
				getLogger().error("[AssessTriadBusinessImpl -- processTriad] -- SQLException: " + e);
			}
			spbe.setErrorKey(StatementProcessorBatchConstants.ERROR_TRIAD);
			throw spbe;
		} catch (Exception e) {
			getLogger().error("[AssessTriadBusinessImpl -- processTriad] -- Exception: " + e);
			try {
				accountInfoStatusDaoImpl.updateCimAccountInfoStatus(publicAccNum,statementDt,StatementProcessorBatchConstants.AR_STATUS_ERROR);
			} catch(SQLException sqe) {
				getLogger().error("[AssessTriadBusinessImpl -- processTriad] -- SQLException: " + sqe);
			}
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_BUSINESS_ERROR_CODE,
					"[AssessTriadBusinessImpl-processTriad] Exception",
					"Business exception generated at time to process Triad " + e.getMessage(),
					StatementProcessorBatchConstants.ERROR_TRIAD, null, e);
		}
		getLogger().debug("[AssessTriadBusinessImpl -- processTriad] -- End");
		return response;
	}

	private boolean isValidTRIADResponse(com.shopdirect.nce.sp.model.ReassessTRIADARResponseType response) {
		
		return response != null &&
				response.getReassessTriadRespType() != null &&
				response.getReassessTriadRespType().getTriadResponseType() != null &&
				response.getReassessTriadRespType().getTriadResponseType().getAccountResponseType() != null &&
				response.getReassessTriadRespType().getTriadResponseType().getAccountResponseType().getTriadDataType() != null &&
				response.getReassessTriadRespType().getTriadResponseType().getAccountResponseType().getTriadDataType().getCreditLimitType() != null;
	}

	/**
	 * @return the commonConfigHelper
	 */
	public CommonConfigHelper getCommonConfigHelper() {
		return commonConfigHelper;
	}

	/**
	 * @param commonConfigHelper
	 *            the commonConfigHelper to set
	 */
	public void setCommonConfigHelper(CommonConfigHelper commonConfigHelper) {
		this.commonConfigHelper = commonConfigHelper;
	}

	public AssessTriadDao getAssessTriadDao() throws StatementProcessorBatchException {
		if (assessTriadDao == null) {
			assessTriadDao = new AssessTriadDao();
		}
		return assessTriadDao;
	}

	public void setAssessTriadDao(AssessTriadDao assessTriadDao) {
		this.assessTriadDao = assessTriadDao;
	}

	public AssessTriadTransformer getTransformer() {
		if (transformer == null) {
			transformer = new AssessTriadTransformer();
		}
		return transformer;
	}

	public void setTransformer(AssessTriadTransformer transformer) {
		this.transformer = transformer;
	}

	public AssessTriadExternalClient getTriadExternalClient() throws StatementProcessorBatchException {
		if (triadExternalClient == null) {
			triadExternalClient = new AssessTriadExternalClient();
		}
		return triadExternalClient;
	}

	public void setTriadExternalClient(AssessTriadExternalClient triadExternalClient) {
		this.triadExternalClient = triadExternalClient;
	}

}
