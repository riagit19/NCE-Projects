package com.shopdirect.nce.sp.model;

public class TriadDataType {

	private AuthType authType;
	private CreditLimitType creditLimitType;
	
	public AuthType getAuthType() {
		return authType;
	}
	public void setAuthType(AuthType authType) {
		this.authType = authType;
	}
	public CreditLimitType getCreditLimitType() {
		return creditLimitType;
	}
	public void setCreditLimitType(CreditLimitType creditLimitType) {
		this.creditLimitType = creditLimitType;
	}
}
