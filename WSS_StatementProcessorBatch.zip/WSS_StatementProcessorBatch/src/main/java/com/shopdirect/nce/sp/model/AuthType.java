package com.shopdirect.nce.sp.model;

import java.math.BigInteger;

public class AuthType {

	private String authDecision;

	private String authApprovalActionOrder;

	private String authApprovalActionShadowLimit;
	
	private String authLetterAlpha;

	private String authLetterDigits;

	private String authReferDeclineReason;

	private String authReferDeclineLetterId;
	
	private BigInteger annotationsTriadDecisionKeyAuth;

	private BigInteger bNPLEligibility;

	private BigInteger shadowCreditMonetaryLimit;
	
	private BigInteger actualCreditMonetaryLimit;
	
	private String authOverrideDecision;
	
	private String authOverrideRDReason;
	
	private String authOverrideRDLetterId;

	public String getAuthDecision() {
		return authDecision;
	}

	public void setAuthDecision(String authDecision) {
		this.authDecision = authDecision;
	}

	public String getAuthApprovalActionOrder() {
		return authApprovalActionOrder;
	}

	public void setAuthApprovalActionOrder(String authApprovalActionOrder) {
		this.authApprovalActionOrder = authApprovalActionOrder;
	}

	public String getAuthApprovalActionShadowLimit() {
		return authApprovalActionShadowLimit;
	}

	public void setAuthApprovalActionShadowLimit(String authApprovalActionShadowLimit) {
		this.authApprovalActionShadowLimit = authApprovalActionShadowLimit;
	}

	public String getAuthLetterAlpha() {
		return authLetterAlpha;
	}

	public void setAuthLetterAlpha(String authLetterAlpha) {
		this.authLetterAlpha = authLetterAlpha;
	}

	public String getAuthLetterDigits() {
		return authLetterDigits;
	}

	public void setAuthLetterDigits(String authLetterDigits) {
		this.authLetterDigits = authLetterDigits;
	}

	public String getAuthReferDeclineReason() {
		return authReferDeclineReason;
	}

	public void setAuthReferDeclineReason(String authReferDeclineReason) {
		this.authReferDeclineReason = authReferDeclineReason;
	}

	public String getAuthReferDeclineLetterId() {
		return authReferDeclineLetterId;
	}

	public void setAuthReferDeclineLetterId(String authReferDeclineLetterId) {
		this.authReferDeclineLetterId = authReferDeclineLetterId;
	}

	public BigInteger getAnnotationsTriadDecisionKeyAuth() {
		return annotationsTriadDecisionKeyAuth;
	}

	public void setAnnotationsTriadDecisionKeyAuth(BigInteger annotationsTriadDecisionKeyAuth) {
		this.annotationsTriadDecisionKeyAuth = annotationsTriadDecisionKeyAuth;
	}

	public BigInteger getbNPLEligibility() {
		return bNPLEligibility;
	}

	public void setbNPLEligibility(BigInteger bNPLEligibility) {
		this.bNPLEligibility = bNPLEligibility;
	}

	public BigInteger getShadowCreditMonetaryLimit() {
		return shadowCreditMonetaryLimit;
	}

	public void setShadowCreditMonetaryLimit(BigInteger shadowCreditMonetaryLimit) {
		this.shadowCreditMonetaryLimit = shadowCreditMonetaryLimit;
	}

	public BigInteger getActualCreditMonetaryLimit() {
		return actualCreditMonetaryLimit;
	}

	public void setActualCreditMonetaryLimit(BigInteger actualCreditMonetaryLimit) {
		this.actualCreditMonetaryLimit = actualCreditMonetaryLimit;
	}

	public String getAuthOverrideDecision() {
		return authOverrideDecision;
	}

	public void setAuthOverrideDecision(String authOverrideDecision) {
		this.authOverrideDecision = authOverrideDecision;
	}

	public String getAuthOverrideRDReason() {
		return authOverrideRDReason;
	}

	public void setAuthOverrideRDReason(String authOverrideRDReason) {
		this.authOverrideRDReason = authOverrideRDReason;
	}

	public String getAuthOverrideRDLetterId() {
		return authOverrideRDLetterId;
	}

	public void setAuthOverrideRDLetterId(String authOverrideRDLetterId) {
		this.authOverrideRDLetterId = authOverrideRDLetterId;
	}
	
}
