package com.shopdirect.nce.sp.model;

import java.util.Date;

public class DrawdownItem {
	
	private String drawdownItemId;
	 
	private String drawdownId;
	
	private String drawdownOldId;
	 
	private String ddiStatus;
	 
	private String orderNumber;
	 
	private Double itemLineNumber;
	 
	private String itemCode;
	 
    private String itemText;
	 
	private Double retailPrice;
	 
 	private Long batchId;
	
	private String errorFlag;
	
	private String errorMessage;
	
	private Date creationDate;
	
	private Long createdByUser;
	
	private Date lastUpdateDate;
	
	private Long lastUpdateByUser;

	public String getDrawdownItemId() {
		return drawdownItemId;
	}

	public void setDrawdownItemId(String drawdownItemId) {
		this.drawdownItemId = drawdownItemId;
	}

	public String getDrawdownId() {
		return drawdownId;
	}

	public void setDrawdownId(String drawdownId) {
		this.drawdownId = drawdownId;
	}

	public String getDdiStatus() {
		return ddiStatus;
	}

	public void setDdiStatus(String ddiStatus) {
		this.ddiStatus = ddiStatus;
	}

	public String getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}

	public Double getItemLineNumber() {
		return itemLineNumber;
	}

	public void setItemLineNumber(Double itemLineNumber) {
		this.itemLineNumber = itemLineNumber;
	}

	public String getItemCode() {
		return itemCode;
	}

	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}

	public String getItemText() {
		return itemText;
	}

	public void setItemText(String itemText) {
		this.itemText = itemText;
	}

	public Double getRetailPrice() {
		return retailPrice;
	}

	public void setRetailPrice(Double retailPrice) {
		this.retailPrice = retailPrice;
	}

	public Long getBatchId() {
		return batchId;
	}

	public void setBatchId(Long batchId) {
		this.batchId = batchId;
	}

	public String getErrorFlag() {
		return errorFlag;
	}

	public void setErrorFlag(String errorFlag) {
		this.errorFlag = errorFlag;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public Long getCreatedByUser() {
		return createdByUser;
	}

	public void setCreatedByUser(Long createdByUser) {
		this.createdByUser = createdByUser;
	}

	public Date getLastUpdateDate() {
		return lastUpdateDate;
	}

	public void setLastUpdateDate(Date lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}

	public Long getLastUpdateByUser() {
		return lastUpdateByUser;
	}

	public void setLastUpdateByUser(Long lastUpdateByUser) {
		this.lastUpdateByUser = lastUpdateByUser;
	}

	public String getDrawdownOldId() {
		return drawdownOldId;
	}

	public void setDrawdownOldId(String drawdownOldId) {
		this.drawdownOldId = drawdownOldId;
	}

}
