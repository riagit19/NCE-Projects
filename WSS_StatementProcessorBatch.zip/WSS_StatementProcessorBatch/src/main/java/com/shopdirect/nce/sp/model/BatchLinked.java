package com.shopdirect.nce.sp.model;

import java.math.BigDecimal;
import java.sql.Date;

public class BatchLinked extends BatchDetails {
	private BigDecimal batchLinkedOccurence;
	private BigDecimal debitAmount;
	private BigDecimal numReturnedPaymentsTSP;
	private BigDecimal creditRiskFactor;
	private Date fidFlagDate;
	private BigDecimal totalUnchargedMvmts;
	
	public BatchLinked() {
		super();
	}

	public BatchLinked(BigDecimal batchLinkedOccurence, BigDecimal debitAmount, BigDecimal numReturnedPaymentsTSP,
			BigDecimal creditRiskFactor, Date fidFlagDate, BigDecimal totalUnchargedMvmts) {
		super();
		this.batchLinkedOccurence = batchLinkedOccurence;
		this.debitAmount = debitAmount;
		this.numReturnedPaymentsTSP = numReturnedPaymentsTSP;
		this.creditRiskFactor = creditRiskFactor;
		this.fidFlagDate = fidFlagDate;
		this.totalUnchargedMvmts = totalUnchargedMvmts;
	}

	public BigDecimal getBatchLinkedOccurence() {
		return batchLinkedOccurence;
	}

	public void setBatchLinkedOccurence(BigDecimal batchLinkedOccurence) {
		this.batchLinkedOccurence = batchLinkedOccurence;
	}

	public BigDecimal getDebitAmount() {
		return debitAmount;
	}

	public void setDebitAmount(BigDecimal debitAmount) {
		this.debitAmount = debitAmount;
	}

	public BigDecimal getNumReturnedPaymentsTSP() {
		return numReturnedPaymentsTSP;
	}

	public void setNumReturnedPaymentsTSP(BigDecimal numReturnedPaymentsTSP) {
		this.numReturnedPaymentsTSP = numReturnedPaymentsTSP;
	}

	public BigDecimal getCreditRiskFactor() {
		return creditRiskFactor;
	}

	public void setCreditRiskFactor(BigDecimal creditRiskFactor) {
		this.creditRiskFactor = creditRiskFactor;
	}

	public Date getFidFlagDate() {
		return fidFlagDate;
	}

	public void setFidFlagDate(Date fidFlagDate) {
		this.fidFlagDate = fidFlagDate;
	}

	public BigDecimal getTotalUnchargedMvmts() {
		return totalUnchargedMvmts;
	}

	public void setTotalUnchargedMvmts(BigDecimal totalUnchargedMvmts) {
		this.totalUnchargedMvmts = totalUnchargedMvmts;
	}
	
	
}
