package com.shopdirect.nce.sp.externalclient.handler;

import javax.xml.ws.handler.LogicalHandler;
import javax.xml.ws.handler.LogicalMessageContext;
import javax.xml.ws.handler.MessageContext;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;





/**
 * Adds a performance record to the performance logs measuring the entire time taken to fulfill
 * the request related to the IMS services. Consequently, the SOAP message must be parsed prior to
 * executing this handler.
 * @author Amit C Kumar
 */
public class ExternalServicePerformanceLoggingHandler implements LogicalHandler<LogicalMessageContext> {

	private static final SDLoggerImpl Logger = new SDLoggerImpl();
	private String operationName;

	/**
	 * @param context LogicalMessageContext
	 * @return boolean
	 */
	@Override
	public boolean handleMessage(LogicalMessageContext context) {
		return processMessage(context);
	}

	/**
	 * @param context LogicalMessageContext
	 * @return boolean
	 */
	@Override
	public boolean handleFault(LogicalMessageContext context) {
		return processMessage(context);
	}

	/**
	 * @param context MessageContext
	 */
	@Override
	public void close(MessageContext context) {
		// Not Implemented
	}

	/**
	 * Print  total time taken web service 
	 * @param context
	 * @return boolean
	 */
	private boolean processMessage(LogicalMessageContext context) {
		Boolean outboundProperty = (Boolean) context.get(MessageContext.MESSAGE_OUTBOUND_PROPERTY);
		if (outboundProperty) {
			getLogger().info(operationName + "- Start.");
		} else {
			getLogger().info(operationName + "- End.");
		}
		return true;
	}

	/**
	 * @return the logger
	 */
	public static SDLoggerImpl getLogger() {
		return Logger;
	}

	/**
	 * @return the operationName
	 */
	public final String getOperationName() {
		return operationName;
	}
	
	/**
	 * @param operationName the operationName to set
	 */
	public final void setOperationName(String operationName) {
		this.operationName = operationName;
	}
}

