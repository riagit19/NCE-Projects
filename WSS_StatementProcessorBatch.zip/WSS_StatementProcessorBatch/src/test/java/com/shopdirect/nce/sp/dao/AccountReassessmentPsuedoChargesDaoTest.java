/**
 * 
 */
package com.shopdirect.nce.sp.dao;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.AccountReassessmentPseudoChargeReqType;
import com.shopdirect.nce.sp.model.CustomerAccountInfo;
import com.shopdirect.nce.sp.util.StatementProcessorBatchUtil;

/**
 * @author VijayaprakashPrathip
 *
 */
public class AccountReassessmentPsuedoChargesDaoTest {
	private static SDLoggerImpl logger = new SDLoggerImpl();
	AccountReassessmentPsuedoChargesDao accountReassessmentPsuedoChargesDao = null;
	
	@Before
	public void setUp() {
		String CURRENT_WORKING_PATH = (System.getProperty("user.dir") + "\\src\\main\\extcnf\\").replaceAll("\\\\",	"/");
		String SD_ENV_NAME = "DEV";
		System.setProperty("SERVER_CONFIG_ROOT", CURRENT_WORKING_PATH);
		System.setProperty("SDEnvName", SD_ENV_NAME);	
		try {
			accountReassessmentPsuedoChargesDao = new AccountReassessmentPsuedoChargesDao();
		} catch (Exception e) {
			e.printStackTrace();
		}
	} 
	
	/**
	 * Test method for {@link com.shopdirect.nce.sp.dao.AccountReassessmentPsuedoChargesDao#getCalculatePseudoCharges()}.
	 * @throws Exception
	 */
	@Test
	public void testGetCalculatePseudoCharges() throws Exception {
		CustomerAccountInfo customerAccountInfo = new CustomerAccountInfo();
		Calendar cal = Calendar.getInstance();
    	cal.add(Calendar.DATE , 0);    	
		customerAccountInfo.setAccountInfoId("341");
		customerAccountInfo.setStatementDate(cal.getTime());
		customerAccountInfo.setAccountStatus("0");
		customerAccountInfo.setCreditAccountId("166");
		customerAccountInfo.setBrandCode("LAI");
		
		try{
		List<AccountReassessmentPseudoChargeReqType> accountReassessmentPseudoChargeReqTypeList = new ArrayList<AccountReassessmentPseudoChargeReqType>();
		accountReassessmentPsuedoChargesDao = new AccountReassessmentPsuedoChargesDao();
    	accountReassessmentPseudoChargeReqTypeList = accountReassessmentPsuedoChargesDao.getCalculatePseudoCharges(customerAccountInfo.getCreditAccountId());
		
		for(AccountReassessmentPseudoChargeReqType accountReassessmentPseudoChargeReqType : accountReassessmentPseudoChargeReqTypeList){
			System.out.println("===getCustomerAccountType()==>: "+accountReassessmentPseudoChargeReqType.getCustomerAccountType());
			System.out.println("===getCreditProductType()==>: "+accountReassessmentPseudoChargeReqType.getCreditProductType());
			System.out.println("===getDrawdownTermType()==>: "+accountReassessmentPseudoChargeReqType.getDrawdownTermType());
			System.out.println("===getBrandCreditProductType()==>: "+accountReassessmentPseudoChargeReqType.getBrandCreditProductType());
			System.out.println("===getDrawdownTermItemType()==>: "+accountReassessmentPseudoChargeReqType.getDrawdownTermItemType());
			System.out.println("===getDailyRateType()==>: "+accountReassessmentPseudoChargeReqType.getDailyRateType());
			System.out.println("===getPaymentType()==>: "+accountReassessmentPseudoChargeReqType.getPaymentType());
		}
    	
    		boolean result = false;
    	
    		Assert.assertNotNull(result);
		}catch(StatementProcessorBatchException e){
			getLogger().error("[AccountReassessmentPsuedoChargesDaoTest -- testgetCalculatePseudoCharges] StatementProcessorBatchException Block "+ e.getMessage());
			StatementProcessorBatchUtil.getprintStackTraceString(e);
		}
	}

	public static SDLoggerImpl getLogger() {
		return logger;
	}
	public static void setLogger(SDLoggerImpl logger) {
		AccountReassessmentPsuedoChargesDaoTest.logger = logger;
	}
	
	/**
	 * Test method for {@link com.shopdirect.nce.sp.dao.AccountReassessmentPsuedoChargesDao#getCalculatePseudoCharges()}.
	 * @throws Exception
	 */
	@Test
	public void testGetCalculatePseudoCharges1() throws Exception {
		CustomerAccountInfo customerAccountInfo = new CustomerAccountInfo();
    	String input="18-05-2017";
    	String fromat2="dd-MM-yyyy";
		SimpleDateFormat sdf1 = new SimpleDateFormat(fromat2);
		java.util.Date statementDate = sdf1.parse(input); 
		customerAccountInfo.setAccountInfoId("341");
		customerAccountInfo.setStatementDate(statementDate);
		customerAccountInfo.setAccountStatus("0");
		customerAccountInfo.setCreditAccountId("A89894499");
		customerAccountInfo.setBrandCode("LAI");
		
		try{
		List<AccountReassessmentPseudoChargeReqType> accountReassessmentPseudoChargeReqTypeList = new ArrayList<AccountReassessmentPseudoChargeReqType>();
		accountReassessmentPsuedoChargesDao = new AccountReassessmentPsuedoChargesDao();
    	//accountReassessmentPseudoChargeReqTypeList = accountReassessmentPsuedoChargesDao.getCalculatePseudoCharges(customerAccountInfo.getCreditAccountId(),customerAccountInfo.getStatementDate());
		}catch(StatementProcessorBatchException e){
			getLogger().error("[AccountReassessmentPsuedoChargesDaoTest -- testgetCalculatePseudoCharges] StatementProcessorBatchException Block "+ e.getMessage());
			StatementProcessorBatchUtil.getprintStackTraceString(e);
		}
	}
}
