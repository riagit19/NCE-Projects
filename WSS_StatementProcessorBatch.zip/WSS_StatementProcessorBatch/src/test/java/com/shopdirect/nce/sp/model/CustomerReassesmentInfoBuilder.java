package com.shopdirect.nce.sp.model;

import java.util.Date;

public class CustomerReassesmentInfoBuilder {

	private String publicAccountId;
	private Date statementDate;
	private String accountInfoId;
	private boolean isDormant;
	private String retailAccNum;

	public CustomerReassesmentInfoBuilder withPublicAccountId(String publicAccountId) {
		this.publicAccountId = publicAccountId;
		return this;
	}

	public CustomerReassesmentInfoBuilder withStatementDate(Date statementDate) {
		this.statementDate = statementDate;
		return this;
	}

	public CustomerReassesmentInfoBuilder withAccountInfoId(String accountInfoId) {
		this.accountInfoId = accountInfoId;
		return this;
	}

	public CustomerReassesmentInfo build() {
		return new CustomerReassesmentInfo(publicAccountId, statementDate, accountInfoId, isDormant, retailAccNum);
	}

	public static CustomerReassesmentInfo populateCustomerReassesmentInfo() {
		CustomerReassesmentInfo customerReassesmentInfo = new CustomerReassesmentInfoBuilder().withAccountInfoId("9876")
				.withPublicAccountId("111").withStatementDate(new Date()).build();
		return customerReassesmentInfo;
	}
}
