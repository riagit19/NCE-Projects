package com.shopdirect.nce.sp.util;

import org.junit.Before;
import org.junit.Test;

import com.shopdirect.nce.common.extcnfg.ExternalFileDataConfiguration;
import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import junit.framework.TestCase;

public class CommonConfigHelperTest extends TestCase {
	
private static SDLoggerImpl logger = new SDLoggerImpl();

    CommonConfigHelper commonConfigHelper = null;
    ExternalFileDataConfiguration extFileDataCfg = null;	

	@Before
	public void setUp() throws StatementProcessorBatchException {
		String CURRENT_WORKING_PATH = (System.getProperty("user.dir") + "\\src\\main\\extcnf\\").replaceAll("\\\\",	"/");
		String SD_ENV_NAME = "DEV";
		System.setProperty("SERVER_CONFIG_ROOT", CURRENT_WORKING_PATH);
		System.setProperty("SDEnvName", SD_ENV_NAME);	
		commonConfigHelper=CommonConfigHelper.getInstance();
	}
	@Test
	public void testLoadPropertyConfig() throws StatementProcessorBatchException{
		try{
			ExternalFileDataConfiguration externalClientConfig = commonConfigHelper.loadPropertyConfig(StatementProcessorBatchConstants.AUDITLOG_CONFIGURATION_FILE_KEY);
			assertNotNull(externalClientConfig);
		}catch(Exception e){
			logger.error(e.getMessage());
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_BUSINESS_ERROR_CODE,
					"[CommonConfigHelperTest-testLoadPropertyConfig] Exception Block",
					"Business exception generated at time to process the data collection "+ e.getMessage(),
					null, null,e);
		}	
	}
	
	
	@Test
	public void testReadConfigData() throws StatementProcessorBatchException{
		try{
			
			ExternalFileDataConfiguration externalClientConfig = commonConfigHelper
					.loadPropertyConfig(StatementProcessorBatchConstants.AUDITLOG_CONFIGURATION_FILE_KEY);
			 String value=commonConfigHelper.readConfigData(externalClientConfig, "invokeCallSuccess");
			 assertNotNull(value);
		}catch(Exception e){
			logger.error(e.getMessage());
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_BUSINESS_ERROR_CODE,
					"[CommonConfigHelperTest-testReadConfigData] Exception Block",
					"Business exception generated at time to process the data collection "+ e.getMessage(),
					null, null,e);
		}	
	}
	
	
	

}
