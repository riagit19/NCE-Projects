package com.shopdirect.nce.sp.dao.creditdataload;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.exception.BuisnessException;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.DrawdownTransaction;

public class DrawdownTransactionDaoImplTest {
	ArrayList<DrawdownTransaction> drawdownTransactionList = null;
	Calendar cal = Calendar.getInstance();
	private static SDLoggerImpl logger = new SDLoggerImpl();

	@Before
	public void setUp() throws Exception {
		String CURRENT_WORKING_PATH = (System.getProperty("user.dir") + "\\src\\main\\extcnf\\").replaceAll("\\\\",
				"/");
		String SD_ENV_NAME = "DEV";
		System.setProperty("SERVER_CONFIG_ROOT", CURRENT_WORKING_PATH);
		System.setProperty("SDEnvName", SD_ENV_NAME);
		// cal.add(Calendar.DATE , 0);
		Timestamp ts = new Timestamp(cal.getTimeInMillis());
		drawdownTransactionList = new ArrayList<DrawdownTransaction>();
		logger.debug(cal.getTime().toString());
		
		for (int i = 0; i <= 10; i++) {
			DrawdownTransaction drawdownTransaction = new DrawdownTransaction();
			
			drawdownTransaction.setDrawdownTransactionId("1");
			drawdownTransaction.setDrawdownId("2");
			drawdownTransaction.setTransactionCreateDate(ts);
			drawdownTransaction.setInterestLiableDate(ts);
			drawdownTransaction.setTransactionEffectiveDate(ts);
			drawdownTransaction.setTransactionAmount((double)1624.00);
			drawdownTransaction.setTransactionType("");
			drawdownTransaction.setReasonCode("");
			drawdownTransaction.setMivCode((long)56);
			drawdownTransaction.setMivSubCode("PRCH");
			drawdownTransaction.setBatchId(100l);
			drawdownTransaction.setDdtType("");
			drawdownTransaction.setCreatedByUser((long)555);
			drawdownTransaction.setTfrLink("");
			drawdownTransaction.setBatchId((long)66444);
			drawdownTransaction.setInternalTrxInd("T");

			drawdownTransactionList.add(drawdownTransaction);
		}
		
		
	}

	@Test
	public void testInsertDrawDownTransactionData() throws StatementProcessorBatchException, BuisnessException {
		DrawdownTransactionDaoImpl drawdownTransactionDaoImpl = Mockito.mock(DrawdownTransactionDaoImpl.class);
		
		String insertMsg = null;
		
		Object[] result = new Object[2];
		result[0] = 0;
		Mockito.when(drawdownTransactionDaoImpl.insertDrawDownTransactionData(Mockito.isA(ArrayList.class))).thenReturn(result);
		
		try{
			Object[] insertFlag = drawdownTransactionDaoImpl.insertDrawDownTransactionData(drawdownTransactionList);
			
			if ((int) insertFlag[0] == 0) {
				insertMsg = StatementProcessorBatchConstants.EMPTY_STRING;
			} else {
				insertMsg = null;
			}
			
			assertNotNull(insertMsg);
			
		} catch (StatementProcessorBatchException spbe) {
			assertEquals(StatementProcessorBatchConstants.CONNECTTION_DB_ERROR_CODE, spbe.getErrorCode());
		}
	}

}
