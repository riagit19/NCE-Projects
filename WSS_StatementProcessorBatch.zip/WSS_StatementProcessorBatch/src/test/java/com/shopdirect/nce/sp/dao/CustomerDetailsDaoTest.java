package com.shopdirect.nce.sp.dao;

import org.junit.Assert;
import org.junit.Test;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.util.StatementProcessorBatchUtil;

public class CustomerDetailsDaoTest {
	private static SDLoggerImpl logger = new SDLoggerImpl();
	/**
	 * Test method for customerDetailsDao.updateAccountdetail
	 * @throws Exception 
	 */
	@Test
	public void testUpdateAccountdetails() {
		try{
		CustomerDetailsDao customerDetailsDao = new CustomerDetailsDao();
		String updateStatus = "1";
		
    	String cimAccountInfoId="1234";		
    	int result =customerDetailsDao.updateAccountdetails(updateStatus,  cimAccountInfoId);
    	
         Assert.assertNotNull(result);
		}
		catch(StatementProcessorBatchException sbe){
			getLogger().error("[CustomerDetailsDaoTest -- testUpdateAccountdetails] StatementProcessorBatchException Block "+ sbe.getMessage());
			StatementProcessorBatchUtil.getprintStackTraceString(sbe);
		} catch (Exception e) {
			getLogger().error("[CustomerDetailsDaoTest -- testUpdateAccountdetails] General Exception Block "+ e.getMessage());
			StatementProcessorBatchUtil.getprintStackTraceString(e);
		}
	}
	public static SDLoggerImpl getLogger() {
		return logger;
	}
	public static void setLogger(SDLoggerImpl logger) {
		CustomerDetailsDaoTest.logger = logger;
	}
	
}
