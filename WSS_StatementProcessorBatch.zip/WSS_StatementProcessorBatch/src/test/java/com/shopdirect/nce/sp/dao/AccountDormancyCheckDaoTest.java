/**
 * 
 */
package com.shopdirect.nce.sp.dao;

import static org.junit.Assert.*;

import java.sql.SQLException;
import java.util.Calendar;
import java.util.Date;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.AccountReassessmentInfoModel;
import com.shopdirect.nce.sp.model.CustomerAccountInfo;
import com.shopdirect.nce.sp.util.SPDormancyCheckHelper;

/**
 * @author AyantikaBiswas
 *
 */
public class AccountDormancyCheckDaoTest {

	private static SDLoggerImpl logger = new SDLoggerImpl();

	
	CustomerAccountInfo customerAccountInfo = new CustomerAccountInfo();
	Calendar cal = Calendar.getInstance();	
	//CustomerAccountInfo model = new CustomerAccountInfo();
	
	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		String CURRENT_WORKING_PATH = (System.getProperty("user.dir") + "\\src\\main\\extcnf\\").replaceAll("\\\\",	"/");
		String SD_ENV_NAME = "DEV";
		System.setProperty("SERVER_CONFIG_ROOT", CURRENT_WORKING_PATH);
		System.setProperty("SDEnvName", SD_ENV_NAME);    	
    	cal.add(Calendar.DATE , 0);
    	
		customerAccountInfo.setAccountInfoId("341");
		customerAccountInfo.setStatementDate(cal.getTime());
		customerAccountInfo.setAccountStatus("0");
		customerAccountInfo.setCreditAccountId("1990");
		customerAccountInfo.setBrandCode("LAI");
		
    		
	}



	/**
	 * Test method for {@link com.shopdirect.nce.sp.dao.AccountDormancyCheckDao#getAccountBalance(java.lang.String)}.
	 * @throws StatementProcessorBatchException , SQLException 
	 */
	@Test
	public void testGetAccountBalance() throws StatementProcessorBatchException , SQLException {
		int accntBal=0;
		AccountDormancyCheckDao dormancyCheckDao = Mockito.mock(AccountDormancyCheckDao.class);
		Mockito.when(dormancyCheckDao.getAccountBalance(customerAccountInfo.getCreditAccountId())).thenReturn((double) accntBal);
		Mockito.when(dormancyCheckDao.getAccountBalance(customerAccountInfo.getCreditAccountId())).thenThrow(new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_BUSINESS_ERROR_CODE,
				"[AccountDormancyCheckDaoTest-testGetAccountBalance] Exception Block",
				"Business exception generated at time to process the dormancy check " + null, null, null,
				null));
		Assert.assertFalse(false);	
	}

	/**
	 * Test method for {@link com.shopdirect.nce.sp.dao.AccountDormancyCheckDao#getLastTransDt(java.lang.String, java.util.Date)}.
	 * @throws Exception 
	 */
	@Test
	public void testGetLastTransDt() throws Exception {
		Date lastTrnDt = new Date();
		AccountDormancyCheckDao dormancyCheckDao = Mockito.mock(AccountDormancyCheckDao.class);
		Mockito.when(dormancyCheckDao.getLastTransDt(customerAccountInfo.getCreditAccountId(),customerAccountInfo.getStatementDate())).thenReturn(lastTrnDt);
		Mockito.when(dormancyCheckDao.getLastTransDt(customerAccountInfo.getCreditAccountId(),customerAccountInfo.getStatementDate())).thenThrow(new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_BUSINESS_ERROR_CODE,
				"[AccountDormancyCheckDaoTest-testGetLastTransDt] Exception Block",
				"Business exception generated at time to process the dormancy check " + null, null, null,
				null));
		Assert.assertFalse(false);		
		
	}

	/**
	 * Test method for {@link com.shopdirect.nce.sp.dao.AccountDormancyCheckDao#getCreditStatus(java.lang.String)}.
	 * @throws Exception 
	 */
	@Test
	public void testGetCreditStatus() throws Exception {
		String creditStatus = null;
		AccountDormancyCheckDao dormancyCheckDao = Mockito.mock(AccountDormancyCheckDao.class);
		Mockito.when(dormancyCheckDao.getCreditStatus(customerAccountInfo.getCreditAccountId())).thenReturn(creditStatus);
		Mockito.when(dormancyCheckDao.getCreditStatus(customerAccountInfo.getCreditAccountId())).thenThrow(new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_BUSINESS_ERROR_CODE,
				"[AccountDormancyCheckDaoTest-testGetCreditStatus] Exception Block",
				"Business exception generated at time to process the dormancy check " + null, null, null,
				null));
		Assert.assertFalse(false);			
	}

	/**
	 * Test method for {@link com.shopdirect.nce.sp.dao.AccountDormancyCheckDao#updateAccountStatus(java.lang.String, java.lang.String, int)}.
	 * @throws Exception 
	 */
	@Test
	public void testUpdateAccountStatus() throws Exception {
		int updtFlag = 0;
		AccountDormancyCheckDao dormancyCheckDao = Mockito.mock(AccountDormancyCheckDao.class);
		Mockito.when(dormancyCheckDao.updateAccountStatus(customerAccountInfo.getAccountInfoId(), customerAccountInfo.getCreditAccountId(), 60)).thenReturn(updtFlag);
		Mockito.when((dormancyCheckDao.updateAccountStatus(customerAccountInfo.getAccountInfoId(), customerAccountInfo.getCreditAccountId(), 60)).equals(null)).thenThrow(new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_BUSINESS_ERROR_CODE,
				"[AccountDormancyCheckDaoTest-testUpdateAccountStatus] Exception Block",
				"Business exception generated at time to process the dormancy check " + null, null, null,
				null));
		Assert.assertFalse(false);		
		
	}

	/**
	 * Test method for {@link com.shopdirect.nce.sp.dao.AccountReassessmentBaseDao#getSpMainSchema()}.
	 */
	/*@Test
	public void testGetSpMainSchema() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link com.shopdirect.nce.sp.dao.AccountReassessmentBaseDao#setSpMainSchema(java.lang.String)}.
	 */
	/*@Test
	public void testSetSpMainSchema() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link com.shopdirect.nce.sp.dao.AccountReassessmentBaseDao#getCon()}.
	 */
	/*@Test
	public void testGetCon() {
		fail("Not yet implemented");
	}*/

}
