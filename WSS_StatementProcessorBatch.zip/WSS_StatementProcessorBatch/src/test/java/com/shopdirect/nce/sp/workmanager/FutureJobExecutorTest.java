package com.shopdirect.nce.sp.workmanager;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

import java.lang.reflect.Field;
import java.util.concurrent.Future;

import org.junit.Before;
import org.junit.Test;

import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;

public class FutureJobExecutorTest {

	FutureJobExecutor executor;

	@Before
	public void setup() {
		String CURRENT_WORKING_PATH = (System.getProperty("user.dir") + "\\src\\main\\extcnf\\").replaceAll("\\\\",
				"/");
		String SD_ENV_NAME = "DEV";
		System.setProperty("SERVER_CONFIG_ROOT", CURRENT_WORKING_PATH);
		System.setProperty("SDEnvName", SD_ENV_NAME);
		
		executor = new FutureJobExecutor();
	}

	@Test
	public void testExecuteJobs() {
		AccountReassessmentExecutor job = new AccountReassessmentExecutor();
		Future<AccountReassessmentExecutor> result = executor.submitJob(job);

		assertNotNull(result);
	}

	@Test
	public void testCloseExecutorService() {
		try {
			executor.closeExecutorService();
		} catch (Throwable t) {
			fail();
		}
	}
	
	@Test
	public void testCloseExecutorServiceNull() {
		try {
			Field field = FutureJobExecutor.class.getDeclaredField("executorService");
			field.setAccessible(true);
			field.set(executor, null);
			executor.closeExecutorService();
		} catch (Throwable t) {
			fail();
		}
	}
	
	@Test
	public void testExecutePseudoJobs() throws StatementProcessorBatchException {
		PseudoChargeExecutor job = new PseudoChargeExecutor();
		Future<PseudoChargeExecutor> result = executor.submitPseudoJobs(job);

		assertNotNull(result);
	}

}
