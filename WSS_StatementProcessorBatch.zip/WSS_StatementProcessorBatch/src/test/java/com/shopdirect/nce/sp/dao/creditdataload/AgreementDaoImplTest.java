package com.shopdirect.nce.sp.dao.creditdataload;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.exception.BuisnessException;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.Agreement;

public class AgreementDaoImplTest {
	ArrayList<Agreement> agreementList = null;
	Calendar cal = Calendar.getInstance();
	private static SDLoggerImpl logger = new SDLoggerImpl();

	@Before
	public void setUp() throws Exception {
		String CURRENT_WORKING_PATH = (System.getProperty("user.dir") + "\\src\\main\\extcnf\\").replaceAll("\\\\",
				"/");
		String SD_ENV_NAME = "DEV";
		System.setProperty("SERVER_CONFIG_ROOT", CURRENT_WORKING_PATH);
		System.setProperty("SDEnvName", SD_ENV_NAME);
		// cal.add(Calendar.DATE , 0);
		Timestamp ts = new Timestamp(cal.getTimeInMillis());
		agreementList = new ArrayList<Agreement>();
		logger.debug(cal.getTime().toString());
		
		for (int i = 0; i <= 10; i++) {
			Agreement agreement = new Agreement();
			
			agreement.setAgreementId("901");
			agreement.setAgreementSeq((long)1);
			agreement.setStatementDate(ts);
			agreement.setInterestRate((double)0.097946);
			agreement.setOpeningBalance((double)0);
			agreement.setClosingBalance((double)4274.00);
			agreement.setArrangementAmount((double)0);
			agreement.setMinimumPayment((double)0);
			agreement.setMinimumPaymentcalculatedBalance((double)299.1877777777);
			agreement.setMinimumPaymentPercentage((double)0);
			agreement.setFixedMinimumPayment((double)0);
			agreement.setDirectDebitAmount((double)0);
			agreement.setPpiAmount((double)0);
			agreement.setArrearsAmount((double)0);
			agreement.setNextpaymentDueDate(ts);
			agreement.setPreviousPaymentDuedate(ts);
			agreement.setCreditLimit((double)0);
			agreement.setAvailableToSpend((double)0);
			agreement.setAgreementType("Running Account");
			agreement.setTakeAll((double)0);
			agreement.setAgreementTypePaymentsTransferredIn((double)0);
			agreement.setAccountPromotionEndDate(ts);
			agreement.setMissedMinPayInd((int)1);
			agreement.setDirectDebitTypeInd((int)0);
			agreement.setScheduledPaymentAmount((double)0);
			agreement.setScheduledPaymentPastDue((double)0);
			agreement.setBatchId(100l);
			agreement.setCreatedByUser((long)555);
			agreement.setPendingItemInd("N");
			agreement.setNoInterestIndicator("T");
			
			agreementList.add(agreement);
		}

	}

	@Test
	public void testInsertAgreementData() throws BuisnessException, Exception {
		AgreementDaoImpl agreementDao = Mockito.mock(AgreementDaoImpl.class);
		String insertMsg = null;

		Object[] result = new Object[2];
		result[0] = 0;
		Mockito.when(agreementDao.insertAgreementData(Mockito.isA(ArrayList.class))).thenReturn(result);

		try {
			Object[] insertFlag = agreementDao.insertAgreementData(agreementList);
			
			if ((int) insertFlag[0] == 0) {
				insertMsg = StatementProcessorBatchConstants.EMPTY_STRING;
			} else {
				insertMsg = null;
			}
			
			assertNotNull(insertMsg);
			
		} catch (StatementProcessorBatchException spbe) {
			assertEquals(StatementProcessorBatchConstants.CONNECTTION_DB_ERROR_CODE, spbe.getErrorCode());
		}

	}

}
