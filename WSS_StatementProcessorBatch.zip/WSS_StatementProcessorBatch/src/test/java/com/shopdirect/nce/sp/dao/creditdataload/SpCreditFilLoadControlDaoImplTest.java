package com.shopdirect.nce.sp.dao.creditdataload;

import java.sql.SQLException;
import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.exception.BuisnessException;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.SpCreditFilLoadControl;

public class SpCreditFilLoadControlDaoImplTest {

	SpCreditFilLoadControl spCreditFilLoadControl;
	SpCreditFilLoadControlDaoImpl spCreditFLCDaoImpl;
	private static SDLoggerImpl logger = new SDLoggerImpl();

	@Before
	public void setUp() throws Exception {
		String CURRENT_WORKING_PATH = (System.getProperty("user.dir") + "\\src\\main\\extcnf\\").replaceAll("\\\\",
				"/");
		String SD_ENV_NAME = "DEV";
		System.setProperty("SERVER_CONFIG_ROOT", CURRENT_WORKING_PATH);
		System.setProperty("SDEnvName", SD_ENV_NAME);
		Date currDate = new Date();
		java.sql.Date currDBDate = new java.sql.Date(currDate.getTime());

		spCreditFLCDaoImpl = Mockito.mock(SpCreditFilLoadControlDaoImpl.class);
		spCreditFilLoadControl = new SpCreditFilLoadControl();
		spCreditFilLoadControl.setBatchId(100l);
		spCreditFilLoadControl.setFileName("Agreement.csv");
		spCreditFilLoadControl.setFileRunStatus("NOT STARTED");
		spCreditFilLoadControl.setErrorMessage("");
		spCreditFilLoadControl.setCreatedDate(currDBDate);
		spCreditFilLoadControl.setCreatedBy(444);
		spCreditFilLoadControl.setFileIdentifier("AGREEMENT");
	}

	@Test
	public void testInsertControlData() throws StatementProcessorBatchException, Exception {
		boolean insertFlag = false;
		Mockito.when(spCreditFLCDaoImpl.insertControlData(Mockito.isA(SpCreditFilLoadControl.class))).thenReturn(true);
		insertFlag = spCreditFLCDaoImpl.insertControlData(spCreditFilLoadControl);
		logger.debug("insertFlag for Control table++++++++++++" + insertFlag);
	}

	@Test
	public void testUpdateControlData() throws BuisnessException, SQLException, Exception {
		int batchId = 1;
		boolean insertStatus = true;
		String errorMessege = "";
		String fileIdentifier = "Agreement";
		Mockito.when(spCreditFLCDaoImpl.updateControlData(Mockito.isA(int.class), Mockito.isA(boolean.class), Mockito.isA(String.class), Mockito.isA(String.class))).thenReturn(true);
		boolean updateFlag = spCreditFLCDaoImpl.updateControlData(batchId, insertStatus, errorMessege,fileIdentifier);

		logger.debug("updateFlag for Control table++++++++++++" + updateFlag);
	}

}
