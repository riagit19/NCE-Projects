package com.shopdirect.nce.sp.dao;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

public class AssessTriadDaoTest {

	@Before
	public void setUp() throws Exception {
		String CURRENT_WORKING_PATH = (System.getProperty("user.dir") + "\\src\\main\\extcnf\\").replaceAll("\\\\",
				"/");
		String SD_ENV_NAME = "DEV";
		System.setProperty("SERVER_CONFIG_ROOT", CURRENT_WORKING_PATH);
		System.setProperty("SDEnvName", SD_ENV_NAME);

	}

	@Test
	public void getAllTriadDataTest() throws Exception {
		AssessTriadDao assessTriadDaoObj = Mockito.mock(AssessTriadDao.class);
		String publicAccNum = "AB999787";
		Date statementDate = new Date("14-OCT-17");
		Set<String> linkedAccountNumSet = new HashSet<>();
		linkedAccountNumSet.add("AB997787");
		Mockito.when(assessTriadDaoObj.getAllTriadData(Mockito.isA(String.class), Mockito.isA(Date.class), Mockito.isA(Set.class))).thenReturn(new Object[6]);
		assessTriadDaoObj.getAllTriadData(publicAccNum, statementDate, linkedAccountNumSet);

	}
}
