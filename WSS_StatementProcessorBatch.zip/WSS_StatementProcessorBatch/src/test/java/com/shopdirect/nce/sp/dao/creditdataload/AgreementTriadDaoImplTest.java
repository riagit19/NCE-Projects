package com.shopdirect.nce.sp.dao.creditdataload;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.AgreementTriadType;

public class AgreementTriadDaoImplTest {
	ArrayList<AgreementTriadType> agreementTriadList = null;
	Calendar cal = Calendar.getInstance();
	private static SDLoggerImpl logger = new SDLoggerImpl();

	@Before
	public void setUp() throws Exception {
		String CURRENT_WORKING_PATH = (System.getProperty("user.dir") + "\\src\\main\\extcnf\\").replaceAll("\\\\",
				"/");
		String SD_ENV_NAME = "DEV";
		System.setProperty("SERVER_CONFIG_ROOT", CURRENT_WORKING_PATH);
		System.setProperty("SDEnvName", SD_ENV_NAME);
		// cal.add(Calendar.DATE , 0);
		Timestamp ts = new Timestamp(cal.getTimeInMillis());
		agreementTriadList = new ArrayList<AgreementTriadType>();
		logger.debug(cal.getTime().toString());
		
		for (int i = 0; i <= 10; i++) {
			AgreementTriadType agreementTriad = new AgreementTriadType();
			agreementTriad.setStatementDate(ts);
			agreementTriad.setLastPayMethod(Double.valueOf(1));
			agreementTriad.setCurrentBalance(45.67);
			agreementTriad.setDateLastOrder(ts);
			agreementTriad.setDateLastPay(ts);
			agreementTriad.setScheduledPaymentAmount(76.78);
			agreementTriad.setScheduledPaymentPastDue(65.76);
			agreementTriad.setDateSection87(ts);
			agreementTriad.setDateNsf(ts);
			agreementTriad.setLastPaymentAmount(67.65);
			agreementTriad.setBnplBalance(654.87);
			agreementTriad.setApr(654.87);
			agreementTriad.setTotPay30Days(54.67);
			agreementTriad.setInstArrears(54.78);
			agreementTriad.setDateLastArrangement(ts);
			agreementTriad.setPayAmtTsp(54.67);
			agreementTriad.setDateLastZeroBal(ts);
			agreementTriad.setReturnsAmtTsp(543.6);
			agreementTriad.setOtherAdjAmtTsp(654.67);
			agreementTriad.setPaymentPreviousInd(Long.valueOf(6666));
			agreementTriad.setPaymentCurrentInd(Long.valueOf(5555));
			agreementTriad.setNumPurchasesTsp(65.78);
			agreementTriad.setTotFeesTsp(54.56);
			agreementTriad.setCustCreditsTsp(65.67);
			agreementTriad.setTotPayYear(76.56);
			agreementTriad.setNumPayTsp(65.78);
			agreementTriad.setIntChargedTsp(65.76);
			agreementTriad.setPurchaseAmtTsp(98.67);
			agreementTriad.setRebatesAmtTsp(76.56);
			agreementTriad.setBnplIntAmtTsp(765.78);
			agreementTriad.setNumRatePayTsp(654.78);
			agreementTriad.setLastArrearsWks(65.78);
			agreementTriad.setCreditLimit(65.78);
			agreementTriad.setLastPaymentDays(65.78);
			agreementTriad.setNilBalanceDays(65.87);
			agreementTriad.setBatchId(100l);
			agreementTriad.setErrorFlag("N");
			agreementTriad.setErrorMessage("Error");
			agreementTriad.setCreationDate(ts);
			agreementTriad.setCreatedByUser((long) 9876);
			agreementTriad.setLastUpdateDate(ts);
			agreementTriad.setLastUpdateByUser((long) 87564);
			agreementTriad.setAgreementID("65345");
			agreementTriad.setFnStatNo((long)765);
			agreementTriad.setPaymentDueDate(ts);
			agreementTriad.setLastStatementDate(ts);
			agreementTriad.setStatementDate(ts);
			agreementTriad.setPastDueAmount(76.87);
			agreementTriad.setAvailableToSpend(765.87);
			agreementTriad.setSourceRowNumber((long)11);
			
			agreementTriad.setValueFailedPayments((long)0);
			agreementTriad.setBalanceBeforePpi((long)0);
			agreementTriad.setOtherCredits((long)0);
			agreementTriad.setOtherDebits((long)0);
			agreementTriad.setPayLastColl((long)0);
			agreementTriad.setLateInsufFeesTsp((long)0);
			agreementTriad.setCollAdminFeesTsp((long)0);
			agreementTriad.setOrderFeesAmtTsp((long)0);
			agreementTriad.setCreditLimit((double)78);
			
			agreementTriadList.add(agreementTriad);
		}
		
	}

	@Test
	public void testInsertAgreementTriadData() throws StatementProcessorBatchException {
		AgreementTriadDaoImpl agreementTriadDaoImpl = Mockito.mock(AgreementTriadDaoImpl.class);
		
		String insertMsg = null;
		
		Object[] result = new Object[2];
		result[0] = 0;
		Mockito.when(agreementTriadDaoImpl.insertAgreementTriadData(Mockito.isA(ArrayList.class))).thenReturn(result);
		
		try {
			Object[] insertFlag = agreementTriadDaoImpl.insertAgreementTriadData(agreementTriadList);
			
			if ((int) insertFlag[0] == 0) {
				insertMsg = StatementProcessorBatchConstants.EMPTY_STRING;
			} else {
				insertMsg = null;
			}
			
			assertNotNull(insertMsg);
			
		} catch (StatementProcessorBatchException spbe) {
			System.out.println("---- Agreement Triad Exception -----" + spbe);
			assertEquals(StatementProcessorBatchConstants.CONNECTTION_DB_ERROR_CODE, spbe.getErrorCode());
		}

	
	}

}
