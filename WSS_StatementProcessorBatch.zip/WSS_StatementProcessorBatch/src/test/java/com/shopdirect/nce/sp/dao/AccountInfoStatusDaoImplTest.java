package com.shopdirect.nce.sp.dao;

import static org.junit.Assert.assertEquals;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;

public class AccountInfoStatusDaoImplTest {

	private static SDLoggerImpl logger = new SDLoggerImpl();
	AccountInfoStatusDaoImpl accountInfoStatusDaoImpl = null;
	
	@Before
	public void setUp() throws Exception {
		String CURRENT_WORKING_PATH = (System.getProperty("user.dir") + "\\src\\main\\extcnf\\").replaceAll("\\\\",
				"/");
		String SD_ENV_NAME = "DEV";
		System.setProperty("SERVER_CONFIG_ROOT", CURRENT_WORKING_PATH);
		System.setProperty("SDEnvName", SD_ENV_NAME);
		accountInfoStatusDaoImpl = Mockito.mock(AccountInfoStatusDaoImpl.class);
	}
	
	@Test
	public void testProcessUpdateCreditAndReassessment() throws Exception {
		logger.info("[AccountReassessmentDaoImplTest - testUpdateAccReassessment ] - Start");
		String pubAccNo = "D0000002";
		Date statementDate = new Date();
		Format formatter = new SimpleDateFormat("dd-MMM-yy");
		String statementDt = formatter.format(statementDate);
		String updateStatus = "AR_Completed";
		Mockito.when(accountInfoStatusDaoImpl.updateCimAccountInfoStatus(Mockito.isA(String.class), Mockito.isA(String.class), Mockito.isA(String.class))).thenReturn(1);
		int status = accountInfoStatusDaoImpl.updateCimAccountInfoStatus(pubAccNo, statementDt, updateStatus);
		assertEquals(1,status);
		logger.info("[AccountReassessmentDaoImplTest - testUpdateAccReassessment ] - End");
	}
}
