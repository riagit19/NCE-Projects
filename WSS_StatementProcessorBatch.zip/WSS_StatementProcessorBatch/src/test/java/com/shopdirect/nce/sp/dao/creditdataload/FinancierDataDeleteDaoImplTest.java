package com.shopdirect.nce.sp.dao.creditdataload;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;

public class FinancierDataDeleteDaoImplTest {

	FinancierDataDeleteDaoImpl financierDataDeleteDaoImpl;
	private static SDLoggerImpl logger = new SDLoggerImpl();
	long batchID;

	@Before
	public void setUp() throws Exception {
		financierDataDeleteDaoImpl = Mockito.mock(FinancierDataDeleteDaoImpl.class);
		batchID = 303;
	}

	@Test
	public void testDeleteAllData() throws StatementProcessorBatchException, Exception {
		boolean deleteFlag = false;
		Mockito.when(financierDataDeleteDaoImpl.deleteAllData(Mockito.isA(long.class))).thenReturn(true);
		deleteFlag = financierDataDeleteDaoImpl.deleteAllData(batchID);
		logger.debug("deleteFlag for All table++++++++++++" + deleteFlag);
	}

}
