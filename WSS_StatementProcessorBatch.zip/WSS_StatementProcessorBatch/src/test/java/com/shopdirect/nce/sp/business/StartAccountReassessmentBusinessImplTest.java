package com.shopdirect.nce.sp.business;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.shopdirect.nce.sp.dao.StatementProcessorARDao;
import com.shopdirect.nce.sp.model.CustomerAccountInfo;
import com.shopdirect.nce.sp.model.StartAccountReassessmentRequestType;
import com.shopdirect.nce.sp.model.StartAccountReassessmentResponseType;

import junit.framework.TestCase;

/**
 * This is JUNIT class to test StartAccountReassessmentBusinessImpl
 * 
 * @author amitkumar
 *
 */
public class StartAccountReassessmentBusinessImplTest extends TestCase {

	StartAccountReassessmentBusinessImpl arBusinessImpl;
	StatementProcessorARDao arDao;

	@Before
	protected void setUp() throws Exception {
		
		super.setUp();
		String CURRENT_WORKING_PATH = (System.getProperty("user.dir") + "\\src\\main\\extcnf\\").replaceAll("\\\\",	"/");
		String SD_ENV_NAME = "DEV";
		System.setProperty("SERVER_CONFIG_ROOT", CURRENT_WORKING_PATH);
		System.setProperty("SDEnvName", SD_ENV_NAME);
		arBusinessImpl = new StartAccountReassessmentBusinessImpl();
		arDao = Mockito.mock(StatementProcessorARDao.class);
		arBusinessImpl.setStatementProcessorARDao(arDao);
	}

	@Before
	public void initialize() {
		MockitoAnnotations.initMocks(this);
	}
    
	/**
	 *  This is test method for startAR for record count more than 10000
	 * @param 
	 * @return
	 * @throws Exception
	 */
	@Test
	public final void testStartAR() throws Exception {
		StartAccountReassessmentRequestType startType = new StartAccountReassessmentRequestType();
		int startCountVal = 1;
		int endCountVal = 20000;
		
		List<CustomerAccountInfo> customerRecords = new ArrayList<CustomerAccountInfo>();
		Calendar cal = Calendar.getInstance();
		Mockito.when(arDao.getAccountList(startCountVal, endCountVal,cal)).thenReturn(customerRecords);
				
		arBusinessImpl.startAR(startType);

	}
	
	/**
	 *  This is test method for startAR for record count less than 10000
	 * @param 
	 * @return
	 * @throws Exception
	 */
	@Test
	public final void testStartARLessValue() throws Exception {
		
		StartAccountReassessmentRequestType startType = new StartAccountReassessmentRequestType();
		int startCountVal = 1;
		int endCountVal = 100;
		
		List<CustomerAccountInfo> customerRecords = new ArrayList<CustomerAccountInfo>();
		Calendar cal = Calendar.getInstance();
		Mockito.when(arDao.getAccountList(startCountVal, endCountVal,cal)).thenReturn(customerRecords);
		
		StartAccountReassessmentResponseType responseType = arBusinessImpl.startAR(startType);
		
		assertNotNull(responseType);
	}

}
