/**
 * 
 */
package com.shopdirect.nce.sp.util;

import java.util.Calendar;
import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.shopdirect.nce.sp.dao.AccountDormancyCheckDao;
import com.shopdirect.nce.sp.model.CustomerAccountInfo;

/**
 * @author AyantikaBiswas
 *
 */
public class SPDormancyCheckHelperTest {

	AccountDormancyCheckDao dormancyCheckDao;
	SPDormancyCheckHelper dormancyCheckHelper = null;
	CustomerAccountInfo customerAccountInfo = new CustomerAccountInfo();
	Calendar cal = Calendar.getInstance();
	
	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		String CURRENT_WORKING_PATH = (System.getProperty("user.dir") + "\\src\\main\\extcnf\\").replaceAll("\\\\",	"/");
		String SD_ENV_NAME = "DEV";
		System.setProperty("SERVER_CONFIG_ROOT", CURRENT_WORKING_PATH);
		System.setProperty("SDEnvName", SD_ENV_NAME);
    	
    	cal.add(Calendar.DATE , 0);
    	dormancyCheckHelper = new SPDormancyCheckHelper();
    	dormancyCheckDao = Mockito.mock(AccountDormancyCheckDao.class);
    	dormancyCheckHelper.setDormancyCheckDao(dormancyCheckDao);
	}

	/**
	 * Test method for {@link com.shopdirect.nce.sp.util.SPDormancyCheckHelper#checkCreditStatus(java.lang.String)}.
	 * @throws Exception 
	 */
	@Test
	public void testCheckCreditStatus() throws Exception {
		Mockito.when(dormancyCheckDao.getCreditStatus(Mockito.isA(String.class))).thenReturn(new String("B"));
		dormancyCheckHelper.checkCreditStatus("A000123");
	}

	/**
	 * Test method for {@link com.shopdirect.nce.sp.util.SPDormancyCheckHelper#calculateTime(java.util.Date, java.util.Date)}.
	 */
	@Test
	public void testCalculateTime() {
	   	Calendar cal1 = Calendar.getInstance();
    	cal1.add(Calendar.DATE , 0);
    	Calendar cal2 = Calendar.getInstance();
    	cal2.add(Calendar.DATE, -1);
		try {
			dormancyCheckHelper.calculateTime(cal1.getTime(),cal2.getTime());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Test method for {@link com.shopdirect.nce.sp.util.SPDormancyCheckHelper#checkLastTransactionDt(java.lang.String, java.util.Date)}.
	 * @throws Exception 
	 */
	@Test
	public void testCheckLastTransactionDt() throws Exception {
		Mockito.when(dormancyCheckDao.getLastTransDt(Mockito.isA(String.class), Mockito.isA(Date.class))).thenReturn(new Date());
		dormancyCheckHelper.checkLastTransactionDt("A000123", cal.getTime());
	}

	/**
	 * Test method for {@link com.shopdirect.nce.sp.util.SPDormancyCheckHelper#checkAccountBalance(java.lang.String)}.
	 * @throws Exception 
	 */
	@Test
	public void testCheckAccountBalance() throws Exception {
		double result = 100;
		Mockito.when(dormancyCheckDao.getAccountBalance(Mockito.isA(String.class))).thenReturn(result);
		dormancyCheckHelper.checkAccountBalance("A000123");
	}

	/**
	 * Test method for {@link com.shopdirect.nce.sp.util.SPDormancyCheckHelper#updateStatus(java.lang.String, java.lang.String, int)}.
	 * @throws Exception 
	 */
	@Test
	public void testUpdateStatus() throws Exception {
		Mockito.when(dormancyCheckDao.updateAccountStatus(Mockito.isA(String.class), Mockito.isA(String.class), Mockito.isA(int.class))).thenReturn(new Integer(1));
		dormancyCheckHelper.updateStatus("199", "A000123", 60);
	}

}
