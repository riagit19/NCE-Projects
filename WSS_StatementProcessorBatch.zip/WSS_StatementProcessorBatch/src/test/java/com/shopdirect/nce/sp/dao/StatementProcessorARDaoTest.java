/**
 * 
 */
package com.shopdirect.nce.sp.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.CustomerAccountInfo;

/**
 * @author AyantikaBiswas
 *
 */
public class StatementProcessorARDaoTest {
	
	StatementProcessorARDao stmtProcARDao = null;
	
	@Before
	public void setUp() {
		
		String CURRENT_WORKING_PATH = (System.getProperty("user.dir") + "\\src\\main\\extcnf\\").replaceAll("\\\\",	"/");
		String SD_ENV_NAME = "DEV";
		System.setProperty("SERVER_CONFIG_ROOT", CURRENT_WORKING_PATH);
		System.setProperty("SDEnvName", SD_ENV_NAME);	
		stmtProcARDao = Mockito.mock(StatementProcessorARDao.class);
	}

	/**
	 * Test method for {@link com.shopdirect.nce.sp.dao.StatementProcessorARDao#getAccountList()}.
	 * @throws Exception 
	 */
	@Test
	public void testGetAccountList() throws Exception {
		
		List<CustomerAccountInfo> CustomerAccountInfoList = new ArrayList<CustomerAccountInfo>(); 
    	Calendar cal = Calendar.getInstance();
    	cal.add(Calendar.DATE , 0);
    	boolean result = true ;
		Mockito.when(stmtProcARDao.getAccountList(1,2, cal)).thenReturn(CustomerAccountInfoList);
		Mockito.when(stmtProcARDao.getAccountList(1,2, cal)).thenThrow(new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_BUSINESS_ERROR_CODE,
				"[StatementProcessorARDaoTest-getAccountList] Exception Block",
				"Business exception generated at time to process the dormancy check " + null, null, null,
				null));
    	
    	if(CustomerAccountInfoList==null)
			result = false;
    	
       Assert.assertNotNull(result);
	}

	@Test
	public void testUpdateStatusMessage() throws Exception {
		int result = 0;
		Mockito.when(stmtProcARDao.updateStatusMessage(Mockito.isA(String.class), Mockito.isA(String.class), Mockito.isA(String.class))).thenReturn(result);
		try {
			int count = stmtProcARDao.updateStatusMessage("0055", "AR_Completed", "111");
			Assert.assertEquals(0, count);
		} catch (SQLException sqle) {
			Assert.fail();
		}

	}
}
