package com.shopdirect.nce.sp.dao;

import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.AccountConfirmationModel;
import com.shopdirect.nce.sp.util.StatementProcessorBatchUtil;

import junit.framework.TestCase;

public class AccountForecastInterestRetreivalDaoTest extends TestCase {

	private static SDLoggerImpl logger = new SDLoggerImpl();
	AccountForecastInterestRetreivalDao dao = null;


	@Before
	public void setUp() throws StatementProcessorBatchException {
		String CURRENT_WORKING_PATH = (System.getProperty("user.dir") + "/src/main/extcnf/");
		String SD_ENV_NAME = "DEV";
		System.setProperty("SERVER_CONFIG_ROOT", CURRENT_WORKING_PATH);
		System.setProperty("SDEnvName", SD_ENV_NAME);

		dao= new AccountForecastInterestRetreivalDao();
	}

	@Test
	public void testCallMargePreformatSP() {
		try {
			String agreementCode = new String("A8476781345");
			String statementDate="01-APR-17";
			dao.callMargePreformatSP(statementDate, agreementCode, "dd-MMM-yy");
		} catch (StatementProcessorBatchException e) {
			getLogger()
			.error("[AccountForecastInterestRetreivalDaoTest -- testCallMargePreformatSP] StatementProcessorBatchException Block "
					+ e.getMessage());
			StatementProcessorBatchUtil.getprintStackTraceString(e);
		}
	}

	@Test
	public void testGetForcastRequestData() {
		try {
			List<AccountConfirmationModel> resp = dao.getForcastRequestData("AB999787", "14-OCT-17", "488", "dd-MMM-yy");
//			assertNotNull(resp);
		} catch (StatementProcessorBatchException e) {
			getLogger()
			.error("[AccountForecastInterestRetreivalDaoTest -- testGetForcastRequestData] StatementProcessorBatchException Block "
					+ e.getMessage());
			StatementProcessorBatchUtil.getprintStackTraceString(e);
		}
	}
	
	@Test
	public void testGetForcastRequestDataInvalidData() {
		try {
			List<AccountConfirmationModel> resp = dao.getForcastRequestData("00000000", "25-APR-17", "21826", "dd-MMM-yy");
			assertNull(resp.get(0));
		} catch (StatementProcessorBatchException e) {
			getLogger()
			.error("[AccountForecastInterestRetreivalDaoTest -- testGetForcastRequestData] StatementProcessorBatchException Block "
					+ e.getMessage());
			StatementProcessorBatchUtil.getprintStackTraceString(e);
		}
	}
	
	public static SDLoggerImpl getLogger() {
		return logger;
	}
		
	public static void setLogger(SDLoggerImpl logger) {
		AccountForecastInterestRetreivalDaoTest.logger = logger;
	}
	
}
