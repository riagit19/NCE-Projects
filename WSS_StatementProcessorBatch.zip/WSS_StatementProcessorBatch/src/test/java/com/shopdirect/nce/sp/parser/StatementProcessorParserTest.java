package com.shopdirect.nce.sp.parser;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.xml.bind.JAXBException;

import org.junit.Assert;
import org.junit.Test;

import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.CustomerAccountInfo;
import com.shopdirect.nce.sp.model.CustomerAccountInfoBuilder;
import com.shopdirect.nce.sp.model.CustomerReassesmentInfo;

import junit.framework.TestCase;

/**
 * @author GouravChakraborty
 */
public class StatementProcessorParserTest extends TestCase {
	
	private final String CURRENT_WORKING_PATH = (System.getProperty("user.dir")+"\\src\\main\\extcnf\\")
			.replaceAll("\\\\", "/");
	
	@Override
	protected void setUp() throws Exception {
		super.setUp();
		
		String SD_ENV_NAME = "DEV";
		System.setProperty("SERVER_CONFIG_ROOT", CURRENT_WORKING_PATH);
		System.setProperty("SDEnvName", SD_ENV_NAME);
		
		
	}
	
	/**
	 * Test method for {@link com.shopdirect.nce.sp.parser.StatementProcessorParser#daoToXml()}.
	 * @throws JAXBException 
	 * @throws StatementProcessorBatchException 
	 */
	
	@Test
	public void testDaoToXml() throws JAXBException, StatementProcessorBatchException{
		CustomerAccountInfo customerAccountInfo;
		ArrayList<CustomerAccountInfo> customerAccountInfoList=new ArrayList<CustomerAccountInfo>();
		for(int i=0;i<1;i++){
			customerAccountInfo=CustomerAccountInfoBuilder.populateCustomerAccountInfo();
			customerAccountInfoList.add(customerAccountInfo);
		}

		List<String> messageList=StatementProcessorParser.daoToXml(customerAccountInfoList);
		Assert.assertNotNull(messageList.get(0));
			
	}
	
	@Test
	public void testgetCustomerReassesInfoAsXml() throws JAXBException, StatementProcessorBatchException {
		List<CustomerReassesmentInfo> customerReassesmentInfoList = new ArrayList<>();
		customerReassesmentInfoList.add(new CustomerReassesmentInfo("111", new Date(), "980", false, "D002"));

		List custReassInfoList = StatementProcessorParser.getCustomerReassesInfoAsXml(customerReassesmentInfoList);
		assertNotNull(custReassInfoList);
		assertEquals(1, custReassInfoList.size());
	}
}
