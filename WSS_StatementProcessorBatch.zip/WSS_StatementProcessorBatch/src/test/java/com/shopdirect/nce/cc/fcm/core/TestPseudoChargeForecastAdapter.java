package com.shopdirect.nce.cc.fcm.core;
import org.junit.Test;

//import com.shopdirect.nce.cc.fcm.core.adapter.PseudoChargeAdapter;

import junit.framework.Assert;

public class TestPseudoChargeForecastAdapter {

//	private final static PseudoChargeAdapter PSEUDO_CHARGE_ADAPTER = new PseudoChargeAdapter();

//	@Test
//	public void testDummyExistence() {
//		boolean isCustomerAccountInterestAdapterNull = null == PSEUDO_CHARGE_ADAPTER;
//		Assert.assertFalse("Adapter should not be NULL.", isCustomerAccountInterestAdapterNull);
//	}

}
