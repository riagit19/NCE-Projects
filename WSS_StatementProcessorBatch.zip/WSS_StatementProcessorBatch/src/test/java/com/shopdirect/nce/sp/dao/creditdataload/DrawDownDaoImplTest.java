package com.shopdirect.nce.sp.dao.creditdataload;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.exception.BuisnessException;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.Drawdown;

public class DrawDownDaoImplTest {
	ArrayList<Drawdown> drawDownTermList = null;
	Calendar cal = Calendar.getInstance();
	private static SDLoggerImpl logger = new SDLoggerImpl();

	@Before
	public void setUp() throws Exception {
		String CURRENT_WORKING_PATH = (System.getProperty("user.dir") + "\\src\\main\\extcnf\\").replaceAll("\\\\",
				"/");
		String SD_ENV_NAME = "DEV";
		System.setProperty("SERVER_CONFIG_ROOT", CURRENT_WORKING_PATH);
		System.setProperty("SDEnvName", SD_ENV_NAME);
		// cal.add(Calendar.DATE , 0);
		Timestamp ts = new Timestamp(cal.getTimeInMillis());
		drawDownTermList = new ArrayList<Drawdown>();
		logger.debug(cal.getTime().toString());
		
		for (int i = 0; i <= 10; i++) {
			Drawdown drawdownTerm = new Drawdown();

			drawdownTerm.setDrawdownId("1");
			drawdownTerm.setAgreementId("901");
			drawdownTerm.setAgreementSeqNumber((long)1);
			drawdownTerm.setBnplEndDate(ts);
			drawdownTerm.setDefInterestAmount((double)0);
			drawdownTerm.setDrawdownEndDate(ts);
			drawdownTerm.setInstallmentAmount((double)0);
			drawdownTerm.setInterestRate((double)0.09794);
			drawdownTerm.setOptOutAmount((double)0);
			drawdownTerm.setOutstandingBalance((double)0);
			drawdownTerm.setOutstandingCapital((double)0);
			drawdownTerm.setOutstandingInterestAmount((double)0);
			drawdownTerm.setPeriod((int)5);
			drawdownTerm.setDrawdownTerm((int)6);
			drawdownTerm.setProdCode("VYTN");
			drawdownTerm.setRateType("O");
			drawdownTerm.setStartDate(ts);
			drawdownTerm.setStatCode("O");
			drawdownTerm.setBroughtForwardBalance((double)0);
			drawdownTerm.setBfInitialBalance((double)0);
			drawdownTerm.setClosedDate(ts);
			drawdownTerm.setDrawdownSettledInd("N");
			drawdownTerm.setPromotionEndDate(ts);
			drawdownTerm.setSettlementFee((double)0);
			drawdownTerm.setBatchId(100l);
			drawdownTerm.setInstallmentAmount((double)0);
			drawdownTerm.setOutBalanceInt((double)0);
			drawdownTerm.setOutInterest((double)0);
			drawdownTerm.setCreatedByUser((long)555);
			drawdownTerm.setPrevInterestRate((double)0);
			
			drawDownTermList.add(drawdownTerm);
		}
	}

	@Test
	public void testInsertDrawDownTermData() throws BuisnessException, Exception {
		DrawDownDaoImpl drawDownTermDao = Mockito.mock(DrawDownDaoImpl.class);
		String insertMsg = null;
		
		Object[] result = new Object[2];
		result[0] = 0;
		Mockito.when(drawDownTermDao.insertDrawDownData(Mockito.isA(ArrayList.class))).thenReturn(result);
		
		try{
			Object[] insertFlag = drawDownTermDao.insertDrawDownData(drawDownTermList);
			
			if ((int) insertFlag[0] == 0) {
				insertMsg = StatementProcessorBatchConstants.EMPTY_STRING;
			} else {
				insertMsg = null;
			}
			
			assertNotNull(insertMsg);
		
		} catch (StatementProcessorBatchException spbe) {
			assertEquals(StatementProcessorBatchConstants.CONNECTTION_DB_ERROR_CODE, spbe.getErrorCode());
		}
	}

}
