package com.shopdirect.nce.sp.dao.creditdataload;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.exception.BuisnessException;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.TargetedPayment;

public class TargetedPaymentDaoImplTest {

	ArrayList<TargetedPayment> targetedPmttList = null;
	Calendar cal = Calendar.getInstance();
	private static SDLoggerImpl logger = new SDLoggerImpl();

	@Before
	public void setUp() throws Exception {
		String CURRENT_WORKING_PATH = (System.getProperty("user.dir") + "\\src\\main\\extcnf\\").replaceAll("\\\\",
				"/");
		String SD_ENV_NAME = "DEV";
		System.setProperty("SERVER_CONFIG_ROOT", CURRENT_WORKING_PATH);
		System.setProperty("SDEnvName", SD_ENV_NAME);
		Timestamp ts = new Timestamp(cal.getTimeInMillis());
		targetedPmttList = new ArrayList<TargetedPayment>();
		logger.debug(cal.getTime().toString());
		
		for (int i = 0; i <= 10; i++) {
			TargetedPayment targetedPayment = new TargetedPayment();
			
			targetedPayment.setAmount(Double.valueOf(56.87));
			targetedPayment.setBatchId(100l);
			targetedPayment.setCreatedByUser((long)555);
			targetedPayment.setDdtDtype("");
			targetedPayment.setDrawdownId("3");
			targetedPayment.setPayStatus("");
			targetedPayment.setPeriodPaymentId("1");
			targetedPayment.setRevPaymentId("2");
			targetedPayment.setTargetedPaymentId("5");
			targetedPayment.setPeriodPaymentId("2");
			targetedPayment.setAmount(Double.valueOf(0));
			targetedPayment.setTargetedPaymentDate(ts);
			targetedPayment.setTranType("");
			targetedPayment.setInternalTrxInd("T");
			
			targetedPmttList.add(targetedPayment);
		}
	}

	@Test
	public void testInsertTargetedPaymentData() throws BuisnessException, Exception {
		TargetedPaymentDaoImpl targetedPaymentDaoImpl = Mockito.mock(TargetedPaymentDaoImpl.class);
		
		String insertMsg = null;
		
		Object[] result = new Object[2];
		result[0] = 0;
		Mockito.when(targetedPaymentDaoImpl.insertTargetedPaymentData(Mockito.isA(ArrayList.class))).thenReturn(result);
		
		try {
			Object[] insertFlag = targetedPaymentDaoImpl.insertTargetedPaymentData(targetedPmttList);
			
			if ((int) insertFlag[0] == 0) {
				insertMsg = StatementProcessorBatchConstants.EMPTY_STRING;
			} else {
				insertMsg = null;
			}
			
			assertNotNull(insertMsg);

		
		} catch (StatementProcessorBatchException spbe) {
			assertEquals(StatementProcessorBatchConstants.CONNECTTION_DB_ERROR_CODE, spbe.getErrorCode());
		}
	}

}
