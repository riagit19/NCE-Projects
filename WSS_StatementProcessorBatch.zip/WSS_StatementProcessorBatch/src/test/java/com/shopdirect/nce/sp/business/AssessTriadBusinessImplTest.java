package com.shopdirect.nce.sp.business;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.CustomerAccountInfo;
import com.shopdirect.nce.sp.model.PseudoChargeResponseType;

public class AssessTriadBusinessImplTest {

	private AssessTriadBusinessImpl triadImpl;

	@Before
	public void setUp() throws Exception{
		String CURRENT_WORKING_PATH = (System.getProperty("user.dir") + "\\src\\main\\extcnf\\").replaceAll("\\\\",
				"/");
		String SD_ENV_NAME = "DEV";
		System.setProperty("SERVER_CONFIG_ROOT", CURRENT_WORKING_PATH);
		System.setProperty("SDEnvName", SD_ENV_NAME);

		triadImpl = new AssessTriadBusinessImpl();
	}

	@Test
	public void testProcessTriad() {
		
		CustomerAccountInfo accountInfo = new CustomerAccountInfo();
		accountInfo.setPublicAccountId("AB999787");
		accountInfo.setRetailAccountId("AB999787");
		accountInfo.setStatementDate(new Date("14-OCT-17"));
		accountInfo.setCreditStartDate(new Date());
		Map<String, String> updateCustomerMap = new HashMap<>();
		updateCustomerMap.put("ARREARS_STATUS_CODE", "20");
		updateCustomerMap.put("TRADING_CODE", "10");
		
		Map<String, PseudoChargeResponseType> pseudoMap = new HashMap<>();
		pseudoMap.put("AB997787", null);
		
		try {
			triadImpl.processTriad(accountInfo, pseudoMap, updateCustomerMap);
		} catch (StatementProcessorBatchException e) {
			e.printStackTrace();
		}
		
		}

}
