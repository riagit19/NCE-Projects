/**
 * 
 */
package com.shopdirect.nce.sp.business;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import com.shopdirect.nce.sp.model.CustomerAccountInfo;
import com.shopdirect.nce.sp.util.StatementProcessorBatchUtil;

/**
 * @author ibm
 *
 */
public class CustomerDetailsBusinessImplTest {

	/**
	 * Test method for customerDetailsBusinessImpl.updateAccountdetail
	 * @throws Exception 
	 */
	/*@Test
	public void testGetAccountList() throws Exception {
		UpdateCustomerInfoBusinessImpl customerDetailsBusinessImpl = new UpdateCustomerInfoBusinessImpl();
		CustomerAccountInfo customerAccountInfo = new CustomerAccountInfo();
		customerAccountInfo.setAccountStatus(3);
		customerAccountInfo.setPublicAccountId("A0000002");
		
		int updateStatus = 2;
		Calendar cal = Calendar.getInstance();
    	cal.add(Calendar.DATE , 0);
    	Date inputDate = cal.getTime();
    	customerAccountInfo.setStatementDate(inputDate);
    	customerDetailsBusinessImpl.process(customerAccountInfo, updateStatus);
    	
    	boolean result = false; 
    	
       Assert.assertNotNull(result);
	}*/

}
