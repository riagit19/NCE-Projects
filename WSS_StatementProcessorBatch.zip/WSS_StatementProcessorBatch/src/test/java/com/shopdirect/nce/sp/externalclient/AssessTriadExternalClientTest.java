package com.shopdirect.nce.sp.externalclient;

import static org.junit.Assert.fail;
import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;

import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.util.CommonConfigHelper;
//import com.shopdirect.osb.xsd.assesstriad.AssessTRIADRequestType;
import com.shopdirect.osb.xsd.header.RequestHeaderType;

/*
 * JUNIT Test class for TriadExternalClient
 */
public class AssessTriadExternalClientTest {
	
	private AssessTriadExternalClient triadExternalClient;

	@Before
	public void setUp() {
		String CURRENT_WORKING_PATH = (System.getProperty("user.dir") + "\\src\\main\\extcnf\\").replaceAll("\\\\",
				"/");
		String SD_ENV_NAME = "DEV";
		System.setProperty("SERVER_CONFIG_ROOT", CURRENT_WORKING_PATH);
		System.setProperty("SDEnvName", SD_ENV_NAME);

		try {
			triadExternalClient = new AssessTriadExternalClient();
		} catch (StatementProcessorBatchException e) {
			fail();
		}
	}

	@Test
	public final void testRetrieveTRIADContent() {/*
		RequestHeaderType headerType = new RequestHeaderType();
		AssessTRIADRequestType request = new AssessTRIADRequestType();
		try {
			triadExternalClient.setExtFileDataCfg(CommonConfigHelper.getInstance().loadPropertyConfig("externalClientConfig"));
			triadExternalClient.retrieveTRIADContent(headerType, request);
		} catch (Exception e) {
			assertNotNull(triadExternalClient.getLocalHeader());
		}
	*/}
	
}
