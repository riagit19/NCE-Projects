package com.shopdirect.nce.sp.dao.creditdataload;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.exception.BuisnessException;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.ServiceCharge;

public class ServiceChargeDaoImplTest {

	ArrayList<ServiceCharge> serviceChargetList = null;
	Calendar cal = Calendar.getInstance();
	private static SDLoggerImpl logger = new SDLoggerImpl();

	@Before
	public void setUp() throws Exception {
		String CURRENT_WORKING_PATH = (System.getProperty("user.dir") + "\\src\\main\\extcnf\\").replaceAll("\\\\",
				"/");
		String SD_ENV_NAME = "DEV";
		System.setProperty("SERVER_CONFIG_ROOT", CURRENT_WORKING_PATH);
		System.setProperty("SDEnvName", SD_ENV_NAME);
		serviceChargetList = new ArrayList<ServiceCharge>();
		Timestamp ts = new Timestamp(cal.getTimeInMillis());
		logger.debug(cal.getTime().toString());
		
		for (int i = 0; i <= 10; i++) {
			ServiceCharge serviceCharge = new ServiceCharge();
			
			serviceCharge.setAgreemntId("876");
			serviceCharge.setAgreemntSeq(Long.valueOf(9876));
			serviceCharge.setBatchId(100l);
			serviceCharge.setChargeType("");
			serviceCharge.setCreatedByUser(Long.valueOf(65347));
			serviceCharge.setCreationDate(ts);
			serviceCharge.setDailyInterestRate(Double.valueOf(4553.76));
			serviceCharge.setDdtDType("");
			serviceCharge.setDefaultSumnInArrearsNotice("");
			serviceCharge.setDrawdownId("4");
			serviceCharge.setInsuranceProdRefNo("");
			serviceCharge.setMivCode(Double.valueOf(333));
			serviceCharge.setMivSubCode("33");
			serviceCharge.setReasnCd("");
			serviceCharge.setServiceChargeAmount(Double.valueOf(4553.76));
			serviceCharge.setServiceChargeDate(ts);
			serviceCharge.setServiceChargeId("6543");
			
			serviceChargetList.add(serviceCharge);
		}
	}

	@Test
	public void testInsertServiceChargeData() throws BuisnessException, Exception {
		ServiceChargeDaoImpl serviceChargeDaoImpl = Mockito.mock(ServiceChargeDaoImpl.class);
		String insertMsg = null;
		
		Object[] result = new Object[2];
		result[0] = 0;
		Mockito.when(serviceChargeDaoImpl.insertServiceChargeData(Mockito.isA(ArrayList.class))).thenReturn(result);
		
		try {
			Object[] insertFlag = serviceChargeDaoImpl.insertServiceChargeData(serviceChargetList);
			
			if ((int) insertFlag[0] == 0) {
				insertMsg = StatementProcessorBatchConstants.EMPTY_STRING;
			} else {
				insertMsg = null;
			}
			
			assertNotNull(insertMsg);
		} catch (StatementProcessorBatchException spbe) {
			assertEquals(StatementProcessorBatchConstants.CONNECTTION_DB_ERROR_CODE, spbe.getErrorCode());
		}
	}

}
