package com.shopdirect.nce.cc.fcm.core;
import org.junit.Test;

import com.shopdirect.nce.cc.fcm.core.adapter.CustomerAccountInterestAdapter;

import junit.framework.Assert;

public class TestCustomerAccountAdapter {

	private final static CustomerAccountInterestAdapter CUSTOMER_ACCOUNT_INTEREST_ADAPTER = new CustomerAccountInterestAdapter();

	@Test
	public void testDummyExistence() {
		boolean isCustomerAccountInterestAdapterNull = null == CUSTOMER_ACCOUNT_INTEREST_ADAPTER;
		Assert.assertFalse("Adapter should not be NULL.", isCustomerAccountInterestAdapterNull);
	}

}
