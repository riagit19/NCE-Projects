package com.shopdirect.nce.sp.externalclient;

import java.util.ArrayList;

import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;
import org.mockito.Mockito;

import com.shopdirect.nce.common.extcnfg.ExternalFileDataConfiguration;
import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.dao.StatementProcessorARDao;
import com.shopdirect.nce.sp.jms.QueueSend;
import com.shopdirect.nce.sp.model.CustomerAccountInfo;
import com.shopdirect.nce.sp.model.CustomerAccountInfoBuilder;
import com.shopdirect.nce.sp.parser.StatementProcessorParser;
import com.shopdirect.nce.sp.util.CommonConfigHelper;

import junit.framework.TestCase;

/**
 * @author GouravChakraborty
 */
public class CustomerARProcessMsgSendTest extends TestCase {
	
	QueueSend queueSend;
	StatementProcessorARDao statementProcessorARDao;
	private final String CURRENT_WORKING_PATH = (System.getProperty("user.dir")+"\\src\\main\\extcnf\\")
			.replaceAll("\\\\", "/");
	
	@Override
	protected void setUp() throws Exception {
		// TODO Auto-generated method stub
		super.setUp();
		
		String SD_ENV_NAME = "DEV";
		System.setProperty("SERVER_CONFIG_ROOT", CURRENT_WORKING_PATH);
		System.setProperty("SDEnvName", SD_ENV_NAME);
		
		try{
			queueSend=new QueueSend();
		}catch(Exception e){
			e.getMessage();
		}
		statementProcessorARDao = Mockito.mock(StatementProcessorARDao.class);
		queueSend.setStatementProcessorARDao(statementProcessorARDao);
		
		
	}
	
	private static SDLoggerImpl logger = new SDLoggerImpl();
	
	/**
	 * Test method for {@link com.shopdirect.nce.sp.externalclient.CustomerARProcessMsgSend#customerMsgPut()}.
	 * @throws Exception 
	 */
	
	@Test
	public void testCustomerMsgPut() throws Exception{	
		CommonConfigHelper commonConfigHelper = CommonConfigHelper.getInstance();
		ExternalFileDataConfiguration externalClientConfig = commonConfigHelper.loadPropertyConfig(StatementProcessorBatchConstants.AUDITLOG_CONFIGURATION_FILE_KEY);
		
		QueueSend qs=new QueueSend();
		CustomerAccountInfo customerAccountInfo;
		try{
			customerAccountInfo=CustomerAccountInfoBuilder.populateCustomerAccountInfo();
			String message=StatementProcessorParser.daoToXml(customerAccountInfo);
			//queueSend.sendAsyncMessage(message,"12345678987",customerAccountInfo.getStatementDate(), "REQ_QUEUE");
			qs.init("REQ_QUEUE");
			qs.send(message);
			qs.close();
			//Mockito.when(statementProcessorARDao.updateARStatusMessage("12345678987", commonConfigHelper.readConfigData(externalClientConfig, "startedAR"), new java.sql.Date(customerAccountInfo.getStatementDate().getTime()))).thenReturn(statusUpdate);
			Mockito.doNothing().when(statementProcessorARDao).updateARStatusMessage("12345678987", commonConfigHelper.readConfigData(externalClientConfig, "startedAR"), new java.sql.Date(customerAccountInfo.getStatementDate().getTime()));
			
			Assert.assertNotNull(customerAccountInfo);
		}catch(Exception e){
			logger.error((e.getMessage()));
		}	
	}
}
