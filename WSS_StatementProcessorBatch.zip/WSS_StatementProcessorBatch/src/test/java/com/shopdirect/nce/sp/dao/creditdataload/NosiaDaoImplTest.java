package com.shopdirect.nce.sp.dao.creditdataload;

import static org.junit.Assert.assertNotNull;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.exception.BuisnessException;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.Nosia;

public class NosiaDaoImplTest {

	ArrayList<Nosia> nosiaList = null;
	Calendar cal = Calendar.getInstance();
	private static SDLoggerImpl logger = new SDLoggerImpl();

	@Before
	public void setUp() throws Exception {
		String CURRENT_WORKING_PATH = (System.getProperty("user.dir") + "\\src\\main\\extcnf\\").replaceAll("\\\\",
				"/");
		String SD_ENV_NAME = "DEV";
		System.setProperty("SERVER_CONFIG_ROOT", CURRENT_WORKING_PATH);
		System.setProperty("SDEnvName", SD_ENV_NAME);
		Timestamp ts = new Timestamp(cal.getTimeInMillis());
		nosiaList = new ArrayList<Nosia>();
		logger.debug(cal.getTime().toString());
		
		
		for (int i = 0; i <= 10; i++) {
			Nosia nosia = new Nosia();
			
			nosia.setPreviousNosiaBalance((double)453);
			nosia.setPreviousNosiaArrears((double)453);
			nosia.setClosingBalance((double)453);
			nosia.setArrearsAmount((double)453);
			nosia.setMostRecentPaymentAmount((double)453);
			nosia.setAgreementId("6754");
			nosia.setAgreementSeq((long)453);
			nosia.setPreviousPaymentAmount((double)453.87);
			nosia.setPrevPayDueDate(ts);
			nosia.setPrev2PayDueDate(ts);
			nosia.setPrevArrearsAmount((double)453.56); 
			nosia.setPrev2ArrearsAmount((double)453.56);
			nosia.setPrevMinPayAmount((double)453.56);
			nosia.setPrev2MinPayAmount((double)453.56);
			nosia.setTotPrevPayAmount((double)300.65);
			nosia.setTotPrev2PayAmount((double)453.56);
			nosia.setBatchId(100l);
			nosia.setCreatedByUser((long)555);
			
			nosiaList.add(nosia);
		}
	}

	@Test
	public void testInsertNosiaData() throws BuisnessException, Exception {
		NosiaDaoImpl nosiaDaoImpl = Mockito.mock(NosiaDaoImpl.class);
		String insertMsg = null;
		
		Object[] result = new Object[2];
		result[0] = 0;
		Mockito.when(nosiaDaoImpl.insertNosiaData(Mockito.isA(ArrayList.class))).thenReturn(result);
		
		try {
			Object[] insertFlag = nosiaDaoImpl.insertNosiaData(nosiaList);
			
			if ((int) insertFlag[0] == 0) {
				insertMsg = StatementProcessorBatchConstants.EMPTY_STRING;
			} else {
				insertMsg = null;
			}
			
			assertNotNull(insertMsg);

		
		} catch (StatementProcessorBatchException spbe) {
			assertNotNull(spbe.getErrorCode());
		}
	}

}
