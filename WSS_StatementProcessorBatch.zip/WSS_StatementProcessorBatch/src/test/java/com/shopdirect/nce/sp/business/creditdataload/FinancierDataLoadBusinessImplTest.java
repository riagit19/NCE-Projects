package com.shopdirect.nce.sp.business.creditdataload;

import org.junit.Before;
import org.junit.Test;

import com.shopdirect.nce.sp.business.creditdataload.FinancierDataLoadBusinessImpl;

public class FinancierDataLoadBusinessImplTest {

	private FinancierDataLoadBusinessImpl impl;

	@Before
	public void setUp() throws Exception {

		String CURRENT_WORKING_PATH = (System.getProperty("user.dir") + "\\src\\main\\extcnf\\").replaceAll("\\\\",
				"/");
		String SD_ENV_NAME = "DEV";
		System.setProperty("SERVER_CONFIG_ROOT", CURRENT_WORKING_PATH);
		System.setProperty("SDEnvName", SD_ENV_NAME);

	}

	@Test
	public void test() {
		try {

			impl = new FinancierDataLoadBusinessImpl();
			impl.dispatch("464",0,"2018-01-05");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

}
