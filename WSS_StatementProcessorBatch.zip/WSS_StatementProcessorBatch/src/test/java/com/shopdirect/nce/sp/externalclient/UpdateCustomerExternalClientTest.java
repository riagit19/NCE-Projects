package com.shopdirect.nce.sp.externalclient;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.osb.xsd.updatecustomeraccount.AccountArrearsGroupType;
import com.shopdirect.osb.xsd.updatecustomeraccount.AccountStatusGroupType;
import com.shopdirect.osb.xsd.updatecustomeraccount.UpdateCustomerAccountReqType;
import com.shopdirect.osb.xsd.updatecustomeraccount.UpdateCustomerAccountRequestType;
import com.shopdirect.osb.xsd.updatecustomeraccount.UpdateCustomerAccountResponseType;

public class UpdateCustomerExternalClientTest {
	
	private static SDLoggerImpl logger = new SDLoggerImpl();
	
	@Mock
	UpdateCustomerExternalClient updateCustomerExternalClient;
	
	@Mock
	UpdateCustomerAccountResponseType resp;
	
	@Before
	public void initialize() {
		
		MockitoAnnotations.initMocks(this);
	}
	
	@Before
	public void setUp() throws Exception {
		String CURRENT_WORKING_PATH = (System.getProperty("user.dir") + "\\src\\main\\extcnf\\").replaceAll("\\\\", "/");
		String SD_ENV_NAME = "DEV";
		System.setProperty("SERVER_CONFIG_ROOT", CURRENT_WORKING_PATH);
		System.setProperty("SDEnvName", SD_ENV_NAME);

	}
	
	@Test
	public final void testUpdateCustomerAccountContent()  {
		try{
			updateCustomerExternalClient = new UpdateCustomerExternalClient();
			UpdateCustomerAccountRequestType request = new UpdateCustomerAccountRequestType();
			UpdateCustomerAccountReqType updateCustomerAccountReqType = new UpdateCustomerAccountReqType();
			request.setUpdateCustomerAccountReq(updateCustomerAccountReqType);
			
			updateCustomerAccountReqType.setPublicAccountNumber("A908077");
			updateCustomerAccountReqType.setAgreementReference("A847908");
			
			AccountStatusGroupType accountStatusGroupType = new AccountStatusGroupType();
			updateCustomerAccountReqType.setAccountStatusGroup(accountStatusGroupType);
			
			accountStatusGroupType.setOldAccountStatus("71");
			accountStatusGroupType.setNewAccountStatus("00");
			
			AccountArrearsGroupType accountArrearsGroupType = new AccountArrearsGroupType();
			updateCustomerAccountReqType.setAccountArrearsGroup(accountArrearsGroupType);
			
			accountArrearsGroupType.setArrearsStatus("73");
			
			updateCustomerAccountReqType.setStatusChange("DORM");
			resp =updateCustomerExternalClient.updateCustomerAccountContent(request);
		} catch(StatementProcessorBatchException e){
				getLogger().error("[UpdateCustomerExternalClientTest -- testUpdateCustomerAccountContent] Exception Block "+ e.getMessage());
		}
	}
	public static SDLoggerImpl getLogger() {
		return logger;
	}
	public static void setLogger(SDLoggerImpl logger) {
		UpdateCustomerExternalClientTest.logger = logger;
	}
	
}
