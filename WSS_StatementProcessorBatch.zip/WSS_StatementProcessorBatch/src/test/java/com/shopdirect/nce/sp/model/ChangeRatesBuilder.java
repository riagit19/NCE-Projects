package com.shopdirect.nce.sp.model;

import java.util.Date;

import com.shopdirect.nce.sp.model.ChangeRates;

public class ChangeRatesBuilder {
	

	 private Integer cimAccountInfoID;
	  private Long air;
	  private String creditAccountNumber;
	  private Date implementAfter;
	  private Integer assessmentNumber;
	  private Double outstandingBnplBalAmt;
	  private Integer riskNavScore;
	  private Double scheduledPaymntPastDue;
	  private String aprAction;
	  private Double apr;
	  private String brandCode;

		public ChangeRatesBuilder withAccountInfoId(Integer accountInfoId) {
			this.cimAccountInfoID = accountInfoId;
			return this;
		}

		public ChangeRatesBuilder withCreditAccountNumber(String creditAccountNumber) {
			this.creditAccountNumber = creditAccountNumber;
			return this;
		}

		public ChangeRatesBuilder withImplementAfter(Date implementAfter) {
			this.implementAfter = implementAfter;
			return this;
		}

		public ChangeRatesBuilder withRiskNavScore(Integer riskNavScore) {
			this.riskNavScore = riskNavScore;
			return this;
		}
		
		public ChangeRatesBuilder withAssessmentNumber(Integer assessmentNumber) {
			this.assessmentNumber = assessmentNumber;
			return this;
		}
		
		public ChangeRatesBuilder withScheduledPaymntPastDue(Double scheduledPaymntPastDue) {
			this.scheduledPaymntPastDue = scheduledPaymntPastDue;
			return this;
		}

		

		public ChangeRatesBuilder withAprAction(String aprAction) {
			this.aprAction = aprAction;
			return this;
		}

		public ChangeRatesBuilder withBrandCode(String brandCode) {
			this.brandCode = brandCode;
			return this;
		}

		

		public ChangeRatesBuilder withApr(Double apr) {
			this.apr = apr;
			return this;
		}

		public ChangeRatesBuilder withAir(Long air) {
			this.air = air;
			return this;
		}

		public ChangeRatesBuilder withOutstandingBnplBalAmt(Double outstandingBnplBalAmt) {
			this.outstandingBnplBalAmt = outstandingBnplBalAmt;
			return this;
		}
		
		public ChangeRates build() {
			return new ChangeRates(cimAccountInfoID,  air,  creditAccountNumber,  implementAfter,
					 assessmentNumber,  outstandingBnplBalAmt,  riskNavScore,  scheduledPaymntPastDue,
					 aprAction,  apr,  brandCode);
		}

		public static ChangeRates populateCustomerAccountInfo(){
			ChangeRates changeRates=new ChangeRatesBuilder().withAccountInfoId(new Integer(2308)).withAir(new Long(1)).withCreditAccountNumber("111")
					.withImplementAfter(new Date(2011-11-11)).withAssessmentNumber(new Integer(2)).withOutstandingBnplBalAmt(new Double(2.0)).withRiskNavScore(new Integer(1))
					.withScheduledPaymntPastDue(new Double(1.0)).withAprAction("111").withBrandCode("111").withApr(new Double(1.0)).build();
			return changeRates;
		}
		
	

}
