package com.shopdirect.nce.sp.business;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.shopdirect.nce.sp.dao.AccountReassementProcessDao;
import com.shopdirect.nce.sp.dao.StatementProcessorARDao;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.jms.QueueSend;
import com.shopdirect.nce.sp.model.CustomerAccountInfo;
import com.shopdirect.nce.sp.model.CustomerAccountInfoBuilder;
import com.shopdirect.nce.sp.model.PseudoChargeResponseType;
import com.shopdirect.nce.sp.workmanager.AccountReassessmentExecutor;

import junit.framework.TestCase;

/**
 * 
 * @author SudiptaRoy
 *
 */
public class AccountReassementProcessBusinessImplTest extends TestCase {

	private static final String JMS_MESSAGE = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><customerAccountInfo><accountInfoId>111</accountInfoId><accountStatus>2.0</accountStatus><addressLine1>111</addressLine1></customerAccountInfo>";
	AccountReassementProcessBusinessImpl arpbi;
	AccountReassementProcessDao arpd;
	StatementProcessorARDao arDao;
	QueueSend queueSend;

	@Before
	public void setUp() {
		String CURRENT_WORKING_PATH = (System.getProperty("user.dir") + "\\src\\main\\extcnf\\").replaceAll("\\\\",
				"/");
		String SD_ENV_NAME = "DEV";
		System.setProperty("SERVER_CONFIG_ROOT", CURRENT_WORKING_PATH);
		System.setProperty("SDEnvName", SD_ENV_NAME);
		
		try {
			arpbi = new AccountReassementProcessBusinessImpl();
		} catch (Exception e) {
			e.printStackTrace();
		}

		arpd = Mockito.mock(AccountReassementProcessDao.class);
		arDao = Mockito.mock(StatementProcessorARDao.class);
		queueSend = Mockito.mock(QueueSend.class);
		arpbi.setAccountReassementProcessDao(arpd);
		arpbi.setArDao(arDao);
		arpbi.setQueueSend(queueSend);
	}

	@Test
	public void testExtractValue() {
		String customerId = arpbi.extractValue(JMS_MESSAGE, "accountInfoId");
		assertNotNull(customerId);
		assertEquals("111", customerId);
		
		assertEquals("",arpbi.extractValue(null, null));
		assertEquals("",arpbi.extractValue("", ""));
		assertEquals("", arpbi.extractValue("<accountInfoId>111</accountI>", "accountInfoId"));
	}

	@Test
	public void testGetCustIdDetailsFromJMSMessage() throws StatementProcessorBatchException {
		List<CustomerAccountInfo> customerAccountInfoList = new ArrayList<CustomerAccountInfo>();
		customerAccountInfoList.add(CustomerAccountInfoBuilder.populateCustomerAccountInfo());

		Mockito.when(arpd.getCustomerDetails(Mockito.isA(String.class), Mockito.isA(String.class))).thenReturn(customerAccountInfoList);
		try{
			arpbi.getCustIdDetailsFromJMSMessage(JMS_MESSAGE);
		} catch (Exception e){
			fail();
		}
	}
	
	@Test
	public void testGetCustIdDetailsFromJMSMessage_Empty() throws StatementProcessorBatchException {
		List<CustomerAccountInfo> customerAccountInfoList = new ArrayList<CustomerAccountInfo>();
		customerAccountInfoList.add(new CustomerAccountInfo());
		customerAccountInfoList.add(new CustomerAccountInfo());
		customerAccountInfoList.add(new CustomerAccountInfo());

		Mockito.when(arpd.getCustomerDetails("111", "2017-04-03")).thenReturn(customerAccountInfoList);
		try{
			arpbi.getCustIdDetailsFromJMSMessage(JMS_MESSAGE);
		} catch (Exception e){
			fail();
		}
	}

	@Test
	public void testPutToResponseQueue() throws Exception {
		CustomerAccountInfo custAccInfo = new CustomerAccountInfo();
		custAccInfo.setPublicAccountId("111");
		Map<String, PseudoChargeResponseType> pseudoRspMap = new HashMap<>();
		AccountReassessmentExecutor reassessmentExecutor = new AccountReassessmentExecutor(custAccInfo, pseudoRspMap);
		List<String> messageList = new ArrayList<>();

		Mockito.doNothing().when(queueSend).sendAsyncMessage(messageList, "RSP_QUEUE");
		arpbi.putToResponseQueue(reassessmentExecutor, "AR_Failed");
	}
	
	@Test
	public void testHandleResponse() throws Exception {
		AccountReassessmentExecutor reassessExecRsp = new AccountReassessmentExecutor();
		reassessExecRsp.setProcessorBatchException(new StatementProcessorBatchException());

		arpbi.handleResponse(null);
		arpbi.handleResponse(reassessExecRsp);

		reassessExecRsp.setProcessorBatchException(null);
		CustomerAccountInfo cai = new CustomerAccountInfo();
		cai.setPublicAccountId("111");
		cai.setAccountInfoId("1234");
		reassessExecRsp.setCustomerAccountInfo(cai);
		List<String> messageList = new ArrayList<>();

		try {
			AccountReassementProcessBusinessImpl impl = new AccountReassementProcessBusinessImpl();
			impl.getAccountReassementProcessDao();
			impl.setQueueSend(new QueueSend());
			impl.getQueueSend();
			Mockito.when(arDao.updateStatusMessage("111", "AR_Completed", "1234")).thenReturn(1);
			Mockito.doNothing().when(queueSend).sendAsyncMessage(messageList, "RSP_QUEUE");
			arpbi.handleResponse(reassessExecRsp);
		} catch (SQLException e) {
			fail();
		}
	}
}
