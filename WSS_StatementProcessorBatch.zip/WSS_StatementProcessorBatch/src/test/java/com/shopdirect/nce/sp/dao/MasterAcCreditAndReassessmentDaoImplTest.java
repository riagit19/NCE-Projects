package com.shopdirect.nce.sp.dao;

import static org.junit.Assert.assertEquals;

import java.math.BigInteger;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.model.AuthType;
import com.shopdirect.nce.sp.model.CreditLimitType;

public class MasterAcCreditAndReassessmentDaoImplTest {

	private static SDLoggerImpl logger = new SDLoggerImpl();
	MasterAcCreditAndReassessmentDaoImpl masterAcCreditAndReassessmentDaoImpl = null;
	
	@Before
	public void setUp() throws Exception {
		String CURRENT_WORKING_PATH = (System.getProperty("user.dir") + "\\src\\main\\extcnf\\").replaceAll("\\\\",
				"/");
		String SD_ENV_NAME = "DEV";
		System.setProperty("SERVER_CONFIG_ROOT", CURRENT_WORKING_PATH);
		System.setProperty("SDEnvName", SD_ENV_NAME);
	}
	
	@Test
	public void testProcessUpdateCreditAndReassessment() throws Exception {
		logger.info("[AccountReassessmentDaoImplTest - testUpdateAccReassessment ] - Start");
		masterAcCreditAndReassessmentDaoImpl = Mockito.mock(MasterAcCreditAndReassessmentDaoImpl.class);
		
		CreditLimitType creditLimitType = new CreditLimitType();
		AuthType authType = new AuthType();
		creditLimitType.setProposedCreditLimit(BigInteger.ONE);
		creditLimitType.setActualCreditLimit(BigInteger.TEN);
		creditLimitType.setCreditLineReasonCode("RSN");
		creditLimitType.setCreditRiskFactor(BigInteger.ONE);
		creditLimitType.setAuthStrategyId(BigInteger.ZERO);
		creditLimitType.setCustBehaviourScore(BigInteger.ONE);
		creditLimitType.setDaysProposedLimitExpires("1");
		creditLimitType.setLimitCapValue(BigInteger.ZERO);
		authType.setShadowCreditMonetaryLimit(BigInteger.TEN);
		authType.setActualCreditMonetaryLimit(BigInteger.ONE);
		
		String pubAccNo = "D0000002";
		String creditLimitAction = "CHANGE";
		String clStatus = "NEW";
		Date statementDate = new Date("25-APR-17");
		Format formatter = new SimpleDateFormat("dd-MMM-yy");
		String statementDt = formatter.format(statementDate);
		String arrearsStatus = "20";
		String tradingCode = "33";
		Mockito.when(masterAcCreditAndReassessmentDaoImpl.processUpdateCreditAndReassessment(Mockito.isA(CreditLimitType.class),
				Mockito.isA(AuthType.class), Mockito.isA(String.class), Mockito.isA(String.class), Mockito.isA(String.class),
				Mockito.isA(String.class), Mockito.isA(String.class), Mockito.isA(String.class))).thenReturn(1);
		int status = masterAcCreditAndReassessmentDaoImpl.processUpdateCreditAndReassessment(creditLimitType, authType, pubAccNo, creditLimitAction,
				clStatus, statementDt, arrearsStatus, tradingCode);
		assertEquals(1,status);
		logger.info("[AccountReassessmentDaoImplTest - testUpdateAccReassessment ] - End");
	}
}
