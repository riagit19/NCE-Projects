package com.shopdirect.nce.sp.externalclient.handler;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;



/*
 * This is test class for ExternalServiceAuditLoggingHandler
 */
public class ExternalServiceAuditLoggingHandlerTest {
	
	@Mock
	ExternalServiceAuditLoggingHandler auditLoggingHandler;
	@Before
	public void initialize() {
		
		MockitoAnnotations.initMocks(this);
	}
	@Test
	public final void testHandleMessage()  {
		
		ExternalServiceAuditLoggingHandler extClient = Mockito.mock(ExternalServiceAuditLoggingHandler.class);
		extClient.handleMessage(Mockito.any());
		
		
	}
	
	@Test
	public final void testHandleFault()  {
		
		ExternalServiceAuditLoggingHandler extClient = Mockito.mock(ExternalServiceAuditLoggingHandler.class);
		extClient.handleFault(Mockito.any());
		
		
	}
}
