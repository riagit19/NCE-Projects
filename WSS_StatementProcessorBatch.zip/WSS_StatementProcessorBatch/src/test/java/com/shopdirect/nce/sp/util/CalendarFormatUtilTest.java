package com.shopdirect.nce.sp.util;

import java.text.ParseException;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;

import junit.framework.TestCase;

public class CalendarFormatUtilTest extends TestCase {
	
	private static SDLoggerImpl logger = new SDLoggerImpl();
	
	@Before
	public void setUp() throws StatementProcessorBatchException {
		String CURRENT_WORKING_PATH = (System.getProperty("user.dir") + "\\src\\main\\extcnf\\").replaceAll("\\\\",	"/");
		String SD_ENV_NAME = "DEV";
		System.setProperty("SERVER_CONFIG_ROOT", CURRENT_WORKING_PATH);
		System.setProperty("SDEnvName", SD_ENV_NAME);		
		
	}
	
	
	@Test
	public void testConvertCalendarWithValue() throws StatementProcessorBatchException{
		try{
			CalendarFormatUtil.convertCalendar("2015-03-01");
		}catch(Exception e){
			logger.error(e.getMessage());
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_BUSINESS_ERROR_CODE,
					"[CalendarFormatUtilTest-testConvertCalendar] Exception Block",
					"Business exception generated at time to process the data collection "+ e.getMessage(),
					null, null,e);
		}	
	}
	

}
