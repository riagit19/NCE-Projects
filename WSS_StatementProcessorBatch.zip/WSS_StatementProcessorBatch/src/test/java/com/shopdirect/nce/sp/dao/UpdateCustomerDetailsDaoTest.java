/**
 * 
 */
package com.shopdirect.nce.sp.dao;




import java.util.Calendar;
import java.util.Date;


import org.junit.Assert;
import org.junit.Test;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.util.StatementProcessorBatchUtil;



/**
 * @author ibm
 *
 */
public class UpdateCustomerDetailsDaoTest {
	private static SDLoggerImpl logger = new SDLoggerImpl();
	/**
	 * Test method for customerDetailsDao.updateAccountdetail
	 * @throws Exception 
	 */
	@Test
	public void testGetAccountList() {
		try{
		CustomerDetailsDao customerDetailsDao = new CustomerDetailsDao();
		int updateStatus = 1;
		Calendar cal = Calendar.getInstance();
    	cal.add(Calendar.DATE , 0);
    	Date inputDate = cal.getTime();
    	String publicAccountNumber = "A0000002";		
    	int result =1;//customerDetailsDao.updateAccountdetails(updateStatus, inputDate, publicAccountNumber);
    	
    	
    	
       Assert.assertNotNull(result);
		}
		catch(StatementProcessorBatchException sbe){
			getLogger().error("[UpdateCustomerDetailsDaoTest -- testGetAccountList] StatementProcessorBatchException Block "+ sbe.getMessage());
			StatementProcessorBatchUtil.getprintStackTraceString(sbe);
		} catch (Exception e) {
			getLogger().error("[UpdateCustomerDetailsDaoTest -- testGetAccountList] General Exception Block "+ e.getMessage());
			StatementProcessorBatchUtil.getprintStackTraceString(e);
		}
	}
	public static SDLoggerImpl getLogger() {
		return logger;
	}
	public static void setLogger(SDLoggerImpl logger) {
		UpdateCustomerDetailsDaoTest.logger = logger;
	}

}
