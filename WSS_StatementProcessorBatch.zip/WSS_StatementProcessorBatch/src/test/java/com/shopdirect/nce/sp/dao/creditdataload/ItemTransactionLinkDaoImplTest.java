package com.shopdirect.nce.sp.dao.creditdataload;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.exception.BuisnessException;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.ItemTransactionLink;

public class ItemTransactionLinkDaoImplTest {
	ArrayList<ItemTransactionLink> itemTransactionLinkList = null;
	Calendar cal = Calendar.getInstance();
	private static SDLoggerImpl logger = new SDLoggerImpl();
	

	@Before
	public void setUp() throws Exception {
		
		String CURRENT_WORKING_PATH = (System.getProperty("user.dir") + "\\src\\main\\extcnf\\").replaceAll("\\\\",
				"/");
		String SD_ENV_NAME = "DEV";
		System.setProperty("SERVER_CONFIG_ROOT", CURRENT_WORKING_PATH);
		System.setProperty("SDEnvName", SD_ENV_NAME);
		// cal.add(Calendar.DATE , 0);
		itemTransactionLinkList = new ArrayList<ItemTransactionLink>();
		logger.debug(cal.getTime().toString());
		
		for (int i = 0; i <= 10; i++) {
			ItemTransactionLink itemTransactionLink = new ItemTransactionLink();
			
			itemTransactionLink.setDrawdownItemId("1");
			itemTransactionLink.setDrawdownTransactionId("2");
			itemTransactionLink.setBatchId(100l);
			itemTransactionLink.setCreatedByUser((long)555);
			itemTransactionLinkList.add(itemTransactionLink);
		}
	}

	@Test
	public void testInsertItemTransactionLinkData() throws BuisnessException, Exception {
		ItemTransactionLinkDaoImpl itemTransactionLinkDaoImpl = Mockito.mock(ItemTransactionLinkDaoImpl.class);
		String insertMsg = null;
		
		Object[] result = new Object[2];
		result[0] = 0;
		Mockito.when(itemTransactionLinkDaoImpl.insertItemTransactionLinkData(Mockito.isA(ArrayList.class))).thenReturn(result);
		
		try{
			Object[] insertFlag = itemTransactionLinkDaoImpl.insertItemTransactionLinkData(itemTransactionLinkList);

			if ((int) insertFlag[0] == 0) {
				insertMsg = StatementProcessorBatchConstants.EMPTY_STRING;
			} else {
				insertMsg = null;
			}
			
			assertNotNull(insertMsg);
		
		
		} catch (StatementProcessorBatchException spbe) {
			assertEquals(StatementProcessorBatchConstants.CONNECTTION_DB_ERROR_CODE, spbe.getErrorCode());
		}
	}

}
