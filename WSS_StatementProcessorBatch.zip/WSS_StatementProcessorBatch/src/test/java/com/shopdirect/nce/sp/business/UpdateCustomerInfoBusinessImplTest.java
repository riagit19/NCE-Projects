package com.shopdirect.nce.sp.business;

import java.util.Date;

import org.junit.Before;
import org.junit.Test;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.CustomerAccountInfo;
import com.shopdirect.nce.sp.util.StatementProcessorBatchUtil;

public class UpdateCustomerInfoBusinessImplTest {

	private static SDLoggerImpl logger = new SDLoggerImpl();
	
	@Before
	public void setUp() throws Exception{
		String CURRENT_WORKING_PATH = (System.getProperty("user.dir") + "\\src\\main\\extcnf\\").replaceAll("\\\\",
				"/");
		String SD_ENV_NAME = "DEV";
		System.setProperty("SERVER_CONFIG_ROOT", CURRENT_WORKING_PATH);
		System.setProperty("SDEnvName", SD_ENV_NAME);
	}
	
	@Test
	public void testProcess(){
		CustomerAccountInfo customerAccountInfo = new CustomerAccountInfo();
		customerAccountInfo.setPublicAccountId("AB999787");
		customerAccountInfo.setAccountStatus("98");
		customerAccountInfo.setStatementDate(new Date("14-OCT-17"));
		customerAccountInfo.setAccountInfoId("488");
		customerAccountInfo.setCreditAccountId("A847908");
		try{
		UpdateCustomerInfoBusinessImpl businessImpl =  new UpdateCustomerInfoBusinessImpl();
		String updateStatus= "1";
		businessImpl.process(customerAccountInfo, updateStatus);
		}
		catch (StatementProcessorBatchException sbe) {
			getLogger().error("[UpdateCustomerInfoBusinessImplTest -- testProcess] StatementProcessorBatchException Block "+ sbe.getMessage());
			StatementProcessorBatchUtil.getprintStackTraceString(sbe);
		}
	}
	
	@Test
	public void testProcessWithLinkAccount(){
		CustomerAccountInfo customerAccountInfo = new CustomerAccountInfo();
		customerAccountInfo.setPublicAccountId("M0000001");
		customerAccountInfo.setLinkedAccntIndex(0);
		customerAccountInfo.setAccountInfoId("22824");
		customerAccountInfo.setAccountStatus("98");
		try{
		UpdateCustomerInfoBusinessImpl businessImpl =  new UpdateCustomerInfoBusinessImpl();
		String updateStatus= "1";
		businessImpl.process(customerAccountInfo, updateStatus);
		}
		catch (StatementProcessorBatchException sbe) {
			getLogger().error("[UpdateCustomerInfoBusinessImplTest -- testProcess] StatementProcessorBatchException Block "+ sbe.getMessage());
			StatementProcessorBatchUtil.getprintStackTraceString(sbe);
		}
	}
	public static SDLoggerImpl getLogger() {
		return logger;
	}

	public static void setLogger(SDLoggerImpl logger) {
		UpdateCustomerInfoBusinessImplTest.logger = logger;
	}
	
}
