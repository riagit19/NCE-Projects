package com.shopdirect.nce.sp.workmanager;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.CustomerAccountInfo;
import com.shopdirect.nce.sp.model.CustomerAccountInfoBuilder;
import com.shopdirect.nce.sp.model.PseudoChargeResponseType;

public class AccountReassessmentExecutorTest {

	AccountReassessmentExecutor executor;

	@Before
	public void setUp() {
		String CURRENT_WORKING_PATH = 
				(System.getProperty("user.dir") + "\\src\\main\\extcnf\\").replaceAll("\\\\",	"/");
		String SD_ENV_NAME = "DEV";
		System.setProperty("SERVER_CONFIG_ROOT", CURRENT_WORKING_PATH);
		System.setProperty("SDEnvName", SD_ENV_NAME);
		Map<String, PseudoChargeResponseType> pseudoMap = new HashMap<>();

		CustomerAccountInfo accountInfo = CustomerAccountInfoBuilder.populateCustomerAccountInfo();
		try {
			executor = new AccountReassessmentExecutor(accountInfo, pseudoMap);
		} catch (StatementProcessorBatchException e) {
			fail();
		}
	}

	@Test
	public void testCall() {
		try {
			executor.call();
		} catch (Exception e) {
			assertNotNull(executor);
		}
	}
	
	@Test
	public void testCallException() {
		executor.setLinkedAccountPseudoRspMap(new HashMap<>());
		try {
			executor.call();
		} catch (Exception e) {
			assertNotNull(executor);
		}
	}


}
