package com.shopdirect.nce.sp.model;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.model.CustomerAccountInfo;

/**
 * @author GouravChakraborty Populates dummy data in CustomerAccountInfo type
 *         object
 */
public class CustomerAccountInfoBuilder {

	private String accountInfoId;
	private String publicAccountId;
	private String creditAccountId;
	private String retailAccountId;
	private Integer linkedAccntIndex;
	private Date statementDate;
	private Date pmtDueDate;
	private Date pendingPdd;
	private String stmtOffsetDaysFrmPdd;
	private String brandCode;
	private String brandType;
	private String specialAttCode;
	private String lateArrearsInd;
	private Double cedtRiskFactor;
	private String title;
	private String surname;
	private String initials;
	private String forename;
	private String gender;
	private String email;
	private String nationalDialCode;
	private String mobileNumber;
	private String addressLine1;
	private String addressLine2;
	private String addressLine3;
	private String addressLine4;
	private String postCode;
	private String deliveryPtSuffix;
	private String countryName;
	private String accountStatus;
	private String prevAccountStatus;
	private String creditStatus;
	private String deliverNxtStatToOfc;
	private String onlineStmtInd;
	private String doNotPrintStmt;
	private String status;
	private Date createdTimestmp;
	private Date modifiedTimestmp;
	private Date dOB;
	private Date dateAccntStatChng;
	private String customerId;
	private static SDLoggerImpl logger = new SDLoggerImpl();

	public CustomerAccountInfoBuilder withAccountInfoId(String accountInfoId) {
		this.accountInfoId = accountInfoId;
		return this;
	}

	public CustomerAccountInfoBuilder withPublicAccountId(String publicAccountId) {
		this.publicAccountId = publicAccountId;
		return this;
	}

	public CustomerAccountInfoBuilder withCreditAccountId(String creditAccountId) {
		this.creditAccountId = creditAccountId;
		return this;
	}

	public CustomerAccountInfoBuilder withRetailAccountId(String retailAccountId) {
		this.retailAccountId = retailAccountId;
		return this;
	}

	public CustomerAccountInfoBuilder withLinkedAccntIndex(Integer linkedAccntIndex) {
		this.linkedAccntIndex = linkedAccntIndex;
		return this;
	}

	public CustomerAccountInfoBuilder withStatementDate(Date stmtDate) {
		statementDate = stmtDate;
		return this;
	}

	public CustomerAccountInfoBuilder withPmtDueDate(Date pmtDueDate) {
		this.pmtDueDate = pmtDueDate;
		return this;
	}

	public CustomerAccountInfoBuilder withPendingPdd(Date pendingPdd) {
		this.pendingPdd = pendingPdd;
		return this;
	}

	public CustomerAccountInfoBuilder withStmtOffsetDaysFrmPdd(String stmtOffsetDaysFrmPdd) {
		this.stmtOffsetDaysFrmPdd = stmtOffsetDaysFrmPdd;
		return this;
	}

	public CustomerAccountInfoBuilder withBrandCode(String brandCode) {
		this.brandCode = brandCode;
		return this;
	}

	public CustomerAccountInfoBuilder withBrandType(String brandType) {
		this.brandType = brandType;
		return this;
	}

	public CustomerAccountInfoBuilder withSpecialAttCode(String specialAttCode) {
		this.specialAttCode = specialAttCode;
		return this;
	}

	public CustomerAccountInfoBuilder withLateArrearsInd(String lateArrearsInd) {
		this.lateArrearsInd = lateArrearsInd;
		return this;
	}

	public CustomerAccountInfoBuilder withCedtRiskFactor(Double cedtRiskFactor) {
		this.cedtRiskFactor = cedtRiskFactor;
		return this;
	}

	public CustomerAccountInfoBuilder withTitle(String title) {
		this.title = title;
		return this;
	}

	public CustomerAccountInfoBuilder withSurname(String surname) {
		this.surname = surname;
		return this;
	}

	public CustomerAccountInfoBuilder withInitials(String initials) {
		this.initials = initials;
		return this;
	}

	public CustomerAccountInfoBuilder withForename(String forename) {
		this.forename = forename;
		return this;
	}

	public CustomerAccountInfoBuilder withGender(String gender) {
		this.gender = gender;
		return this;
	}

	public CustomerAccountInfoBuilder withEmail(String email) {
		this.email = email;
		return this;
	}

	public CustomerAccountInfoBuilder withNationalDialCode(String nationalDialCode) {
		this.nationalDialCode = nationalDialCode;
		return this;
	}

	public CustomerAccountInfoBuilder withMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
		return this;
	}

	public CustomerAccountInfoBuilder withAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
		return this;
	}

	public CustomerAccountInfoBuilder withAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
		return this;
	}

	public CustomerAccountInfoBuilder withAddressLine3(String addressLine3) {
		this.addressLine3 = addressLine3;
		return this;
	}

	public CustomerAccountInfoBuilder withAddressLine4(String addressLine4) {
		this.addressLine4 = addressLine4;
		return this;
	}

	public CustomerAccountInfoBuilder withPostCode(String postCode) {
		this.postCode = postCode;
		return this;
	}

	public CustomerAccountInfoBuilder withDeliveryPtSuffix(String deliveryPtSuffix) {
		this.deliveryPtSuffix = deliveryPtSuffix;
		return this;
	}

	public CustomerAccountInfoBuilder withCountryName(String countryName) {
		this.countryName = countryName;
		return this;
	}

	public CustomerAccountInfoBuilder withAccountStatus(String accountStatus) {
		this.accountStatus = accountStatus;
		return this;
	}

	public CustomerAccountInfoBuilder withPrevAccountStatus(String prevAccountStatus) {
		this.prevAccountStatus = prevAccountStatus;
		return this;
	}

	public CustomerAccountInfoBuilder withCreditStatus(String creditStatus) {
		this.creditStatus = creditStatus;
		return this;
	}

	public CustomerAccountInfoBuilder withDeliverNxtStatToOfc(String deliverNxtStatToOfc) {
		this.deliverNxtStatToOfc = deliverNxtStatToOfc;
		return this;
	}

	public CustomerAccountInfoBuilder withOnlineStmtInd(String onlineStmtInd) {
		this.onlineStmtInd = onlineStmtInd;
		return this;
	}

	public CustomerAccountInfoBuilder withDoNotPrintStmt(String doNotPrintStmt) {
		this.doNotPrintStmt = doNotPrintStmt;
		return this;
	}

	public CustomerAccountInfoBuilder withStatus(String status) {
		this.status = status;
		return this;
	}

	public CustomerAccountInfoBuilder withCreatedTimestmp(Date createdTimestmp) {
		this.createdTimestmp = createdTimestmp;
		return this;
	}

	public CustomerAccountInfoBuilder withModifiedTimestmp(Date modifiedTimestmp) {
		this.modifiedTimestmp = modifiedTimestmp;
		return this;
	}

	public CustomerAccountInfoBuilder withDOB(Date dOB) {
		this.dOB = dOB;
		return this;
	}

	public CustomerAccountInfoBuilder withDateAccntStatChng(Date dateAccntStatChng) {
		this.dateAccntStatChng = dateAccntStatChng;
		return this;
	}

	public CustomerAccountInfoBuilder withCustomerId(String customerId) {
		this.customerId = customerId;
		return this;
	}

	public Date parseDate() {
		SimpleDateFormat simpaleDateFomrat = new SimpleDateFormat("dd-MMM-yyyy");
		String dateString = "30-APR-2017";
		try {
			statementDate = simpaleDateFomrat.parse(dateString);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
		return statementDate;
	}

	public CustomerAccountInfo build() {
		return new CustomerAccountInfo(accountInfoId, publicAccountId, creditAccountId, retailAccountId,
				linkedAccntIndex, statementDate, pmtDueDate, pendingPdd, stmtOffsetDaysFrmPdd, brandCode, brandType,
				specialAttCode, lateArrearsInd, cedtRiskFactor, title, surname, initials, forename, gender, email,
				nationalDialCode, mobileNumber, addressLine1, addressLine2, addressLine3, addressLine4, postCode,
				deliveryPtSuffix, countryName, accountStatus, prevAccountStatus, creditStatus, deliverNxtStatToOfc,
				onlineStmtInd, doNotPrintStmt, status, createdTimestmp, modifiedTimestmp, dOB, dateAccntStatChng,
				customerId);
	}

	public static CustomerAccountInfo populateCustomerAccountInfo() {
		CustomerAccountInfo CustomerAccountInfo = new CustomerAccountInfoBuilder().withAccountInfoId("111")
				.withPublicAccountId("A908077").withCreditAccountId("111").withRetailAccountId("111")
				.withLinkedAccntIndex(1).withStatementDate(new Date("25-APR-17")).withPmtDueDate(new Date())
				.withPendingPdd(new Date(2011 - 11 - 11)).withStmtOffsetDaysFrmPdd("111").withBrandCode("111")
				.withBrandType("111").withSpecialAttCode("111").withLateArrearsInd("111").withCedtRiskFactor(2.0)
				.withTitle("111").withSurname("111").withInitials("111").withForename("111").withGender("111")
				.withEmail("111").withNationalDialCode("111").withMobileNumber("111").withAddressLine1("111")
				.withAddressLine2("111").withAddressLine3("111").withAddressLine4("111").withPostCode("111")
				.withDeliveryPtSuffix("111").withCountryName("111").withAccountStatus("2").withPrevAccountStatus("111")
				.withCreditStatus("111").withDeliverNxtStatToOfc("111").withOnlineStmtInd("111")
				.withDoNotPrintStmt("111").withStatus("111").withCreatedTimestmp(new Date(2011 - 11 - 11))
				.withModifiedTimestmp(new Date(2011 - 11 - 11)).withDOB(new Date(2011 - 11 - 11))
				.withDateAccntStatChng(new Date(2011 - 11 - 11)).withCustomerId("12345678987").build();
		return CustomerAccountInfo;
	}

}
