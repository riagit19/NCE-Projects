package com.shopdirect.nce.sp.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;

public class ArrearsStatusDaoImplTest {

	@Mock
	ArrearsStatusDaoImpl arrearsStatusDaoImpl;

	@Before
	public void setUp() throws Exception {
		String CURRENT_WORKING_PATH = (System.getProperty("user.dir") + "\\src\\main\\extcnf\\").replaceAll("\\\\", "/");
		String SD_ENV_NAME = "DEV";
		System.setProperty("SERVER_CONFIG_ROOT", CURRENT_WORKING_PATH);
		System.setProperty("SDEnvName", SD_ENV_NAME);
		arrearsStatusDaoImpl = Mockito.mock(ArrearsStatusDaoImpl.class);
	}

	@Test
	public void getArrearsStatusTest() throws Exception {
		String publicAccNum = "AB999787";
		Date statementDate = new Date();
		Map<String, String> resultMap = new HashMap<>();
		Mockito.when(arrearsStatusDaoImpl.getArrearsStatus(Mockito.isA(String.class), Mockito.isA(Date.class))).thenReturn(resultMap);
		arrearsStatusDaoImpl.getArrearsStatus(publicAccNum, statementDate);
	}
}
