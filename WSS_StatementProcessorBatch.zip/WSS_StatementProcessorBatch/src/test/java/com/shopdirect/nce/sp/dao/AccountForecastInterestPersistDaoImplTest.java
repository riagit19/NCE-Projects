package com.shopdirect.nce.sp.dao;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;

import com.shopdirect.fcm.xsd.forecastmodeller.BNPLDefIntByMonth;
import com.shopdirect.fcm.xsd.forecastmodeller.CustomerAccountInterestRespType;
import com.shopdirect.fcm.xsd.forecastmodeller.DailyRateType;
import com.shopdirect.fcm.xsd.forecastmodeller.EstIntWithDDTType;
import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.AccountReassessmentInfoModel;
import com.shopdirect.nce.sp.util.StatementProcessorBatchUtil;

import junit.framework.Assert;
import junit.framework.TestCase;

public class AccountForecastInterestPersistDaoImplTest extends TestCase {

	private static SDLoggerImpl logger = new SDLoggerImpl();
	AccountForcastInterestPersistDaoImpl dao = null;
	CustomerAccountInterestRespType fcmResponse;

	@Before
	public void setUp() throws StatementProcessorBatchException {
		String CURRENT_WORKING_PATH = (System.getProperty("user.dir") + "/src/main/extcnf/");
		String SD_ENV_NAME = "DEV";
		System.setProperty("SERVER_CONFIG_ROOT", CURRENT_WORKING_PATH);
		System.setProperty("SDEnvName", SD_ENV_NAME);

		dao= new AccountForcastInterestPersistDaoImpl();
		fcmResponse = new CustomerAccountInterestRespType();
	}

	/**
	 * Test method for
	 * {@link com.shopdirect.nce.sp.jms.QueueSend#sendAsyncMessage()}.
	 * 
	 * @throws Exception
	 */
	@Test
	public void testPersistForcastInterest(){
		try {
			String status = "";
			/*{"error":null,"estimatedInterest":0.00,"estIntByDDT":
			 * [{"drawdownTermId":"1001.5","estimatedInterest":0.00,"dailyRates":[],
			 * "bnpldefIntOneMonthLeft":0.0,"bnpldefIntTwoMonthsLeft":0.0,"bnpldefIntByMonths":[],
			 * "bnpldefInterest":0.0,"bnpldefCumulativeInterest":0.0}],"bnpldefIntOneMonthLeft":0.0,"bnpldefIntTwoMonthsLeft":0.0}*/
			fcmResponse.setEstimatedInterest(new BigDecimal(0));
			EstIntWithDDTType estIntByDDT = new EstIntWithDDTType();
			estIntByDDT.setDrawdownTermId("1001.5");
			estIntByDDT.setEstimatedInterest(new BigDecimal(0));
			estIntByDDT.setBNPLDefIntOneMonthLeft(new BigDecimal(0));
			estIntByDDT.setBNPLDefIntTwoMonthsLeft(new BigDecimal(0));
			estIntByDDT.setBNPLDefCumulativeInterest(new BigDecimal(0));
			estIntByDDT.setBNPLDefInterest(new BigDecimal(0));
			DailyRateType ddRateType = new DailyRateType();
			ddRateType.setRate(new BigDecimal(0));
			ddRateType.setStartDate(Calendar.getInstance());
			estIntByDDT.getDailyRates().set(0, ddRateType);
			BNPLDefIntByMonth defIntByMnth = new BNPLDefIntByMonth();
			defIntByMnth.setAmount(new BigDecimal(0));
			defIntByMnth.setStatementDate(Calendar.getInstance());
			estIntByDDT.getBNPLDefIntByMonths().set(0, defIntByMnth);
			fcmResponse.getEstIntByDDT().set(0, estIntByDDT);
			
			status=dao.persistForcastInterest(fcmResponse,"201", new Date());
			Assert.assertEquals("SUCCESS", status);
		} catch (Exception e) {
			getLogger()
			.error("[AccountForecastInterestPersistDaoImplTest -- testPersistForcastInterest] StatementProcessorBatchException Block "
					+ e.getMessage());
			StatementProcessorBatchUtil.getprintStackTraceString(e);
		}
	}

	public static SDLoggerImpl getLogger() {
		return logger;
	}
		
	public static void setLogger(SDLoggerImpl logger) {
		AccountForecastInterestPersistDaoImplTest.logger = logger;
	}
}
