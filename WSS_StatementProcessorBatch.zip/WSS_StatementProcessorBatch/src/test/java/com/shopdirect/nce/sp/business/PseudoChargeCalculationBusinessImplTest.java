/**
 * 
 */
package com.shopdirect.nce.sp.business;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;

import com.shopdirect.fcm.xsd.forecastmodeller.BrandCreditProductType;
import com.shopdirect.fcm.xsd.forecastmodeller.CreditProductType;
import com.shopdirect.fcm.xsd.forecastmodeller.CustomerAccountType;
import com.shopdirect.fcm.xsd.forecastmodeller.DailyRateType;
import com.shopdirect.fcm.xsd.forecastmodeller.DrawdownTermForPseudoCharge;
import com.shopdirect.fcm.xsd.forecastmodeller.DrawdownTermItemType;
import com.shopdirect.fcm.xsd.forecastmodeller.PaymentType;
import com.shopdirect.fcm.xsd.forecastmodeller.PseudoChargeReqByCustomerType;
import com.shopdirect.fcm.xsd.forecastmodeller.PseudoChargeReqType;
import com.shopdirect.fcm.xsd.forecastmodeller.PseudoChargeRespType;
import com.shopdirect.fcm.xsd.forecastmodeller.SPPDRate;
import com.shopdirect.nce.cc.fcm.core.adapter.pseudocharge.PseudoChargeAdapter;
import com.shopdirect.nce.cc.fcm.core.factory.AdapterFactory;
import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.dao.AccountReassessmentPsuedoChargesDao;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.AccountReassessmentPseudoChargeReqType;
import com.shopdirect.nce.sp.model.CustomerAccountInfo;
import com.shopdirect.nce.sp.model.PseudoChargeResponseType;
import com.shopdirect.nce.sp.util.StatementProcessorBatchUtil;
import com.shopdirect.osb.xsd.header.RequestHeaderType;

/**
 * @author VijayaprakashPrathip
 *
 */
public class PseudoChargeCalculationBusinessImplTest {
	
	private static SDLoggerImpl logger = new SDLoggerImpl();
	private AccountReassessmentPsuedoChargesDao arPsuedoChargesDao = null;
	private AccountReassessmentPseudoChargeReqType arPseudoChargeReqType = null;
	private PseudoChargeResponseType arPseudoChargeRespType = null;
	private PseudoChargeCalculationBusinessImpl pseudoChargeCalcBusinessImpl = null;
	private PseudoChargeRespType pseudoChargeRespType = null;
	private PseudoChargeReqType pseudoChargeReqType = null;
	private List<AccountReassessmentPseudoChargeReqType> arPseudoChargeReqTypeList;
	private CustomerAccountType customerAccountType  = null;
	private BrandCreditProductType brandCreditProductType  = null;
	private DailyRateType dailyRateType = null;
	private DrawdownTermForPseudoCharge  drawdownTermType = null;
	private DrawdownTermItemType   drawdownTermItemType  = null;
	private CreditProductType  creditProductType;
	private PaymentType  paymentType  = null;
	private SPPDRate  sppdRateType   = null;
		
	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		String CURRENT_WORKING_PATH = (System.getProperty("user.dir") + "\\src\\main\\extcnf\\").replaceAll("\\\\",	"/");
		String SD_ENV_NAME = "DEV";
		System.setProperty("SERVER_CONFIG_ROOT", CURRENT_WORKING_PATH);
		System.setProperty("SDEnvName", SD_ENV_NAME);
		try {
			arPsuedoChargesDao = new AccountReassessmentPsuedoChargesDao();
			arPseudoChargeReqType = new AccountReassessmentPseudoChargeReqType();
			arPseudoChargeRespType = new PseudoChargeResponseType();
			pseudoChargeCalcBusinessImpl = new PseudoChargeCalculationBusinessImpl();
			arPseudoChargeReqTypeList = new ArrayList();
			customerAccountType = new CustomerAccountType();
			brandCreditProductType = new BrandCreditProductType();
			dailyRateType = new DailyRateType();
			drawdownTermType  = new DrawdownTermForPseudoCharge();
			drawdownTermItemType  = new DrawdownTermItemType();
			paymentType = new PaymentType();
			sppdRateType = new SPPDRate();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Test method for {@link com.shopdirect.nce.sp.business.PseudoChargeCalculationBusinessImpl#process(CustomerAccountInfo customerAccountInfo)}.
	 * @throws Exception 
	 */
	// Commenting Test Case as PseudoCharge not yet implemented
	//@Test
	public void xtestProcess() throws Exception {
		CustomerAccountInfo customerAccountInfo = new CustomerAccountInfo();
	
    	Calendar cal = Calendar.getInstance();
    	cal.add(Calendar.DATE , 0);    	
		customerAccountInfo.setAccountInfoId("341");
		customerAccountInfo.setStatementDate(cal.getTime());
		customerAccountInfo.setAccountStatus("0");
		customerAccountInfo.setCreditAccountId("166");
		customerAccountInfo.setBrandCode("LAI");
		customerAccountInfo.setLinkedAccntIndex(22);
	
		arPseudoChargeRespType = pseudoChargeCalcBusinessImpl.process(customerAccountInfo);
		boolean result = false; 
        Assert.assertNotNull(result);
	}
	
	
	/**
	 * Test method for {@link com.shopdirect.nce.sp.business.PseudoChargeCalculationBusinessImpl#CalculatePseudoCharges(
	 * CustomerAccountInfo customerAccountInfo)}.
	 * @throws Exception
	 */
	/*@Test
	public void testCalculatePseudoCharges() throws Exception {
		CustomerAccountInfo customerAccountInfo = new CustomerAccountInfo();
	
		Calendar cal = Calendar.getInstance();
    	cal.add(Calendar.DATE , 0);  
		customerAccountInfo.setCreditAccountId("166");
		customerAccountInfo.setBrandCode("LAI");
		customerAccountInfo.setLinkedAccntIndex(new Double("22.12"));
		
		customerAccountType.setBrandType("LWI");
		customerAccountType.setPaymentDayOfMonth(12);
		customerAccountType.setPaymentPeriod(12);
		customerAccountType.setStopFees(false);
		customerAccountType.setStopInterest(false);
		customerAccountType.setStopDefaultFees(false);
		customerAccountType.setMinPayThreshold(new BigDecimal("1234"));
		customerAccountType.setMinPayPercentageThreshold(new BigDecimal("567"));
		customerAccountType.setCurrentArrearsAmount(new BigDecimal("899"));
		customerAccountType.setCurrentBalance(new BigDecimal("234"));
		customerAccountType.setCurrentOTB(new BigDecimal("12345"));
		//uniqueID = UUID.randomUUID().toString();
    	brandCreditProductType.setID(UUID.randomUUID().toString());
    	//brandCreditProductType.setType(creditProductType.DIRECT_BNPL_PLAN.valueOf("SDG_SP_PSEUDO_JUNIT"));
    	brandCreditProductType.setChargeDate(cal.getInstance());
    	brandCreditProductType.setTermInDays(12);
    	brandCreditProductType.setDefferedTermInDays(12);
    	brandCreditProductType.setTermInMonths(12);
    	brandCreditProductType.setDeferredTermInMonthsdeferredTermInMonths(12);
    	
    	dailyRateType.setRate(new BigDecimal("12.12"));
    	dailyRateType.setStartDate(cal.getInstance());
    	dailyRateType.setEndDate(cal.getInstance());
    	
    	drawdownTermItemType.setCashPrice(new BigDecimal(12.12));
    	
    	drawdownTermType.setCurrentBalance(new BigDecimal(123.12));
    	drawdownTermType.setCashPrice(new BigDecimal(212.31));
    	
    	paymentType.setAmount(new BigDecimal("1234.11"));
    	paymentType.setDate(cal.getInstance());
    	
		arPseudoChargeReqType.setCustomerAccountType(customerAccountType);
		arPseudoChargeReqType.setBrandCreditProductType(brandCreditProductType);
		arPseudoChargeReqType.setDailyRateType(dailyRateType);
		arPseudoChargeReqType.setDrawdownTermType(drawdownTermType);
		arPseudoChargeReqType.setDrawdownTermItemType(drawdownTermItemType);
		arPseudoChargeReqType.setCreditProductType(creditProductType);
		arPseudoChargeReqType.setPaymentType(paymentType);
		arPseudoChargeReqType.setSppdRateType(sppdRateType);
		
		arPseudoChargeReqTypeList = arPsuedoChargesDao.getCalculatePseudoCharges(customerAccountInfo.getCreditAccountId());
		arPseudoChargeReqTypeList.add(arPseudoChargeReqType);
		
		pseudoChargeRespType = pseudoChargeCalcBusinessImpl.calculatePseudoCharges(customerAccountInfo);
		
        Assert.assertNotNull(pseudoChargeRespType);
	}*/
	
	/**
	 * Test method for {@link com.shopdirect.nce.sp.business.PseudoChargeCalculationBusinessImpl#getPseudoCharge(RequestHeaderType requestHeaderType,
	 *  PseudoChargeReqType pseudoChargeReqType)}.
	 * @throws Exception 
	 */
	//@Test
	public void testGetPseudoCharge() throws Exception {
		
		PseudoChargeReqType pseudoChargeReqType = new PseudoChargeReqType();
		PseudoChargeRespType pseudoChargeRespType = new PseudoChargeRespType();
		RequestHeaderType requestHeaderType = new RequestHeaderType();
		CustomerAccountType customerAccountType = new CustomerAccountType();
		PseudoChargeReqByCustomerType pseudoChargeReqByCustomerType = new PseudoChargeReqByCustomerType();
		pseudoChargeReqByCustomerType.setCustomerAccount(customerAccountType);
		pseudoChargeReqType.getPseudoChargeReqByCustomer().add(pseudoChargeReqByCustomerType);
		
		//customerAccountType.setBrandType("LW");
		//customerAccountType.setCurrentOTB(new BigDecimal("7.0"));
		customerAccountType.setCurrentArrearsAmount(new BigDecimal("9.0"));
		customerAccountType.setPaymentDayOfMonth(12);
		customerAccountType.setPaymentPeriod(16);
		customerAccountType.setMinPayThreshold(new BigDecimal("11.0"));
		customerAccountType.setMinPayPercentageThreshold(new BigDecimal("129.0"));
		
		arPseudoChargeReqType.setCustomerAccountType(customerAccountType);
		
		requestHeaderType.setAuditLevel("Initial");
		requestHeaderType.setTransactionId("ax23dscv14ynbb876");
		requestHeaderType.setCallingApplicationName("PseudoChargeCalustiaonApp");
		requestHeaderType.setVersion("1.0");
		
		pseudoChargeCalcBusinessImpl.getPseudoCharge(requestHeaderType, pseudoChargeReqType);
		PseudoChargeAdapter pseudoChargeadapter = AdapterFactory.getAdapter(pseudoChargeReqType);
		try{
			pseudoChargeRespType =  pseudoChargeadapter.invoke(pseudoChargeReqType);
		}catch(StatementProcessorBatchException e){
			getLogger().error("[PseudoChargeCalculationBusinessImplTest -- testGetPseudoCharge] StatementProcessorBatchException Block "+ e.getMessage());
			StatementProcessorBatchUtil.getprintStackTraceString(e);
		}
		
		
	}
	
	
	public static SDLoggerImpl getLogger() {
		return logger;
	}
	public static void setLogger(SDLoggerImpl logger) {
		PseudoChargeCalculationBusinessImplTest.logger = logger;
	}
}
