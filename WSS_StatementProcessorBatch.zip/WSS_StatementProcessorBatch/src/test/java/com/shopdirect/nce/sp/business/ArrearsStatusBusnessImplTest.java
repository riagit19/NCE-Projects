package com.shopdirect.nce.sp.business;

import java.util.Date;

import org.junit.Before;
import org.junit.Test;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.CustomerAccountInfo;
import com.shopdirect.nce.sp.util.StatementProcessorBatchUtil;

public class ArrearsStatusBusnessImplTest {

	private static SDLoggerImpl logger = new SDLoggerImpl();
	
	@Before
	public void setUp() throws Exception{
		String CURRENT_WORKING_PATH = (System.getProperty("user.dir") + "\\src\\main\\extcnf\\").replaceAll("\\\\",
				"/");
		String SD_ENV_NAME = "DEV";
		System.setProperty("SERVER_CONFIG_ROOT", CURRENT_WORKING_PATH);
		System.setProperty("SDEnvName", SD_ENV_NAME);
	}
	
	@Test
	public void testProcess(){
		CustomerAccountInfo customerAccountInfo = new CustomerAccountInfo();
		customerAccountInfo.setPublicAccountId("AB999787");
		customerAccountInfo.setStatementDate(new Date("14-OCT-17"));
		try{
			ArrearsStatusBusinessImpl businessImpl =  new ArrearsStatusBusinessImpl();
			businessImpl.process(customerAccountInfo);
		}
		catch (StatementProcessorBatchException sbe) {
			getLogger().error("[ArrearsStatusBusnessImplTest -- testProcess] StatementProcessorBatchException Block "+ sbe.getMessage());
			StatementProcessorBatchUtil.getprintStackTraceString(sbe);
		}
	}
	
	public static SDLoggerImpl getLogger() {
		return logger;
	}

}
