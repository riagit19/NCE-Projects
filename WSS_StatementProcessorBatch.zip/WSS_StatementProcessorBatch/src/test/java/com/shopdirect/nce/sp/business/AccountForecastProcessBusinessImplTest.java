package com.shopdirect.nce.sp.business;


import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.shopdirect.fcm.xsd.forecastmodeller.BRAND_CODE;
import com.shopdirect.fcm.xsd.forecastmodeller.BRAND_CREDIT_PRODUCT_CODE;
import com.shopdirect.fcm.xsd.forecastmodeller.BrandCreditProductType;
import com.shopdirect.fcm.xsd.forecastmodeller.CurrentDDTWithTransactionsAndIncomesType;
import com.shopdirect.fcm.xsd.forecastmodeller.CustomerAccountInterestReqType;
import com.shopdirect.fcm.xsd.forecastmodeller.CustomerAccountType;
import com.shopdirect.nce.common.extcnfg.ExternalFileDataConfiguration;
import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.dao.AccountForecastInterestRetreivalDao;
import com.shopdirect.nce.sp.dao.StatementProcessorARDao;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.AccountReassessmentInfoModel;
import com.shopdirect.nce.sp.util.CommonConfigHelper;
import com.shopdirect.nce.sp.util.StatementProcessorBatchUtil;

import junit.framework.TestCase;

public class AccountForecastProcessBusinessImplTest extends TestCase {
	
	private static SDLoggerImpl logger = new SDLoggerImpl();
	AccountForcastProcessBusinessImpl impl;
	AccountReassessmentInfoModel model;
	List<AccountReassessmentInfoModel> modelList=new ArrayList<AccountReassessmentInfoModel>();
	AccountForecastInterestRetreivalDao accountForecastRetrievalDao;
	StatementProcessorARDao statementProcessorARDao;
	CustomerAccountInterestReqType request;

	@Before
	public void setUp() throws StatementProcessorBatchException {
		String CURRENT_WORKING_PATH = (System.getProperty("user.dir") + "/src/main/extcnf/");
		String SD_ENV_NAME = "DEV";
		System.setProperty("SERVER_CONFIG_ROOT", CURRENT_WORKING_PATH);
		System.setProperty("SDEnvName", SD_ENV_NAME);		
		try {
			impl = new AccountForcastProcessBusinessImpl();
		} catch (Exception e) {
			e.getMessage();
		}
		
		request = new CustomerAccountInterestReqType();
	}
	
	@Test
	public void testProcessForcastInterest() throws StatementProcessorBatchException, SQLException{
	
		CommonConfigHelper commonConfigHelper = CommonConfigHelper.getInstance();
		ExternalFileDataConfiguration externalClientConfig = commonConfigHelper.loadPropertyConfig(StatementProcessorBatchConstants.AUDITLOG_CONFIGURATION_FILE_KEY);
		
		try{	
//			impl.processForcastInterest("AB999787,14-OCT-17,100,31-Oct-17,488,CHANGE");
			impl.processForcastInterest("D0000002,25-APR-17,100,31-Oct-17,21826,CHANGE");
		}catch(Exception e){
			getLogger().error("[AccountForecastProcessBusinessImplTest -- testProcessForcastInterest] StatementProcessorBatchException Block "+ e.getMessage());
			StatementProcessorBatchUtil.getprintStackTraceString(e);
		}
	}
	
	@Test
	public void testProcessForcastInterestInvalidData() throws StatementProcessorBatchException, SQLException{
	
		CommonConfigHelper commonConfigHelper = CommonConfigHelper.getInstance();
		ExternalFileDataConfiguration externalClientConfig = commonConfigHelper.loadPropertyConfig(StatementProcessorBatchConstants.AUDITLOG_CONFIGURATION_FILE_KEY);
		
		try{	
			impl.processForcastInterest("00000000,25-APR-17,100,31-Oct-17,00000,CHANGE");
		}catch(Exception e){
			getLogger().error("[AccountForecastProcessBusinessImplTest -- testProcessForcastInterest] StatementProcessorBatchException Block "+ e.getMessage());
			StatementProcessorBatchUtil.getprintStackTraceString(e);
		}
	}
	
	@Test
	public void testMergePreFormatCall() throws Exception{
		CommonConfigHelper commonConfigHelper = CommonConfigHelper.getInstance();
		ExternalFileDataConfiguration externalClientConfig = commonConfigHelper.loadPropertyConfig(StatementProcessorBatchConstants.AUDITLOG_CONFIGURATION_FILE_KEY);
		String custID="D0000002";
		String statementDate="25-APR-17";
		String accountId="21826";
		int statusUpdate=0;
		try{	
			accountForecastRetrievalDao = Mockito.mock(AccountForecastInterestRetreivalDao.class);
			statementProcessorARDao = Mockito.mock(StatementProcessorARDao.class);
			impl.setAccountReassessmentConfirmationDao(accountForecastRetrievalDao);
			impl.setStatementProcessorARDao(statementProcessorARDao);
			Mockito.doNothing().when(accountForecastRetrievalDao).callMargePreformatSP(statementDate, accountId, "dd-MMM-yy");
			Mockito.when(statementProcessorARDao.updateStatusMessage(custID, commonConfigHelper.readConfigData(externalClientConfig, "mergerPreformatSuccess"), accountId)).thenReturn(statusUpdate);
		}catch(Exception e){
			Mockito.when(statementProcessorARDao.updateStatusMessage(custID, commonConfigHelper.readConfigData(externalClientConfig, "mergerPreformatFailure"), accountId)).thenReturn(statusUpdate);
			getLogger().error("[AccountForecastProcessBusinessImplTest -- testMergePreFormatCall] StatementProcessorBatchException Block "+ e.getMessage());
			StatementProcessorBatchUtil.getprintStackTraceString(e);
		}
	}
	
	
	@Test
	public void testCallInvoke() throws Exception{
		CommonConfigHelper commonConfigHelper = CommonConfigHelper.getInstance();
		ExternalFileDataConfiguration externalClientConfig = commonConfigHelper.loadPropertyConfig(StatementProcessorBatchConstants.AUDITLOG_CONFIGURATION_FILE_KEY);
		String custID="D0000002";
		String statementDate="25-APR-17";
		String accountId="21826";
		int statusUpdate=0;
		
		/*{"currentDate":1507919400000,"currentTakeAmount":180.44,"currentMinPayAmount":113.68,
		 * "customer":{"paymentDayOfMonth":1,"paymentPeriod":0,"code":"LWI","nextStatementDate":null,"id":null,"currentTerm":0,"producCategory":null,"insuranceCode":null,
		 * "stopFees":false,"stopInterest":false,"stopDefaultFees":false,"minPayThreshold":null,"minPayPercentageThreshold":null,"currentArrearsLvl":0,
		 * "currentInstallmentsInArrearsQty":0,"currentOutstandingBalance":268.95,"currentArrearsAmount":null,"addOptOutPayment":false,"addFixedPayment":false,
		 * "addFullBalancePayment":false,"addFullBalanceWithOutBNPLPayment":false,"isInsuranceOnHold":false,"outstandingBalanceNet":null,"insuranceProduct":null,
		 * "agreementInsurance":null,"incomes":[],"transactions":[],
		 * "drawdowns":[{"id":"1001.5","cashPrice":268.95,"chargeDate":1481913000000,
		 * "creditProduct":{"id":null,"code":"VYTF","termInMonths":3,"deferredTermInMonths":11,"dailyRates":[]},"items":[],"currentPeriod":0,"transactions":[],
		 * "incomes":[],"currentOutStandingBalance":268.95,"currentMonthPayment":84.65,"currentOptOutamount":null,"currentCapital":null,"currentInterest":null,
		 * "deferredInterest":null,"endDate":null, "creditProductConfiguration":null}],
		 * "defaultFeeMissedPayment":null,"defaultFeeInsuficientPayment":null,"defaultFeeLatePayment":null},"drawdowns":[]}*/
		try{	
			request.setCurrentDate(Calendar.getInstance());
			request.setCurrentMinPayAmount(new BigDecimal(113.68));
			request.setCurrentTakeAmount(new BigDecimal(180.44));
			CustomerAccountType custAcctType = new CustomerAccountType();
			custAcctType.setPaymentDayOfMonth(1);
			custAcctType.setPaymentPeriod(3);
			custAcctType.setCode(BRAND_CODE.LWI);
			custAcctType.setCurrentTerm(1);
			custAcctType.setCurrentOutstandingBalance(new BigDecimal(268.95));
			custAcctType.setCurrentPeriod(3);
			CurrentDDTWithTransactionsAndIncomesType ddt = new CurrentDDTWithTransactionsAndIncomesType();
			ddt.setID("1001.5");
			ddt.setCashPrice(new BigDecimal(268.95));
			ddt.setChargeDate(Calendar.getInstance());
			List<CurrentDDTWithTransactionsAndIncomesType> ddtList = new ArrayList();
			BrandCreditProductType creditProduct = new BrandCreditProductType();
			creditProduct.setCode(BRAND_CREDIT_PRODUCT_CODE.VYTF);
			creditProduct.setTermInMonths(3);
			creditProduct.setDeferredTermInMonths(2);
			ddt.setCreditProduct(creditProduct);
			ddt.setCurrentOutStandingBalance(new BigDecimal(268.95));
			ddt.setCurrentMonthPayment(new BigDecimal(84.65));
			ddtList.add(ddt);
			custAcctType.getDrawdowns().addAll(ddtList);
			
			request.setCustomer(custAcctType);
			
			impl.callInvoke(custID,request, statementDate);
		}catch(Exception e){
			getLogger().error("[AccountForecastProcessBusinessImplTest -- testCallInvoke] StatementProcessorBatchException Block "+ e.getMessage());
			StatementProcessorBatchUtil.getprintStackTraceString(e);
		}
	}
	
	public static SDLoggerImpl getLogger() {
		return logger;
	}
	
	public static void setLogger(SDLoggerImpl logger) {
		AccountForecastProcessBusinessImplTest.logger = logger;
	}


}
