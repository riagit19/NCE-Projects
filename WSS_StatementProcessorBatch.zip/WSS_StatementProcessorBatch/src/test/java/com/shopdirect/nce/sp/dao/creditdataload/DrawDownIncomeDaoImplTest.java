package com.shopdirect.nce.sp.dao.creditdataload;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.exception.BuisnessException;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.DrawdownIncome;

public class DrawDownIncomeDaoImplTest {
	ArrayList<DrawdownIncome> drawdownIncomeList = null;
	Calendar cal = Calendar.getInstance();
	private static SDLoggerImpl logger = new SDLoggerImpl();

	@Before
	public void setUp() throws Exception {
		String CURRENT_WORKING_PATH = (System.getProperty("user.dir") + "\\src\\main\\extcnf\\").replaceAll("\\\\",
				"/");
		String SD_ENV_NAME = "DEV";
		System.setProperty("SERVER_CONFIG_ROOT", CURRENT_WORKING_PATH);
		System.setProperty("SDEnvName", SD_ENV_NAME);
		// cal.add(Calendar.DATE , 0);
		Timestamp ts = new Timestamp(cal.getTimeInMillis());
		drawdownIncomeList = new ArrayList<DrawdownIncome>();
		logger.debug(cal.getTime().toString());
		
		for (int i = 0; i <= 10; i++) {
			
			DrawdownIncome drawdownIncome =  new DrawdownIncome();
			drawdownIncome.setAgrPaymentPeriod((int)6666);
			drawdownIncome.setBatchId(100l);
			drawdownIncome.setCreatedByUser((long)777);
			drawdownIncome.setDrawdownId("687");
			drawdownIncome.setIncomeType("xxx");
			drawdownIncome.setOutstandingAmount((double)876.98);
			drawdownIncome.setOutstandingCapital((double)876.98);
			drawdownIncome.setOutstandingInterest((double)876.98);
			drawdownIncome.setOutstandingCharge((double)876.98);
			
			drawdownIncomeList.add(drawdownIncome);
		}
	}

	@Test
	public void testInsertDrawDownIncomeData() throws StatementProcessorBatchException, BuisnessException {
		
		DrawDownIncomeDaoImpl daoImpl = Mockito.mock(DrawDownIncomeDaoImpl.class);
		String insertMsg = null;
		
		Object[] result = new Object[2];
		result[0] = 0;
		Mockito.when(daoImpl.insertDrawDownIncomeData(Mockito.isA(ArrayList.class))).thenReturn(result);
		
		try {
			Object[] insertFlag = daoImpl.insertDrawDownIncomeData(drawdownIncomeList);
			
			if ((int) insertFlag[0] == 0) {
				insertMsg = StatementProcessorBatchConstants.EMPTY_STRING;
			} else {
				insertMsg = null;
			}
			
			assertNotNull(insertMsg);
			
		} catch (StatementProcessorBatchException spbe) {
			System.out.println("---- Draw Down Income Exception -----" + spbe);
			assertEquals(StatementProcessorBatchConstants.CONNECTTION_DB_ERROR_CODE, spbe.getErrorCode());
		}
		

	
	
	
	}

}
