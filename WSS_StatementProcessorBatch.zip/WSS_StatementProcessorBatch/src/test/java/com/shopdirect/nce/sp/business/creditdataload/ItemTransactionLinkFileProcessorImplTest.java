package com.shopdirect.nce.sp.business.creditdataload;

import static org.junit.Assert.assertNotNull;

import java.io.File;

import org.junit.Before;
import org.junit.Test;

import com.shopdirect.nce.sp.dao.creditdataload.SpCreditFilLoadControlDaoImpl;

public class ItemTransactionLinkFileProcessorImplTest {
	
	private ItemTransactionLinkFileProcessorImpl impl;

	@Before
	public void setUp() throws Exception {
		
		String CURRENT_WORKING_PATH = (System.getProperty("user.dir") + "\\src\\main\\extcnf\\").replaceAll("\\\\",
				"/");
		String SD_ENV_NAME = "DEV";
		System.setProperty("SERVER_CONFIG_ROOT", CURRENT_WORKING_PATH);
		System.setProperty("SDEnvName", SD_ENV_NAME);
	}

	@Test
	public void testProcessFile() {
		
		try {
			
			SpCreditFilLoadControlDaoImpl spCreditFilLoadControlDaoImpl = new SpCreditFilLoadControlDaoImpl();
			long batchID = spCreditFilLoadControlDaoImpl.fetchBatchId();

			impl = new ItemTransactionLinkFileProcessorImpl();
			boolean processFlag = impl.processFile(new File("H:\\config\\finfile"), batchID, 0, "20180105");
			assertNotNull(processFlag);
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

}
