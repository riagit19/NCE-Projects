package com.shopdirect.nce.sp.dao.creditdataload;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.exception.BuisnessException;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.PPIStatement;

public class PPIStatementDaoImplTest {
	ArrayList<PPIStatement> pPIStatementList = null;
	Calendar cal = Calendar.getInstance();
	private static SDLoggerImpl logger = new SDLoggerImpl();

	@Before
	public void setUp() throws Exception {
		String CURRENT_WORKING_PATH = (System.getProperty("user.dir") + "\\src\\main\\extcnf\\").replaceAll("\\\\",
				"/");
		String SD_ENV_NAME = "DEV";
		System.setProperty("SERVER_CONFIG_ROOT", CURRENT_WORKING_PATH);
		System.setProperty("SDEnvName", SD_ENV_NAME);
		pPIStatementList = new ArrayList<PPIStatement>();
		Timestamp ts = new Timestamp(cal.getTimeInMillis());
		logger.debug(cal.getTime().toString());
		
		for (int i = 0; i <= 10; i++) {
			PPIStatement pPIStatement = new PPIStatement();
			
			pPIStatement.setAgreementId("1001");
			pPIStatement.setAgreementSeq(Long.valueOf(65347));
			pPIStatement.setAvgMonthlyChrg(Double.valueOf(4553.76));
			pPIStatement.setBatchId(100l);
			pPIStatement.setClosingBalance(Double.valueOf(4553.76));
			pPIStatement.setCostPercentage(Double.valueOf(4553.76));
			pPIStatement.setCreatedByUser(Long.valueOf(555));
			pPIStatement.setCreationDate(ts);
			pPIStatement.setCreditLimit(Double.valueOf(4553.76));
			pPIStatement.setInsuranceProdRefNo("");
			pPIStatement.setOpeningBalance(Double.valueOf(4553.76));
			pPIStatement.setPreviousYearPPIPremium(Double.valueOf(4553.76));
			pPIStatement.setPrevYrPpiBalAmt(Double.valueOf(4553.76));
			pPIStatement.setRenewalDate(ts);
			pPIStatement.setStartDate(ts);
			pPIStatement.setTypeofCover("");

			pPIStatementList.add(pPIStatement);
		}
	}

	@Test
	public void testInsertPpiStatementData() throws BuisnessException, Exception {
		PPIStatementDaoImpl pPIStatementDaoImpl = Mockito.mock(PPIStatementDaoImpl.class);
		String insertMsg = null;
		
		Object[] result = new Object[2];
		result[0] = 0;
		Mockito.when(pPIStatementDaoImpl.insertPpiStatementData(Mockito.isA(ArrayList.class))).thenReturn(result);
		
		try {
		Object[] insertFlag = pPIStatementDaoImpl.insertPpiStatementData(pPIStatementList);
		
		if ((int) insertFlag[0] == 0) {
			insertMsg = StatementProcessorBatchConstants.EMPTY_STRING;
		} else {
			insertMsg = null;
		}
		
		assertNotNull(insertMsg);
		
		
		} catch (StatementProcessorBatchException spbe) {
			assertEquals(StatementProcessorBatchConstants.CONNECTTION_DB_ERROR_CODE, spbe.getErrorCode());
		}
		
	}

}
