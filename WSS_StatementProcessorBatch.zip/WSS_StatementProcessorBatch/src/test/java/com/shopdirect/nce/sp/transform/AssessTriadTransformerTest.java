package com.shopdirect.nce.sp.transform;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

import java.sql.SQLException;
import java.sql.SQLInput;
import java.sql.SQLOutput;
import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.shopdirect.nce.sp.model.Agreement;
import com.shopdirect.nce.sp.model.AssessTriadResponseType;
import com.shopdirect.nce.sp.model.BureauSummaryBlock;
import com.shopdirect.nce.sp.model.CustomerAccountInfo;
import com.shopdirect.nce.sp.model.CustomerAccountInfoBuilder;
import com.shopdirect.nce.sp.model.PseudoChargeResponseType;
import com.shopdirect.nce.sp.model.QueryCreditBlock;
import com.shopdirect.nce.sp.model.RiskNavigatorParams;
//import com.shopdirect.osb.xsd.assesstriad.AssessTRIADRequestType;
//import com.shopdirect.osb.xsd.assesstriad.AssessTRIADResponseType;

/**
 * 
 * @author SudiptaRoy
 *
 */
public class AssessTriadTransformerTest {
	
	private AssessTriadTransformer transformer;

	@Before
	public void setUp() throws Exception {
		String CURRENT_WORKING_PATH = (System.getProperty("user.dir") + "\\src\\main\\extcnf\\").replaceAll("\\\\",
				"/");
		String SD_ENV_NAME = "DEV";
		System.setProperty("SERVER_CONFIG_ROOT", CURRENT_WORKING_PATH);
		System.setProperty("SDEnvName", SD_ENV_NAME);
		
		transformer = new AssessTriadTransformer();
	}

	@Test
	public void testTransformRequest() {
		Agreement agreement = new Agreement();
		agreement.setClosingBalance(100.0d);
		agreement.setNextpaymentDueDate(new Date());
		agreement.setScheduledPaymentAmount(30.5d);
		agreement.setCreditLimit(300.0d);
		CustomerAccountInfo accountInfo = CustomerAccountInfoBuilder.populateCustomerAccountInfo();
		BureauSummaryBlock bureauSummary = new BureauSummaryBlock();
		QueryCreditBlock queryCredit = new QueryCreditBlock();
		Map<String, PseudoChargeResponseType> pseudoMap = new HashMap<>();
		RiskNavigatorParams riskNavParams = new RiskNavigatorParams();
		riskNavParams.setRiskNavScore(new Double(2));
		/*try {
			AssessTRIADRequestType request = transformer.transformRequest(riskNavParams, queryCredit, bureauSummary,
					accountInfo, agreement, pseudoMap);
			assertNotNull(request);
			assertNotNull(request.getAssessTRIAD());
			assertNotNull(request.getAssessTRIAD().getGetCRDRData());
			assertNotNull(request.getAssessTRIAD().getGetCRDRData().getAccountDetail().getAccountNumber());
		} catch (Exception e) {
			fail();
		}*/

	}

	@Test
	public void testSQLStreamOfModels() {
		SQLInput inputStream = Mockito.mock(SQLInput.class);
		SQLOutput outputStream = Mockito.mock(SQLOutput.class);

		BureauSummaryBlock bureauSummaryBlock = new BureauSummaryBlock();
		RiskNavigatorParams riskNavigatorParams = new RiskNavigatorParams();
		QueryCreditBlock queryCreditBlock = new QueryCreditBlock();

		try {
			Mockito.when(inputStream.readString()).thenReturn("1234");
			Mockito.when(inputStream.readDate()).thenReturn(new java.sql.Date(new Date().getTime()));
			Mockito.when(inputStream.readDouble()).thenReturn(3d);

			riskNavigatorParams.readSQL(inputStream, "dataType");
			riskNavigatorParams.writeSQL(outputStream);
			
			queryCreditBlock.readSQL(inputStream, "dataType");
			queryCreditBlock.writeSQL(outputStream);
			
			bureauSummaryBlock.readSQL(inputStream, "dataType");
			bureauSummaryBlock.writeSQL(outputStream);
		} catch (SQLException sqle) {
			fail();
		}
	}

	

	@Test
	public void testTransformResponse() {/*
		AssessTRIADResponseType response = new AssessTRIADResponseType();
		AssessTriadResponseType modelResp = transformer.transformRespone(response);
	*/}
	
}
