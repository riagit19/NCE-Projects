package com.shopdirect.nce.sp.dao.creditdataload;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.PeriodPayment;

public class PeriodPaymentDaoImplTest {

	ArrayList<PeriodPayment> periodPaymentList = null;
	Calendar cal = Calendar.getInstance();
	private static SDLoggerImpl logger = new SDLoggerImpl();

	@Before
	public void setUp() throws Exception {
		String CURRENT_WORKING_PATH = (System.getProperty("user.dir") + "\\src\\main\\extcnf\\").replaceAll("\\\\",
				"/");
		String SD_ENV_NAME = "DEV";
		System.setProperty("SERVER_CONFIG_ROOT", CURRENT_WORKING_PATH);
		System.setProperty("SDEnvName", SD_ENV_NAME);
		periodPaymentList = new ArrayList<PeriodPayment>();
		Timestamp ts = new Timestamp(cal.getTimeInMillis());
		logger.debug(cal.getTime().toString());
		
		for (int i = 0; i <= 10; i++) {
			PeriodPayment periodPayment = new PeriodPayment();
			
			periodPayment.setPeriodPaymentId("1");
			periodPayment.setAgreementId("2");
			periodPayment.setAgreementSeq((long)45);
			periodPayment.setDatePaid(ts);
			periodPayment.setPaymentType("credit");
			periodPayment.setPaymentAmount((double)6778);
			periodPayment.setPaymentSourceType("XXX");
		    periodPayment.setMivCode("333");
		    periodPayment.setMivSubCode("HTF");
		    periodPayment.setBatchId(100l);
		    periodPayment.setCreatedByUser((long)555);
			
			periodPaymentList.add(periodPayment);
		}
	}

	@Test
	public void testInsertPeriodPaymentData() throws Exception {
		PeriodPaymentDaoImpl ppDaoImpl = Mockito.mock(PeriodPaymentDaoImpl.class);
		String insertMsg = null;
		
		Object[] result = new Object[2];
		result[0] = 0;
		Mockito.when(ppDaoImpl.insertPeriodPaymentData(Mockito.isA(ArrayList.class))).thenReturn(result);
		
		try {
			Object[] insertFlag = ppDaoImpl.insertPeriodPaymentData(periodPaymentList);
			
			if ((int) insertFlag[0] == 0) {
				insertMsg = StatementProcessorBatchConstants.EMPTY_STRING;
			} else {
				insertMsg = null;
			}
			assertNotNull(insertMsg);
		
		} catch (StatementProcessorBatchException spbe) {
			assertEquals(StatementProcessorBatchConstants.CONNECTTION_DB_ERROR_CODE, spbe.getErrorCode());
		}
	}

}
