package com.shopdirect.nce.sp.util;

import org.junit.Before;
import org.junit.Test;
import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.AccountReassessmentInfoModel;

import junit.framework.TestCase;

public class ConvertToJsonUtilTest extends TestCase {
	
	private static SDLoggerImpl logger = new SDLoggerImpl();
	AccountReassessmentInfoModel model;
	
	@Before
	public void setUp() throws StatementProcessorBatchException {
		String CURRENT_WORKING_PATH = (System.getProperty("user.dir") + "\\src\\main\\extcnf\\").replaceAll("\\\\",	"/");
		String SD_ENV_NAME = "DEV";
		System.setProperty("SERVER_CONFIG_ROOT", CURRENT_WORKING_PATH);
		System.setProperty("SDEnvName", SD_ENV_NAME);		
		
		model= new AccountReassessmentInfoModel("A8989426","1000","2015-03-01","2015-03-30","25","12","1","01","BNPL","19","1","Year");
		
	}
	
	@Test
	public void testConvertToJson() throws StatementProcessorBatchException{
		
		try{
			ConvertToJsonUtil.convertToJson(model);

		}catch(Exception e){
			logger.error(e.getMessage());
			throw new StatementProcessorBatchException(StatementProcessorBatchConstants.GENERIC_BUSINESS_ERROR_CODE,
					"[ConvertToJson-convertToJson] Exception Block",
					"Business exception generated at time to process the data collection "+ e.getMessage(),
					null, null,e);
		}
		
	}

}
