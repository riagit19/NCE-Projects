package com.shopdirect.nce.sp.workmanager;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

import org.junit.Before;
import org.junit.Test;

import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.CustomerAccountInfo;
import com.shopdirect.nce.sp.model.CustomerAccountInfoBuilder;
import com.shopdirect.nce.sp.model.PseudoChargeResponseType;

/**
 * 
 * @author SudiptaRoy
 *
 */
public class PseudoChargeExecutorTest {

	private PseudoChargeExecutor executor;

	@Before
	public void setUp() throws Exception {
		String CURRENT_WORKING_PATH = (System.getProperty("user.dir") + "\\src\\main\\extcnf\\").replaceAll("\\\\",
				"/");
		String SD_ENV_NAME = "DEV";
		System.setProperty("SERVER_CONFIG_ROOT", CURRENT_WORKING_PATH);
		System.setProperty("SDEnvName", SD_ENV_NAME);

		CustomerAccountInfo custAccountInfo = CustomerAccountInfoBuilder.populateCustomerAccountInfo();
		try {
			executor = new PseudoChargeExecutor(custAccountInfo);
		} catch (StatementProcessorBatchException e) {
			fail();
		}
	}

	@Test
	public void testCall() {
		CustomerAccountInfo accountInfo = executor.getCustomerAccountInfo();
		accountInfo.setLinkedAccntIndex(0);
		executor.setCustomerAccountInfo(accountInfo);
		try {
			executor.call();
		} catch (Exception e) {
			assertNotNull(executor);
		}
	}

	@Test
	public void testCallForLinkedAccount() {
		executor.getCustomerAccountInfo().setLinkedAccntIndex(1);
		executor.setPseudoChargeResponse(new PseudoChargeResponseType());
		try {
			assertNotNull(executor.getPseudoChargeResponse());
			executor.call();
		} catch (Exception e) {
			assertNotNull(executor);
		}
	}

}
