package com.shopdirect.nce.sp.business;

import static org.junit.Assert.*;

import java.sql.SQLException;
import java.util.Calendar;
import java.util.Date;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.shopdirect.nce.logger.log4j2.SDLoggerImpl;
import com.shopdirect.nce.sp.constants.StatementProcessorBatchConstants;
import com.shopdirect.nce.sp.dao.AccountDormancyCheckDao;
import com.shopdirect.nce.sp.exception.StatementProcessorBatchException;
import com.shopdirect.nce.sp.model.CustomerAccountInfo;
import com.shopdirect.nce.sp.util.SPDormancyCheckHelper;

public class SPDormancyCheckBusinessImplTest {
	
	private static SDLoggerImpl logger = new SDLoggerImpl();
	CustomerAccountInfo customerAccountInfo = new CustomerAccountInfo();
	Calendar cal = Calendar.getInstance();

	@Before
	public void setUp() throws Exception {
		String CURRENT_WORKING_PATH = (System.getProperty("user.dir") + "\\src\\main\\extcnf\\").replaceAll("\\\\",	"/");
		String SD_ENV_NAME = "DEV";
		System.setProperty("SERVER_CONFIG_ROOT", CURRENT_WORKING_PATH);
		System.setProperty("SDEnvName", SD_ENV_NAME);    	
    	cal.add(Calendar.DATE , 0);
    	
		customerAccountInfo.setAccountInfoId("26286");
		customerAccountInfo.setStatementDate(cal.getTime());
		customerAccountInfo.setAccountStatus("0");
		customerAccountInfo.setCreditAccountId("U5088336_11");
		customerAccountInfo.setBrandCode("LAI");
	}


	@Test
	public void testSPDormancyCheckBusinessImpl() throws StatementProcessorBatchException, SQLException {
			SPDormancyCheckHelper dormancyCheckHelper = new SPDormancyCheckHelper(); 

	}

	
	@Test
	public void testProcessForNonZeroStatus() throws StatementProcessorBatchException, SQLException {
		
		SPDormancyCheckBusinessImpl dc = new SPDormancyCheckBusinessImpl();
    	customerAccountInfo.setAccountStatus("60");
    	customerAccountInfo.setStatementDate(cal.getTime());
    	String updateFlag = "0";
		try {
			updateFlag = dc.process(customerAccountInfo);
			logger.entry("test testProcessForNonZeroStatus^^^^^^^^^^^^^^^^^^^"+updateFlag.toString());
		} catch (StatementProcessorBatchException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Assert.assertFalse(false);
	}	

	@Test
	public void testUpdateStatForNonZerostatusDLW() throws StatementProcessorBatchException, SQLException {
		customerAccountInfo.setStatementDate(cal.getTime());
		String updateFlag = "0";
		SPDormancyCheckBusinessImpl dormancyCheck = new SPDormancyCheckBusinessImpl();
		AccountDormancyCheckDao dormancyCheckDao = new AccountDormancyCheckDao();
		SPDormancyCheckHelper dormancyCheckHelper = new SPDormancyCheckHelper();
		customerAccountInfo.setAccountStatus("72");
		customerAccountInfo.setCreditAccountId("U5088336_11");
		customerAccountInfo.setBrandCode("LAI");
		String creditStatus = "D";
		try {
			int daysBetween = dormancyCheckHelper.calculateTime(customerAccountInfo.getStatementDate(), dormancyCheckDao.getLastTransDt(customerAccountInfo.getCreditAccountId(), customerAccountInfo.getStatementDate()));
			
			updateFlag = dormancyCheck.updateStatForNonZerostatusD(creditStatus, customerAccountInfo.getBrandCode(), daysBetween, customerAccountInfo.getAccountInfoId(), customerAccountInfo.getCreditAccountId(), customerAccountInfo.getPublicAccountId(), new Date(), new Date());
			logger.entry("test testUpdateStatForNonZerostatusDLW^^^^^^^^^^^^^^^^^^^^^^"+updateFlag.toString());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	public void testUpdateStatForNonZerostatusDNonLW() throws StatementProcessorBatchException, SQLException {
		String updateFlag = "0";
		customerAccountInfo.setStatementDate(cal.getTime());
		SPDormancyCheckBusinessImpl dormancyCheck = new SPDormancyCheckBusinessImpl();
		AccountDormancyCheckDao dormancyCheckDao = new AccountDormancyCheckDao();
		SPDormancyCheckHelper dormancyCheckHelper = new SPDormancyCheckHelper();
		customerAccountInfo.setAccountStatus("70");
		customerAccountInfo.setCreditAccountId("U5088336_11");
		customerAccountInfo.setBrandCode("LWX");
		String creditStatus ="D";
		try {
			int daysBetween = dormancyCheckHelper.calculateTime(customerAccountInfo.getStatementDate(), dormancyCheckDao.getLastTransDt(customerAccountInfo.getCreditAccountId(), customerAccountInfo.getStatementDate()));
			
			updateFlag = dormancyCheck.updateStatForNonZerostatusD(creditStatus, customerAccountInfo.getBrandCode(), daysBetween, customerAccountInfo.getAccountInfoId(), customerAccountInfo.getCreditAccountId(), customerAccountInfo.getPublicAccountId(), new Date(), new Date());

			logger.entry("test testUpdateStatForNonZerostatusDNonLW"+updateFlag.toString());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}	

	@Test
	public void testUpdateStatForNonZerostatusOtherLW() throws StatementProcessorBatchException, SQLException {
		String updateFlag = "0";
		customerAccountInfo.setStatementDate(cal.getTime());
		SPDormancyCheckBusinessImpl dormancyCheck = new SPDormancyCheckBusinessImpl();
		AccountDormancyCheckDao dormancyCheckDao = new AccountDormancyCheckDao();
		SPDormancyCheckHelper dormancyCheckHelper = new SPDormancyCheckHelper();
		customerAccountInfo.setAccountStatus("60");
		customerAccountInfo.setCreditAccountId("U5088336_11");
		customerAccountInfo.setBrandCode("LAI");
		String creditStatus = "B";
		try {
			int daysBetween = dormancyCheckHelper.calculateTime(customerAccountInfo.getStatementDate(), dormancyCheckDao.getLastTransDt(customerAccountInfo.getCreditAccountId(), customerAccountInfo.getStatementDate()));
			
			updateFlag = dormancyCheck.updateStatForNonZerostatusOther(creditStatus, customerAccountInfo.getBrandCode(), daysBetween, customerAccountInfo.getAccountInfoId(), customerAccountInfo.getCreditAccountId(), customerAccountInfo.getPublicAccountId(), new Date(), new Date());
			logger.entry("test testUpdateStatForNonZerostatusOtherLW"+updateFlag.toString());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void testUpdateStatForNonZerostatusOtherNonLW() throws StatementProcessorBatchException, SQLException {
		String updateFlag = "0";
		customerAccountInfo.setStatementDate(cal.getTime());
		SPDormancyCheckBusinessImpl dormancyCheck = new SPDormancyCheckBusinessImpl();
		AccountDormancyCheckDao dormancyCheckDao = new AccountDormancyCheckDao();
		SPDormancyCheckHelper dormancyCheckHelper = new SPDormancyCheckHelper();
		customerAccountInfo.setAccountStatus("60");
		customerAccountInfo.setCreditAccountId("U5088336_11");
		customerAccountInfo.setBrandCode("LWX");
		String creditStatus = "B";
		try {
			int daysBetween = dormancyCheckHelper.calculateTime(customerAccountInfo.getStatementDate(), dormancyCheckDao.getLastTransDt(customerAccountInfo.getCreditAccountId(), customerAccountInfo.getStatementDate()));
			
			updateFlag = dormancyCheck.updateStatForNonZerostatusOther(creditStatus, customerAccountInfo.getBrandCode(), daysBetween, customerAccountInfo.getAccountInfoId(), customerAccountInfo.getCreditAccountId(), customerAccountInfo.getPublicAccountId(), new Date(), new Date());
			logger.entry("test testUpdateStatForNonZerostatusOtherNonLW"+updateFlag.toString());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}	

	@Test
	public void testUpdateStatForBalanceZeroLW() throws StatementProcessorBatchException, SQLException {
		String updateFlag = "0";
		customerAccountInfo.setStatementDate(cal.getTime());
		SPDormancyCheckBusinessImpl dormancyCheck = new SPDormancyCheckBusinessImpl();
		customerAccountInfo.setAccountStatus("0");
		customerAccountInfo.setCreditAccountId("U5088336_11");
		customerAccountInfo.setBrandCode("LAI");

			try {
				
			updateFlag = dormancyCheck.updateStatForBalanceZero(customerAccountInfo.getBrandCode(), customerAccountInfo.getAccountInfoId(), customerAccountInfo.getCreditAccountId());
			logger.entry("^^^^^^^^^^^^^^^^^^^^test testUpdateStatForBalanceZeroLW"+updateFlag.toString());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void testUpdateStatForBalanceZeroNonLW() throws StatementProcessorBatchException, SQLException {
		String updateFlag = "0";
		customerAccountInfo.setStatementDate(cal.getTime());
		SPDormancyCheckBusinessImpl dormancyCheck = new SPDormancyCheckBusinessImpl();
		customerAccountInfo.setAccountStatus("0");
		customerAccountInfo.setCreditAccountId("U5088336_11");
		customerAccountInfo.setBrandCode("LWX");

			try {
				
			updateFlag = dormancyCheck.updateStatForBalanceZero(customerAccountInfo.getBrandCode(), customerAccountInfo.getAccountInfoId(), customerAccountInfo.getCreditAccountId());

			logger.entry("^^^^^^^^^^^^^^^^^^^^^^test testUpdateStatForBalanceZeroNonLW"+updateFlag.toString());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}	

	@Test
	public void testUpdateFinal() throws StatementProcessorBatchException, SQLException {
		String updateFlag = "0";
		customerAccountInfo.setStatementDate(cal.getTime());
		SPDormancyCheckBusinessImpl dormancyCheck = new SPDormancyCheckBusinessImpl();
		SPDormancyCheckHelper dormancyCheckHelper = new SPDormancyCheckHelper();

			try {
			Date accntOpened = dormancyCheckHelper.checkAccntOpened(customerAccountInfo.getCreditAccountId());
			Date lastOrderDate = dormancyCheckHelper.getLastOrderDate(customerAccountInfo.getPublicAccountId(), new Date());
			int days = dormancyCheckHelper.calculateTime(accntOpened, lastOrderDate);
			updateFlag = dormancyCheck.updateFinal(days, customerAccountInfo.getAccountInfoId(), customerAccountInfo.getCreditAccountId());
			logger.entry("^^^^^^^^^^^^^^^^^^test testUpdateFinal"+updateFlag.toString());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


}
