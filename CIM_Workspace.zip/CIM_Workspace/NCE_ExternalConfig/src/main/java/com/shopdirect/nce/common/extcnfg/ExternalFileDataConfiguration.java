package com.shopdirect.nce.common.extcnfg;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.configuration.FileConfiguration;
import org.apache.commons.configuration.XMLConfiguration;
import org.apache.commons.configuration.reloading.FileChangedReloadingStrategy;
import org.apache.commons.configuration.tree.ConfigurationNode;
import org.apache.log4j.Logger;

/**
 * @author msomanat@in.ibm.com
 * 
 *         Handles external file (property file, xml file, etc) based
 *         configuration data.
 * 
 *         user can use this class to create the configuration object and fetch
 *         the configuration data. For Example ExternalFileDataConfiguration
 *         fileDataConfiguration=new
 *         ExternalFileDataConfiguration("serviceName",
 *         "configClassName","configFile");
 *         fileDataConfiguration.getConfigData("key");
 *         
 * @author Palash S Roy,         
 *         
 *         Added new method to get a Map data structure from a XML. This map will contain the entire XML structure as a key value pair.
 *         Recursively it will check for next child element and will capture the value.
 *         
 *  Modified date - 19/03/2014
 *         
 */
public class ExternalFileDataConfiguration implements ExternalConfiguration {

	private static Logger logger = Logger.getLogger(ExternalFileDataConfiguration.class);
	private static final String SERVER_CONFIG_ROOT = "SERVER_CONFIG_ROOT";
	private static final String SD_ENV_NAME = "SDEnvName";
	private static final String PROPERTIES_CONFIG_CLASS = "org.apache.commons.configuration.PropertiesConfiguration";
	private static final String MASTER_DATA_CONFIG = "MasterDataConfig.properties";
	private static Map<String, FileConfiguration> masterConfiguration = new HashMap<String, FileConfiguration>();

	private String configRootPath;
	private String reloadflag;
	private String configTypeClassName;
	private String configFileName;
	private String archiveAccessFlag;
	private Object configObject;
	FileConfiguration fileConfiguration;

	
	public ExternalFileDataConfiguration(String serviceName, String configClassTypeKey, String configFilekey)
			throws ExternalConfigurationException {
		if(System.getProperty(SD_ENV_NAME)== null){
			this.configRootPath = loadSystemProperty() + serviceName + "/";	
		}
		else{
			this.configRootPath = loadSystemProperty() + serviceName + "/" + System.getProperty(SD_ENV_NAME) + "/";
		}
		loadMasterConfiguration(serviceName,configRootPath, configClassTypeKey,	configFilekey);
		loadFileConfiguration();
	}

	/**
	 * Loads FileConfiguration object into memory.
	 */
	private void loadFileConfiguration() throws ExternalConfigurationException {
		fileConfiguration = (FileConfiguration) loadExternalFileConfiguration(configTypeClassName, concatenatePath(configRootPath, configFileName));
	}

	/**
	 * Default constructor.
	 */
	@SuppressWarnings("unused")
	private ExternalFileDataConfiguration() {
		super();
		// TODO Auto-generated constructor stub
	}

	/*
	 * 
	 * @see com.td.config.ExternalConfiguration#getConfigData(java.lang.String)
	 * This method helps to get the configuration data.
	 * 
	 * @param propertyName
	 * 
	 * @return Returns configuration data of type String.
	 */
	public String getConfigData(String propertyName) {
		return fileConfiguration.getString(propertyName);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.td.config.ExternalConfiguration#getConfigDataList(java.lang.String)
	 * This method helps to get the List of configuration data.
	 * 
	 * @param propertyName
	 * 
	 * @return Returns configuration data list of type String.
	 */
	@SuppressWarnings("unchecked")
	public List<String> getConfigDataList(String propertyName) {
		return fileConfiguration.getList(propertyName);
	}

	/**
	 * Loads the external file configuration data based on the availability of
	 * the configuration source. Also handle the AUTO refresh mechanism based on
	 * the need.
	 * 
	 * @param className
	 *            : name of the configuration class
	 * @param path
	 *            : Path of the configuration source.
	 * @return configuration object.
	 * @throws Exception
	 */
	private Object loadExternalFileConfiguration(String className, String path) throws ExternalConfigurationException {
		FileConfiguration fileConfiguration = (FileConfiguration) loadExternalConfiguration(className, path);
		if (fileConfiguration != null) {
			if (reloadflag != null && reloadflag.equals("AUTO")){
				fileConfiguration.setReloadingStrategy(new FileChangedReloadingStrategy());
			}	
		} else {
			if (archiveAccessFlag.equals("true")) {
				fileConfiguration = (FileConfiguration) loadExternalConfiguration(className, configRootPath + "/archive" + configFileName);
				if (fileConfiguration != null && reloadflag != null && reloadflag.equals("AUTO")) {
					fileConfiguration.setReloadingStrategy(new FileChangedReloadingStrategy());
				} else if (fileConfiguration == null) {
					throw new ExternalConfigurationException( "ExternalConfigurationException: Configuration Source not found [ " + configRootPath + "/archive"	+ configFileName + " ]");
				}
			} else {
				logger.error("ExternalConfigurationException: Configuration Source not found [ " + configRootPath + configFileName + " ]");
				throw new ExternalConfigurationException("ExternalConfigurationException: Configuration Source not found [ " + configRootPath + configFileName + " ]");
			}
		}
		logger.debug("File configuration data is loaded successfully");
		return fileConfiguration;
	}

	/**
	 * This method concatenate root path with relative path to generate the
	 * source path.
	 * 
	 * @param rootPath
	 * @param relativePath
	 * @return returns concatenated path string.
	 */
	String concatenatePath(String rootPath, String relativePath) {
		return rootPath + relativePath;
	}

	/**
	 * Loads the Master configuration data from property file.
	 * 
	 * @param rootPath
	 *            : Root path of the Master configuration property file.
	 * @param configFileClass
	 *            : Configuration class type to be used to manage the external
	 *            configuration.
	 * @param filePath
	 *            : Configuration file path.
	 */
	private void loadMasterConfiguration(String serviceName,String rootPath, String configFileClass, String filePath) throws ExternalConfigurationException {
		FileConfiguration config = null;
		
		if(masterConfiguration.containsKey(serviceName)){
			config = masterConfiguration.get(serviceName);
		}else{
			config = (FileConfiguration) loadExternalConfiguration(PROPERTIES_CONFIG_CLASS, rootPath + MASTER_DATA_CONFIG);
			masterConfiguration.put(serviceName, config);
		}
		if (config == null){
			throw new ExternalConfigurationException("ExternalConfigurationException: Master configuration data source not found at : " + rootPath);
		}

		this.configTypeClassName = config.getString(configFileClass);
		this.configFileName = config.getString(filePath);
		this.reloadflag = config.getString("reloadflag");
		this.archiveAccessFlag = config.getString("archiveAccessFlag");
		
		if (configTypeClassName == null || configFileName == null || reloadflag == null || archiveAccessFlag == null) {
			throw new ExternalConfigurationException("one of the configuration data among [configTypeClassName,configFileName,reloadflag,archiveAccessFlag] is not valid, Please check");
		}
		logger.debug("Master configuration data is loaded successfully");
	}

	/**
	 * Creates the appropriate configuration object with the help of external
	 * configuration data and returns the loaded object.
	 * 
	 * @param className
	 * @param path
	 * @return Object which represent apache commons Configuration Object.
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private Object loadExternalConfiguration(String className, String path) {
		try {
			Class[] parmTypes = { String.class };
			Class classDefinition = Class.forName(className);
			Constructor constructor = null;
			try {
				constructor = classDefinition.getConstructor(parmTypes);
			} catch (NoSuchMethodException ex) {
			} catch (SecurityException ex) {
			}
			Object[] parms = { path };
			try {
				this.configObject = constructor.newInstance(parms);
			} catch (InstantiationException ex) {
			} catch (IllegalAccessException ex) {
			} catch (IllegalArgumentException ex) {
			} catch (InvocationTargetException ex) {
			}

		} catch (ClassNotFoundException e) {
		}
		return configObject;
	}

	/**
	 * Loads configuration root path from system environment using
	 * SERVER_CONFIG_ROOT environment variable.
	 * 
	 * @return String
	 */
	private String loadSystemProperty() {
		String configRootPath = null;
		configRootPath = System.getProperty(SERVER_CONFIG_ROOT);
		return configRootPath;
	}

	/**
	 * Fetches List of all configuration data from a xml file based on input
	 * key.
	 * 
	 * @param nodeName
	 * @return ArrayList.
	 */
	@SuppressWarnings("rawtypes")
	public ArrayList getXmlDataAll(String nodeName) {
		ConfigurationNode node;
		ArrayList xmlList = null;
		try {
			node = getXmlConfiguration(nodeName);
			xmlList = extractXmlTwoLevelData(node);
		} catch (ExternalConfigurationException ece) {
			// logger.error(ece) ;
		}
		return xmlList;
	}

	/**
	 * Fetches List of configuration data from a xml source at element level
	 * based on input parameter.
	 * 
	 * @param nodeName
	 * @param params
	 * @return ArrayList.
	 */
	@SuppressWarnings("rawtypes")
	public ArrayList getXmlQueryData(String nodeName, HashMap params) {

		ConfigurationNode node;
		ArrayList xmlList = null;
		try {
			node = getXmlConfiguration(nodeName);
			xmlList = extractXmlQueuryData(node, params);
		} catch (ExternalConfigurationException ece) {
			// logger.error(ece) ;
		}
		return xmlList;
	}

	/**
	 * Returns ConfigurationNode object of configuration type XMLConfiguration.
	 * 
	 * @param NodeName
	 *            .
	 * @return ConfigurationNode.
	 * @throws ExternalConfigurationException.
	 */
	@SuppressWarnings("rawtypes")
	private ConfigurationNode getXmlConfiguration(String NodeName)
			throws ExternalConfigurationException {
		String currentNodeName;
		ConfigurationNode fnode = null;

		XMLConfiguration xmlcongig = (XMLConfiguration) configObject;
		
		/**
		 * The following line will reload the file automatically.
		 */
		xmlcongig.getString("reload");
		fnode = xmlcongig.getRootNode();
		currentNodeName = fnode.getName();
		if (currentNodeName != null && currentNodeName.equals(NodeName)) {
			return fnode;
		}

		List flist = fnode.getChildren(NodeName);
		if (flist == null || flist.size() <= 0) {
			logger.error("Node : " + NodeName
					+ " is missing in the Configuration source");
			throw new ExternalConfigurationException("Node : " + NodeName
					+ " is missing in the Configuration source");

		}
		try {
			Iterator fiter = flist.iterator();
			while (fiter.hasNext()) {
				ConfigurationNode snode = (ConfigurationNode) fiter.next();
				currentNodeName = snode.getName();
				if (currentNodeName != null && currentNodeName.equals(NodeName)) {
					return snode;
				}
				List slist = snode.getChildren();
				Iterator siter = slist.iterator();
				while (siter.hasNext()) {
					ConfigurationNode ccnode = (ConfigurationNode) siter.next();
					currentNodeName = ccnode.getName();
					if (currentNodeName != null
							&& currentNodeName.equals(NodeName)) {
						return ccnode;
					}
				}
			}
		} catch (Exception exception) {
			logger.error("Exception thrown while fetching the data with node "
					+ NodeName);
			throw new ExternalConfigurationException(
					"Exception thrown while fetching the data with node "
							+ NodeName);
		}
		return fnode;

	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	ArrayList extractXmlTwoLevelData(ConfigurationNode fnode) {
		ArrayList finaldata = new ArrayList();

		List flist = fnode.getChildren();
		Iterator fiter = flist.iterator();
		while (fiter.hasNext()) {
			ConfigurationNode snode = (ConfigurationNode) fiter.next();
			List slist = snode.getChildren();
			Iterator siter = slist.iterator();
			HashMap mapdata = new HashMap();
			while (siter.hasNext()) {

				ConfigurationNode ccnode = (ConfigurationNode) siter.next();
				if (ccnode != null) {
					mapdata.put(ccnode.getName(), ccnode.getValue());

				}

			}
			finaldata.add(mapdata);

		}

		return finaldata;
	}

	/**
	 * Helps to extract hierarchical configuration data from xml file.
	 * 
	 * @param fnode
	 * @param params
	 * @return ArrayList
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private ArrayList extractXmlQueuryData(ConfigurationNode fnode,
			HashMap params) {
		ArrayList finaldata = new ArrayList();
		int paramSize = params.size();
		List flist = fnode.getChildren();
		Iterator fiter = flist.iterator();

		while (fiter.hasNext()) {
			int count = 0;
			ConfigurationNode snode = (ConfigurationNode) fiter.next();
			List slist = snode.getChildren();
			Iterator siter = slist.iterator();
			HashMap mapdata = new HashMap();
			while (siter.hasNext()) {

				ConfigurationNode ccnode = (ConfigurationNode) siter.next();
				if (ccnode != null) {
					mapdata.put(ccnode.getName(), ccnode.getValue());

					if (params.containsKey(ccnode.getName())
							&& params.get(ccnode.getName()).equals(
									ccnode.getValue())) {
						count++;
					}

				}

			}
			if (count == paramSize)
				finaldata.add(mapdata);

		}

		return finaldata;
	}

	/**
	 * This method returns exact hierarchical XML structure from XML file inside a Map.
	 * 
	 * @param nodeName - root node name.
	 * @return Map - XML structure.
	 */
	@SuppressWarnings("rawtypes")
	public Map getXmlDataStructure(String nodeName) {
		ConfigurationNode node;
		Map<String, Object> rntValue = null;
		try {
			node = getXmlConfiguration(nodeName);
			rntValue = buildXMLDataStructure(node);
		} catch (ExternalConfigurationException ece) {
			// logger.error(ece) ;
		}
		return rntValue;
	}
	

	/**
	 * This method will create a hierarchical Structure from ConfigurationNode object.
	 *  
	 * @param configNode - Root's ConfigurationNode object.
	 * @return Map - XML structure.
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private Map<String, Object> buildXMLDataStructure(ConfigurationNode configNode) {
		
		/**
		 * This variable holds complete children node as a list. 
		 */
		List childrenList = configNode.getChildren();
	
		Map<String, Object> childrenMapInfo = new HashMap<String, Object>();
		
		if(childrenList != null){
		
			Iterator childrenNodeIte = childrenList.iterator();
			
			while (childrenNodeIte.hasNext()) {
				ConfigurationNode childrenNodeItem = (ConfigurationNode) childrenNodeIte.next();
				
				/**
				 * Following lines will check whether childrenNodeItem is holding any complex element or not.
				 * childrenNodeItem.getChildren().size() > 0 = true, means tag is having complex element.
				 * In case of complex element, recursively it will call "buildXMLDataStructure()"  
				 */
				if(childrenNodeItem.getChildren().size() > 0){
					List<Map> childrenNodeList = (List<Map>) childrenMapInfo.get(childrenNodeItem.getName());
					if(childrenNodeList == null ){
						childrenNodeList = new ArrayList<Map>();
						childrenMapInfo.put(childrenNodeItem.getName(), childrenNodeList);
					}
					childrenNodeList.add(buildXMLDataStructure(childrenNodeItem));
				}
				/**
				 * Following lines will check whether childrenNodeItem is holding any attribute or not.
				 * childrenNodeItem.getAttributes().size() > 0 = true, means tag is having attribute.
				 * The following lines of code will execute for simple type tag with attribute.   
				 */
				else if(childrenNodeItem.getAttributes().size() > 0){
					Map<String, String> attribute = getAttributes(childrenNodeItem);
					
					if( childrenNodeItem.getValue() != null){
						attribute.put(childrenNodeItem.getName(), childrenNodeItem.getValue().toString());
					}
					
					updateStructureMap(childrenMapInfo, childrenNodeItem.getName(), attribute);
				}
				else{
					updateStructureMap(childrenMapInfo, childrenNodeItem.getName(), childrenNodeItem.getValue());
				}
			}
		}
		
		/**
		 * The following variable holds the attribute information for a complex object. 
		 */
		childrenMapInfo.putAll(getAttributes(configNode));

		return childrenMapInfo;
	}

	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void updateStructureMap(Map nodeValueMap, String keyName, Object value){
		
		/**
		 * The following lines will check whether nodeValueMap is already holding this key or not.
		 */
		if(nodeValueMap.containsKey(keyName)){
			/**
			 * containValue variable is defined to check what kind of data type is placed inside nodeValueMap.
			 */
			Object containValue = nodeValueMap.get(keyName);

			/**
			 * If data type = List, it will add the element inside list,
			 * other wise it will create a list and update the nodeValueMap with list value.
			 */
			if (containValue instanceof List){
				((List)containValue).add(value);
			}else{
				List list = new ArrayList();
				list.add(containValue);
				list.add(value);
				nodeValueMap.put(keyName, list);
			}
		}else{
			nodeValueMap.put(keyName, value);
		}
	}
	
	/**
	 * This method will create a Map object for attribute.
	 * @param configNode - ConfigurationNode object of current Node.
	 * @return Map - Contains the attribute value.
	 */
	@SuppressWarnings("rawtypes")
	private Map<String, String> getAttributes(ConfigurationNode configNode){
		Map<String, String> attributeValueMap = new HashMap<String, String>();
		
		List attributesList = configNode.getAttributes();
		if(attributesList != null && attributesList.size() > 0){
			Iterator attributesIte = attributesList.iterator();
			while (attributesIte.hasNext()) {
				ConfigurationNode attributesNode = (ConfigurationNode)attributesIte.next();
				attributeValueMap.put(attributesNode.getName(), attributesNode.getValue().toString());
			}
		}
		return attributeValueMap;
	}

}
