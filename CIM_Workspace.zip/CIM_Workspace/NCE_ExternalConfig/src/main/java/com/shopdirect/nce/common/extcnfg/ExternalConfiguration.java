package com.shopdirect.nce.common.extcnfg;

import java.util.List;

/**
 * @author msomanat@in.ibm.com
 *
 */
public interface ExternalConfiguration {
	String getConfigData(String propertyName);
	List<String> getConfigDataList(String propertyName);
}
