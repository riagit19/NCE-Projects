package com.shopdirect.nce.common.extcnfg;

/**
 * @author msomanat@in.ibm.com
 * Custom Exception class for external common configuration data.
 */
public class ExternalConfigurationException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3790622375464284650L;

	public ExternalConfigurationException() {
		super();
		}

	public ExternalConfigurationException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public ExternalConfigurationException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public ExternalConfigurationException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
