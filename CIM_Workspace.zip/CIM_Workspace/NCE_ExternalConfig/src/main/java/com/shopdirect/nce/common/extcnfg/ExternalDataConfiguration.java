package com.shopdirect.nce.common.extcnfg;

import java.util.List;

//import org.apache.commons.configuration.Configuration;
//import org.apache.commons.configuration.FileConfiguration;

public class ExternalDataConfiguration 
		implements ExternalConfiguration {

	public void ExternalDataConfiguration() {

	}

	public String getConfigData(String propertyName) {
		
		return null;

	}

	public List<String> getConfigDataList(String propertyName) {
		
		return null;
	}
}
