package com.shopdirect.nce.common.extcnfg;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.shopdirect.nce.common.extcnfg.ExternalFileDataConfiguration;

public class Test {
	 public static void main(String[] args) throws Exception {
			
		   
		  String rootPath=getMasterConfigFileWithPath("SBB\\"); 
		// Property type configuration
		 /* try{
			   ExternalFileDataConfiguration fileDataConfiguration=new ExternalFileDataConfiguration("SBB","configClassName","configFile");
			   System.out.println("property  data :  "+fileDataConfiguration.getConfigData("4001"));
			   System.out.println("property  data list :   "+fileDataConfiguration.getConfigDataList("db.type"));
		  }catch(ExternalConfigurationException e){
			  
		  }*/
	   // xml type configuration   
			   ExternalFileDataConfiguration config=new ExternalFileDataConfiguration("SBB","xmlconfigClassName","xmlconfigFile");
			   ArrayList listAll=config.getXmlDataAll("TD_PRODUCT_LKUP_DETAILS");
			   HashMap map=new HashMap();
			   map.put("PRODUCT_SUBTYPE_CODE","A");
			   map.put("SECURITY_TYPE_CODE", "");
			   map.put("MIN_BREAK","40");
			   ArrayList list=config.getXmlQueryData("TD_PRODUCT_LKUP_DETAILS",map);
			  /* System.out.println("xml data tables.table.fields.field.name:   "+config.getConfigData("tables.table(0).fields.field(2).name"));
			   System.out.println("xml data @database:  "+config.getConfigData("tables.table(0).fields.field(1).name[@database]"));
			   System.out.println("xml data list:  "+config.getConfigDataList("tables.table(0).fields.field(0).type"));*/
	
			   
	 
	 }
		  



static String getMasterConfigFileWithPath(String rootPath){
	return rootPath+"MasterDataConfig.properties";
}




}






class UseDefinedException extends Exception{
	   String msg = "";
	  int marks;
	   public UseDefinedException() {

	 }
	   public UseDefinedException(String str){
	   super(str);
	 }
	  public String toString(){
	   if (marks <= 50)
	   msg = "You have failed";   

	  if (marks > 50) 

	   msg = "You have Passed"; 
	   return msg;
	}
	}
	  
	 
	 










