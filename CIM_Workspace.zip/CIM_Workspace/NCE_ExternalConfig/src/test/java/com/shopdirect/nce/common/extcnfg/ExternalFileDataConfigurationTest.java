package com.shopdirect.nce.common.extcnfg;

import java.util.List;
import java.util.Map;

import com.shopdirect.nce.common.extcnfg.ExternalConfigurationException;
import com.shopdirect.nce.common.extcnfg.ExternalFileDataConfiguration;

import junit.framework.TestCase;


/**
 * This is a test class which contains the Junit test case.
 * @author Palash S Roy
 *
 */
public class ExternalFileDataConfigurationTest extends TestCase {

	public static String CURRENT_WORKING_PATH = (System.getProperty("user.dir")+"\\src\\test\\java\\com\\shopdirect\\nce\\common\\extcnfg"+"\\")
												.replaceAll("\\\\", "/");
	
	static{
		System.setProperty("SERVER_CONFIG_ROOT", CURRENT_WORKING_PATH);
	}

	private String SERVICE_NAME = "input";
	private String CONFIG_CLASS_KEY_NAME = "xmlConfigClassName";
	
	@Override
	protected void setUp() throws Exception {
		super.setUp();
	}
	
	public void testXMLStrutureMap_1(){
		try {
			ExternalFileDataConfiguration fileDataConfiguration = new ExternalFileDataConfiguration(SERVICE_NAME, CONFIG_CLASS_KEY_NAME, "packetConfig");
			Object rntValue = fileDataConfiguration.getXmlDataStructure("TSYSPacketLoggingConfig");
			assertEquals(true, (rntValue instanceof Map));
			
			Object expression = ((Map)rntValue).get("Expression");
			assertNotNull(expression);
			assertEquals(true, (expression instanceof List));
			assertEquals(2, ((List)expression).size());

			Object packet = ((Map)rntValue).get("Packet");
			assertNotNull(packet);
			assertEquals(true, (packet instanceof List));
			assertEquals(2, ((List)packet).size());

		} catch (ExternalConfigurationException e) {
			e.printStackTrace();
		}
		
	}	
	
	public void testXMLStrutureMap_2(){
		try {
			ExternalFileDataConfiguration fileDataConfiguration = new ExternalFileDataConfiguration(SERVICE_NAME, CONFIG_CLASS_KEY_NAME, "errorMessages");
			Object rntValue = fileDataConfiguration.getXmlDataStructure("ERROR_MESSAGES");
			assertEquals(true, (rntValue instanceof Map));
			assertEquals(true, ((Map)rntValue).containsKey("ERROR_MESSAGE"));
			
			List ERROR_MESSAGE = (List) ((Map)rntValue).get("ERROR_MESSAGE");
			assertEquals(3, ERROR_MESSAGE.size());
			
		} catch (ExternalConfigurationException e) {
			e.printStackTrace();
		}
	}	

}
