/**
 * 
 */
package com.shopdirect.nce.logger.log4j2;

import static org.junit.Assert.*;

import java.io.File;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.spi.LoggerContext;
import org.junit.Test;

/**
 * @author ibm
 *
 */
public class SDLoggerImplTest {

	
	/**
	 * Test method for {@link com.shopdirect.nce.logger.log4j2.SDLoggerImpl#debug(java.lang.String, java.lang.String, java.lang.String)}.
	 */
	@Test
	public void testDebugStringStringString() {

	    LoggerContext context = (org.apache.logging.log4j.core.LoggerContext) LogManager.getContext(false);
	    File file = new File("/resources/log4j2.xml");
	    ((org.apache.logging.log4j.core.LoggerContext) context).setConfigLocation(file.toURI());
        SDLoggerImpl sdLoggerImpl = new SDLoggerImpl();
        sdLoggerImpl.debug("This is a debug message");
		//fail("Not yet implemented");
	}

	/**
	 * Test method for {@link com.shopdirect.nce.logger.log4j2.SDLoggerImpl#entry(java.lang.String, java.lang.String)}.
	 */
	@Test
	public void testEntry() {
	    LoggerContext context = (org.apache.logging.log4j.core.LoggerContext) LogManager.getContext(false);
	    File file = new File("/resources/log4j2.xml");
	    ((org.apache.logging.log4j.core.LoggerContext) context).setConfigLocation(file.toURI());
        SDLoggerImpl sdLoggerImpl = new SDLoggerImpl();
        sdLoggerImpl.entry(SDLoggerImplTest.class.getName() , null);
	}

	/**
	 * Test method for {@link com.shopdirect.nce.logger.log4j2.SDLoggerImpl#info(java.lang.String, java.lang.String, java.lang.String)}.
	 */
	@Test
	public void testInfo() {
	    LoggerContext context = (org.apache.logging.log4j.core.LoggerContext) LogManager.getContext(false);
	    File file = new File("/resources/log4j.xml");
	    ((org.apache.logging.log4j.core.LoggerContext) context).setConfigLocation(file.toURI());
        SDLoggerImpl sdLoggerImpl = new SDLoggerImpl();
        sdLoggerImpl.info( SDLoggerImplTest.class.getName(), null,"AUDIT INFO:");		
		//fail("Not yet implemented");
	}

	/**
	 * Test method for {@link com.shopdirect.nce.logger.log4j2.SDLoggerImpl#warning(java.lang.String, java.lang.String, java.lang.String)}.
	 */
	@Test
	public void testWarning() {
	    LoggerContext context = (org.apache.logging.log4j.core.LoggerContext) LogManager.getContext(false);
	    File file = new File("/resources/log4j.xml");
	    ((org.apache.logging.log4j.core.LoggerContext) context).setConfigLocation(file.toURI());
        SDLoggerImpl sdLoggerImpl = new SDLoggerImpl();
        sdLoggerImpl.info( SDLoggerImplTest.class.getName(), null,"WARNING msg:");	
	}
	
	/**
	 * Test method for {@link com.shopdirect.nce.logger.log4j2.SDLoggerImpl#error(java.lang.String, java.lang.String, java.lang.String)}.
	 */
	@Test
	public void testErrorString() {
	    LoggerContext context = (org.apache.logging.log4j.core.LoggerContext) LogManager.getContext(false);
	    File file = new File("/resources/log4j.xml");
	    ((org.apache.logging.log4j.core.LoggerContext) context).setConfigLocation(file.toURI());
        SDLoggerImpl sdLoggerImpl = new SDLoggerImpl();
        sdLoggerImpl.error( null, null,"ERROR msg:");	
	}	

	/**
	 * Test method for {@link com.shopdirect.nce.logger.log4j2.SDLoggerImpl#error(java.lang.String)}.
	 */
	@Test
	public void testError() {
	    LoggerContext context = (org.apache.logging.log4j.core.LoggerContext) LogManager.getContext(false);
	    File file = new File("/resources/log4j.xml");
	    ((org.apache.logging.log4j.core.LoggerContext) context).setConfigLocation(file.toURI());
        SDLoggerImpl sdLoggerImpl = new SDLoggerImpl();
        sdLoggerImpl.error("ERROR XXXXXX");		
		//fail("Not yet implemented");
	}

	/**
	 * Test method for {@link com.shopdirect.nce.logger.log4j2.SDLoggerImpl#debug(java.lang.String)}.
	 */
	@Test
	public void testDebugString() {
	    LoggerContext context = (org.apache.logging.log4j.core.LoggerContext) LogManager.getContext(false);
	    File file = new File("/resources/log4j.xml");
	    ((org.apache.logging.log4j.core.LoggerContext) context).setConfigLocation(file.toURI());
        SDLoggerImpl sdLoggerImpl = new SDLoggerImpl();
        sdLoggerImpl.debug("This is a debug message");		
		//fail("Not yet implemented");
	}

	/**
	 * Test method for {@link com.shopdirect.nce.logger.log4j2.SDLoggerImpl#trace(java.lang.String)}.
	 */
	@Test
	public void testentry() {
	    LoggerContext context = (org.apache.logging.log4j.core.LoggerContext) LogManager.getContext(false);
	    File file = new File("/resources/log4j.xml");
	    ((org.apache.logging.log4j.core.LoggerContext) context).setConfigLocation(file.toURI());
        SDLoggerImpl sdLoggerImpl = new SDLoggerImpl();
        sdLoggerImpl.entry("This is a trace message");	
	}

	/**
	 * Test method for {@link com.shopdirect.nce.logger.log4j2.SDLoggerImpl#warn(java.lang.String)}.
	 */
	@Test
	public void testDebusString() {
	    LoggerContext context = (org.apache.logging.log4j.core.LoggerContext) LogManager.getContext(false);
	    File file = new File("/resources/log4j.xml");
	    ((org.apache.logging.log4j.core.LoggerContext) context).setConfigLocation(file.toURI());
        SDLoggerImpl sdLoggerImpl = new SDLoggerImpl();
        sdLoggerImpl.debug("This is a warning message");
		//fail("Not yet implemented");
	}

}
