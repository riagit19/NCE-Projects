package com.shopdirect.nce.logger.log4j2;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public interface SDLogger {
	Logger logger = LogManager.getLogger(); 
	public void debug (String className, String methodName, String message);
	public void entry (String className, String methodName);
	public void info (String className, String methodName, String message);
	public void warning (String className, String methodName, String message);
	public void error (String className, String methodName, String message);
	public void error (String message);
	public void debug (String message);
	public void entry (String message);
	public void warn (String message);
	public void info (String message);
	public void perf (String message);

}
