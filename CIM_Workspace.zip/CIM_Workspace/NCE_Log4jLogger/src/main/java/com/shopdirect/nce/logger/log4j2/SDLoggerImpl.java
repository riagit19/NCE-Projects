package com.shopdirect.nce.logger.log4j2;

import org.apache.logging.log4j.Logger;

public class SDLoggerImpl {

	
	private final String COLON = " : ";
	
	Logger logger = SDLogger.logger;
	
	public void debug (String className, String methodName, String message)
	{
		StringBuffer strBuffer = new StringBuffer ();
		
		if (className != null) 
			strBuffer.append (className).append (COLON);
		
		if (methodName != null) 
			strBuffer.append (methodName).append (COLON);
		
		if (message != null) 
			strBuffer.append (message);
		
		logger.debug (strBuffer.toString ());
		
	}


	public void entry (String className, String methodName)
	{
		StringBuffer strBuffer = new StringBuffer (" ENTRY : ");
		
		if (className != null) 
			strBuffer.append (className).append (COLON);
		
		if (methodName != null) 
			strBuffer.append (methodName).append (COLON);
				
		strBuffer.append (System.currentTimeMillis ());
		
		logger.entry(strBuffer.toString ());
	}


	public void info (String className, String methodName, String message)
	{
		StringBuffer strBuffer = new StringBuffer ();
		
		if (className != null) 
			strBuffer.append (className).append (COLON);
		
		if (methodName != null) 
			strBuffer.append (methodName).append (COLON);
		
		if (message != null) 
			strBuffer.append (message);
		
		logger.info (strBuffer.toString ());
	}

	public void warning (String className, String methodName, String message)
	{
		StringBuffer strBuffer = new StringBuffer ();
		
		if (className != null) 
			strBuffer.append (className).append (COLON);
		
		if (methodName != null) 
			strBuffer.append (methodName).append (COLON);
		
		if (message != null) 
			strBuffer.append (message);
		
		logger.warn (strBuffer.toString ());
	}
	
	public void error (String className, String methodName, String message)
	{
		StringBuffer strBuffer = new StringBuffer ();
		
		if (className != null) 
			strBuffer.append (className).append (COLON);
		
		if (methodName != null) 
			strBuffer.append (methodName).append (COLON);
		
		if (message != null) 
			strBuffer.append (message);
		
		logger.error (strBuffer.toString ());
	}	

	public void error (String message)
	{
		logger.error (message);
	}
		

	public void debug (String message)
	{		
		logger.debug (message);
	}
	

	public void entry (String message)
	{		
		logger.entry (message);
	}
		
	/* (non-Javadoc)
	 * @see com.damco.sp.framework.logger.SPLogger#warn(java.lang.String)
	 */
	public void warn (String message)
	{
		logger.warn (message);
	}
	
	/* (non-Javadoc)
	 * @see com.damco.sp.framework.logger.SPLogger#info(java.lang.String)
	 */
	public void info (String message)
	{
		logger.info (message);
	}
	
	/* (non-Javadoc)
	 * @see com.damco.sp.framework.logger.SPLogger#perf(java.lang.String)
	 */
	public void perf (String message)
	{
		logger.trace(message);
	}	
	
}
